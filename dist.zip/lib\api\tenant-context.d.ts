import type { Request } from "express";
import type { Permission } from "../permissions";
import type { TenantContext } from "../../server/types/context";
export type ApiErrorBody = {
    status: number;
    body: Record<string, unknown>;
};
export declare function resolveTenantContext(req: Request): Promise<TenantContext | null>;
export declare function requireTenantContext(req: Request): Promise<{
    error: null;
    ctx: TenantContext;
} | {
    error: {
        status: number;
        body: {
            error: string;
        };
    };
    ctx: null;
}>;
export declare function requireTenantPermission(req: Request, permission: Permission): Promise<{
    error: null;
    ctx: TenantContext;
} | {
    error: {
        status: number;
        body: {
            error: string;
        };
    };
    ctx: null;
}>;
export declare function requireTenantPermissions(req: Request, permissions: Permission[], mode?: "any" | "all"): Promise<{
    error: null;
    ctx: TenantContext;
} | {
    error: {
        status: number;
        body: {
            error: string;
        };
    };
    ctx: null;
}>;
export declare function assertTenantPermission(ctx: TenantContext, permission: Permission): void;
