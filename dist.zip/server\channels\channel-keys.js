"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.channelKeys = exports.DISPATCH_LOCK_TTL_SECONDS = exports.CHANNEL_QUEUE_POLL_MS = exports.CHANNEL_COOLDOWN_MS = void 0;
exports.getChannelCooldownMs = getChannelCooldownMs;
exports.getChannelQueuePollMs = getChannelQueuePollMs;
exports.getChannelReconcilePollMs = getChannelReconcilePollMs;
exports.getStaleQueuedAtProviderMs = getStaleQueuedAtProviderMs;
function getChannelCooldownMs() {
    return Number(process.env.CHANNEL_COOLDOWN_MS ?? 5_000);
}
function getChannelQueuePollMs() {
    return Number(process.env.CHANNEL_QUEUE_POLL_MS ?? 1_000);
}
function getChannelReconcilePollMs() {
    const parsed = Number(process.env.CHANNEL_RECONCILE_POLL_MS ?? 30_000);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : 30_000;
}
function getStaleQueuedAtProviderMs() {
    const parsed = Number(process.env.CHANNEL_STALE_QUEUED_AT_PROVIDER_MS ?? 2 * 60 * 1000);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : 2 * 60 * 1000;
}
exports.CHANNEL_COOLDOWN_MS = getChannelCooldownMs();
exports.CHANNEL_QUEUE_POLL_MS = getChannelQueuePollMs();
exports.DISPATCH_LOCK_TTL_SECONDS = 60;
exports.channelKeys = {
    channels: (companyId) => `company:${companyId}:channels`,
    queue: (companyId) => `company:${companyId}:queue`,
    queueDedup: (companyId) => `company:${companyId}:queue:dedup`,
    cooldown: (companyId) => `company:${companyId}:cooldown`,
    dispatchLock: (callLogId) => `call:dispatch-lock:${callLogId}`,
    companyPrefix: (companyId) => `company:${companyId}:*`,
};
//# sourceMappingURL=channel-keys.js.map