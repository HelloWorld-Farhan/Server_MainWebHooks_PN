export declare class RetryWorkerService {
    processDueRetries(limit?: number): Promise<number>;
    private processJob;
    private skipJob;
}
export declare const retryWorkerService: RetryWorkerService;
