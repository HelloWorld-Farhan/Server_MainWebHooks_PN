import type { PrismaClient } from "@prisma/client";
import { PublicResourceType } from "./public-id/types";
type TransactionClient = Omit<PrismaClient, "$connect" | "$disconnect" | "$on" | "$transaction" | "$use" | "$extends">;
export declare function allocateResourceKey(tx: TransactionClient, companyId: string, resourceType: PublicResourceType): Promise<string>;
export declare function allocateResourceKeys(tx: TransactionClient, companyId: string, resourceType: PublicResourceType, count: number): Promise<string[]>;
export declare function allocateResourceKeyWithPrisma(prisma: PrismaClient, companyId: string, resourceType: PublicResourceType): Promise<string>;
export type ResourceKeyCreateData<T> = T & {
    resourceKey: string;
};
export declare function withAllocatedResourceKey<T extends Record<string, unknown>>(data: T, resourceKey: string): ResourceKeyCreateData<T>;
export {};
