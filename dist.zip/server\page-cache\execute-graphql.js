"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.executeGraphQLFromRequest = executeGraphQLFromRequest;
const yoga_1 = require("../graphql/yoga");
async function executeGraphQLFromRequest(request, query, variables) {
    const url = new URL("/graphql", request.url);
    const cookie = request.headers.get("cookie");
    const response = await yoga_1.yoga.fetch(new Request(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            ...(cookie ? { cookie } : {}),
        },
        body: JSON.stringify({ query, variables }),
    }), {});
    if (!response.ok) {
        throw new Error(`GraphQL request failed with status ${response.status}`);
    }
    const json = (await response.json());
    if (json.errors?.length) {
        throw new Error(json.errors[0]?.message ?? "GraphQL error");
    }
    if (!json.data) {
        throw new Error("GraphQL response missing data");
    }
    return json.data;
}
//# sourceMappingURL=execute-graphql.js.map