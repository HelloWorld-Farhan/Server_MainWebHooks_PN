"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApiModule = void 0;
const common_1 = require("@nestjs/common");
const api_controllers_1 = require("./api.controllers");
const billing_controller_1 = require("../billing/billing.controller");
const calls_controller_1 = require("../calls/calls.controller");
const campaign_execution_controller_1 = require("../calls/campaign-execution.controller");
const campaign_execution_controller_2 = require("../campaigns/campaign-execution.controller");
const company_controller_1 = require("../company/company.controller");
const sub_company_controller_1 = require("../company/sub-company.controller");
const graphql_module_1 = require("../graphql/graphql.module");
const integrations_controller_1 = require("../integrations/integrations.controller");
const channels_internal_controller_1 = require("../internal/channels-internal.controller");
const internal_controller_1 = require("../internal/internal.controller");
const invitations_controller_1 = require("../invitations/invitations.controller");
const obd_controller_1 = require("../obd/obd.controller");
const bonvoice_controller_1 = require("../obd/bonvoice.controller");
const page_cache_controller_1 = require("../page-cache/page-cache.controller");
const telephony_controller_1 = require("../telephony/telephony.controller");
const webhooks_controller_1 = require("../webhooks/webhooks.controller");
const inbound_webhooks_controller_1 = require("../webhooks/inbound-webhooks.controller");
const users_controller_1 = require("../users/users.controller");
let ApiModule = class ApiModule {
};
exports.ApiModule = ApiModule;
exports.ApiModule = ApiModule = __decorate([
    (0, common_1.Module)({
        imports: [graphql_module_1.GraphQLModule],
        controllers: [
            company_controller_1.CompanyController,
            sub_company_controller_1.SubCompaniesController,
            company_controller_1.ContactRequestsController,
            billing_controller_1.BillingController,
            telephony_controller_1.TelephonyController,
            obd_controller_1.ObdController,
            bonvoice_controller_1.BonvoiceController,
            webhooks_controller_1.WebhooksController,
            inbound_webhooks_controller_1.InboundWebhooksController,
            users_controller_1.UsersController,
            internal_controller_1.InternalController,
            channels_internal_controller_1.ChannelsInternalController,
            integrations_controller_1.IntegrationsController,
            invitations_controller_1.InvitationsController,
            api_controllers_1.AgentsController,
            api_controllers_1.ToolsController,
            api_controllers_1.ContactPhonesController,
            page_cache_controller_1.PageCacheController,
            calls_controller_1.CallsController,
            campaign_execution_controller_1.OutboundCampaignExecutionController,
            campaign_execution_controller_2.CampaignExecutionController,
        ],
    })
], ApiModule);
//# sourceMappingURL=api.module.js.map