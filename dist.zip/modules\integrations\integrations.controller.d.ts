import type { Request, Response } from "express";
export declare class IntegrationsController {
    list(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    oauthStart(req: Request, res: Response): Promise<void | Response<any, Record<string, any>>>;
    oauthCallback(req: Request, res: Response): Promise<void>;
    googleConnect(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    sheetsConfig(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    listSpreadsheets(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    createSpreadsheet(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    createSpreadsheetAlias(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    deleteSpreadsheet(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    worksheets(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    headers(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    sheetsSync(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    syncHistory(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    calendarConfig(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    calendars(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    getById(req: Request, res: Response, id: string): Promise<Response<any, Record<string, any>> | undefined>;
    connect(req: Request, res: Response, id: string): Promise<Response<any, Record<string, any>> | undefined>;
    disconnect(req: Request, res: Response, id: string): Promise<Response<any, Record<string, any>> | undefined>;
}
