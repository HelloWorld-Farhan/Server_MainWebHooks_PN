"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPageLoader = getPageLoader;
exports.isValidPageCacheKey = isValidPageCacheKey;
const loaders_1 = require("./loaders");
const PAGE_LOADERS = {
    home: loaders_1.loadHomePage,
    billing: loaders_1.loadBillingPage,
    "call-logs": loaders_1.loadCallLogsPage,
    "call-detail": loaders_1.loadCallDetailPage,
    agents: loaders_1.loadAgentsPage,
    "agent-detail": loaders_1.loadAgentDetailPage,
    "agent-library": loaders_1.loadAgentLibraryPage,
    "agent-template": loaders_1.loadAgentTemplatePage,
    "lead-reactivation": loaders_1.loadLeadReactivationPage,
    setup: loaders_1.loadSetupPage,
    settings: loaders_1.loadSettingsPage,
    "phone-detail": loaders_1.loadPhoneDetailPage,
    "phone-contacts": loaders_1.loadPhoneContactsPage,
};
function getPageLoader(pageKey) {
    return PAGE_LOADERS[pageKey] ?? null;
}
function isValidPageCacheKey(pageKey) {
    return pageKey in PAGE_LOADERS;
}
//# sourceMappingURL=registry.js.map