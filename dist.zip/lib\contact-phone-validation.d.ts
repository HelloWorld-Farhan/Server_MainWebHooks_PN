export declare function normalizeContactPhone(raw: string): string | null;
export declare function isValidContactPhone(value: string): boolean;
export declare function normalizeStoredContactPhone(raw: string): string | null;
export declare function isValidStoredContactPhone(value: string): boolean;
