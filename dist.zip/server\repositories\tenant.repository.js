"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TenantRepository = void 0;
const client_1 = require("@prisma/client");
const base_repository_1 = require("./base.repository");
const cli_1 = require("../lib/cli");
const company_code_1 = require("../lib/company-code");
const contract_id_1 = require("../lib/contract-id");
class TenantRepository extends base_repository_1.BaseRepository {
    findCompanyByClerkOrgId(clerkOrganizationId) {
        return this.prisma.company.findFirst({
            where: { clerkOrganizationId },
        });
    }
    findCompanyById(companyId) {
        return this.prisma.company.findUnique({
            where: { id: companyId },
        });
    }
    findCompanyByContractId(contractId) {
        return this.prisma.company.findFirst({
            where: { contractId },
        });
    }
    findCompanyByOwnerUserId(ownerUserId) {
        return this.prisma.company.findFirst({
            where: { ownerUserId },
        });
    }
    findUserByClerkId(clerkUserId) {
        return this.prisma.user.findUnique({
            where: { clerkUserId },
        });
    }
    findUserByEmail(email) {
        return this.prisma.user.findFirst({
            where: { email: { equals: email, mode: "insensitive" } },
        });
    }
    findMembership(companyId, userId) {
        return this.prisma.companyMember.findUnique({
            where: {
                companyId_userId: { companyId, userId },
            },
            include: {
                customRole: true,
                user: true,
                company: true,
                campaignAccess: true,
            },
        });
    }
    upsertUser(data) {
        return this.prisma.user.upsert({
            where: { clerkUserId: data.clerkUserId },
            create: {
                clerkUserId: data.clerkUserId,
                email: data.email,
                firstName: data.firstName,
                lastName: data.lastName,
                imageUrl: data.imageUrl,
                phone: data.phone,
            },
            update: {
                email: data.email,
                firstName: data.firstName,
                lastName: data.lastName,
                imageUrl: data.imageUrl,
                phone: data.phone,
            },
        });
    }
    async upsertCompany(data) {
        const updateData = {
            name: data.name,
            ...(data.primaryUseCase !== undefined
                ? { primaryUseCase: data.primaryUseCase }
                : {}),
            ...(data.callVolume !== undefined ? { callVolume: data.callVolume } : {}),
        };
        const existing = await this.findCompanyByClerkOrgId(data.clerkOrganizationId);
        if (existing) {
            const legacyIds = !existing.cli || !existing.companyCode
                ? {
                    ...(existing.cli ? {} : { cli: await (0, cli_1.generateUniqueCliFromSlug)(this.prisma, data.slug) }),
                    ...(existing.companyCode
                        ? {}
                        : { companyCode: await (0, company_code_1.generateUniqueCompanyCode)(this.prisma) }),
                }
                : {};
            return this.prisma.company.update({
                where: { id: existing.id },
                data: { ...updateData, ...legacyIds },
            });
        }
        const contractId = await (0, contract_id_1.generateUniqueContractId)(this.prisma);
        const cli = await (0, cli_1.generateUniqueCliFromSlug)(this.prisma, data.slug);
        const companyCode = await (0, company_code_1.generateUniqueCompanyCode)(this.prisma);
        try {
            return await this.prisma.company.create({
                data: {
                    clerkOrganizationId: data.clerkOrganizationId,
                    name: data.name,
                    slug: data.slug,
                    contractId,
                    cli,
                    companyCode,
                    ownerUserId: null,
                    primaryUseCase: data.primaryUseCase ?? undefined,
                    callVolume: data.callVolume ?? undefined,
                },
            });
        }
        catch (error) {
            if (error instanceof client_1.Prisma.PrismaClientKnownRequestError &&
                error.code === "P2002") {
                const raced = await this.findCompanyByClerkOrgId(data.clerkOrganizationId);
                if (raced) {
                    const legacyIds = !raced.cli || !raced.companyCode
                        ? {
                            ...(raced.cli ? {} : { cli: await (0, cli_1.generateUniqueCliFromSlug)(this.prisma, data.slug) }),
                            ...(raced.companyCode
                                ? {}
                                : { companyCode: await (0, company_code_1.generateUniqueCompanyCode)(this.prisma) }),
                        }
                        : {};
                    return this.prisma.company.update({
                        where: { id: raced.id },
                        data: { ...updateData, ...legacyIds },
                    });
                }
            }
            throw error;
        }
    }
    upsertMembership(data) {
        return this.prisma.companyMember.upsert({
            where: {
                companyId_userId: {
                    companyId: data.companyId,
                    userId: data.userId,
                },
            },
            create: {
                companyId: data.companyId,
                userId: data.userId,
                role: data.role,
                status: data.status ?? "ACTIVE",
                joinedAt: new Date(),
            },
            update: {
                role: data.role,
                status: data.status ?? "ACTIVE",
            },
        });
    }
    findUsersByIds(companyId, ids) {
        return this.prisma.user.findMany({
            where: {
                id: { in: ids },
                memberships: { some: { companyId, status: "ACTIVE" } },
            },
        });
    }
    findCompanyContact(companyId) {
        return this.prisma.companyContact.findUnique({
            where: { companyId },
        });
    }
    upsertCompanyContact(companyId, data) {
        return this.prisma.companyContact.upsert({
            where: { companyId },
            create: { companyId, ...data },
            update: data,
        });
    }
}
exports.TenantRepository = TenantRepository;
//# sourceMappingURL=tenant.repository.js.map