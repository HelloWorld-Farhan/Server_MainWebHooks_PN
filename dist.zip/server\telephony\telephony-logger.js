"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.logObdOutbound = logObdOutbound;
exports.logObdProviderRequest = logObdProviderRequest;
exports.logObdProviderResponse = logObdProviderResponse;
exports.logObdWebhook = logObdWebhook;
exports.logObdRetry = logObdRetry;
exports.logObdError = logObdError;
exports.logObdWebhookDuplicate = logObdWebhookDuplicate;
function maskPhone(phone) {
    if (phone.length <= 4) {
        return "****";
    }
    return `${"*".repeat(Math.max(0, phone.length - 4))}${phone.slice(-4)}`;
}
function stringifyPayload(value) {
    try {
        return JSON.stringify(value, null, 2);
    }
    catch {
        return String(value);
    }
}
function logObdOutbound(fields) {
    console.info("[obd:outbound]", {
        correlationId: fields.correlationId,
        callLogPublicId: fields.callLogPublicId,
        campaignPublicId: fields.campaignPublicId,
        companyId: fields.companyId,
        phone: maskPhone(fields.phone),
        ...(fields.payload !== undefined
            ? { payload: fields.payload, payloadJson: stringifyPayload(fields.payload) }
            : {}),
    });
}
function logObdProviderRequest(fields) {
    const payloadJson = stringifyPayload(fields.payload);
    console.info("[obd:provider-request]", {
        correlationId: fields.correlationId,
        url: fields.url,
        method: fields.method,
        headers: fields.headers,
        payload: fields.payload,
        payloadJson,
    });
    console.info(`[obd:provider-request:body] correlationId=${fields.correlationId} url=${fields.url}\n${payloadJson}`);
}
function logObdProviderResponse(fields) {
    const responseBodyJson = stringifyPayload(fields.responseBody);
    console.info("[obd:provider-response]", {
        correlationId: fields.correlationId,
        httpStatus: fields.httpStatus,
        responseHeaders: fields.responseHeaders,
        responseBody: fields.responseBody,
        responseBodyJson,
        providerCallId: fields.providerCallId ?? null,
        ...(fields.warning ? { warning: fields.warning } : {}),
    });
    console.info(`[obd:provider-response:body] correlationId=${fields.correlationId} httpStatus=${fields.httpStatus}\n${responseBodyJson}`);
}
function logObdWebhook(fields) {
    console.info("[obd:webhook]", {
        correlationId: fields.correlationId,
        callLogPublicId: fields.callLogPublicId,
        providerStatus: fields.providerStatus,
        durationSeconds: fields.durationSeconds,
        durationMs: fields.durationMs,
    });
}
function logObdRetry(fields) {
    console.warn("[obd:retry]", {
        correlationId: fields.correlationId,
        attempt: fields.attempt,
        httpStatus: fields.httpStatus,
    });
}
function logObdError(fields) {
    console.warn("[obd:error]", {
        correlationId: fields.correlationId,
        message: fields.message,
        httpStatus: fields.httpStatus,
        ...(fields.responseBody !== undefined
            ? { responseBody: fields.responseBody }
            : {}),
    });
}
function logObdWebhookDuplicate(fields) {
    console.info("[obd:webhook:duplicate]", {
        correlationId: fields.correlationId,
        callLogPublicId: fields.callLogPublicId,
        providerEventId: fields.providerEventId,
        durationMs: fields.durationMs,
    });
}
//# sourceMappingURL=telephony-logger.js.map