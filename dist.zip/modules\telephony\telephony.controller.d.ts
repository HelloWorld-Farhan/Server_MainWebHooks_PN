import type { Request, Response } from "express";
export declare class TelephonyController {
    getConfig(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    saveConfig(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    testConnection(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    testCall(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
}
