import type { CampaignAccessType, UserRole } from "@prisma/client";
import type { createDataLoaders } from "../graphql/dataloaders";
import type { CompanyPublicIdentity } from "../lib/public-id/types";
export type CampaignAccessContext = {
    type: CampaignAccessType;
    campaignIds: string[];
};
export type TenantAuthType = "user" | "api_key";
export type TenantContext = {
    authType: TenantAuthType;
    userId: string;
    clerkUserId: string;
    companyId: string;
    membershipId: string;
    role: UserRole;
    permissions: string[];
    campaignAccess: CampaignAccessContext;
    loaders: ReturnType<typeof createDataLoaders>;
    companyPublicIdentity?: CompanyPublicIdentity;
    apiKeyId?: string;
};
export type GraphQLContext = TenantContext & {
    isAuthenticated: boolean;
};
