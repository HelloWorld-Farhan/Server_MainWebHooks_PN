export declare function executeGraphQLFromRequest<T>(request: Request, query: string, variables?: Record<string, unknown>): Promise<T>;
