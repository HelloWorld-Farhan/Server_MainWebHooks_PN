"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.tenantService = exports.TenantService = void 0;
const cache_service_1 = require("../cache/cache.service");
const keys_1 = require("../cache/keys");
const errors_1 = require("../lib/errors");
const prisma_1 = __importDefault(require("../lib/prisma"));
const tenant_repository_1 = require("../repositories/tenant.repository");
const clerk_provision_service_1 = require("./clerk-provision.service");
const permissions_1 = require("../types/permissions");
class TenantService {
    repo = new tenant_repository_1.TenantRepository(prisma_1.default);
    async resolveCompany(clerkOrgId) {
        if (!clerkOrgId) {
            throw new errors_1.UnauthorizedError("Organization context required");
        }
        const company = await this.repo.findCompanyByClerkOrgId(clerkOrgId);
        if (!company) {
            throw new errors_1.NotFoundError("Company not found");
        }
        return company;
    }
    async resolveMembership(companyId, clerkUserId) {
        const user = await this.ensureUserFromClerk(clerkUserId);
        if (!user) {
            throw new errors_1.NotFoundError("User not found");
        }
        let membership = await this.repo.findMembership(companyId, user.id);
        if (!membership || membership.status !== "ACTIVE") {
            await (0, clerk_provision_service_1.ensureActiveCompanyMembership)(companyId, clerkUserId);
            membership = await this.repo.findMembership(companyId, user.id);
        }
        if (!membership || membership.status !== "ACTIVE") {
            throw new errors_1.ForbiddenError("Not a member of this organization");
        }
        return { user, membership };
    }
    async resolveMembershipFromRecord(companyId, clerkUserId, membership) {
        if (membership.status !== "ACTIVE" || membership.companyId !== companyId) {
            throw new errors_1.ForbiddenError("Not a member of this organization");
        }
        return { user: membership.user, membership };
    }
    async getPermissions(userId, role, customPermissions = []) {
        return cache_service_1.cacheService.getOrSet(keys_1.cacheKeys.userPermissions(userId), keys_1.CACHE_TTL.PERMISSIONS, async () => {
            const rolePermissions = (0, permissions_1.getPermissionsForRole)(role);
            return (0, permissions_1.mergePermissions)(rolePermissions, customPermissions);
        });
    }
    requirePermission(ctx, permission) {
        if (!(0, permissions_1.hasPermission)(ctx.permissions, permission)) {
            throw new errors_1.ForbiddenError(`Missing permission: ${permission}`);
        }
    }
    async syncUserFromClerk(data) {
        return this.repo.upsertUser(data);
    }
    async ensureUserFromClerk(clerkUserId) {
        const existing = await this.repo.findUserByClerkId(clerkUserId);
        if (existing) {
            return existing;
        }
        return (0, clerk_provision_service_1.resolveOrMergeUserFromClerk)(clerkUserId);
    }
    async syncCompanyFromClerk(data) {
        return this.repo.upsertCompany(data);
    }
    async syncMembership(data) {
        return this.repo.upsertMembership(data);
    }
    async getViewer(ctx) {
        const membership = await this.repo.findMembership(ctx.companyId, ctx.userId);
        if (!membership) {
            throw new errors_1.NotFoundError("Membership not found");
        }
        const contact = await this.repo.findCompanyContact(ctx.companyId);
        return {
            id: membership.user.id,
            membershipId: membership.id,
            email: membership.user.email,
            firstName: membership.user.firstName,
            lastName: membership.user.lastName,
            role: membership.role,
            permissions: ctx.permissions,
            campaignAccessType: membership.campaignAccessType,
            campaignIds: ctx.campaignAccess.type === "ALL" ? [] : ctx.campaignAccess.campaignIds,
            company: {
                id: membership.company.id,
                name: membership.company.name,
                slug: membership.company.slug,
                contact: contact
                    ? {
                        name: contact.name,
                        email: contact.email,
                        phone: contact.phone,
                        title: contact.title,
                    }
                    : null,
            },
        };
    }
}
exports.TenantService = TenantService;
exports.tenantService = new TenantService();
//# sourceMappingURL=tenant.service.js.map