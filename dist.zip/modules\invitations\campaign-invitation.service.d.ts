export type CampaignInvitationErrorCode = "not_found" | "accepted" | "cancelled" | "expired" | "not_pending";
export type CampaignInvitationView = {
    id: string;
    email: string;
    status: string;
    expiresAt: string;
    campaign: {
        id: string;
        name: string;
    };
    company: {
        id: string;
        name: string;
        clerkOrganizationId: string | null;
    };
};
export type GetCampaignInvitationResult = {
    valid: true;
    invitation: CampaignInvitationView;
} | {
    valid: false;
    error: CampaignInvitationErrorCode;
    message: string;
    expiresAt?: string;
};
export declare function getCampaignInvitationByToken(token: string): Promise<GetCampaignInvitationResult>;
export type AcceptCampaignInvitationResult = {
    success: true;
} | {
    success: false;
    error: string;
    statusCode: number;
};
export declare function acceptCampaignInvitation(token: string, clerkUserId: string): Promise<AcceptCampaignInvitationResult>;
