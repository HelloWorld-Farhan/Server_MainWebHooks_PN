import type { ApiKey, ApiKeyCampaignAccess } from "@prisma/client";
import type { TenantContext } from "../types/context";
type ApiKeyWithCampaigns = ApiKey & {
    campaignAccess: ApiKeyCampaignAccess[];
};
export declare function buildApiKeyTenantContext(apiKey: ApiKeyWithCampaigns): TenantContext;
export {};
