"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PhoneNumbersRepository = void 0;
const public_id_1 = require("../lib/public-id");
const types_1 = require("../lib/public-id/types");
const pagination_1 = require("../lib/pagination");
const resource_key_1 = require("../lib/resource-key");
const base_repository_1 = require("./base.repository");
const agentSelect = {
    id: true,
    name: true,
};
class PhoneNumbersRepository extends base_repository_1.BaseRepository {
    buildWhere(companyId, filter) {
        const where = this.scope(companyId);
        const and = [];
        if (filter?.number) {
            where.number = filter.number.trim();
        }
        if (filter?.numberContains?.trim()) {
            and.push({
                number: { contains: filter.numberContains.trim() },
            });
        }
        if (filter?.labelContains?.trim()) {
            and.push({
                label: {
                    contains: filter.labelContains.trim(),
                    mode: "insensitive",
                },
            });
        }
        if (filter?.search?.trim()) {
            const term = filter.search.trim();
            and.push({
                OR: [
                    { number: { contains: term } },
                    { label: { contains: term, mode: "insensitive" } },
                ],
            });
        }
        if (filter?.provider)
            where.provider = filter.provider;
        if (filter?.status)
            where.status = filter.status;
        if (filter?.inboundAgentId) {
            where.inboundAgentId = filter.inboundAgentId;
        }
        else if (typeof filter?.hasInboundAgent === "boolean") {
            where.inboundAgentId = filter.hasInboundAgent ? { not: null } : null;
        }
        if (filter?.outboundAgentId) {
            where.outboundAgentId = filter.outboundAgentId;
        }
        else if (typeof filter?.hasOutboundAgent === "boolean") {
            where.outboundAgentId = filter.hasOutboundAgent ? { not: null } : null;
        }
        if (typeof filter?.channelIndex === "number") {
            and.push({
                channelAssignments: {
                    some: { channelIndex: filter.channelIndex },
                },
            });
        }
        if (typeof filter?.hasChannelAssignment === "boolean") {
            and.push({
                channelAssignments: filter.hasChannelAssignment
                    ? { some: {} }
                    : { none: {} },
            });
        }
        if (filter?.createdFrom || filter?.createdTo) {
            where.createdAt = {};
            if (filter.createdFrom)
                where.createdAt.gte = filter.createdFrom;
            if (filter.createdTo)
                where.createdAt.lte = filter.createdTo;
        }
        if (filter?.lastActivityFrom || filter?.lastActivityTo) {
            where.lastActivityAt = {};
            if (filter.lastActivityFrom) {
                where.lastActivityAt.gte = filter.lastActivityFrom;
            }
            if (filter.lastActivityTo) {
                where.lastActivityAt.lte = filter.lastActivityTo;
            }
        }
        if (filter?.ids && filter.ids.length > 0) {
            where.id = { in: filter.ids };
        }
        if (and.length > 0) {
            where.AND = and;
        }
        return where;
    }
    buildOrderBy(sort) {
        const direction = sort?.direction === "ASC" ? "asc" : "desc";
        const field = sort?.field ?? "CREATED_AT";
        const primary = (() => {
            switch (field) {
                case "UPDATED_AT":
                    return { updatedAt: direction };
                case "LAST_ACTIVITY_AT":
                    return { lastActivityAt: direction };
                case "NUMBER":
                    return { number: direction };
                case "INBOUND_CALLS_COUNT":
                    return { inboundCallsCount: direction };
                case "OUTBOUND_CALLS_COUNT":
                    return { outboundCallsCount: direction };
                case "CREATED_AT":
                default:
                    return { createdAt: direction };
            }
        })();
        return [primary, { id: direction }];
    }
    findMany(companyId, filter, sort) {
        return this.prisma.phoneNumber.findMany({
            where: this.buildWhere(companyId, filter),
            include: {
                inboundAgent: { select: agentSelect },
                outboundAgent: { select: agentSelect },
            },
            orderBy: this.buildOrderBy(sort),
        });
    }
    findConnection(companyId, limit, after, filter, sort) {
        const cursor = after ? (0, pagination_1.decodeIdCursor)(after) : undefined;
        return this.prisma.phoneNumber.findMany({
            where: this.buildWhere(companyId, filter),
            include: {
                inboundAgent: { select: agentSelect },
                outboundAgent: { select: agentSelect },
            },
            orderBy: this.buildOrderBy(sort),
            take: limit + 1,
            ...(cursor
                ? {
                    cursor: { id: cursor.id },
                    skip: 1,
                }
                : {}),
        });
    }
    count(companyId, filter) {
        return this.prisma.phoneNumber.count({
            where: this.buildWhere(companyId, filter),
        });
    }
    findById(companyId, id) {
        return this.prisma.phoneNumber.findFirst({
            where: { id, companyId },
            include: {
                inboundAgent: { select: agentSelect },
                outboundAgent: { select: agentSelect },
            },
        });
    }
    findByIds(companyId, ids) {
        return this.prisma.phoneNumber.findMany({
            where: { companyId, id: { in: ids } },
            select: {
                id: true,
                number: true,
                label: true,
            },
        });
    }
    create(companyId, data) {
        return this.prisma.$transaction(async (tx) => {
            const phoneNumberId = await (0, resource_key_1.allocateResourceKey)(tx, companyId, types_1.PublicResourceType.PHONE_NUMBER);
            let publicId;
            if (data.campaignResourceKey && data.companyCli) {
                publicId = (0, public_id_1.generatePublicId)({
                    cli: data.companyCli,
                    campaignId: data.campaignResourceKey,
                    entityId: phoneNumberId,
                });
            }
            else {
                const company = await tx.company.findUnique({
                    where: { id: companyId },
                    select: { cli: true, companyCode: true },
                });
                if (!company) {
                    throw new Error("Company not found");
                }
                publicId = (0, public_id_1.generateLegacyPublicId)({
                    cli: company.cli,
                    companyCode: company.companyCode,
                    resourceKey: phoneNumberId,
                });
            }
            return tx.phoneNumber.create({
                data: {
                    number: data.number,
                    provider: data.provider,
                    label: data.label,
                    phoneNumberId,
                    publicId,
                    company: { connect: { id: companyId } },
                    ...(data.campaignId
                        ? { campaign: { connect: { id: data.campaignId } } }
                        : {}),
                    ...(data.inboundAgentId
                        ? { inboundAgent: { connect: { id: data.inboundAgentId } } }
                        : {}),
                    ...(data.outboundAgentId
                        ? { outboundAgent: { connect: { id: data.outboundAgentId } } }
                        : {}),
                },
                include: {
                    inboundAgent: { select: agentSelect },
                    outboundAgent: { select: agentSelect },
                },
            });
        });
    }
    update(companyId, id, data) {
        return this.prisma.phoneNumber.update({
            where: { id },
            data,
            include: {
                inboundAgent: { select: agentSelect },
                outboundAgent: { select: agentSelect },
            },
        });
    }
    findByCampaignAndNumber(tx, companyId, campaignId, number) {
        return tx.phoneNumber.findFirst({
            where: { companyId, campaignId, number },
        });
    }
    async createForCampaign(tx, companyId, campaignId, number, campaignResourceKey, companyCli) {
        const phoneNumberId = await (0, resource_key_1.allocateResourceKey)(tx, companyId, types_1.PublicResourceType.PHONE_NUMBER);
        const publicId = (0, public_id_1.generatePublicId)({
            cli: companyCli,
            campaignId: campaignResourceKey,
            entityId: phoneNumberId,
        });
        return tx.phoneNumber.create({
            data: {
                companyId,
                campaignId,
                number,
                phoneNumberId,
                publicId,
                provider: "PROPNEX",
            },
        });
    }
}
exports.PhoneNumbersRepository = PhoneNumbersRepository;
//# sourceMappingURL=phone-numbers.repository.js.map