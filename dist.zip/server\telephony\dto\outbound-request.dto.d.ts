import { z } from "zod";
import type { ObdConfig } from "../obd-config";
export declare const obdOutboundPhoneEntrySchema: z.ZodObject<{
    phone: z.ZodString;
    callid: z.ZodString;
}, z.core.$strip>;
export type ObdOutboundPhoneEntry = z.infer<typeof obdOutboundPhoneEntrySchema>;
export type ObdOutboundContactFields = {
    userName?: string | null;
    recordingUrl?: string | null;
    transcripts?: string | null;
    summary?: string | null;
};
export type ObdOutboundCallInput = {
    callid: string;
    phone: string;
    correlationId: string;
    webhookUrl?: string;
    contactFields?: ObdOutboundContactFields;
};
export type VoiceNsmsMsisdnListEntry = {
    phoneno: string;
    callid: string;
    user_name: string;
    "Recording URL": string;
    Summary: string;
    " Transcripts": string;
};
export type ObdProviderOutboundPayload = {
    sourcetype: string;
    sendnow: string;
    schddate?: string;
    campaigntype: string;
    filetype: string;
    ukey: string;
    serviceno: string;
    ivrtemplateid: string;
    retryatmpt: string;
    retryduration: string;
    msisdnlist: VoiceNsmsMsisdnListEntry[];
};
export declare function toVoiceNsmsMsisdn(phone: string): string;
export declare function formatObdScheduleDate(date?: Date): string;
export declare function buildObdProviderOutboundPayload(input: ObdOutboundCallInput, config: Pick<ObdConfig, "apiKey" | "serviceNo" | "ivrTemplateId" | "retryAttempts" | "retryDuration" | "sourceType" | "campaignType" | "fileType" | "sendNow">): ObdProviderOutboundPayload;
