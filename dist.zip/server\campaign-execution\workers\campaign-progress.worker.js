"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CampaignProgressWorker = void 0;
const common_1 = require("@nestjs/common");
const campaign_execution_config_1 = require("../campaign-execution.config");
const campaign_progress_service_1 = require("../campaign-progress.service");
const run_worker_task_1 = require("../../lib/run-worker-task");
let CampaignProgressWorker = class CampaignProgressWorker {
    interval = null;
    processing = false;
    onModuleInit() {
        this.interval = setInterval(() => {
            (0, run_worker_task_1.runWorkerTask)("campaign-progress", () => this.tick());
        }, campaign_execution_config_1.campaignExecutionConfig.progressIntervalMs);
    }
    onModuleDestroy() {
        if (this.interval) {
            clearInterval(this.interval);
            this.interval = null;
        }
    }
    async tick() {
        if (this.processing) {
            return;
        }
        this.processing = true;
        try {
            await campaign_progress_service_1.campaignProgressService.updateAllActive();
        }
        finally {
            this.processing = false;
        }
    }
};
exports.CampaignProgressWorker = CampaignProgressWorker;
exports.CampaignProgressWorker = CampaignProgressWorker = __decorate([
    (0, common_1.Injectable)()
], CampaignProgressWorker);
//# sourceMappingURL=campaign-progress.worker.js.map