import type { Request, Response } from "express";
export declare class BillingController {
    getRates(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    listQuotes(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    createQuote(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    purchaseQuote(req: Request, res: Response, id: string): Promise<Response<any, Record<string, any>> | undefined>;
}
