import type { PageCacheKey } from "../cache/keys";
import { type PageLoader } from "./loaders";
export declare function getPageLoader(pageKey: string): PageLoader | null;
export declare function isValidPageCacheKey(pageKey: string): pageKey is PageCacheKey;
