import { CallVolumeRange, PrimaryUseCase } from "@prisma/client";
export { CallVolumeRange, PrimaryUseCase };
export type UserOnboardingMetadata = {
    onboardingComplete?: boolean;
    companyName?: string;
    primaryUseCase?: PrimaryUseCase;
    callVolume?: CallVolumeRange;
    phone?: string;
};
export declare function isPrimaryUseCase(value: unknown): value is PrimaryUseCase;
export declare function isCallVolumeRange(value: unknown): value is CallVolumeRange;
export declare function parsePrimaryUseCase(value: unknown): PrimaryUseCase | undefined;
export declare function parseCallVolumeRange(value: unknown): CallVolumeRange | undefined;
export declare function getUserMetadata(unsafeMetadata: Record<string, unknown> | undefined): UserOnboardingMetadata;
export declare function formatPrimaryUseCase(useCase?: PrimaryUseCase): string;
export declare function formatCallVolumeRange(volume?: CallVolumeRange): string;
