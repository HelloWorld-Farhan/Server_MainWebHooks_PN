import type { GraphQLSchema } from "graphql";
export declare const schema: GraphQLSchema;
