"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapProviderStatusToCallStatus = mapProviderStatusToCallStatus;
const PROVIDER_STATUS_MAP = {
    SUCCESS: "COMPLETED",
    ANSWERED: "ANSWERED",
    COMPLETED: "COMPLETED",
    RINGING: "RINGING",
    BUSY: "BUSY",
    NO_ANSWER: "NO_ANSWER",
    UNANSWERED: "NO_ANSWER",
    CANCELLED: "CANCELLED",
    CANCELED: "CANCELLED",
    FAILED: "FAILED",
    ERROR: "FAILED",
    VOICEMAIL: "VOICEMAIL",
    QUEUED: "QUEUED_AT_PROVIDER",
    QUEUED_AT_PROVIDER: "QUEUED_AT_PROVIDER",
    PENDING: "PENDING",
    DISPATCHING: "DISPATCHING",
    MISSED: "MISSED",
};
function mapProviderStatusToCallStatus(providerStatus) {
    const normalized = providerStatus.trim().toUpperCase();
    return PROVIDER_STATUS_MAP[normalized] ?? "FAILED";
}
//# sourceMappingURL=status-mapper.js.map