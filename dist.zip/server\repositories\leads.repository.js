"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LeadsRepository = void 0;
const base_repository_1 = require("./base.repository");
const pagination_1 = require("../lib/pagination");
const DEFAULT_PIPELINE_STAGES = [
    { name: "New", slug: "new", order: 0, isDefault: true },
    { name: "Contacted", slug: "contacted", order: 1, isDefault: false },
    { name: "Qualified", slug: "qualified", order: 2, isDefault: false },
];
class LeadsRepository extends base_repository_1.BaseRepository {
    findById(companyId, id) {
        return this.prisma.lead.findFirst({
            where: { id, companyId },
            include: {
                stage: true,
                source: true,
                assignedUser: true,
            },
        });
    }
    buildWhere(companyId, filter, scopeWhere) {
        const where = this.scope(companyId);
        if (filter?.temperature) {
            where.temperature = filter.temperature;
        }
        if (filter?.dormantOnly || filter?.minDaysInactive) {
            const days = filter.minDaysInactive ?? 30;
            const cutoff = new Date();
            cutoff.setDate(cutoff.getDate() - days);
            where.OR = [
                { lastContactedAt: { lt: cutoff } },
                { lastContactedAt: null },
            ];
        }
        if (scopeWhere && Object.keys(scopeWhere).length > 0) {
            return { AND: [where, scopeWhere] };
        }
        return where;
    }
    findConnection(companyId, limit, after, filter, scopeWhere) {
        const cursor = after ? (0, pagination_1.decodeIdCursor)(after) : undefined;
        return this.prisma.lead.findMany({
            where: this.buildWhere(companyId, filter, scopeWhere),
            include: {
                source: true,
                stage: true,
                callLogs: {
                    orderBy: { startedAt: "desc" },
                    take: 1,
                    include: { aiAgent: { select: { id: true, name: true } } },
                },
            },
            orderBy: [{ lastContactedAt: "asc" }, { id: "desc" }],
            take: limit + 1,
            ...(cursor
                ? {
                    cursor: { id: cursor.id },
                    skip: 1,
                }
                : {}),
        });
    }
    countByTemperature(companyId, scopeWhere) {
        const where = scopeWhere && Object.keys(scopeWhere).length > 0
            ? { AND: [this.scope(companyId), scopeWhere] }
            : this.scope(companyId);
        return this.prisma.lead.groupBy({
            by: ["temperature"],
            where,
            _count: { id: true },
        });
    }
    create(companyId, data) {
        return this.prisma.lead.create({
            data: {
                ...data,
                company: { connect: { id: companyId } },
            },
        });
    }
    findByPhone(companyId, phone) {
        return this.prisma.lead.findFirst({
            where: { companyId, phone },
        });
    }
    async ensureImportDefaults(companyId) {
        const stage = (await this.prisma.leadPipelineStage.findFirst({
            where: { companyId },
            orderBy: [{ isDefault: "desc" }, { order: "asc" }],
        })) ??
            (await this.prisma.leadPipelineStage.create({
                data: {
                    companyId,
                    ...DEFAULT_PIPELINE_STAGES[0],
                },
            }));
        const source = (await this.prisma.leadSource.findFirst({
            where: { companyId, type: "CSV" },
        })) ??
            (await this.prisma.leadSource.create({
                data: {
                    companyId,
                    name: "CSV Import",
                    type: "CSV",
                },
            }));
        return { stageId: stage.id, sourceId: source.id };
    }
    async importRows(companyId, rows) {
        const stats = {
            hot: 0,
            warm: 0,
            cold: 0,
            total: 0,
            invalid: 0,
            created: 0,
            updated: 0,
        };
        const { stageId, sourceId } = await this.ensureImportDefaults(companyId);
        const seenPhones = new Set();
        for (const row of rows) {
            const phone = row.phone.trim();
            if (!phone || seenPhones.has(phone)) {
                stats.invalid++;
                continue;
            }
            seenPhones.add(phone);
            const temperature = row.temperature;
            const score = temperature === "HOT" ? 80 : temperature === "WARM" ? 55 : 30;
            if (temperature === "HOT")
                stats.hot++;
            else if (temperature === "WARM")
                stats.warm++;
            else
                stats.cold++;
            stats.total++;
            const existing = await this.findByPhone(companyId, phone);
            if (existing) {
                await this.prisma.lead.update({
                    where: { id: existing.id },
                    data: {
                        firstName: row.firstName ?? existing.firstName,
                        lastName: row.lastName ?? existing.lastName,
                        email: row.email ?? existing.email,
                        temperature,
                        score,
                        source: { connect: { id: sourceId } },
                    },
                });
                stats.updated++;
                continue;
            }
            await this.create(companyId, {
                firstName: row.firstName ?? undefined,
                lastName: row.lastName ?? undefined,
                email: row.email ?? undefined,
                phone,
                temperature,
                score,
                stage: { connect: { id: stageId } },
                source: { connect: { id: sourceId } },
            });
            stats.created++;
        }
        return stats;
    }
}
exports.LeadsRepository = LeadsRepository;
//# sourceMappingURL=leads.repository.js.map