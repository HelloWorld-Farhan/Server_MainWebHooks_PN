import { type GenerateLegacyPublicIdInput, type ParsedLegacyPublicIdV1, type PublicResourceType } from "./types";
export declare function generateLegacyPublicId(input: GenerateLegacyPublicIdInput): string;
export declare function parseLegacyPublicId(input: string): ParsedLegacyPublicIdV1 | null;
export declare function validateLegacyPublicId(input: string, expectedResourceType?: PublicResourceType): boolean;
export declare function decodeLegacyPublicId(input: string): ParsedLegacyPublicIdV1;
