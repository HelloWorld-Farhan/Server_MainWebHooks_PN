"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.campaignExecutionQueue = exports.CAMPAIGN_EXECUTION_QUEUE_NAME = void 0;
exports.startCampaignJob = startCampaignJob;
exports.getCampaignState = getCampaignState;
exports.clearCampaignState = clearCampaignState;
exports.forceStopCampaignState = forceStopCampaignState;
exports.pauseCampaignState = pauseCampaignState;
exports.resumeCampaignState = resumeCampaignState;
const bullmq_1 = require("bullmq");
const redis_client_1 = require("./redis.client");
const campaign_gateway_1 = require("../../modules/websockets/campaign.gateway");
const prisma_1 = __importDefault(require("../lib/prisma"));
exports.CAMPAIGN_EXECUTION_QUEUE_NAME = "campaign-execution-queue";
exports.campaignExecutionQueue = redis_client_1.redisConnection
    ? new bullmq_1.Queue(exports.CAMPAIGN_EXECUTION_QUEUE_NAME, {
        connection: redis_client_1.redisConnection,
        defaultJobOptions: {
            attempts: 1,
            removeOnComplete: true,
            removeOnFail: true,
        },
    })
    : null;
async function startCampaignJob(data, delayMs) {
    if (!exports.campaignExecutionQueue) {
        throw new Error("Redis not configured. Cannot start campaign.");
    }
    const uniqueJobId = `campaign-${data.companyId}-${Date.now()}`;
    if (!delayMs) {
        try {
            const stateStr = await redis_client_1.redisConnection.get(`campaign-state:${data.companyId}`);
            if (stateStr) {
                const state = JSON.parse(stateStr);
                if (state.status === "running") {
                    if (!data.isReactivation && (state.isReactivation || state.qStage)) {
                        console.log(`[Traffic Cop] Preempting Reactivation for company ${data.companyId} to start Live Campaign.`);
                        const pausedState = { ...state, status: "paused" };
                        await redis_client_1.redisConnection.set(`campaign-state:paused:${data.companyId}`, JSON.stringify(pausedState));
                    }
                    else {
                        throw new Error("A campaign is already currently running for this company.");
                    }
                }
            }
        }
        catch (e) {
            if (e.message.includes("already running"))
                throw e;
            console.error("Error checking existing campaign state:", e);
        }
    }
    const uniqueLeadsMap = new Map();
    for (const lead of data.leads) {
        if (lead?.phone) {
            const corePhone = lead.phone.replace(/\D/g, "").slice(-10);
            uniqueLeadsMap.set(corePhone, lead);
        }
    }
    const deduplicatedLeads = Array.from(uniqueLeadsMap.values());
    data.leads = deduplicatedLeads;
    const initialState = {
        campaignId: data.campaignId,
        status: delayMs ? "scheduled" : "running",
        activeJobId: !delayMs ? uniqueJobId : undefined,
        totalContacts: data.leads.length,
        completedCalls: 0,
        successfulCalls: 0,
        failedCalls: 0,
        leads: data.leads,
        isReactivation: !!data.isReactivation,
        qStage: data.qStage,
        scheduledAt: delayMs ? data.scheduledAt : undefined,
        uploadedFileName: data.uploadedFileName
    };
    await redis_client_1.redisConnection.set(`campaign-state:${data.companyId}`, JSON.stringify(initialState));
    const gateway = campaign_gateway_1.CampaignGateway.getInstance();
    if (gateway) {
        gateway.broadcastCampaignUpdate(data.companyId, initialState);
    }
    await exports.campaignExecutionQueue.add(uniqueJobId, data, {
        jobId: uniqueJobId,
        delay: delayMs ? Math.max(0, delayMs) : undefined,
        removeOnComplete: true,
        removeOnFail: true
    });
}
async function getCampaignState(companyId) {
    if (!redis_client_1.redisConnection)
        return null;
    const state = await redis_client_1.redisConnection.get(`campaign-state:${companyId}`);
    if (state)
        return JSON.parse(state);
    if (exports.campaignExecutionQueue) {
        try {
            const delayedJobs = await exports.campaignExecutionQueue.getDelayed();
            const pending = delayedJobs.find((job) => job.data.companyId === companyId && job.data.isReactivation);
            if (pending) {
                const scheduledState = {
                    campaignId: pending.data.campaignId,
                    status: "scheduled",
                    totalContacts: pending.data.leads?.length || 0,
                    completedCalls: 0,
                    successfulCalls: 0,
                    failedCalls: 0,
                    leads: pending.data.leads || [],
                    isReactivation: true,
                    qStage: pending.data.qStage,
                    scheduledAt: pending.data.scheduledAt,
                    uploadedFileName: pending.data.uploadedFileName,
                };
                await redis_client_1.redisConnection.set(`campaign-state:${companyId}`, JSON.stringify(scheduledState));
                return scheduledState;
            }
        }
        catch (e) {
            console.error("[getCampaignState] BullMQ fallback check failed:", e);
        }
    }
    return null;
}
async function clearCampaignState(companyId) {
    if (!redis_client_1.redisConnection)
        return;
    await redis_client_1.redisConnection.del(`campaign-state:${companyId}`);
    const gateway = campaign_gateway_1.CampaignGateway.getInstance();
    if (gateway) {
        gateway.broadcastCampaignUpdate(companyId, { status: "idle", leads: [] });
    }
}
async function forceStopCampaignState(companyId) {
    if (!redis_client_1.redisConnection)
        return;
    const stateStr = await redis_client_1.redisConnection.get(`campaign-state:${companyId}`);
    if (stateStr) {
        const state = JSON.parse(stateStr);
        const updatedCount = await prisma_1.default.callLog.updateMany({
            where: {
                companyId,
                status: { in: ["PENDING", "QUEUED", "DISPATCHING", "RINGING"] }
            },
            data: {
                status: "FAILED",
                providerStatus: "force_stopped"
            }
        });
        const newState = {
            ...state,
            status: "force_stopped",
            failedCalls: (state.failedCalls || 0) + updatedCount.count,
            completedCalls: (state.completedCalls || 0) + updatedCount.count,
        };
        await redis_client_1.redisConnection.set(`campaign-state:${companyId}`, JSON.stringify(newState));
        const gateway = campaign_gateway_1.CampaignGateway.getInstance();
        if (gateway) {
            gateway.broadcastCampaignUpdate(companyId, newState);
        }
        return newState;
    }
    return null;
}
async function pauseCampaignState(companyId) {
    if (!redis_client_1.redisConnection)
        return null;
    const stateStr = await redis_client_1.redisConnection.get(`campaign-state:${companyId}`);
    if (stateStr) {
        const state = JSON.parse(stateStr);
        if (state.status === "running") {
            const newState = { ...state, status: "paused" };
            await redis_client_1.redisConnection.set(`campaign-state:${companyId}`, JSON.stringify(newState));
            const gateway = campaign_gateway_1.CampaignGateway.getInstance();
            if (gateway)
                gateway.broadcastCampaignUpdate(companyId, newState);
            return newState;
        }
    }
    return null;
}
async function resumeCampaignState(companyId) {
    if (!redis_client_1.redisConnection)
        return null;
    const stateStr = await redis_client_1.redisConnection.get(`campaign-state:${companyId}`);
    if (stateStr) {
        const state = JSON.parse(stateStr);
        if (state.status === "paused") {
            const newState = { ...state, status: "running" };
            await redis_client_1.redisConnection.set(`campaign-state:${companyId}`, JSON.stringify(newState));
            const gateway = campaign_gateway_1.CampaignGateway.getInstance();
            if (gateway)
                gateway.broadcastCampaignUpdate(companyId, newState);
            return newState;
        }
    }
    return null;
}
//# sourceMappingURL=campaign-execution.queue.js.map