import type { PrismaClient } from "@prisma/client";
export declare function normalizeCli(input: string): string | null;
export declare function deriveCliFromSlug(slug: string): string;
export declare function generateUniqueCliFromSlug(prisma: PrismaClient, slug: string): Promise<string>;
