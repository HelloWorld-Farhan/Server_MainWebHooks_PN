export declare function isClerkWebhooksEnabled(): boolean;
