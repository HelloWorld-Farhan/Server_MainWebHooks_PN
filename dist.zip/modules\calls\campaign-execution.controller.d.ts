import type { Request, Response } from "express";
export declare class OutboundCampaignExecutionController {
    startCampaign(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    getStatus(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    clearCampaign(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    forceStopCampaign(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    pauseCampaign(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    resumeCampaign(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
}
