import type { Request } from "express";
export type SubmitContactRequestResult = {
    success: true;
    requestId: string;
} | {
    success: false;
    error: string;
};
export declare function submitContactRequest(req: Request): Promise<SubmitContactRequestResult>;
