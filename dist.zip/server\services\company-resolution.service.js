"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveAuthenticatedTenant = resolveAuthenticatedTenant;
exports.resolveCompanyForAuthenticatedUser = resolveCompanyForAuthenticatedUser;
const cache_service_1 = require("../cache/cache.service");
const keys_1 = require("../cache/keys");
const debug_1 = require("../graphql/debug");
const errors_1 = require("../lib/errors");
const clerk_config_1 = require("../lib/clerk-config");
const prisma_1 = __importDefault(require("../lib/prisma"));
const resolution_metrics_1 = require("../lib/resolution-metrics");
const tenant_repository_1 = require("../repositories/tenant.repository");
const clerk_provision_service_1 = require("./clerk-provision.service");
const tenant_service_1 = require("./tenant.service");
const tenantRepo = new tenant_repository_1.TenantRepository(prisma_1.default);
async function findActiveMembership(userId, orgId) {
    const memberships = await prisma_1.default.companyMember.findMany({
        where: { userId, status: "ACTIVE" },
        include: {
            customRole: true,
            user: true,
            company: true,
            campaignAccess: true,
        },
        orderBy: { joinedAt: "desc" },
    });
    if (memberships.length === 0) {
        return null;
    }
    if (orgId) {
        const byOrg = memberships.find((m) => m.company?.clerkOrganizationId === orgId);
        if (byOrg) {
            return byOrg;
        }
    }
    return memberships[0];
}
async function findInvitedMembership(userId, orgId) {
    const memberships = await prisma_1.default.companyMember.findMany({
        where: { userId, status: "INVITED" },
        include: {
            customRole: true,
            user: true,
            company: true,
            campaignAccess: true,
        },
        orderBy: { invitedAt: "desc" },
    });
    if (memberships.length === 0) {
        return null;
    }
    if (orgId) {
        const byOrg = memberships.find((m) => m.company?.clerkOrganizationId === orgId);
        if (byOrg) {
            return byOrg;
        }
    }
    return memberships[0];
}
async function loadFromResolvedCache(clerkUserId) {
    const cached = await cache_service_1.cacheService.getResolvedCompany(clerkUserId);
    if (!cached) {
        (0, resolution_metrics_1.incrementMetric)("redis_company_miss");
        return null;
    }
    (0, resolution_metrics_1.incrementMetric)("redis_company_hit");
    (0, debug_1.gqlDebug)("company:cache-hit", { clerkUserId, companyId: cached.companyId });
    const user = await tenantRepo.findUserByClerkId(clerkUserId);
    if (!user) {
        await cache_service_1.cacheService.invalidateClerkMembershipCaches(clerkUserId);
        return null;
    }
    const membership = await tenantRepo.findMembership(cached.companyId, user.id);
    if (!membership ||
        membership.status !== "ACTIVE" ||
        membership.id !== cached.membershipId) {
        await cache_service_1.cacheService.invalidateClerkMembershipCaches(clerkUserId);
        return null;
    }
    return {
        company: membership.company,
        user: membership.user,
        membership,
    };
}
async function cacheResolvedTenant(clerkUserId, tenant) {
    await cache_service_1.cacheService.setResolvedCompany(clerkUserId, {
        companyId: tenant.company.id,
        membershipId: tenant.membership.id,
        role: tenant.membership.role,
    }, keys_1.CACHE_TTL.RESOLVED_COMPANY);
}
async function scheduleBackgroundReconciliation(clerkUserId, orgId) {
    if ((0, clerk_config_1.isClerkWebhooksEnabled)()) {
        return;
    }
    const user = await tenantRepo.findUserByClerkId(clerkUserId);
    if (user) {
        const invitedMembership = await findInvitedMembership(user.id, orgId);
        const pendingCampaignInvite = await prisma_1.default.campaignInvitation.findFirst({
            where: {
                email: { equals: user.email, mode: "insensitive" },
                status: "PENDING",
            },
        });
        if (!invitedMembership && !pendingCampaignInvite) {
            return;
        }
    }
    void (0, clerk_provision_service_1.reconcileInviteMembershipOnLogin)(clerkUserId, orgId).catch((error) => {
        (0, debug_1.gqlLogError)("company:background-reconcile:error", error, {
            clerkUserId,
            orgId,
        });
    });
}
async function resolveFromMongoDb(clerkUserId, orgId) {
    let user = await tenantRepo.findUserByClerkId(clerkUserId);
    if (orgId) {
        try {
            const company = await tenant_service_1.tenantService.resolveCompany(orgId);
            if (user) {
                const membership = await tenantRepo.findMembership(company.id, user.id);
                if (membership?.status === "ACTIVE") {
                    return { company, user, membership };
                }
            }
        }
        catch (error) {
            if (!(0, errors_1.isAppError)(error) || error.statusCode !== 404) {
                throw error;
            }
        }
    }
    if (!user) {
        user = await tenant_service_1.tenantService.ensureUserFromClerk(clerkUserId);
    }
    if (!user) {
        return null;
    }
    const activeMembership = await findActiveMembership(user.id, orgId);
    if (activeMembership?.company) {
        return {
            company: activeMembership.company,
            user,
            membership: activeMembership,
        };
    }
    return null;
}
async function recoverTenant(clerkUserId, orgId, options) {
    let user = await tenantRepo.findUserByClerkId(clerkUserId);
    if (!user) {
        user = await tenant_service_1.tenantService.ensureUserFromClerk(clerkUserId);
    }
    const invitedMembership = user
        ? await findInvitedMembership(user.id, orgId)
        : null;
    const pendingCampaignInvite = user
        ? await prisma_1.default.campaignInvitation.findFirst({
            where: {
                email: { equals: user.email, mode: "insensitive" },
                status: "PENDING",
            },
        })
        : null;
    if (options?.forceReconcile || invitedMembership || pendingCampaignInvite) {
        await (0, clerk_provision_service_1.reconcileInviteMembershipOnLogin)(clerkUserId, orgId);
    }
    if (user) {
        const activeAfterReconcile = await findActiveMembership(user.id, orgId);
        if (activeAfterReconcile?.company) {
            return {
                company: activeAfterReconcile.company,
                user,
                membership: activeAfterReconcile,
            };
        }
    }
    if (invitedMembership?.company) {
        await (0, clerk_provision_service_1.ensureActiveCompanyMembership)(invitedMembership.company.id, clerkUserId, orgId);
        const refreshed = user
            ? await findActiveMembership(user.id, orgId)
            : null;
        if (refreshed?.company && user) {
            return { company: refreshed.company, user, membership: refreshed };
        }
    }
    const syncedCompany = await (0, clerk_provision_service_1.syncTenantFromClerk)(clerkUserId);
    if (syncedCompany) {
        user = user ?? (await tenantRepo.findUserByClerkId(clerkUserId));
        if (user) {
            const membership = await findActiveMembership(user.id, orgId);
            if (membership?.company) {
                return { company: membership.company, user, membership };
            }
            const loaded = await tenantRepo.findMembership(syncedCompany.id, user.id);
            if (loaded?.status === "ACTIVE") {
                return { company: syncedCompany, user, membership: loaded };
            }
        }
    }
    if (!options?.forceReconcile && !invitedMembership) {
        await (0, clerk_provision_service_1.reconcileInviteMembershipOnLogin)(clerkUserId, orgId);
        user = user ?? (await tenantRepo.findUserByClerkId(clerkUserId));
        if (user) {
            const finalActive = await findActiveMembership(user.id, orgId);
            if (finalActive?.company) {
                return { company: finalActive.company, user, membership: finalActive };
            }
        }
    }
    return null;
}
async function resolveAuthenticatedTenant(clerkUserId, orgId, options) {
    const start = performance.now();
    if (options?.resolutionCache?.tenant !== undefined) {
        return options.resolutionCache.tenant;
    }
    const resolve = async () => {
        const fromRedis = await loadFromResolvedCache(clerkUserId);
        if (fromRedis) {
            scheduleBackgroundReconciliation(clerkUserId, orgId);
            return fromRedis;
        }
        const fromMongo = await resolveFromMongoDb(clerkUserId, orgId);
        if (fromMongo) {
            await cacheResolvedTenant(clerkUserId, fromMongo);
            scheduleBackgroundReconciliation(clerkUserId, orgId);
            return fromMongo;
        }
        const recovered = await recoverTenant(clerkUserId, orgId, {
            forceReconcile: options?.forceReconcile,
        });
        if (recovered) {
            await cacheResolvedTenant(clerkUserId, recovered);
            return recovered;
        }
        return null;
    };
    try {
        const tenant = await resolve();
        if (options?.resolutionCache) {
            options.resolutionCache.tenant = tenant;
        }
        const durationMs = Math.round(performance.now() - start);
        (0, resolution_metrics_1.recordCompanyResolutionDuration)(durationMs);
        (0, resolution_metrics_1.logResolutionEvent)("company:resolved", {
            clerkUserId,
            orgId,
            found: Boolean(tenant),
            durationMs,
        });
        return tenant;
    }
    catch (error) {
        (0, debug_1.gqlLogError)("company:resolve:error", error, { clerkUserId, orgId });
        throw error;
    }
}
async function resolveCompanyForAuthenticatedUser(clerkUserId, orgId, options) {
    const tenant = await resolveAuthenticatedTenant(clerkUserId, orgId, options);
    return tenant?.company ?? null;
}
//# sourceMappingURL=company-resolution.service.js.map