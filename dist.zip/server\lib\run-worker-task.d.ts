export declare function runWorkerTask(workerName: string, task: () => Promise<void>): void;
