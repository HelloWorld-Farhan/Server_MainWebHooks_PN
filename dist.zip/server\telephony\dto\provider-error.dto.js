"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toProviderErrorJson = toProviderErrorJson;
function toProviderErrorJson(error) {
    return {
        message: error.message,
        ...(error.httpStatus !== undefined ? { httpStatus: error.httpStatus } : {}),
        ...(error.responseBody !== undefined
            ? { responseBody: error.responseBody }
            : {}),
        ...(error.isNetworkError ? { isNetworkError: true } : {}),
        ...(error.isTimeout ? { isTimeout: true } : {}),
    };
}
//# sourceMappingURL=provider-error.dto.js.map