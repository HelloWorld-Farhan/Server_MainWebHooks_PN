import type { AnalyticsGranularity } from "@prisma/client";
import type { TenantContext } from "../types/context";
type MetricsJson = Record<string, number>;
export declare class AnalyticsService {
    private readonly repo;
    private readonly callLogsRepo;
    getSummary(ctx: TenantContext, granularity?: AnalyticsGranularity, dateFrom?: Date, dateTo?: Date): Promise<{
        totalCalls: number;
        connectedCalls: number;
        conversionRate: number;
        generatedLeads: number;
        periodStart: string;
        periodEnd: string;
    }>;
    getTimeSeries(ctx: TenantContext, granularity?: AnalyticsGranularity, dateFrom?: Date, dateTo?: Date): Promise<{
        granularity: import("@prisma/client").$Enums.AnalyticsGranularity;
        periodStart: string;
        periodEnd: string;
        points: {
            periodStart: string;
            label: string;
            calls: number;
            connectedCalls: number;
            leads: number;
            conversions: number;
            conversionRate: number;
        }[];
    }>;
    private resolveBucketDate;
    private formatBucketLabel;
    incrementDailyMetrics(companyId: string, delta: MetricsJson): Promise<void>;
}
export declare const analyticsService: AnalyticsService;
export {};
