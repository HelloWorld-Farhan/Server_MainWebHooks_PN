"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreditsRepository = void 0;
const base_repository_1 = require("./base.repository");
const pagination_1 = require("../lib/pagination");
const notification_service_1 = require("../services/notification.service");
class CreditsRepository extends base_repository_1.BaseRepository {
    getBalance(companyId) {
        return this.prisma.creditBalance.findUnique({
            where: { companyId },
        });
    }
    ensureBalance(companyId) {
        return this.prisma.creditBalance.upsert({
            where: { companyId },
            create: { companyId, creditsRemaining: 0, creditsUsed: 0 },
            update: {},
        });
    }
    listUsage(companyId, limit, after) {
        const cursor = after ? (0, pagination_1.decodeIdCursor)(after) : undefined;
        return this.prisma.creditUsage.findMany({
            where: this.scope(companyId),
            orderBy: [{ createdAt: "desc" }, { id: "desc" }],
            take: limit + 1,
            ...(cursor
                ? {
                    cursor: { id: cursor.id },
                    skip: 1,
                }
                : {}),
        });
    }
    async recordUsage(companyId, data) {
        return this.prisma.$transaction(async (tx) => {
            const usage = await tx.creditUsage.create({
                data: {
                    companyId,
                    amount: data.amount,
                    reason: data.reason,
                    callLogId: data.callLogId,
                    description: data.description,
                },
            });
            const currentBalance = await tx.creditBalance.findUnique({
                where: { companyId },
            });
            const previousRemaining = currentBalance ? currentBalance.creditsRemaining : 0;
            const newBalance = await tx.creditBalance.upsert({
                where: { companyId },
                create: {
                    companyId,
                    creditsRemaining: Math.max(0, -data.amount),
                    creditsUsed: Math.max(0, data.amount),
                },
                update: {
                    creditsRemaining: { decrement: data.amount },
                    creditsUsed: { increment: Math.max(0, data.amount) },
                },
            });
            if (previousRemaining > 0 && newBalance.creditsRemaining <= 0) {
                process.nextTick(async () => {
                    try {
                        const fullCompany = await this.prisma.company.findUnique({
                            where: { id: companyId },
                            include: {
                                members: { where: { role: "OWNER", status: "ACTIVE" }, include: { user: true } },
                            },
                        });
                        const user = fullCompany?.members?.[0]?.user;
                        if (user && user.email) {
                            if (fullCompany.parentCompanyId) {
                                await notification_service_1.notificationService.sendSubCompanyCreditZeroWarningEmail({
                                    email: user.email,
                                    companyName: fullCompany.name,
                                });
                            }
                            else {
                                await notification_service_1.notificationService.sendCreditZeroWarningEmail({
                                    email: user.email,
                                    name: user.firstName ? `${user.firstName} ${user.lastName}`.trim() : user.email.split("@")[0],
                                });
                            }
                        }
                    }
                    catch (err) {
                        console.error("Failed to process zero credit warning:", err);
                    }
                });
            }
            return usage;
        });
    }
}
exports.CreditsRepository = CreditsRepository;
//# sourceMappingURL=credits.repository.js.map