"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.outboundCallsService = exports.OutboundCallsService = void 0;
const client_1 = require("@prisma/client");
const phone_validation_1 = require("../../lib/phone-validation");
const errors_1 = require("../lib/errors");
const mapper_1 = require("../lib/public-id/mapper");
const types_1 = require("../lib/public-id/types");
const prisma_1 = __importDefault(require("../lib/prisma"));
const call_logs_repository_1 = require("../repositories/call-logs.repository");
const phone_numbers_repository_1 = require("../repositories/phone-numbers.repository");
const campaign_access_service_1 = require("./campaign-access.service");
const call_service_1 = require("./call.service");
const tenant_service_1 = require("./tenant.service");
const permissions_1 = require("../types/permissions");
class OutboundCallsService {
    dispatchService;
    phoneNumbersRepo = new phone_numbers_repository_1.PhoneNumbersRepository(prisma_1.default);
    callLogsRepo = new call_logs_repository_1.CallLogsRepository(prisma_1.default);
    constructor(dispatchService = call_service_1.callService) {
        this.dispatchService = dispatchService;
    }
    async createOutboundCall(ctx, input) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CALL_LOGS_WRITE);
        const campaignPublicId = input.campaignId?.trim();
        if (!campaignPublicId) {
            throw new errors_1.ValidationError("Campaign ID is required");
        }
        const phoneRaw = input.phoneNumber?.trim();
        if (!phoneRaw) {
            throw new errors_1.ValidationError("Phone number is required");
        }
        const normalizedPhone = (0, phone_validation_1.normalizeOutboundPhone)(phoneRaw);
        if (!normalizedPhone) {
            throw new errors_1.ValidationError("Phone number must be in E.164 format");
        }
        const internalCampaignId = await (0, mapper_1.resolveResourceId)(ctx, campaignPublicId, types_1.PublicResourceType.CAMPAIGN);
        const campaign = await prisma_1.default.campaign.findFirst({
            where: { id: internalCampaignId, companyId: ctx.companyId },
            select: { id: true, resourceKey: true },
        });
        if (!campaign) {
            throw new errors_1.ValidationError("Campaign not found");
        }
        campaign_access_service_1.campaignAccessService.assertCampaignAccess(ctx, campaign.id);
        const company = await prisma_1.default.company.findUnique({
            where: { id: ctx.companyId },
            select: { cli: true },
        });
        if (!company?.cli) {
            throw new errors_1.ValidationError("Company public identity is not configured");
        }
        const { phoneNumber, callLog } = await this.createOutboundCallRecords({
            companyId: ctx.companyId,
            campaignId: campaign.id,
            campaignResourceKey: campaign.resourceKey,
            companyCli: company.cli,
            normalizedPhone,
        });
        const dispatchResult = await this.dispatchService.requestDispatch({
            companyId: ctx.companyId,
            callLogId: callLog.id,
            callLogPublicId: callLog.publicId,
            phone: phoneNumber.number,
            campaignPublicId,
        });
        return {
            callLogId: callLog.publicId,
            phoneNumberId: phoneNumber.publicId,
            status: dispatchResult.status,
        };
    }
    async createRetryOutboundCall(ctx, input) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CALL_LOGS_WRITE);
        const campaignPublicId = input.campaignId?.trim();
        if (!campaignPublicId) {
            throw new errors_1.ValidationError("Campaign ID is required");
        }
        const phoneRaw = input.phoneNumber?.trim();
        if (!phoneRaw) {
            throw new errors_1.ValidationError("Phone number is required");
        }
        const normalizedPhone = (0, phone_validation_1.normalizeOutboundPhone)(phoneRaw);
        if (!normalizedPhone) {
            throw new errors_1.ValidationError("Phone number must be in E.164 format");
        }
        const internalCampaignId = await (0, mapper_1.resolveResourceId)(ctx, campaignPublicId, types_1.PublicResourceType.CAMPAIGN);
        const campaign = await prisma_1.default.campaign.findFirst({
            where: { id: internalCampaignId, companyId: ctx.companyId },
            select: { id: true, resourceKey: true },
        });
        if (!campaign) {
            throw new errors_1.ValidationError("Campaign not found");
        }
        campaign_access_service_1.campaignAccessService.assertCampaignAccess(ctx, campaign.id);
        const parentCall = await prisma_1.default.callLog.findFirst({
            where: {
                id: input.parentCallLogId,
                companyId: ctx.companyId,
                campaignId: campaign.id,
            },
            select: { id: true },
        });
        if (!parentCall) {
            throw new errors_1.ValidationError("Parent call log not found");
        }
        const company = await prisma_1.default.company.findUnique({
            where: { id: ctx.companyId },
            select: { cli: true },
        });
        if (!company?.cli) {
            throw new errors_1.ValidationError("Company public identity is not configured");
        }
        const { phoneNumber, callLog } = await this.createOutboundCallRecords({
            companyId: ctx.companyId,
            campaignId: campaign.id,
            campaignResourceKey: campaign.resourceKey,
            companyCli: company.cli,
            normalizedPhone,
            retryNumber: input.retryNumber,
            parentCallLogId: input.parentCallLogId,
            isRetry: true,
            retryReason: input.retryReason,
            correlationId: input.correlationId,
        });
        const dispatchResult = await this.dispatchService.requestDispatch({
            companyId: ctx.companyId,
            callLogId: callLog.id,
            callLogPublicId: callLog.publicId,
            phone: phoneNumber.number,
            campaignPublicId,
        });
        return {
            callLogId: callLog.publicId,
            phoneNumberId: phoneNumber.publicId,
            status: dispatchResult.status,
        };
    }
    async createOutboundCallRecords(input) {
        try {
            return await prisma_1.default.$transaction(async (tx) => {
                let phoneNumber = await this.phoneNumbersRepo.findByCampaignAndNumber(tx, input.companyId, input.campaignId, input.normalizedPhone);
                if (!phoneNumber) {
                    phoneNumber = await this.phoneNumbersRepo.createForCampaign(tx, input.companyId, input.campaignId, input.normalizedPhone, input.campaignResourceKey, input.companyCli);
                }
                const callLog = await this.callLogsRepo.createOutboundPending(tx, {
                    companyId: input.companyId,
                    campaignId: input.campaignId,
                    phoneNumberId: phoneNumber.id,
                    campaignResourceKey: input.campaignResourceKey,
                    companyCli: input.companyCli,
                    retryNumber: input.retryNumber,
                    parentCallLogId: input.parentCallLogId,
                    isRetry: input.isRetry,
                    retryReason: input.retryReason,
                    correlationId: input.correlationId,
                });
                return { phoneNumber, callLog };
            });
        }
        catch (error) {
            if (error instanceof client_1.Prisma.PrismaClientKnownRequestError &&
                error.code === "P2002") {
                return prisma_1.default.$transaction(async (tx) => {
                    const phoneNumber = await this.phoneNumbersRepo.findByCampaignAndNumber(tx, input.companyId, input.campaignId, input.normalizedPhone);
                    if (!phoneNumber) {
                        throw error;
                    }
                    const callLog = await this.callLogsRepo.createOutboundPending(tx, {
                        companyId: input.companyId,
                        campaignId: input.campaignId,
                        phoneNumberId: phoneNumber.id,
                        campaignResourceKey: input.campaignResourceKey,
                        companyCli: input.companyCli,
                        retryNumber: input.retryNumber,
                        parentCallLogId: input.parentCallLogId,
                        isRetry: input.isRetry,
                        retryReason: input.retryReason,
                        correlationId: input.correlationId,
                    });
                    return { phoneNumber, callLog };
                });
            }
            throw error;
        }
    }
}
exports.OutboundCallsService = OutboundCallsService;
exports.outboundCallsService = new OutboundCallsService();
//# sourceMappingURL=outbound-calls.service.js.map