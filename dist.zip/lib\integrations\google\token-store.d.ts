import type { TenantContext } from "../../../server/types/context";
export type GoogleTokenSet = {
    accessToken: string;
    refreshToken: string;
    expiryDate: number | null;
    scope: string;
    tokenType: string;
    email: string | null;
};
export declare function getGoogleTokens(ctx: TenantContext): Promise<GoogleTokenSet | null>;
export declare function saveGoogleTokens(ctx: TenantContext, tokens: GoogleTokenSet): Promise<void>;
export declare function clearGoogleTokens(ctx: TenantContext): Promise<void>;
export declare function hasGoogleTokens(ctx: TenantContext): Promise<boolean>;
