export declare const LEADS_REACTIVATION_QUERY = "\n  query LeadsReactivation($after: String, $filter: LeadFilter) {\n    leads {\n      connection(first: 50, after: $after, filter: $filter) {\n        edges {\n          node {\n            id\n            firstName\n            lastName\n            email\n            phone\n            temperature\n            score\n            lastContactedAt\n            sourceName\n            stageName\n          }\n          cursor\n        }\n        pageInfo {\n          hasNextPage\n          endCursor\n        }\n      }\n      temperatureBreakdown {\n        hot\n        warm\n        cold\n        total\n      }\n    }\n  }\n";
export type LeadsReactivationResult = {
    leads: {
        connection: {
            edges: {
                node: {
                    id: string;
                    firstName: string | null;
                    lastName: string | null;
                    email: string | null;
                    phone: string | null;
                    temperature: string | null;
                    score: number;
                    lastContactedAt: string | null;
                    sourceName: string | null;
                    stageName: string | null;
                };
                cursor: string;
            }[];
            pageInfo: {
                hasNextPage: boolean;
                endCursor: string | null;
            };
        };
        temperatureBreakdown: {
            hot: number;
            warm: number;
            cold: number;
            total: number;
        };
    };
};
export declare const IMPORT_LEADS_MUTATION = "\n  mutation ImportLeads($rows: [LeadImportRowInput!]!) {\n    leads {\n      importRows(rows: $rows) {\n        hot\n        warm\n        cold\n        total\n        invalid\n        created\n        updated\n      }\n    }\n  }\n";
export type LeadImportResult = {
    leads: {
        importRows: {
            hot: number;
            warm: number;
            cold: number;
            total: number;
            invalid: number;
            created: number;
            updated: number;
        };
    };
};
