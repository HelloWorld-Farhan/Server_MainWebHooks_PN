"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadHomePage = loadHomePage;
exports.loadBillingPage = loadBillingPage;
exports.loadCallLogsPage = loadCallLogsPage;
exports.loadCallDetailPage = loadCallDetailPage;
exports.loadAgentsPage = loadAgentsPage;
exports.loadAgentDetailPage = loadAgentDetailPage;
exports.loadAgentLibraryPage = loadAgentLibraryPage;
exports.loadAgentTemplatePage = loadAgentTemplatePage;
exports.loadLeadReactivationPage = loadLeadReactivationPage;
exports.loadSetupPage = loadSetupPage;
exports.loadSettingsPage = loadSettingsPage;
exports.loadPhoneDetailPage = loadPhoneDetailPage;
exports.loadPhoneContactsPage = loadPhoneContactsPage;
const queries_1 = require("../../../lib/graphql/queries");
const execute_graphql_1 = require("../execute-graphql");
async function loadHomePage(request, params) {
    const filter = params.filter;
    return (0, execute_graphql_1.executeGraphQLFromRequest)(request, queries_1.HOME_PAGE_QUERY, {
        dateFrom: filter?.dateFrom,
        dateTo: filter?.dateTo,
    });
}
async function loadBillingPage(request, params) {
    return (0, execute_graphql_1.executeGraphQLFromRequest)(request, queries_1.BILLING_PAGE_QUERY, {
        after: params.after,
    });
}
async function loadCallLogsPage(request, params) {
    return (0, execute_graphql_1.executeGraphQLFromRequest)(request, queries_1.CALL_LOGS_PAGE_QUERY, {
        after: params.after,
        filter: params.filter,
    });
}
async function loadCallDetailPage(request, params) {
    if (!params.id) {
        throw new Error("id is required for call-detail page cache");
    }
    return (0, execute_graphql_1.executeGraphQLFromRequest)(request, queries_1.CALL_DETAIL_QUERY, {
        id: params.id,
    });
}
async function loadAgentsPage(request, _params) {
    return (0, execute_graphql_1.executeGraphQLFromRequest)(request, queries_1.AGENTS_LIST_QUERY);
}
async function loadAgentDetailPage(request, params) {
    if (!params.id) {
        throw new Error("id is required for agent-detail page cache");
    }
    return (0, execute_graphql_1.executeGraphQLFromRequest)(request, queries_1.AGENT_DETAIL_PAGE_QUERY, {
        id: params.id,
    });
}
async function loadAgentLibraryPage(request, _params) {
    return (0, execute_graphql_1.executeGraphQLFromRequest)(request, queries_1.AGENT_LIBRARY_LIST_QUERY);
}
async function loadAgentTemplatePage(request, params) {
    if (!params.slug) {
        throw new Error("slug is required for agent-template page cache");
    }
    return (0, execute_graphql_1.executeGraphQLFromRequest)(request, queries_1.AGENT_LIBRARY_BY_SLUG_QUERY, {
        slug: params.slug,
    });
}
async function loadLeadReactivationPage(request, params) {
    return (0, execute_graphql_1.executeGraphQLFromRequest)(request, queries_1.LEADS_REACTIVATION_QUERY, {
        after: params.after,
        filter: params.filter,
    });
}
async function loadSetupPage(request, _params) {
    return (0, execute_graphql_1.executeGraphQLFromRequest)(request, queries_1.SETUP_PAGE_QUERY);
}
async function loadSettingsPage(request, _params) {
    return (0, execute_graphql_1.executeGraphQLFromRequest)(request, queries_1.SETTINGS_PAGE_QUERY);
}
async function loadPhoneDetailPage(request, params) {
    if (!params.id) {
        throw new Error("id is required for phone-detail page cache");
    }
    return (0, execute_graphql_1.executeGraphQLFromRequest)(request, queries_1.PHONE_NUMBER_DETAIL_QUERY, {
        id: params.id,
        after: params.after,
    });
}
async function loadPhoneContactsPage(request, _params) {
    return (0, execute_graphql_1.executeGraphQLFromRequest)(request, queries_1.UPLOADED_CONTACTS_LIST_QUERY);
}
//# sourceMappingURL=index.js.map