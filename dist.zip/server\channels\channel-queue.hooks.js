"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerCompanyQueueWake = registerCompanyQueueWake;
exports.wakeCompanyQueue = wakeCompanyQueue;
let wakeFn = null;
function registerCompanyQueueWake(fn) {
    wakeFn = fn;
}
function wakeCompanyQueue(companyId) {
    if (!wakeFn) {
        return;
    }
    void wakeFn(companyId).catch((error) => {
        console.warn("[channels] wakeCompanyQueue failed", {
            companyId,
            error: error instanceof Error ? error.message : String(error),
        });
    });
}
//# sourceMappingURL=channel-queue.hooks.js.map