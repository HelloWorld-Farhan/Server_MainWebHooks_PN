"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EventsRepository = void 0;
const base_repository_1 = require("./base.repository");
class EventsRepository extends base_repository_1.BaseRepository {
    listRecent(companyId, limit) {
        return this.prisma.systemEvent.findMany({
            where: this.scope(companyId),
            orderBy: { createdAt: "desc" },
            take: limit,
        });
    }
    create(companyId, data) {
        return this.prisma.systemEvent.create({
            data: {
                companyId,
                type: data.type,
                actorId: data.actorId,
                entityType: data.entityType,
                entityId: data.entityId,
                title: data.title,
                payload: data.payload ?? {},
            },
        });
    }
}
exports.EventsRepository = EventsRepository;
//# sourceMappingURL=events.repository.js.map