export { PERMISSIONS, API_KEY_SCOPE_CATALOG, type Permission, mergePermissions, hasPermission, hasAnyPermission, hasAllPermissions, getPermissionLabels, getApiKeyScopeLabels, isApiKeyScope, ROLE_LABELS, } from "../../lib/permissions";
import type { UserRole } from "@prisma/client";
import { type Permission } from "../../lib/permissions";
export declare function getPermissionsForRole(role: UserRole): Permission[];
