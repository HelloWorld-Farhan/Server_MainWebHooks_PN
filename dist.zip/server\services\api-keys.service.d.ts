import type { ApiKeyEnvironment, CampaignAccessType } from "@prisma/client";
import { type ApiKeyFilter } from "../repositories/api-keys.repository";
import type { TenantContext } from "../types/context";
export type CreateApiKeyInput = {
    name: string;
    description?: string | null;
    environment: ApiKeyEnvironment;
    scopes: string[];
    campaignAccessType?: CampaignAccessType;
    campaignIds?: string[];
    expiresAt?: string | null;
};
export type UpdateApiKeyInput = {
    name?: string;
    description?: string | null;
};
export declare class ApiKeysService {
    private readonly repo;
    private audit;
    private validateScopes;
    private validateCampaigns;
    private enforcePrincipalSubset;
    getConnection(ctx: TenantContext, args: {
        first?: number | null;
        after?: string | null;
        filter?: ApiKeyFilter | null;
    }): Promise<{
        edges: {
            cursor: string;
            node: {
                id: string;
                name: string;
                description: string | null;
                keyId: string;
                maskedSecret: string;
                keyPrefix: string;
                environment: import("@prisma/client").$Enums.ApiKeyEnvironment;
                status: import("@prisma/client").$Enums.ApiKeyStatus;
                scopes: string[];
                campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
                campaignIds: string[];
                expiresAt: string | null;
                lastUsedAt: string | null;
                createdAt: string;
                updatedAt: string;
                createdBy: {
                    id: string;
                    email: string;
                    firstName: string | null;
                    lastName: string | null;
                } | null;
            };
        }[];
        pageInfo: import("../lib/pagination").PageInfo;
        totalCount: number;
    }>;
    getById(ctx: TenantContext, id: string): Promise<{
        id: string;
        name: string;
        description: string | null;
        keyId: string;
        maskedSecret: string;
        keyPrefix: string;
        environment: import("@prisma/client").$Enums.ApiKeyEnvironment;
        status: import("@prisma/client").$Enums.ApiKeyStatus;
        scopes: string[];
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        campaignIds: string[];
        expiresAt: string | null;
        lastUsedAt: string | null;
        createdAt: string;
        updatedAt: string;
        createdBy: {
            id: string;
            email: string;
            firstName: string | null;
            lastName: string | null;
        } | null;
    } | null>;
    listAvailableScopes(ctx: TenantContext): {
        scope: import("../../lib/permissions").Permission;
        label: string;
    }[];
    listAccessibleCampaigns(ctx: TenantContext): Promise<{
        id: string;
        name: string;
        status: import("@prisma/client").$Enums.CampaignStatus;
    }[]>;
    create(ctx: TenantContext, input: CreateApiKeyInput): Promise<{
        secret: string;
        id: string;
        name: string;
        description: string | null;
        keyId: string;
        maskedSecret: string;
        keyPrefix: string;
        environment: import("@prisma/client").$Enums.ApiKeyEnvironment;
        status: import("@prisma/client").$Enums.ApiKeyStatus;
        scopes: string[];
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        campaignIds: string[];
        expiresAt: string | null;
        lastUsedAt: string | null;
        createdAt: string;
        updatedAt: string;
        createdBy: {
            id: string;
            email: string;
            firstName: string | null;
            lastName: string | null;
        } | null;
    }>;
    update(ctx: TenantContext, id: string, input: UpdateApiKeyInput): Promise<{
        id: string;
        name: string;
        description: string | null;
        keyId: string;
        maskedSecret: string;
        keyPrefix: string;
        environment: import("@prisma/client").$Enums.ApiKeyEnvironment;
        status: import("@prisma/client").$Enums.ApiKeyStatus;
        scopes: string[];
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        campaignIds: string[];
        expiresAt: string | null;
        lastUsedAt: string | null;
        createdAt: string;
        updatedAt: string;
        createdBy: {
            id: string;
            email: string;
            firstName: string | null;
            lastName: string | null;
        } | null;
    }>;
    enable(ctx: TenantContext, id: string): Promise<{
        id: string;
        name: string;
        description: string | null;
        keyId: string;
        maskedSecret: string;
        keyPrefix: string;
        environment: import("@prisma/client").$Enums.ApiKeyEnvironment;
        status: import("@prisma/client").$Enums.ApiKeyStatus;
        scopes: string[];
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        campaignIds: string[];
        expiresAt: string | null;
        lastUsedAt: string | null;
        createdAt: string;
        updatedAt: string;
        createdBy: {
            id: string;
            email: string;
            firstName: string | null;
            lastName: string | null;
        } | null;
    }>;
    disable(ctx: TenantContext, id: string): Promise<{
        id: string;
        name: string;
        description: string | null;
        keyId: string;
        maskedSecret: string;
        keyPrefix: string;
        environment: import("@prisma/client").$Enums.ApiKeyEnvironment;
        status: import("@prisma/client").$Enums.ApiKeyStatus;
        scopes: string[];
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        campaignIds: string[];
        expiresAt: string | null;
        lastUsedAt: string | null;
        createdAt: string;
        updatedAt: string;
        createdBy: {
            id: string;
            email: string;
            firstName: string | null;
            lastName: string | null;
        } | null;
    }>;
    delete(ctx: TenantContext, id: string): Promise<{
        success: boolean;
        id: string;
    }>;
    regenerate(ctx: TenantContext, id: string): Promise<{
        secret: string;
        id: string;
        name: string;
        description: string | null;
        keyId: string;
        maskedSecret: string;
        keyPrefix: string;
        environment: import("@prisma/client").$Enums.ApiKeyEnvironment;
        status: import("@prisma/client").$Enums.ApiKeyStatus;
        scopes: string[];
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        campaignIds: string[];
        expiresAt: string | null;
        lastUsedAt: string | null;
        createdAt: string;
        updatedAt: string;
        createdBy: {
            id: string;
            email: string;
            firstName: string | null;
            lastName: string | null;
        } | null;
    }>;
    rotateSecret(ctx: TenantContext, id: string): Promise<{
        secret: string;
        id: string;
        name: string;
        description: string | null;
        keyId: string;
        maskedSecret: string;
        keyPrefix: string;
        environment: import("@prisma/client").$Enums.ApiKeyEnvironment;
        status: import("@prisma/client").$Enums.ApiKeyStatus;
        scopes: string[];
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        campaignIds: string[];
        expiresAt: string | null;
        lastUsedAt: string | null;
        createdAt: string;
        updatedAt: string;
        createdBy: {
            id: string;
            email: string;
            firstName: string | null;
            lastName: string | null;
        } | null;
    }>;
    updateScopes(ctx: TenantContext, id: string, scopes: string[]): Promise<{
        id: string;
        name: string;
        description: string | null;
        keyId: string;
        maskedSecret: string;
        keyPrefix: string;
        environment: import("@prisma/client").$Enums.ApiKeyEnvironment;
        status: import("@prisma/client").$Enums.ApiKeyStatus;
        scopes: string[];
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        campaignIds: string[];
        expiresAt: string | null;
        lastUsedAt: string | null;
        createdAt: string;
        updatedAt: string;
        createdBy: {
            id: string;
            email: string;
            firstName: string | null;
            lastName: string | null;
        } | null;
    }>;
    updateCampaignAccess(ctx: TenantContext, id: string, input: {
        campaignAccessType: CampaignAccessType;
        campaignIds?: string[];
    }): Promise<{
        id: string;
        name: string;
        description: string | null;
        keyId: string;
        maskedSecret: string;
        keyPrefix: string;
        environment: import("@prisma/client").$Enums.ApiKeyEnvironment;
        status: import("@prisma/client").$Enums.ApiKeyStatus;
        scopes: string[];
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        campaignIds: string[];
        expiresAt: string | null;
        lastUsedAt: string | null;
        createdAt: string;
        updatedAt: string;
        createdBy: {
            id: string;
            email: string;
            firstName: string | null;
            lastName: string | null;
        } | null;
    }>;
    updateExpiration(ctx: TenantContext, id: string, expiresAt: string | null): Promise<{
        id: string;
        name: string;
        description: string | null;
        keyId: string;
        maskedSecret: string;
        keyPrefix: string;
        environment: import("@prisma/client").$Enums.ApiKeyEnvironment;
        status: import("@prisma/client").$Enums.ApiKeyStatus;
        scopes: string[];
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        campaignIds: string[];
        expiresAt: string | null;
        lastUsedAt: string | null;
        createdAt: string;
        updatedAt: string;
        createdBy: {
            id: string;
            email: string;
            firstName: string | null;
            lastName: string | null;
        } | null;
    }>;
}
export declare const apiKeysService: ApiKeysService;
