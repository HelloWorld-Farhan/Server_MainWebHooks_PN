export declare const CACHE_TTL: {
    readonly CREDITS: number;
    readonly TOP_CALL_LOGS: number;
    readonly ANALYTICS: number;
    readonly PERMISSIONS: number;
    readonly AGENT_STATUS: 60;
    readonly PAGE_CACHE: 30;
    readonly CLERK_MEMBERSHIPS: 45;
    readonly CLERK_ORG_MEMBERSHIPS: 45;
    readonly RESOLVED_COMPANY: 30;
};
export declare const PAGE_CACHE_STALE_MS = 10000;
export declare const CLERK_MEMBERSHIPS_STALE_MS = 35000;
export type PageCacheKey = "home" | "billing" | "call-logs" | "call-detail" | "agents" | "agent-detail" | "agent-library" | "agent-template" | "lead-reactivation" | "setup" | "settings" | "phone-detail" | "phone-contacts";
export type PageCacheParams = {
    id?: string;
    slug?: string;
    after?: string;
    filter?: Record<string, unknown>;
};
export type ResolvedCompanyCache = {
    companyId: string;
    membershipId: string;
    role: string;
    cachedAt: number;
};
export declare const cacheKeys: {
    clerkMemberships: (clerkUserId: string) => string;
    clerkOrgMemberships: (orgId: string) => string;
    resolvedCompany: (clerkUserId: string) => string;
    companyCredits: (companyId: string) => string;
    companyTopCallLogs: (companyId: string) => string;
    companyAnalytics: (companyId: string) => string;
    userPermissions: (userId: string) => string;
    companyAgentStatus: (companyId: string) => string;
    page: (companyId: string, pageKey: PageCacheKey, params?: PageCacheParams) => string;
    pagePrefix: (companyId: string, pageKey: PageCacheKey) => string;
};
