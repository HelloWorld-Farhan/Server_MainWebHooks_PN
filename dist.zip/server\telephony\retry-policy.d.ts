import type { ProviderErrorDetails } from "./dto/provider-error.dto";
export declare function isRetryableHttpStatus(httpStatus: number): boolean;
export declare function isRetryableProviderError(error: ProviderErrorDetails): boolean;
