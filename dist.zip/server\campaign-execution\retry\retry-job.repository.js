"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.retryJobRepository = exports.RetryJobRepository = void 0;
const prisma_write_retry_1 = require("../../lib/prisma-write-retry");
const prisma_1 = __importDefault(require("../../lib/prisma"));
const base_repository_1 = require("../../repositories/base.repository");
class RetryJobRepository extends base_repository_1.BaseRepository {
    create(data) {
        return this.prisma.contactRetryJob.create({ data });
    }
    findDuePending(limit, now) {
        return this.prisma.contactRetryJob.findMany({
            where: {
                status: "PENDING",
                scheduledAt: { lte: now },
            },
            orderBy: [{ scheduledAt: "asc" }, { id: "asc" }],
            take: limit,
        });
    }
    findByParentCallLogId(parentCallLogId) {
        return this.prisma.contactRetryJob.findUnique({
            where: { parentCallLogId },
        });
    }
    findPendingForCampaign(companyId, campaignId) {
        return this.prisma.contactRetryJob.findMany({
            where: {
                companyId,
                campaignId,
                status: { in: ["PENDING", "PROCESSING"] },
            },
            orderBy: [{ scheduledAt: "asc" }, { id: "asc" }],
        });
    }
    findHistoryForCampaign(companyId, campaignId, phoneNumber) {
        return this.prisma.contactRetryJob.findMany({
            where: {
                companyId,
                campaignId,
                ...(phoneNumber ? { phoneNumber } : {}),
            },
            orderBy: [{ createdAt: "asc" }, { id: "asc" }],
        });
    }
    countPendingForPhone(companyId, campaignId, phoneNumber) {
        return this.prisma.contactRetryJob.count({
            where: {
                companyId,
                campaignId,
                phoneNumber,
                status: { in: ["PENDING", "PROCESSING"] },
            },
        });
    }
    claimJob(id) {
        return this.prisma.contactRetryJob.updateMany({
            where: { id, status: "PENDING" },
            data: { status: "PROCESSING" },
        });
    }
    completeJob(id, data) {
        return this.prisma.contactRetryJob.update({
            where: { id },
            data: {
                status: "COMPLETED",
                createdCallLogId: data.createdCallLogId,
                processedAt: data.processedAt,
            },
        });
    }
    skipJob(id, skipReason) {
        return this.prisma.contactRetryJob.update({
            where: { id },
            data: {
                status: "SKIPPED",
                skipReason,
                processedAt: new Date(),
            },
        });
    }
    failJob(id, skipReason) {
        return this.prisma.contactRetryJob.update({
            where: { id },
            data: {
                status: "FAILED",
                skipReason,
                processedAt: new Date(),
            },
        });
    }
    cancelPendingForCampaign(companyId, campaignId) {
        return this.prisma.contactRetryJob.updateMany({
            where: {
                companyId,
                campaignId,
                status: "PENDING",
            },
            data: {
                status: "CANCELLED",
                skipReason: "Campaign cancelled",
                processedAt: new Date(),
            },
        });
    }
    countByStatus(companyId, campaignId, status) {
        return this.prisma.contactRetryJob.count({
            where: { companyId, campaignId, status },
        });
    }
    incrementExecutionCounters(companyId, campaignId, data) {
        return (0, prisma_write_retry_1.withPrismaWriteRetry)(() => this.prisma.campaignExecution.updateMany({
            where: { companyId, campaignId },
            data,
        }));
    }
}
exports.RetryJobRepository = RetryJobRepository;
exports.retryJobRepository = new RetryJobRepository(prisma_1.default);
//# sourceMappingURL=retry-job.repository.js.map