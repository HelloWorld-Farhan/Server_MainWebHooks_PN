import type { PrismaClient } from "@prisma/client";
export declare function generateContractId(): string;
export declare function normalizeContractId(input: string): string | null;
export declare function generateUniqueContractId(prisma: PrismaClient): Promise<string>;
