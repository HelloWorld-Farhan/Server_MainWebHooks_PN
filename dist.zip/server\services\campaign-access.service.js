"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.campaignAccessService = exports.CampaignAccessService = void 0;
exports.buildCampaignAccessFromMember = buildCampaignAccessFromMember;
const errors_1 = require("../lib/errors");
function buildCampaignAccessFromMember(data) {
    if (data.role === "OWNER" || data.campaignAccessType === "ALL") {
        return { type: "ALL", campaignIds: [] };
    }
    return {
        type: "SELECTED",
        campaignIds: data.campaignAccess?.map((row) => row.campaignId) ?? [],
    };
}
class CampaignAccessService {
    hasAllCampaignAccess(ctx) {
        return ctx.role === "OWNER" || ctx.campaignAccess.type === "ALL";
    }
    assertCampaignAccess(ctx, campaignId) {
        if (this.hasAllCampaignAccess(ctx))
            return;
        if (!ctx.campaignAccess.campaignIds.includes(campaignId)) {
            throw new errors_1.ForbiddenError("You do not have access to this campaign");
        }
    }
    assertCampaignIdsAccess(ctx, campaignIds) {
        if (this.hasAllCampaignAccess(ctx))
            return;
        const allowed = new Set(ctx.campaignAccess.campaignIds);
        const denied = campaignIds.filter((id) => !allowed.has(id));
        if (denied.length > 0) {
            throw new errors_1.ForbiddenError("You do not have access to one or more campaigns");
        }
    }
    campaignIdScopeFilter(ctx) {
        if (this.hasAllCampaignAccess(ctx))
            return {};
        return { id: { in: ctx.campaignAccess.campaignIds } };
    }
    campaignRelationFilter(ctx) {
        if (this.hasAllCampaignAccess(ctx))
            return {};
        return { campaignId: { in: ctx.campaignAccess.campaignIds } };
    }
    callLogCampaignFilter(ctx) {
        if (this.hasAllCampaignAccess(ctx))
            return {};
        return { campaignId: { in: ctx.campaignAccess.campaignIds } };
    }
    employeeScopeFilter(ctx) {
        if (this.hasAllCampaignAccess(ctx))
            return {};
        const campaignIds = ctx.campaignAccess.campaignIds;
        if (campaignIds.length === 0) {
            return { id: { in: [] } };
        }
        return {
            OR: [
                { campaignAccessType: "ALL" },
                {
                    campaignAccess: {
                        some: { campaignId: { in: campaignIds } },
                    },
                },
            ],
        };
    }
    assertEmployeeVisible(ctx, employee) {
        if (this.hasAllCampaignAccess(ctx))
            return;
        if (employee.campaignAccessType === "ALL")
            return;
        const visibleIds = new Set(ctx.campaignAccess.campaignIds);
        const hasOverlap = employee.campaignAccess?.some((row) => visibleIds.has(row.campaignId));
        if (!hasOverlap) {
            throw new errors_1.ForbiddenError("You do not have access to this employee");
        }
    }
    mergeEmployeeWhere(ctx, where) {
        const scope = this.employeeScopeFilter(ctx);
        if (Object.keys(scope).length === 0)
            return where;
        return { AND: [where, scope] };
    }
    mergeLeadWhere(ctx, where) {
        const campaignFilter = this.campaignRelationFilter(ctx);
        if (Object.keys(campaignFilter).length === 0)
            return where;
        return { AND: [where, campaignFilter] };
    }
    mergeCallLogWhere(ctx, where) {
        const campaignFilter = this.callLogCampaignFilter(ctx);
        if (Object.keys(campaignFilter).length === 0)
            return where;
        return { AND: [where, campaignFilter] };
    }
    mergeCampaignWhere(ctx, where) {
        const campaignFilter = this.campaignIdScopeFilter(ctx);
        if (Object.keys(campaignFilter).length === 0)
            return where;
        return { AND: [where, campaignFilter] };
    }
    assertLeadCampaignAccess(ctx, campaignId) {
        if (!campaignId) {
            if (!this.hasAllCampaignAccess(ctx)) {
                throw new errors_1.ForbiddenError("You do not have access to this record");
            }
            return;
        }
        this.assertCampaignAccess(ctx, campaignId);
    }
    assertCallLogCampaignAccess(ctx, campaignId) {
        this.assertLeadCampaignAccess(ctx, campaignId);
    }
}
exports.CampaignAccessService = CampaignAccessService;
exports.campaignAccessService = new CampaignAccessService();
//# sourceMappingURL=campaign-access.service.js.map