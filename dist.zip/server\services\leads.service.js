"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.leadsService = exports.LeadsService = void 0;
const cache_service_1 = require("../cache/cache.service");
const errors_1 = require("../lib/errors");
const pagination_1 = require("../lib/pagination");
const prisma_1 = __importDefault(require("../lib/prisma"));
const leads_repository_1 = require("../repositories/leads.repository");
const permissions_1 = require("../types/permissions");
const events_service_1 = require("./events.service");
const campaign_access_service_1 = require("./campaign-access.service");
const tenant_service_1 = require("./tenant.service");
const E164_REGEX = /^\+[1-9]\d{1,14}$/;
const MAX_IMPORT_ROWS = 1000;
function parseTemperature(value) {
    const normalized = value.trim().toUpperCase();
    if (normalized === "HOT" || normalized === "WARM" || normalized === "COLD") {
        return normalized;
    }
    return null;
}
function mapLead(lead) {
    return {
        id: lead.id,
        firstName: lead.firstName,
        lastName: lead.lastName,
        email: lead.email,
        phone: lead.phone,
        temperature: lead.temperature,
        score: lead.score,
        lastContactedAt: lead.lastContactedAt?.toISOString() ?? null,
        createdAt: lead.createdAt.toISOString(),
        sourceName: lead.source?.name ?? null,
        stageName: lead.stage?.name ?? null,
    };
}
class LeadsService {
    repo = new leads_repository_1.LeadsRepository(prisma_1.default);
    async getConnection(ctx, args) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.LEADS_READ);
        const limit = Math.min(args.first ?? 20, 100);
        const scopeWhere = campaign_access_service_1.campaignAccessService.campaignRelationFilter(ctx);
        const items = await this.repo.findConnection(ctx.companyId, limit, args.after, args.filter, scopeWhere);
        const connection = (0, pagination_1.buildConnection)(items, limit, (item) => (0, pagination_1.encodeIdCursor)(item.id, item.createdAt));
        return {
            ...connection,
            edges: connection.edges.map(({ node, cursor }) => ({
                cursor,
                node: mapLead(node),
            })),
        };
    }
    async getById(ctx, id) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.LEADS_READ);
        const lead = await this.repo.findById(ctx.companyId, id);
        if (!lead) {
            throw new errors_1.NotFoundError("Lead not found");
        }
        campaign_access_service_1.campaignAccessService.assertLeadCampaignAccess(ctx, lead.campaignId);
        return {
            id: lead.id,
            firstName: lead.firstName,
            lastName: lead.lastName,
            email: lead.email,
            phone: lead.phone,
            temperature: lead.temperature,
            score: lead.score,
            lastContactedAt: lead.lastContactedAt?.toISOString() ?? null,
            createdAt: lead.createdAt.toISOString(),
            sourceName: lead.source?.name ?? null,
            stageName: lead.stage?.name ?? null,
        };
    }
    async getTemperatureBreakdown(ctx) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.LEADS_READ);
        const groups = await this.repo.countByTemperature(ctx.companyId, campaign_access_service_1.campaignAccessService.campaignRelationFilter(ctx));
        const breakdown = { hot: 0, warm: 0, cold: 0, total: 0 };
        for (const group of groups) {
            const count = group._count.id;
            breakdown.total += count;
            if (group.temperature === "HOT")
                breakdown.hot = count;
            if (group.temperature === "WARM")
                breakdown.warm = count;
            if (group.temperature === "COLD")
                breakdown.cold = count;
        }
        return breakdown;
    }
    async importRows(ctx, rows) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.LEADS_WRITE);
        const stats = {
            hot: 0,
            warm: 0,
            cold: 0,
            total: 0,
            invalid: 0,
            created: 0,
            updated: 0,
        };
        const validRows = [];
        for (const row of rows.slice(0, MAX_IMPORT_ROWS)) {
            const phone = row.phone.trim();
            if (!E164_REGEX.test(phone)) {
                stats.invalid++;
                continue;
            }
            const temperature = parseTemperature(row.temperature);
            if (!temperature) {
                stats.invalid++;
                continue;
            }
            validRows.push({
                firstName: row.firstName?.trim() || null,
                lastName: row.lastName?.trim() || null,
                email: row.email?.trim() || null,
                phone,
                temperature,
            });
        }
        const importStats = await this.repo.importRows(ctx.companyId, validRows);
        await events_service_1.eventsService.emit(ctx, {
            type: "LEAD_CREATED",
            entityType: "lead_import",
            title: `${importStats.created} leads imported from CSV`,
            payload: {
                created: importStats.created,
                updated: importStats.updated,
                invalid: stats.invalid + importStats.invalid,
                total: importStats.total,
            },
        });
        await cache_service_1.cacheService.invalidateLeadPages(ctx.companyId);
        return {
            ...importStats,
            invalid: stats.invalid + importStats.invalid,
        };
    }
}
exports.LeadsService = LeadsService;
exports.leadsService = new LeadsService();
//# sourceMappingURL=leads.service.js.map