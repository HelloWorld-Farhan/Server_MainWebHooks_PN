"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.clerkMembershipService = exports.ClerkMembershipService = void 0;
const clerk_1 = require("../../auth/clerk");
const cache_service_1 = require("../cache/cache.service");
const keys_1 = require("../cache/keys");
const debug_1 = require("../graphql/debug");
const clerk_errors_1 = require("../lib/clerk-errors");
const resolution_metrics_1 = require("../lib/resolution-metrics");
const MAX_RETRIES = 2;
const CIRCUIT_FAILURE_THRESHOLD = 3;
const CIRCUIT_COOLDOWN_MS = 30_000;
const CIRCUIT_WINDOW_MS = 60_000;
const pendingUserFetches = new Map();
const pendingOrgFetches = new Map();
const userCircuit = { failures: [], openUntil: 0 };
const orgCircuit = { failures: [], openUntil: 0 };
function recordFailure(circuit) {
    const now = Date.now();
    circuit.failures = circuit.failures.filter((t) => now - t < CIRCUIT_WINDOW_MS);
    circuit.failures.push(now);
    if (circuit.failures.length >= CIRCUIT_FAILURE_THRESHOLD) {
        circuit.openUntil = now + CIRCUIT_COOLDOWN_MS;
        (0, resolution_metrics_1.incrementMetric)("circuit_breaker_opens");
        (0, resolution_metrics_1.logResolutionEvent)("clerk:circuit-breaker:open", {
            failures: circuit.failures.length,
            cooldownMs: CIRCUIT_COOLDOWN_MS,
        });
    }
}
function isCircuitOpen(circuit) {
    return Date.now() < circuit.openUntil;
}
function resetCircuit(circuit) {
    circuit.failures = [];
    circuit.openUntil = 0;
}
async function callClerkWithRetry(label, circuit, fn) {
    let lastError;
    for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
        try {
            (0, resolution_metrics_1.incrementMetric)("clerk_api_requests");
            const start = performance.now();
            const result = await (0, debug_1.gqlDebugTimed)(label, fn);
            (0, debug_1.gqlDebug)("clerk:api:latency", {
                label,
                ms: Math.round(performance.now() - start),
            });
            resetCircuit(circuit);
            return result;
        }
        catch (error) {
            lastError = error;
            if ((0, clerk_errors_1.isClerkOrganizationsUnavailable)(error)) {
                throw error;
            }
            if ((0, clerk_errors_1.isClerkRateLimited)(error)) {
                (0, resolution_metrics_1.incrementMetric)("clerk_api_429");
                recordFailure(circuit);
                if (attempt < MAX_RETRIES) {
                    (0, resolution_metrics_1.incrementMetric)("clerk_api_retries");
                    const delayMs = (0, clerk_errors_1.getClerkRetryAfter)(error);
                    (0, debug_1.gqlDebug)("clerk:rate-limited:retry", { label, attempt, delayMs });
                    await (0, clerk_errors_1.sleep)(delayMs);
                    continue;
                }
            }
            else {
                recordFailure(circuit);
            }
            throw error;
        }
    }
    throw lastError;
}
async function fetchUserMembershipsFromClerk(clerkUserId) {
    const client = clerk_1.clerkClient;
    try {
        const result = await callClerkWithRetry("clerk:getUserMemberships", userCircuit, () => client.users.getOrganizationMembershipList({
            userId: clerkUserId,
            limit: 10,
        }));
        return {
            data: result.data,
            totalCount: result.totalCount,
        };
    }
    catch (error) {
        if ((0, clerk_errors_1.isClerkOrganizationsUnavailable)(error)) {
            return { data: [], totalCount: 0 };
        }
        throw error;
    }
}
async function fetchOrgMembershipsFromClerk(orgId) {
    const client = clerk_1.clerkClient;
    try {
        const result = await callClerkWithRetry("clerk:getOrgMemberships", orgCircuit, () => client.organizations.getOrganizationMembershipList({
            organizationId: orgId,
            limit: 100,
        }));
        return {
            data: result.data,
            totalCount: result.totalCount,
        };
    }
    catch (error) {
        if ((0, clerk_errors_1.isClerkNotFound)(error) || (0, clerk_errors_1.isClerkOrganizationsUnavailable)(error)) {
            return { data: [], totalCount: 0 };
        }
        throw error;
    }
}
async function readMembershipCache(key) {
    const payload = await cache_service_1.cacheService.getCachedPayload(key);
    return payload?.data ?? null;
}
async function writeMembershipCache(key, data, ttlSeconds) {
    await cache_service_1.cacheService.setCachedPayload(key, data, ttlSeconds);
}
function scheduleBackgroundRefresh(key, refresh) {
    void refresh().catch((error) => {
        (0, debug_1.gqlDebug)("clerk:swr:refresh:error", {
            key,
            error: error instanceof Error ? error.message : String(error),
        });
    });
}
class ClerkMembershipService {
    async getUserMemberships(clerkUserId) {
        const cacheKey = keys_1.cacheKeys.clerkMemberships(clerkUserId);
        if (isCircuitOpen(userCircuit)) {
            const stale = await readMembershipCache(cacheKey);
            if (stale) {
                (0, debug_1.gqlDebug)("clerk:circuit-breaker:stale-hit", { clerkUserId });
                return stale;
            }
            return { data: [], totalCount: 0 };
        }
        const cachedPayload = await cache_service_1.cacheService.getCachedPayload(cacheKey);
        if (cachedPayload) {
            const ageMs = Date.now() - cachedPayload.cachedAt;
            (0, resolution_metrics_1.incrementMetric)("redis_membership_hit");
            (0, debug_1.gqlDebug)("clerk:memberships:cache-hit", { clerkUserId, ageMs });
            if (ageMs >= keys_1.CLERK_MEMBERSHIPS_STALE_MS) {
                scheduleBackgroundRefresh(cacheKey, async () => {
                    await this.refreshUserMemberships(clerkUserId);
                });
            }
            return cachedPayload.data;
        }
        (0, resolution_metrics_1.incrementMetric)("redis_membership_miss");
        return this.refreshUserMemberships(clerkUserId);
    }
    async refreshUserMemberships(clerkUserId) {
        const cacheKey = keys_1.cacheKeys.clerkMemberships(clerkUserId);
        const pendingKey = `user:${clerkUserId}`;
        const existing = pendingUserFetches.get(pendingKey);
        if (existing) {
            (0, debug_1.gqlDebug)("clerk:memberships:dedup", { clerkUserId });
            return existing;
        }
        const promise = (async () => {
            try {
                if (isCircuitOpen(userCircuit)) {
                    const stale = await readMembershipCache(cacheKey);
                    if (stale)
                        return stale;
                    return { data: [], totalCount: 0 };
                }
                const data = await fetchUserMembershipsFromClerk(clerkUserId);
                await writeMembershipCache(cacheKey, data, keys_1.CACHE_TTL.CLERK_MEMBERSHIPS);
                return data;
            }
            catch (error) {
                const stale = await readMembershipCache(cacheKey);
                if (stale) {
                    (0, debug_1.gqlDebug)("clerk:memberships:fallback-stale", { clerkUserId });
                    return stale;
                }
                if ((0, clerk_errors_1.isClerkRateLimited)(error)) {
                    (0, debug_1.gqlDebug)("clerk:memberships:rate-limited-empty", { clerkUserId });
                    return { data: [], totalCount: 0 };
                }
                if ((0, clerk_errors_1.isClerkOrganizationsUnavailable)(error)) {
                    (0, debug_1.gqlDebug)("clerk:memberships:orgs-unavailable-empty", { clerkUserId });
                    return { data: [], totalCount: 0 };
                }
                throw error;
            }
        })();
        pendingUserFetches.set(pendingKey, promise);
        try {
            return await promise;
        }
        finally {
            pendingUserFetches.delete(pendingKey);
        }
    }
    async getOrgMemberships(orgId) {
        if (!orgId.startsWith("org_")) {
            return { data: [], totalCount: 0 };
        }
        const cacheKey = keys_1.cacheKeys.clerkOrgMemberships(orgId);
        if (isCircuitOpen(orgCircuit)) {
            const stale = await readMembershipCache(cacheKey);
            if (stale)
                return stale;
            return { data: [], totalCount: 0 };
        }
        const cachedPayload = await cache_service_1.cacheService.getCachedPayload(cacheKey);
        if (cachedPayload) {
            const ageMs = Date.now() - cachedPayload.cachedAt;
            if (ageMs < keys_1.CLERK_MEMBERSHIPS_STALE_MS) {
                return cachedPayload.data;
            }
            scheduleBackgroundRefresh(cacheKey, async () => {
                await this.refreshOrgMemberships(orgId);
            });
            return cachedPayload.data;
        }
        return this.refreshOrgMemberships(orgId);
    }
    async refreshOrgMemberships(orgId) {
        const cacheKey = keys_1.cacheKeys.clerkOrgMemberships(orgId);
        const pendingKey = `org:${orgId}`;
        const existing = pendingOrgFetches.get(pendingKey);
        if (existing)
            return existing;
        const promise = (async () => {
            try {
                const data = await fetchOrgMembershipsFromClerk(orgId);
                await writeMembershipCache(cacheKey, data, keys_1.CACHE_TTL.CLERK_ORG_MEMBERSHIPS);
                return data;
            }
            catch {
                const stale = await readMembershipCache(cacheKey);
                if (stale)
                    return stale;
                return { data: [], totalCount: 0 };
            }
        })();
        pendingOrgFetches.set(pendingKey, promise);
        try {
            return await promise;
        }
        finally {
            pendingOrgFetches.delete(pendingKey);
        }
    }
    async getMembershipInOrg(clerkUserId, clerkOrganizationId) {
        if (!clerkOrganizationId.startsWith("org_")) {
            return null;
        }
        const fromUser = (await this.getUserMemberships(clerkUserId)).data.find((membership) => membership.organization.id === clerkOrganizationId);
        if (fromUser) {
            return fromUser;
        }
        const orgList = await this.getOrgMemberships(clerkOrganizationId);
        return (orgList.data.find((membership) => membership.publicUserData?.userId === clerkUserId) ?? null);
    }
    async isOrganizationMember(organizationId, userId) {
        const membership = await this.getMembershipInOrg(userId, organizationId);
        return membership !== null;
    }
    async invalidateUser(clerkUserId) {
        await cache_service_1.cacheService.invalidateClerkMembershipCaches(clerkUserId);
    }
    async invalidateOrg(orgId) {
        await cache_service_1.cacheService.del(keys_1.cacheKeys.clerkOrgMemberships(orgId));
        (0, resolution_metrics_1.incrementMetric)("cache_invalidations");
    }
}
exports.ClerkMembershipService = ClerkMembershipService;
exports.clerkMembershipService = new ClerkMembershipService();
//# sourceMappingURL=clerk-membership.service.js.map