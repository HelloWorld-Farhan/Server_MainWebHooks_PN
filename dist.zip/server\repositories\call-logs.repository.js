"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CallLogsRepository = void 0;
const public_id_1 = require("../lib/public-id");
const types_1 = require("../lib/public-id/types");
const base_repository_1 = require("./base.repository");
const pagination_1 = require("../lib/pagination");
const resource_key_1 = require("../lib/resource-key");
class CallLogsRepository extends base_repository_1.BaseRepository {
    buildWhere(companyId, filter, scopeWhere) {
        const where = this.scope(companyId);
        if (filter?.direction)
            where.direction = filter.direction;
        if (filter?.status)
            where.status = filter.status;
        if (filter?.aiAgentId)
            where.aiAgentId = filter.aiAgentId;
        if (filter?.campaignId)
            where.campaignId = filter.campaignId;
        if (filter?.phoneNumberId)
            where.phoneNumberId = filter.phoneNumberId;
        if (filter?.assignedUserId)
            where.assignedUserId = filter.assignedUserId;
        if (filter?.dateFrom || filter?.dateTo) {
            where.startedAt = {};
            if (filter.dateFrom)
                where.startedAt.gte = filter.dateFrom;
            if (filter.dateTo)
                where.startedAt.lte = filter.dateTo;
        }
        if (filter?.search) {
            const term = filter.search.trim();
            where.OR = [
                { lead: { firstName: { contains: term, mode: 'insensitive' } } },
                { lead: { lastName: { contains: term, mode: 'insensitive' } } },
                { lead: { phone: { contains: term } } },
                { lead: { email: { contains: term, mode: 'insensitive' } } },
                { callLogId: { contains: term, mode: 'insensitive' } },
                { publicId: { contains: term, mode: 'insensitive' } },
                { phoneNumber: { number: { contains: term } } },
            ];
        }
        if (filter?.callLogId) {
            const term = filter.callLogId.trim();
            where.AND = [
                ...(Array.isArray(where.AND) ? where.AND : []),
                {
                    OR: [
                        { callLogId: { contains: term, mode: 'insensitive' } },
                        { publicId: { contains: term, mode: 'insensitive' } },
                    ],
                },
            ];
        }
        if (scopeWhere && Object.keys(scopeWhere).length > 0) {
            return { AND: [where, scopeWhere] };
        }
        return where;
    }
    findConnection(companyId, limit, after, filter, scopeWhere) {
        const cursor = after ? (0, pagination_1.decodeCursor)(after) : undefined;
        return this.prisma.callLog.findMany({
            where: this.buildWhere(companyId, filter, scopeWhere),
            orderBy: [{ startedAt: 'desc' }, { id: 'desc' }],
            take: limit + 1,
            ...(cursor
                ? {
                    cursor: { id: cursor.id },
                    skip: 1,
                }
                : {}),
            select: {
                id: true,
                companyId: true,
                callLogId: true,
                publicId: true,
                leadId: true,
                aiAgentId: true,
                phoneNumberId: true,
                assignedUserId: true,
                campaignId: true,
                direction: true,
                status: true,
                outcome: true,
                startedAt: true,
                durationSeconds: true,
                recordingUrl: true,
                transcriptUrl: true,
                cost: true,
                creditsUsed: true,
                provider: true,
                providerStatus: true,
                disconnectReason: true,
                aiSummary: true,
                sentiment: true,
                createdAt: true,
                updatedAt: true,
            },
        });
    }
    findRecent(companyId, limit, scopeWhere) {
        const where = scopeWhere && Object.keys(scopeWhere).length > 0
            ? { AND: [this.scope(companyId), scopeWhere] }
            : this.scope(companyId);
        return this.prisma.callLog.findMany({
            where,
            orderBy: { startedAt: 'desc' },
            take: limit,
            select: {
                id: true,
                companyId: true,
                leadId: true,
                aiAgentId: true,
                direction: true,
                status: true,
                startedAt: true,
                durationSeconds: true,
            },
        });
    }
    findById(companyId, id) {
        return this.prisma.callLog.findFirst({
            where: { id, companyId },
            include: {
                transcript: true,
                lead: true,
                aiAgent: true,
                assignedUser: true,
                phoneNumber: true,
            },
        });
    }
    findForBilling(companyId, id) {
        return this.prisma.callLog.findFirst({
            where: { id, companyId },
            select: {
                id: true,
                status: true,
                durationSeconds: true,
                creditsUsed: true,
                cost: true,
                campaignId: true,
            },
        });
    }
    updateBilling(companyId, id, data) {
        return this.prisma.callLog.updateMany({
            where: { id, companyId },
            data: {
                creditsUsed: data.creditsUsed,
                cost: data.cost,
            },
        });
    }
    countSummary(companyId, dateFrom, dateTo, scopeWhere) {
        const where = this.buildWhere(companyId, { dateFrom, dateTo }, scopeWhere);
        return Promise.all([
            this.prisma.callLog.count({ where }),
            this.prisma.callLog.count({
                where: { ...where, status: 'COMPLETED' },
            }),
        ]).then(([totalCalls, connectedCalls]) => ({ totalCalls, connectedCalls }));
    }
    findForTimeSeries(companyId, dateFrom, dateTo, scopeWhere) {
        const where = this.buildWhere(companyId, { dateFrom, dateTo }, scopeWhere);
        return this.prisma.callLog.findMany({
            where,
            select: {
                id: true,
                startedAt: true,
                status: true,
                leadId: true,
                outcome: true,
                aiAgentId: true,
            },
            orderBy: { startedAt: 'asc' },
        });
    }
    updateOutcome(companyId, id, outcome, reactivationPlan) {
        return this.prisma.callLog.updateMany({
            where: { id, companyId },
            data: {
                outcome: outcome,
                ...(reactivationPlan !== undefined
                    ? { reactivationPlan: reactivationPlan }
                    : {}),
            },
        });
    }
    findLeadsByIds(companyId, ids) {
        return this.prisma.lead.findMany({
            where: { companyId, id: { in: ids } },
        });
    }
    findAgentsByIds(companyId, ids) {
        return this.prisma.aiAgent.findMany({
            where: { companyId, id: { in: ids } },
        });
    }
    async createOutboundPending(tx, input) {
        const callLogId = await (0, resource_key_1.allocateResourceKey)(tx, input.companyId, types_1.PublicResourceType.CALL_LOG);
        const publicId = (0, public_id_1.generatePublicId)({
            cli: input.companyCli,
            campaignId: input.campaignResourceKey,
            entityId: callLogId,
        });
        return tx.callLog.create({
            data: {
                companyId: input.companyId,
                campaignId: input.campaignId,
                phoneNumberId: input.phoneNumberId,
                callLogId,
                publicId,
                direction: 'OUTBOUND',
                status: 'PENDING',
                startedAt: new Date(),
                provider: 'obd',
                retryNumber: input.retryNumber ?? 0,
                parentCallLogId: input.parentCallLogId,
                isRetry: input.isRetry ?? false,
                retryReason: input.retryReason,
                correlationId: input.correlationId,
            },
        });
    }
    findByPublicIdForWebhook(publicId) {
        return this.prisma.callLog.findFirst({
            where: { publicId },
            select: {
                id: true,
                companyId: true,
                campaignId: true,
                publicId: true,
                status: true,
                correlationId: true,
                durationSeconds: true,
                answeredAt: true,
                endedAt: true,
                providerWebhook: true,
                providerRequest: true,
                providerResponse: true,
                company: { select: { id: true, cli: true } },
                campaign: { select: { id: true, resourceKey: true, companyId: true } },
                phoneNumber: {
                    select: { id: true, number: true, campaignId: true, companyId: true },
                },
                lead: { select: { id: true, phone: true } },
            },
        });
    }
    findByIdForDispatch(companyId, id) {
        return this.prisma.callLog.findFirst({
            where: { id, companyId },
            select: {
                id: true,
                status: true,
                publicId: true,
                companyId: true,
            },
        });
    }
    transitionStatus(companyId, callLogId, input) {
        return this.prisma.callLog.updateMany({
            where: { id: callLogId, companyId, status: input.from },
            data: { status: input.to },
        });
    }
    appendProviderWebhookOnly(companyId, callLogId, data) {
        return this.prisma.callLog.updateMany({
            where: { id: callLogId, companyId },
            data: { providerWebhook: data.providerWebhook },
        });
    }
    updateFromProviderWebhook(companyId, callLogId, data) {
        return this.prisma.callLog.updateMany({
            where: { id: callLogId, companyId },
            data: {
                status: data.status,
                providerStatus: data.providerStatus,
                ...(data.durationSeconds !== undefined
                    ? { durationSeconds: data.durationSeconds }
                    : {}),
                ...(data.answeredAt !== undefined ? { answeredAt: data.answeredAt } : {}),
                ...(data.endedAt !== undefined ? { endedAt: data.endedAt } : {}),
                ...(data.disconnectReason !== undefined
                    ? { disconnectReason: data.disconnectReason }
                    : {}),
                providerWebhook: data.providerWebhook,
                ...(data.providerCompletedAt !== undefined
                    ? { providerCompletedAt: data.providerCompletedAt }
                    : {}),
            },
        });
    }
    countByStatuses(companyId, statuses) {
        return this.prisma.callLog.count({
            where: { companyId, status: { in: statuses } },
        });
    }
    async findQueuedCallLogIds(companyId) {
        const rows = await this.prisma.callLog.findMany({
            where: {
                companyId,
                status: 'QUEUED',
                phoneNumberId: { not: null },
            },
            select: { id: true },
            orderBy: { createdAt: 'asc' },
        });
        return rows.map((row) => row.id);
    }
    startProviderDispatch(companyId, callLogId, data) {
        return this.prisma.callLog.updateMany({
            where: {
                id: callLogId,
                companyId,
                status: { in: ['PENDING', 'QUEUED'] },
            },
            data: {
                status: 'DISPATCHING',
                correlationId: data.correlationId,
                providerRequest: data.providerRequest,
                providerRequestedAt: new Date(),
                provider: 'obd',
            },
        });
    }
    completeProviderDispatchSuccess(companyId, callLogId, data) {
        return this.prisma.callLog.updateMany({
            where: { id: callLogId, companyId },
            data: {
                status: 'QUEUED_AT_PROVIDER',
                providerCallId: data.providerCallId,
                providerResponse: data.providerResponse,
                providerAcceptedAt: new Date(),
            },
        });
    }
    completeProviderDispatchFailure(companyId, callLogId, data) {
        return this.prisma.callLog.updateMany({
            where: { id: callLogId, companyId },
            data: {
                status: 'FAILED',
                providerResponse: data.providerResponse,
                providerCompletedAt: new Date(),
            },
        });
    }
    async failStaleDispatching(companyId, olderThan) {
        const stale = await this.prisma.callLog.findMany({
            where: {
                companyId,
                status: 'DISPATCHING',
                OR: [
                    { providerRequestedAt: { lt: olderThan } },
                    {
                        providerRequestedAt: null,
                        updatedAt: { lt: olderThan },
                    },
                ],
            },
            select: {
                id: true,
                campaignId: true,
                phoneNumber: { select: { number: true } },
                correlationId: true,
            },
        });
        if (stale.length === 0) {
            return { count: 0, failed: [] };
        }
        const result = await this.prisma.callLog.updateMany({
            where: {
                companyId,
                id: { in: stale.map((row) => row.id) },
                status: 'DISPATCHING',
            },
            data: {
                status: 'FAILED',
                providerCompletedAt: new Date(),
                disconnectReason: 'Stale DISPATCHING cleanup',
            },
        });
        return { count: result.count, failed: stale };
    }
    async failStaleQueuedAtProvider(companyId, olderThan) {
        const stale = await this.prisma.callLog.findMany({
            where: {
                companyId,
                status: 'QUEUED_AT_PROVIDER',
                startedAt: { lt: olderThan },
            },
            select: {
                id: true,
                endedAt: true,
                campaignId: true,
                phoneNumber: { select: { number: true } },
                correlationId: true,
            },
        });
        const targets = stale.filter((row) => row.endedAt == null);
        const ids = targets.map((row) => row.id);
        if (ids.length === 0) {
            return { count: 0, failed: [] };
        }
        const result = await this.prisma.callLog.updateMany({
            where: {
                companyId,
                id: { in: ids },
                status: 'QUEUED_AT_PROVIDER',
            },
            data: {
                status: 'FAILED',
                providerCompletedAt: new Date(),
                disconnectReason: 'Stale QUEUED_AT_PROVIDER cleanup (no webhook)',
            },
        });
        return { count: result.count, failed: targets };
    }
    async failOrphanQueuedCalls(companyId) {
        const orphans = await this.prisma.callLog.findMany({
            where: {
                companyId,
                status: 'QUEUED',
                phoneNumberId: null,
            },
            select: { id: true },
        });
        if (orphans.length === 0) {
            return { count: 0, ids: [] };
        }
        const ids = orphans.map((row) => row.id);
        const result = await this.prisma.callLog.updateMany({
            where: {
                companyId,
                id: { in: ids },
                status: 'QUEUED',
            },
            data: {
                status: 'FAILED',
                providerCompletedAt: new Date(),
                disconnectReason: 'Orphan QUEUED cleanup (missing phone number)',
            },
        });
        return { count: result.count, ids };
    }
}
exports.CallLogsRepository = CallLogsRepository;
//# sourceMappingURL=call-logs.repository.js.map