import type { ColumnMapping, SpreadsheetOption, WorksheetOption } from "../types";
import type { TenantContext } from "../../../server/types/context";
export declare function listSpreadsheets(ctx: TenantContext): Promise<SpreadsheetOption[]>;
export declare function deleteSpreadsheet(ctx: TenantContext, spreadsheetId: string): Promise<void>;
export declare function createSpreadsheet(ctx: TenantContext, name: string, columns?: ColumnMapping[]): Promise<SpreadsheetOption>;
export declare function listWorksheets(ctx: TenantContext, spreadsheetId: string): Promise<WorksheetOption[]>;
export declare function getSheetHeaders(ctx: TenantContext, spreadsheetId: string, worksheetName: string): Promise<string[]>;
export declare function appendSheetRow(ctx: TenantContext, spreadsheetId: string, worksheetName: string, values: string[]): Promise<void>;
export declare function updateSheetRange(ctx: TenantContext, spreadsheetId: string, range: string, values: string[][]): Promise<void>;
export declare function readSheetRange(ctx: TenantContext, spreadsheetId: string, range: string): Promise<string[][]>;
export declare function mapLeadToRow(lead: {
    firstName: string | null;
    lastName: string | null;
    phone: string | null;
    score: number;
    temperature: string | null;
    nextFollowUpAt: Date | null;
    stage?: {
        name: string;
    } | null;
    notes?: {
        content: string;
    }[];
}, mappings: ColumnMapping[]): string[];
export declare function mapDialerCallToRow(dialerCall: {
    callStatus: string;
    summary: string | null;
    customerName?: string | null;
    customerPhone?: string | null;
}, lead: {
    firstName: string | null;
    lastName: string | null;
    phone: string | null;
    score: number;
    temperature: string | null;
    nextFollowUpAt: Date | null;
    stage?: {
        name: string;
    } | null;
    notes?: {
        content: string;
    }[];
}, analysis: {
    intent: string | null;
} | null, mappings: ColumnMapping[]): string[];
export declare function mapDataToRow(data: Record<string, string>, mappings: ColumnMapping[]): string[];
export declare function rowToRecord(row: string[], mappings: ColumnMapping[]): Record<string, string>;
