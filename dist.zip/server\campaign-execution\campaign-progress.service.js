"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.campaignProgressService = exports.CampaignProgressService = void 0;
const campaign_execution_repository_1 = require("./campaign-execution.repository");
const prisma_1 = __importDefault(require("../lib/prisma"));
const contact_completion_service_1 = require("./retry/contact-completion.service");
const DIALING_STATUSES = [
    "DISPATCHING",
    "QUEUED_AT_PROVIDER",
    "RINGING",
];
const QUEUED_STATUSES = ["PENDING", "QUEUED"];
const NO_ANSWER_STATUSES = ["NO_ANSWER", "MISSED", "VOICEMAIL"];
class CampaignProgressService {
    lastProcessedSnapshots = new Map();
    async updateAllActive() {
        const executions = await campaign_execution_repository_1.campaignExecutionRepository.findActiveForProgress();
        let updated = 0;
        for (const execution of executions) {
            await this.updateExecution(execution.companyId, execution.campaignId);
            if (execution.status === "RUNNING") {
                await contact_completion_service_1.contactCompletionService.checkCampaignCompletion(execution.companyId, execution.campaignId);
            }
            updated += 1;
        }
        return updated;
    }
    async updateExecution(companyId, campaignId) {
        const grouped = await prisma_1.default.callLog.groupBy({
            by: ["status"],
            where: { companyId, campaignId },
            _count: { _all: true },
        });
        let statsQueued = 0;
        let statsDialing = 0;
        let statsAnswered = 0;
        let statsBusy = 0;
        let statsNoAnswer = 0;
        let statsFailed = 0;
        let statsCompleted = 0;
        for (const row of grouped) {
            const count = row._count._all;
            if (QUEUED_STATUSES.includes(row.status)) {
                statsQueued += count;
            }
            else if (DIALING_STATUSES.includes(row.status)) {
                statsDialing += count;
            }
            else if (row.status === "ANSWERED") {
                statsAnswered += count;
            }
            else if (row.status === "BUSY") {
                statsBusy += count;
            }
            else if (NO_ANSWER_STATUSES.includes(row.status)) {
                statsNoAnswer += count;
            }
            else if (row.status === "FAILED" || row.status === "CANCELLED") {
                statsFailed += count;
            }
            else if (row.status === "COMPLETED") {
                statsCompleted += count;
            }
        }
        const execution = await campaign_execution_repository_1.campaignExecutionRepository.findByCampaignId(companyId, campaignId);
        if (!execution) {
            return;
        }
        const snapshotKey = `${companyId}:${campaignId}`;
        const now = Date.now();
        const previous = this.lastProcessedSnapshots.get(snapshotKey);
        let estimatedCompletionAt = null;
        if (previous && execution.totalContacts > execution.processedCount) {
            const deltaProcessed = execution.processedCount - previous.processedCount;
            const deltaMs = now - previous.capturedAt;
            if (deltaProcessed > 0 && deltaMs > 0) {
                const ratePerMs = deltaProcessed / deltaMs;
                const remaining = execution.totalContacts - execution.processedCount;
                estimatedCompletionAt = new Date(now + remaining / ratePerMs);
            }
        }
        this.lastProcessedSnapshots.set(snapshotKey, {
            processedCount: execution.processedCount,
            capturedAt: now,
        });
        await campaign_execution_repository_1.campaignExecutionRepository.updateStatistics(companyId, campaignId, {
            statsQueued,
            statsDialing,
            statsAnswered,
            statsBusy,
            statsNoAnswer,
            statsFailed,
            statsCompleted,
            estimatedCompletionAt,
        });
    }
    resetSnapshotsForTests() {
        this.lastProcessedSnapshots.clear();
    }
}
exports.CampaignProgressService = CampaignProgressService;
exports.campaignProgressService = new CampaignProgressService();
//# sourceMappingURL=campaign-progress.service.js.map