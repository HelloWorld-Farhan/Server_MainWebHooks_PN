"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.obdOutboundPhoneEntrySchema = void 0;
exports.toVoiceNsmsMsisdn = toVoiceNsmsMsisdn;
exports.formatObdScheduleDate = formatObdScheduleDate;
exports.buildObdProviderOutboundPayload = buildObdProviderOutboundPayload;
const zod_1 = require("zod");
const contact_phone_fields_1 = require("../../../lib/contact-phone-fields");
exports.obdOutboundPhoneEntrySchema = zod_1.z.object({
    phone: zod_1.z.string().min(1),
    callid: zod_1.z.string().min(1),
});
function toVoiceNsmsMsisdn(phone) {
    const digits = phone.replace(/\D/g, "");
    if (digits.length === 12 && digits.startsWith("91")) {
        return digits.slice(2);
    }
    if (digits.length === 10) {
        return digits;
    }
    return digits;
}
function formatObdScheduleDate(date = new Date()) {
    const pad = (n) => String(n).padStart(2, "0");
    return (`${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ` +
        `${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`);
}
function buildObdProviderOutboundPayload(input, config) {
    const fields = input.contactFields ?? {};
    const sendNow = config.sendNow === "1" ? "1" : "0";
    const payload = {
        sourcetype: config.sourceType,
        sendnow: sendNow,
        campaigntype: config.campaignType,
        filetype: config.fileType,
        ukey: config.apiKey,
        serviceno: config.serviceNo,
        ivrtemplateid: config.ivrTemplateId,
        retryatmpt: config.retryAttempts,
        retryduration: config.retryDuration,
        msisdnlist: [
            {
                phoneno: toVoiceNsmsMsisdn(input.phone),
                callid: input.callid,
                user_name: (0, contact_phone_fields_1.displayContactFieldValue)(fields.userName),
                "Recording URL": (0, contact_phone_fields_1.displayContactFieldValue)(fields.recordingUrl),
                Summary: (0, contact_phone_fields_1.displayContactFieldValue)(fields.summary),
                " Transcripts": (0, contact_phone_fields_1.displayContactFieldValue)(fields.transcripts),
            },
        ],
    };
    if (sendNow !== "1") {
        payload.schddate =
            process.env.OBD_SCHEDULE_DATE?.trim() || formatObdScheduleDate();
    }
    return payload;
}
//# sourceMappingURL=outbound-request.dto.js.map