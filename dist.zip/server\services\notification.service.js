"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.notificationService = exports.NotificationService = void 0;
class NotificationService {
    gasUrl = process.env.GOOGLE_APPS_SCRIPT_URL || "";
    async sendSubCompanyCreatedEmail(payload) {
        if (!this.gasUrl) {
            console.warn("No GOOGLE_APPS_SCRIPT_URL configured. Skipping email notification.");
            return;
        }
        try {
            const response = await fetch(this.gasUrl, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    type: "SUB_COMPANY_CREATED",
                    data: payload,
                }),
            });
            if (!response.ok) {
                console.error("Failed to send GAS notification:", await response.text());
            }
        }
        catch (error) {
            console.error("Error sending GAS notification:", error);
        }
    }
    async sendCreditUpdateEmail(payload) {
        if (!this.gasUrl) {
            console.warn("No GOOGLE_APPS_SCRIPT_URL configured. Skipping credit update email notification.");
            return;
        }
        try {
            const response = await fetch(this.gasUrl, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    type: "CREDIT_UPDATE",
                    data: payload,
                }),
            });
            if (!response.ok) {
                console.error("Failed to send GAS notification:", await response.text());
            }
        }
        catch (error) {
            console.error("Error sending GAS notification:", error);
        }
    }
    async sendCreditZeroWarningEmail(payload) {
        if (!this.gasUrl) {
            console.warn("No GOOGLE_APPS_SCRIPT_URL configured. Skipping email notification.");
            return;
        }
        try {
            const response = await fetch(this.gasUrl, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ type: "CREDIT_ZERO_WARNING", data: payload }),
            });
            if (!response.ok) {
                console.error("Failed to send zero credit warning:", await response.text());
            }
        }
        catch (error) {
            console.error("Error sending zero credit warning:", error);
        }
    }
    async sendSubCompanyCreditZeroWarningEmail(payload) {
        if (!this.gasUrl) {
            console.warn("No GOOGLE_APPS_SCRIPT_URL configured. Skipping email notification.");
            return;
        }
        try {
            const response = await fetch(this.gasUrl, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ type: "SUBCOMPANY_CREDIT_ZERO_WARNING", data: payload }),
            });
            if (!response.ok) {
                console.error("Failed to send subcompany zero credit warning:", await response.text());
            }
        }
        catch (error) {
            console.error("Error sending subcompany zero credit warning:", error);
        }
    }
}
exports.NotificationService = NotificationService;
exports.notificationService = new NotificationService();
//# sourceMappingURL=notification.service.js.map