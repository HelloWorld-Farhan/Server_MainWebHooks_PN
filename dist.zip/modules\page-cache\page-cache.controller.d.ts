import type { Request, Response } from "express";
export declare class PageCacheController {
    getPageCache(req: Request, res: Response, pageKey: string): Promise<Response<any, Record<string, any>>>;
}
