export type BillingHistoryItem = {
    id: string;
    date: string;
    description: string;
    amount: string;
};
export type CreditPack = {
    id: string;
    credits: number;
    price: number;
    popular?: boolean;
};
export type SubscriptionPlan = {
    id: string;
    name: string;
    price: number;
    period: string;
    description: string;
    credits: number;
    features: string[];
    popular?: boolean;
};
export declare const billingSummary: {
    availablePercent: number;
    remainingCredits: number;
    totalCredits: number;
    usedCredits: number;
    resetDate: string;
    activePlan: string;
    nextInvoiceAmount: string;
    nextInvoiceDue: string;
};
export declare const billingHistory: BillingHistoryItem[];
export declare const creditPacks: CreditPack[];
export declare const subscriptionPlans: SubscriptionPlan[];
