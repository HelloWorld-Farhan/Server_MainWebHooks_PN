import type { PhoneNumberStatus, TelephonyProvider } from "@prisma/client";
import { type PhoneNumberFilter, type PhoneNumberSort } from "../repositories/phone-numbers.repository";
import type { TenantContext } from "../types/context";
export declare class PhoneNumbersService {
    private readonly repo;
    list(ctx: TenantContext, filter?: PhoneNumberFilter, sort?: PhoneNumberSort): Promise<{
        id: string;
        number: string;
        label: string | null;
        provider: import("@prisma/client").$Enums.TelephonyProvider;
        status: import("@prisma/client").$Enums.PhoneNumberStatus;
        inboundAgentId: string | null;
        outboundAgentId: string | null;
        inboundAgent: {
            id: string;
            name: string;
        } | null | undefined;
        outboundAgent: {
            id: string;
            name: string;
        } | null | undefined;
        inboundCallsCount: number;
        outboundCallsCount: number;
        lastActivityAt: string | null;
        createdAt: string;
        updatedAt: string;
    }[]>;
    getConnection(ctx: TenantContext, args: {
        first?: number;
        after?: string;
        filter?: PhoneNumberFilter;
        sort?: PhoneNumberSort;
    }): Promise<{
        edges: {
            node: {
                id: string;
                number: string;
                label: string | null;
                provider: import("@prisma/client").$Enums.TelephonyProvider;
                status: import("@prisma/client").$Enums.PhoneNumberStatus;
                inboundAgentId: string | null;
                outboundAgentId: string | null;
                inboundAgent: {
                    id: string;
                    name: string;
                } | null | undefined;
                outboundAgent: {
                    id: string;
                    name: string;
                } | null | undefined;
                inboundCallsCount: number;
                outboundCallsCount: number;
                lastActivityAt: string | null;
                createdAt: string;
                updatedAt: string;
            };
            cursor: string;
        }[];
        pageInfo: import("../lib/pagination").PageInfo;
        totalCount: number;
    }>;
    getById(ctx: TenantContext, id: string): Promise<{
        id: string;
        number: string;
        label: string | null;
        provider: import("@prisma/client").$Enums.TelephonyProvider;
        status: import("@prisma/client").$Enums.PhoneNumberStatus;
        inboundAgentId: string | null;
        outboundAgentId: string | null;
        inboundAgent: {
            id: string;
            name: string;
        } | null | undefined;
        outboundAgent: {
            id: string;
            name: string;
        } | null | undefined;
        inboundCallsCount: number;
        outboundCallsCount: number;
        lastActivityAt: string | null;
        createdAt: string;
        updatedAt: string;
    }>;
    create(ctx: TenantContext, input: {
        number: string;
        provider: TelephonyProvider;
        label?: string;
        inboundAgentId?: string;
        outboundAgentId?: string;
    }): Promise<{
        id: string;
        number: string;
        label: string | null;
        provider: import("@prisma/client").$Enums.TelephonyProvider;
        status: import("@prisma/client").$Enums.PhoneNumberStatus;
        inboundAgentId: string | null;
        outboundAgentId: string | null;
        inboundAgent: {
            id: string;
            name: string;
        } | null | undefined;
        outboundAgent: {
            id: string;
            name: string;
        } | null | undefined;
        inboundCallsCount: number;
        outboundCallsCount: number;
        lastActivityAt: string | null;
        createdAt: string;
        updatedAt: string;
    }>;
    update(ctx: TenantContext, id: string, input: {
        label?: string;
        status?: PhoneNumberStatus;
        inboundAgentId?: string | null;
        outboundAgentId?: string | null;
    }): Promise<{
        id: string;
        number: string;
        label: string | null;
        provider: import("@prisma/client").$Enums.TelephonyProvider;
        status: import("@prisma/client").$Enums.PhoneNumberStatus;
        inboundAgentId: string | null;
        outboundAgentId: string | null;
        inboundAgent: {
            id: string;
            name: string;
        } | null | undefined;
        outboundAgent: {
            id: string;
            name: string;
        } | null | undefined;
        inboundCallsCount: number;
        outboundCallsCount: number;
        lastActivityAt: string | null;
        createdAt: string;
        updatedAt: string;
    }>;
}
export declare const phoneNumbersService: PhoneNumbersService;
