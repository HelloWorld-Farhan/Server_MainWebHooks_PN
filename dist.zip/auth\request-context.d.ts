import { AsyncLocalStorage } from "node:async_hooks";
import type { Request } from "express";
export declare const requestStore: AsyncLocalStorage<Request<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>>;
export declare function getCurrentRequest(): Request | undefined;
export declare function runWithRequest<T>(req: Request, fn: () => T): T;
