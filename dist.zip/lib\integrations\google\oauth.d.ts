import type { GoogleTokenSet } from "./token-store";
import type { IntegrationId } from "../types";
export type GoogleOAuthState = {
    companyId: string;
    integrationId: IntegrationId;
    nonce: string;
};
export declare function buildGoogleAuthUrl(companyId: string, integrationId: IntegrationId): string;
export declare function parseGoogleOAuthState(state: string): GoogleOAuthState;
export declare function exchangeGoogleAuthCode(code: string): Promise<GoogleTokenSet>;
export declare function revokeGoogleToken(refreshToken: string): Promise<void>;
