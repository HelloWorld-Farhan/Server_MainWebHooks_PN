"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.employeesService = exports.EmployeesService = void 0;
const node_crypto_1 = require("node:crypto");
const clerk_1 = require("../../auth/clerk");
const organization_1 = require("../../lib/clerk/organization");
const cache_service_1 = require("../cache/cache.service");
const keys_1 = require("../cache/keys");
const errors_1 = require("../lib/errors");
const clerk_sync_1 = require("../lib/clerk-sync");
const prisma_1 = __importDefault(require("../lib/prisma"));
const clerk_membership_service_1 = require("./clerk-membership.service");
const employees_repository_1 = require("../repositories/employees.repository");
const campaign_access_service_1 = require("./campaign-access.service");
const tenant_service_1 = require("./tenant.service");
const access_policy_1 = require("../policies/access-policy");
const pagination_1 = require("../lib/pagination");
const permissions_1 = require("../types/permissions");
function displayName(user) {
    const full = [user.firstName, user.lastName].filter(Boolean).join(" ").trim();
    return full || user.email;
}
function computeInvitationStatus(row) {
    if (row.status === "ACTIVE" || row.status === "DEACTIVATED") {
        return "ACCEPTED";
    }
    const invitation = row.latestInvitation;
    if (invitation?.status === "EXPIRED" ||
        (invitation?.status === "PENDING" && invitation.expiresAt < new Date())) {
        return "EXPIRED";
    }
    if (row.status === "INVITED") {
        return "PENDING";
    }
    if (row.joinedAt) {
        return "ACCEPTED";
    }
    return "PENDING";
}
function mapEmployee(row) {
    return {
        id: row.id,
        userId: row.userId,
        name: displayName(row.user),
        email: row.user.email,
        phone: row.user.phone,
        imageUrl: row.user.imageUrl,
        jobTitle: row.jobTitle,
        role: row.role,
        customRole: row.customRole
            ? {
                id: row.customRole.id,
                name: row.customRole.name,
                slug: row.customRole.slug,
                permissions: row.customRole.permissions,
                isSystem: row.customRole.isSystem,
            }
            : null,
        campaignAccessType: row.campaignAccessType,
        assignedCampaigns: row.campaignAccessType === "ALL"
            ? []
            : row.campaignAccess.map((access) => ({
                id: access.campaign.id,
                name: access.campaign.name,
                status: access.campaign.status,
            })),
        status: row.status,
        invitationStatus: computeInvitationStatus(row),
        lastActiveAt: row.user.lastLoginAt?.toISOString() ?? null,
        invitedAt: row.invitedAt?.toISOString() ?? null,
        joinedAt: row.joinedAt?.toISOString() ?? null,
        createdAt: row.createdAt.toISOString(),
        updatedAt: row.updatedAt.toISOString(),
    };
}
async function validateCampaignAccessInput(repo, companyId, campaignAccessType, campaignIds, ctx) {
    if (campaignAccessType === "ALL")
        return [];
    const ids = campaignIds ?? [];
    if (ids.length === 0) {
        throw new errors_1.ValidationError("Select at least one campaign");
    }
    campaign_access_service_1.campaignAccessService.assertCampaignIdsAccess(ctx, ids);
    const valid = await repo.validateCampaignIds(companyId, ids);
    if (valid.length !== ids.length) {
        throw new errors_1.ValidationError("One or more campaigns are invalid");
    }
    return ids;
}
function assertCanManageTarget(ctx, target, action) {
    (0, access_policy_1.assertCanManageEmployee)(ctx, { id: target.id, userId: target.userId, role: target.role }, action);
}
class EmployeesService {
    repo = new employees_repository_1.EmployeesRepository(prisma_1.default);
    async getConnection(ctx, args) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.EMPLOYEES_READ);
        const limit = Math.min(Math.max(args.first ?? 25, 1), 200);
        const scope = campaign_access_service_1.campaignAccessService.employeeScopeFilter(ctx);
        const [rows, totalCount] = await Promise.all([
            this.repo.findConnection(ctx.companyId, limit, args.after, args.filter, scope),
            this.repo.count(ctx.companyId, args.filter, scope),
        ]);
        const connection = (0, pagination_1.buildConnection)(rows, limit, (row) => (0, pagination_1.encodeIdCursor)(row.id, row.createdAt));
        return {
            edges: connection.edges.map((edge) => ({
                node: mapEmployee(edge.node),
                cursor: edge.cursor,
            })),
            pageInfo: connection.pageInfo,
            totalCount,
        };
    }
    async getById(ctx, id) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.EMPLOYEES_READ);
        const row = await this.repo.findById(ctx.companyId, id);
        if (!row)
            throw new errors_1.NotFoundError("Employee not found");
        campaign_access_service_1.campaignAccessService.assertEmployeeVisible(ctx, row);
        return mapEmployee(row);
    }
    getPermissionsForRole(_ctx, role) {
        tenant_service_1.tenantService.requirePermission(_ctx, permissions_1.PERMISSIONS.EMPLOYEES_READ);
        return (0, permissions_1.getPermissionsForRole)(role);
    }
    async invite(ctx, input) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.EMPLOYEES_INVITE);
        (0, access_policy_1.assertCanInviteRole)(ctx, input.role);
        const email = input.email.trim().toLowerCase();
        if (!email)
            throw new errors_1.ValidationError("Email is required");
        const jobTitle = input.jobTitle?.trim();
        if (!jobTitle)
            throw new errors_1.ValidationError("Job title is required");
        const existing = await this.repo.findByEmail(ctx.companyId, email);
        if (existing && existing.status !== "REMOVED") {
            throw new errors_1.ValidationError("An employee with this email already exists");
        }
        const campaignIds = await validateCampaignAccessInput(this.repo, ctx.companyId, input.campaignAccessType, input.campaignIds ?? undefined, ctx);
        const company = await prisma_1.default.company.findUnique({
            where: { id: ctx.companyId },
        });
        if (!company)
            throw new errors_1.NotFoundError("Company not found");
        const clerkOrganizationId = await (0, organization_1.getActiveClerkOrganizationId)(company, {
            createdByClerkUserId: ctx.clerkUserId,
        });
        const removedMember = await prisma_1.default.companyMember.findFirst({
            where: {
                companyId: ctx.companyId,
                status: "REMOVED",
                user: { email: { equals: email, mode: "insensitive" } },
            },
            include: { user: true },
        });
        await (0, organization_1.removeClerkOrganizationAccess)({
            organizationId: clerkOrganizationId,
            email,
            clerkUserId: removedMember?.user.clerkUserId,
            requestingUserId: ctx.clerkUserId,
        });
        const [firstName, ...rest] = input.name.trim().split(/\s+/);
        const lastName = rest.join(" ") || null;
        const clerkInvite = await (0, organization_1.sendClerkOrganizationInvitation)({
            organizationId: clerkOrganizationId,
            email,
            role: input.role,
            inviterUserId: ctx.clerkUserId,
            metadata: {
                propnexRole: input.role,
                campaignAccessType: input.campaignAccessType,
                campaignIds,
                jobTitle,
                inviteName: input.name.trim(),
            },
        });
        const token = (0, node_crypto_1.randomUUID)();
        const expiresAt = clerkInvite.expiresAt;
        await this.repo.createInvitation({
            companyId: ctx.companyId,
            email,
            role: input.role,
            jobTitle,
            campaignAccessType: input.campaignAccessType,
            campaignIds,
            token,
            expiresAt,
            invitedById: ctx.userId,
            clerkInvitationId: clerkInvite.invitationId,
            clerkOrganizationId,
        });
        let user = await prisma_1.default.user.findUnique({ where: { email } });
        if (!user) {
            user = await prisma_1.default.user.create({
                data: {
                    clerkUserId: `pending:${token}`,
                    email,
                    firstName: firstName || null,
                    lastName,
                    status: "INVITED",
                },
            });
        }
        else if (firstName || lastName) {
            user = await prisma_1.default.user.update({
                where: { id: user.id },
                data: {
                    firstName: firstName || user.firstName,
                    lastName: lastName || user.lastName,
                },
            });
        }
        const member = await prisma_1.default.companyMember.upsert({
            where: {
                companyId_userId: { companyId: ctx.companyId, userId: user.id },
            },
            create: {
                companyId: ctx.companyId,
                userId: user.id,
                role: input.role,
                status: "INVITED",
                jobTitle,
                campaignAccessType: input.campaignAccessType,
                invitedAt: new Date(),
            },
            update: {
                role: input.role,
                status: "INVITED",
                jobTitle,
                campaignAccessType: input.campaignAccessType,
                invitedAt: new Date(),
            },
            include: {
                user: true,
                customRole: true,
                campaignAccess: { include: { campaign: true } },
            },
        });
        if (input.campaignAccessType === "SELECTED") {
            await this.repo.setCampaignAccess(member.id, campaignIds);
        }
        else {
            await this.repo.setCampaignAccess(member.id, []);
        }
        const refreshed = await this.repo.findById(ctx.companyId, member.id);
        return mapEmployee(refreshed);
    }
    async update(ctx, id, input) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.EMPLOYEES_WRITE);
        const existing = await this.repo.findById(ctx.companyId, id);
        if (!existing)
            throw new errors_1.NotFoundError("Employee not found");
        assertCanManageTarget(ctx, existing, "update");
        if (input.role) {
            (0, access_policy_1.assertCanAssignRole)(ctx, input.role);
        }
        if (existing.role === "OWNER" && input.role && input.role !== "OWNER") {
            const owners = await this.repo.countActiveOwners(ctx.companyId, id);
            if (owners === 0) {
                throw new errors_1.ValidationError("At least one active owner is required");
            }
        }
        const campaignAccessType = input.campaignAccessType ?? existing.campaignAccessType;
        const campaignIds = await validateCampaignAccessInput(this.repo, ctx.companyId, campaignAccessType, input.campaignIds ?? existing.campaignAccess.map((b) => b.campaignId), ctx);
        if (input.firstName !== undefined || input.lastName !== undefined || input.phone !== undefined) {
            await prisma_1.default.user.update({
                where: { id: existing.userId },
                data: {
                    ...(input.firstName !== undefined ? { firstName: input.firstName } : {}),
                    ...(input.lastName !== undefined ? { lastName: input.lastName } : {}),
                    ...(input.phone !== undefined ? { phone: input.phone } : {}),
                },
            });
        }
        await this.repo.updateMember(ctx.companyId, id, {
            ...(input.jobTitle !== undefined ? { jobTitle: input.jobTitle } : {}),
            ...(input.role ? { role: input.role } : {}),
            ...(input.status ? { status: input.status } : {}),
            campaignAccessType,
            ...(input.status === "ACTIVE" && !existing.joinedAt
                ? { joinedAt: new Date() }
                : {}),
        });
        if (campaignAccessType === "SELECTED") {
            await this.repo.setCampaignAccess(id, campaignIds);
        }
        else {
            await this.repo.setCampaignAccess(id, []);
        }
        await cache_service_1.cacheService.del(keys_1.cacheKeys.userPermissions(existing.userId));
        const company = await prisma_1.default.company.findUnique({
            where: { id: ctx.companyId },
        });
        if (existing.user.clerkUserId) {
            await cache_service_1.cacheService.invalidateClerkMembershipCaches(existing.user.clerkUserId, company?.clerkOrganizationId);
        }
        if (input.role &&
            existing.user.clerkUserId &&
            !existing.user.clerkUserId.startsWith("pending:")) {
            if (company?.clerkOrganizationId?.startsWith("org_")) {
                const client = clerk_1.clerkClient;
                try {
                    const clerkMembership = await clerk_membership_service_1.clerkMembershipService.getMembershipInOrg(existing.user.clerkUserId, company.clerkOrganizationId);
                    if (clerkMembership) {
                        await client.organizations.updateOrganizationMembership({
                            organizationId: company.clerkOrganizationId,
                            userId: existing.user.clerkUserId,
                            role: (0, clerk_sync_1.mapUserRoleToClerkRole)(input.role),
                        });
                        await clerk_membership_service_1.clerkMembershipService.invalidateUser(existing.user.clerkUserId);
                    }
                }
                catch {
                }
            }
        }
        const refreshed = await this.repo.findById(ctx.companyId, id);
        return mapEmployee(refreshed);
    }
    async deactivate(ctx, id) {
        return this.update(ctx, id, { status: "DEACTIVATED" });
    }
    async delete(ctx, id) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.EMPLOYEES_WRITE);
        const existing = await this.repo.findById(ctx.companyId, id);
        if (!existing)
            throw new errors_1.NotFoundError("Employee not found");
        assertCanManageTarget(ctx, existing, "delete");
        if (existing.role === "OWNER") {
            const owners = await this.repo.countActiveOwners(ctx.companyId, id);
            if (owners === 0) {
                throw new errors_1.ValidationError("At least one active owner is required");
            }
        }
        await this.repo.updateMember(ctx.companyId, id, { status: "REMOVED" });
        await this.repo.setCampaignAccess(id, []);
        await cache_service_1.cacheService.del(keys_1.cacheKeys.userPermissions(existing.userId));
        const company = await prisma_1.default.company.findUnique({
            where: { id: ctx.companyId },
        });
        if (existing.user.clerkUserId) {
            await cache_service_1.cacheService.invalidateClerkMembershipCaches(existing.user.clerkUserId, company?.clerkOrganizationId);
        }
        if (company?.clerkOrganizationId?.startsWith("org_")) {
            await (0, organization_1.removeClerkOrganizationAccess)({
                organizationId: company.clerkOrganizationId,
                email: existing.user.email,
                clerkUserId: existing.user.clerkUserId,
                requestingUserId: ctx.clerkUserId,
            });
        }
        return true;
    }
    async resendInvite(ctx, id) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.EMPLOYEES_INVITE);
        const existing = await this.repo.findById(ctx.companyId, id);
        if (!existing)
            throw new errors_1.NotFoundError("Employee not found");
        if (existing.status !== "INVITED") {
            throw new errors_1.ValidationError("Only invited employees can be re-invited");
        }
        const company = await prisma_1.default.company.findUnique({
            where: { id: ctx.companyId },
        });
        if (!company)
            throw new errors_1.NotFoundError("Company not found");
        const clerkOrganizationId = await (0, organization_1.getActiveClerkOrganizationId)(company, {
            createdByClerkUserId: ctx.clerkUserId,
        });
        const invitation = await this.repo.findLatestInvitationByEmail(ctx.companyId, existing.user.email);
        const campaignIds = existing.campaignAccessType === "SELECTED"
            ? existing.campaignAccess.map((b) => b.campaignId)
            : invitation?.campaignIds ?? [];
        await (0, organization_1.revokeAllClerkPendingInvitationsForEmail)({
            organizationId: clerkOrganizationId,
            email: existing.user.email,
            requestingUserId: ctx.clerkUserId,
        });
        const displayNameValue = displayName(existing.user);
        const clerkInvite = await (0, organization_1.sendClerkOrganizationInvitation)({
            organizationId: clerkOrganizationId,
            email: existing.user.email,
            role: existing.role,
            inviterUserId: ctx.clerkUserId,
            metadata: {
                propnexRole: existing.role,
                campaignAccessType: existing.campaignAccessType,
                campaignIds,
                jobTitle: existing.jobTitle,
                inviteName: displayNameValue,
            },
        });
        const token = (0, node_crypto_1.randomUUID)();
        const expiresAt = clerkInvite.expiresAt;
        if (invitation) {
            await this.repo.updateInvitation(invitation.id, {
                token,
                expiresAt,
                status: "PENDING",
                clerkInvitationId: clerkInvite.invitationId,
                clerkOrganizationId,
            });
        }
        else {
            await this.repo.createInvitation({
                companyId: ctx.companyId,
                email: existing.user.email,
                role: existing.role,
                jobTitle: existing.jobTitle,
                campaignAccessType: existing.campaignAccessType,
                campaignIds,
                token,
                expiresAt,
                invitedById: ctx.userId,
                clerkInvitationId: clerkInvite.invitationId,
                clerkOrganizationId,
            });
        }
        await this.repo.updateMember(ctx.companyId, id, {
            invitedAt: new Date(),
        });
        const refreshed = await this.repo.findById(ctx.companyId, id);
        return mapEmployee(refreshed);
    }
    async cancelInvite(ctx, id) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.EMPLOYEES_INVITE);
        const existing = await this.repo.findById(ctx.companyId, id);
        if (!existing)
            throw new errors_1.NotFoundError("Employee not found");
        if (existing.status !== "INVITED") {
            throw new errors_1.ValidationError("Only pending invitations can be cancelled");
        }
        assertCanManageTarget(ctx, existing, "cancel");
        const company = await prisma_1.default.company.findUnique({
            where: { id: ctx.companyId },
        });
        if (!company)
            throw new errors_1.NotFoundError("Company not found");
        const clerkOrganizationId = existing.latestInvitation?.clerkOrganizationId ??
            company.clerkOrganizationId;
        if (clerkOrganizationId?.startsWith("org_")) {
            await (0, organization_1.removeClerkOrganizationAccess)({
                organizationId: clerkOrganizationId,
                email: existing.user.email,
                clerkUserId: existing.user.clerkUserId,
                requestingUserId: ctx.clerkUserId,
            });
        }
        await this.repo.revokePendingInvitation(ctx.companyId, existing.user.email);
        await this.repo.updateMember(ctx.companyId, id, { status: "REMOVED" });
        await this.repo.setCampaignAccess(id, []);
        await cache_service_1.cacheService.del(keys_1.cacheKeys.userPermissions(existing.userId));
        if (existing.user.clerkUserId) {
            await cache_service_1.cacheService.invalidateClerkMembershipCaches(existing.user.clerkUserId, clerkOrganizationId);
        }
        return true;
    }
}
exports.EmployeesService = EmployeesService;
exports.employeesService = new EmployeesService();
//# sourceMappingURL=employees.service.js.map