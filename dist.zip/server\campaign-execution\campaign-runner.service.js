"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.campaignRunnerService = exports.CampaignRunnerService = void 0;
const phone_validation_1 = require("../../lib/phone-validation");
const campaign_execution_config_1 = require("./campaign-execution.config");
const campaign_execution_repository_1 = require("./campaign-execution.repository");
const campaign_execution_service_1 = require("./campaign-execution.service");
const campaign_execution_logger_1 = require("./lib/campaign-execution-logger");
const system_tenant_context_1 = require("./lib/system-tenant-context");
const mapper_1 = require("../lib/public-id/mapper");
const prisma_1 = __importDefault(require("../lib/prisma"));
const campaigns_repository_1 = require("../repositories/campaigns.repository");
const outbound_calls_service_1 = require("../services/outbound-calls.service");
const campaign_execution_lock_service_1 = require("./campaign-execution-lock.service");
const retry_job_repository_1 = require("./retry/retry-job.repository");
class CampaignRunnerService {
    campaignsRepo = new campaigns_repository_1.CampaignsRepository(prisma_1.default);
    activeCampaignIds = new Set();
    getActiveCount() {
        return this.activeCampaignIds.size;
    }
    resetActiveForTests() {
        this.activeCampaignIds.clear();
    }
    async processRunnableCampaigns() {
        const running = await campaign_execution_repository_1.campaignExecutionRepository.findRunningExecutions(campaign_execution_config_1.campaignExecutionConfig.maxConcurrentCampaigns * 2);
        let processed = 0;
        for (const execution of running) {
            if (this.activeCampaignIds.size >=
                campaign_execution_config_1.campaignExecutionConfig.maxConcurrentCampaigns) {
                break;
            }
            if (this.activeCampaignIds.has(execution.campaignId)) {
                continue;
            }
            const didProcess = await this.processCampaign(execution);
            if (didProcess) {
                processed += 1;
            }
        }
        return processed;
    }
    async processCampaign(execution) {
        const acquired = await campaign_execution_lock_service_1.campaignExecutionLockService.acquire(execution.campaignId, campaign_execution_config_1.campaignExecutionConfig.workerId);
        if (!acquired) {
            return false;
        }
        this.activeCampaignIds.add(execution.campaignId);
        try {
            const stillRunning = await campaign_execution_service_1.campaignExecutionService.isRunning(execution.companyId, execution.campaignId);
            if (!stillRunning) {
                return false;
            }
            const ctx = await (0, system_tenant_context_1.createSystemTenantContext)(execution.companyId);
            const campaignPublicId = await (0, mapper_1.toCampaignPublicId)(ctx, execution.campaign.resourceKey);
            const contacts = await this.campaignsRepo.findContactsForExecution(execution.companyId, execution.campaignId, campaign_execution_config_1.campaignExecutionConfig.batchSize, execution.lastProcessedContactId ?? undefined);
            if (contacts.length === 0) {
                await campaign_execution_service_1.campaignExecutionService.markCompleted(execution.companyId, execution.campaignId);
                return true;
            }
            (0, campaign_execution_logger_1.logCampaignExecutionEvent)("batch:started", {
                campaignPublicId,
                correlationId: execution.correlationId ?? undefined,
                batchSize: contacts.length,
            });
            let processedCount = execution.processedCount;
            for (const contact of contacts) {
                const running = await campaign_execution_service_1.campaignExecutionService.isRunning(execution.companyId, execution.campaignId);
                if (!running) {
                    break;
                }
                const normalizedPhone = (0, phone_validation_1.normalizeOutboundPhone)(contact.phone);
                if (!normalizedPhone) {
                    (0, campaign_execution_logger_1.logCampaignExecutionEvent)("contact:skipped", {
                        campaignPublicId,
                        correlationId: execution.correlationId ?? undefined,
                        reason: "invalid_phone",
                        phone: contact.phone,
                    });
                    processedCount += 1;
                    await campaign_execution_repository_1.campaignExecutionRepository.updateCursor(execution.companyId, execution.campaignId, contact.id, processedCount);
                    continue;
                }
                const existingCall = await prisma_1.default.callLog.findFirst({
                    where: {
                        companyId: execution.companyId,
                        campaignId: execution.campaignId,
                        phoneNumber: { number: normalizedPhone },
                    },
                    orderBy: { startedAt: "desc" },
                    select: { id: true, status: true },
                });
                const pendingRetries = await retry_job_repository_1.retryJobRepository.countPendingForPhone(execution.companyId, execution.campaignId, normalizedPhone);
                const terminalStatuses = new Set([
                    "FAILED",
                    "NO_ANSWER",
                    "BUSY",
                    "CANCELLED",
                    "MISSED",
                ]);
                const shouldDial = pendingRetries === 0 &&
                    (!existingCall || terminalStatuses.has(existingCall.status));
                if (shouldDial) {
                    await outbound_calls_service_1.outboundCallsService.createOutboundCall(ctx, {
                        campaignId: campaignPublicId,
                        phoneNumber: normalizedPhone,
                    });
                }
                processedCount += 1;
                await campaign_execution_repository_1.campaignExecutionRepository.updateCursor(execution.companyId, execution.campaignId, contact.id, processedCount);
                await campaign_execution_lock_service_1.campaignExecutionLockService.renew(execution.campaignId, campaign_execution_config_1.campaignExecutionConfig.workerId);
                const lockExpiresAt = new Date(Date.now() + campaign_execution_config_1.campaignExecutionConfig.lockTtlMs);
                await campaign_execution_repository_1.campaignExecutionRepository.updateLock(execution.companyId, execution.campaignId, campaign_execution_config_1.campaignExecutionConfig.workerId, lockExpiresAt);
            }
            (0, campaign_execution_logger_1.logCampaignExecutionEvent)("batch:completed", {
                campaignPublicId,
                correlationId: execution.correlationId ?? undefined,
                processedCount,
            });
            const reachedEndOfContacts = contacts.length < campaign_execution_config_1.campaignExecutionConfig.batchSize;
            if (reachedEndOfContacts) {
                await campaign_execution_service_1.campaignExecutionService.markCompleted(execution.companyId, execution.campaignId);
            }
            else {
                const totalContacts = await this.campaignsRepo.countContacts(execution.companyId, execution.campaignId);
                await this.completeIfQueueDrained({
                    companyId: execution.companyId,
                    campaignId: execution.campaignId,
                    processedCount,
                    totalContacts,
                });
            }
            return true;
        }
        catch (error) {
            const message = error instanceof Error ? error.message : "Unknown runner error";
            await campaign_execution_service_1.campaignExecutionService.markFailed(execution.companyId, execution.campaignId, message);
            return true;
        }
        finally {
            this.activeCampaignIds.delete(execution.campaignId);
            const stillRunning = await campaign_execution_service_1.campaignExecutionService.isRunning(execution.companyId, execution.campaignId);
            if (!stillRunning) {
                await campaign_execution_lock_service_1.campaignExecutionLockService.release(execution.campaignId, campaign_execution_config_1.campaignExecutionConfig.workerId);
            }
        }
    }
    async completeIfQueueDrained(execution) {
        if (execution.totalContacts <= 0) {
            return;
        }
        if (execution.processedCount < execution.totalContacts) {
            return;
        }
        await campaign_execution_service_1.campaignExecutionService.markCompleted(execution.companyId, execution.campaignId);
    }
}
exports.CampaignRunnerService = CampaignRunnerService;
exports.campaignRunnerService = new CampaignRunnerService();
//# sourceMappingURL=campaign-runner.service.js.map