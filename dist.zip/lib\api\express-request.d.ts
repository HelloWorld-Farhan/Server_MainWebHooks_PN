import type { Request as ExpressRequest } from "express";
export declare function toFetchRequest(req: ExpressRequest): Request;
