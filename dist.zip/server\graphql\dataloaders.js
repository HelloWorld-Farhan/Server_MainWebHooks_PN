"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createDataLoaders = createDataLoaders;
const dataloader_1 = __importDefault(require("dataloader"));
const prisma_1 = __importDefault(require("../lib/prisma"));
const agents_repository_1 = require("../repositories/agents.repository");
const campaigns_repository_1 = require("../repositories/campaigns.repository");
const call_logs_repository_1 = require("../repositories/call-logs.repository");
const phone_numbers_repository_1 = require("../repositories/phone-numbers.repository");
const tenant_repository_1 = require("../repositories/tenant.repository");
function createDataLoaders(companyId) {
    const leadsRepo = new call_logs_repository_1.CallLogsRepository(prisma_1.default);
    const agentsRepo = new agents_repository_1.AgentsRepository(prisma_1.default);
    const phoneNumbersRepo = new phone_numbers_repository_1.PhoneNumbersRepository(prisma_1.default);
    const tenantRepo = new tenant_repository_1.TenantRepository(prisma_1.default);
    const campaignsRepo = new campaigns_repository_1.CampaignsRepository(prisma_1.default);
    return {
        lead: new dataloader_1.default(async (ids) => {
            const leads = await leadsRepo.findLeadsByIds(companyId, [...ids]);
            const map = new Map(leads.map((l) => [l.id, l]));
            return ids.map((id) => map.get(id) ?? null);
        }),
        aiAgent: new dataloader_1.default(async (ids) => {
            const agents = await agentsRepo.findByIds(companyId, [...ids]);
            const map = new Map(agents.map((a) => [a.id, a]));
            return ids.map((id) => map.get(id) ?? null);
        }),
        phoneNumber: new dataloader_1.default(async (ids) => {
            const numbers = await phoneNumbersRepo.findByIds(companyId, [...ids]);
            const map = new Map(numbers.map((n) => [n.id, n]));
            return ids.map((id) => map.get(id) ?? null);
        }),
        user: new dataloader_1.default(async (ids) => {
            const users = await tenantRepo.findUsersByIds(companyId, [...ids]);
            const map = new Map(users.map((u) => [u.id, u]));
            return ids.map((id) => map.get(id) ?? null);
        }),
        campaign: new dataloader_1.default(async (ids) => {
            const campaigns = await campaignsRepo.findByIds(companyId, [...ids]);
            const map = new Map(campaigns.map((b) => [b.id, b]));
            return ids.map((id) => map.get(id) ?? null);
        }),
    };
}
//# sourceMappingURL=dataloaders.js.map