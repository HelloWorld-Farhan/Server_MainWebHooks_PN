import { type CompanyPublicIdentity, PublicResourceType } from "../lib/public-id/types";
export declare class PublicIdResolverService {
    clearCompanyIdentityCache(companyId?: string): void;
    getCompanyPublicIdentity(companyId: string): Promise<CompanyPublicIdentity>;
    getCampaignResourceKey(companyId: string, campaignInternalId: string): Promise<string>;
    toCampaignPublicId(identity: CompanyPublicIdentity, campaignResourceKey: string): string;
    toLegacyPublicId(identity: CompanyPublicIdentity, resourceKey: string): string;
    toPublicId(identity: CompanyPublicIdentity, campaignId: string, entityId: string): string;
    mapCampaignEntityToPublicId(companyId: string, campaignInternalId: string | null | undefined, entityId: string, identity?: CompanyPublicIdentity): Promise<string>;
    mapResourceKeyToLegacyPublicId(companyId: string, resourceKey: string, identity?: CompanyPublicIdentity): Promise<string>;
    mapInternalIdToPublicId(companyId: string, internalId: string | null | undefined, resourceType: PublicResourceType, identity?: CompanyPublicIdentity): Promise<string | null>;
    mapInternalIdToCampaignScopedPublicId(companyId: string, internalId: string | null | undefined, campaignInternalId: string | null | undefined, resourceType: PublicResourceType.CALL_LOG | PublicResourceType.PHONE_NUMBER, identity?: CompanyPublicIdentity): Promise<string | null>;
    mapInternalIdsToPublicIds(companyId: string, internalIds: string[], resourceType: PublicResourceType, identity?: CompanyPublicIdentity): Promise<string[]>;
    resolveToInternalId(companyId: string, input: string, resourceType: PublicResourceType): Promise<string>;
    private resolveCampaignScopedToInternalId;
    private findLegacyCompanyScopedEntity;
    private resolveLegacyToInternalId;
    private resolveCampaignPublicIdToInternalId;
    tryParsePublicId(input: string): import("../lib/public-id").ParsedCampaignPublicIdV1 | import("../lib/public-id").ParsedPublicIdV1 | import("../lib/public-id").ParsedLegacyPublicIdV1 | null;
}
export declare const publicIdResolver: PublicIdResolverService;
