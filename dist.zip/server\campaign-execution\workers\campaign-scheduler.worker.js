"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CampaignSchedulerWorker = void 0;
const common_1 = require("@nestjs/common");
const campaign_execution_config_1 = require("../campaign-execution.config");
const campaign_scheduler_service_1 = require("../campaign-scheduler.service");
const run_worker_task_1 = require("../../lib/run-worker-task");
let CampaignSchedulerWorker = class CampaignSchedulerWorker {
    interval = null;
    processing = false;
    onModuleInit() {
        (0, run_worker_task_1.runWorkerTask)("campaign-scheduler", () => campaign_scheduler_service_1.campaignSchedulerService.recoverOnStartup());
        this.interval = setInterval(() => {
            (0, run_worker_task_1.runWorkerTask)("campaign-scheduler", () => this.tick());
        }, campaign_execution_config_1.campaignExecutionConfig.schedulerIntervalMs);
    }
    onModuleDestroy() {
        if (this.interval) {
            clearInterval(this.interval);
            this.interval = null;
        }
    }
    async tick() {
        if (this.processing) {
            return;
        }
        this.processing = true;
        try {
            await campaign_scheduler_service_1.campaignSchedulerService.processDueScheduled();
        }
        finally {
            this.processing = false;
        }
    }
};
exports.CampaignSchedulerWorker = CampaignSchedulerWorker;
exports.CampaignSchedulerWorker = CampaignSchedulerWorker = __decorate([
    (0, common_1.Injectable)()
], CampaignSchedulerWorker);
//# sourceMappingURL=campaign-scheduler.worker.js.map