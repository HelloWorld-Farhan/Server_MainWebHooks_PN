"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.submitContactRequest = submitContactRequest;
const zod_1 = require("zod");
const clerk_1 = require("../../auth/clerk");
const contact_form_data_1 = require("../../lib/contact-form-data");
const prisma_1 = __importDefault(require("../../server/lib/prisma"));
const support_request_repository_1 = require("../../server/repositories/support-request.repository");
const tenant_repository_1 = require("../../server/repositories/tenant.repository");
const company_resolution_service_1 = require("../../server/services/company-resolution.service");
const reasonValues = contact_form_data_1.CONTACT_REASON_OPTIONS.map((option) => option.value);
const planIds = contact_form_data_1.CONTACT_PLAN_OPTIONS.map((option) => option.id);
const contactRequestSchema = zod_1.z.object({
    name: zod_1.z.string().trim().min(1, "Full name is required.").max(200),
    email: zod_1.z.string().trim().email("A valid email address is required.").max(320),
    reason: zod_1.z.enum(reasonValues),
    planId: zod_1.z.enum(planIds),
    message: zod_1.z.string().trim().min(1, "Message is required.").max(5000),
});
async function submitContactRequest(req) {
    const parsed = contactRequestSchema.safeParse(req.body);
    if (!parsed.success) {
        return {
            success: false,
            error: parsed.error.issues[0]?.message ?? "Invalid form data.",
        };
    }
    const data = parsed.data;
    const repo = new support_request_repository_1.SupportRequestRepository(prisma_1.default);
    const tenantRepo = new tenant_repository_1.TenantRepository(prisma_1.default);
    let userId = null;
    let companyId = null;
    let clerkUserId = null;
    let email = data.email;
    try {
        const { userId: authUserId, orgId } = await (0, clerk_1.getAuthFromRequest)(req);
        if (authUserId) {
            clerkUserId = authUserId;
            const dbUser = await tenantRepo.findUserByClerkId(authUserId);
            if (dbUser) {
                userId = dbUser.id;
                email = dbUser.email;
            }
            else {
                const clerkUser = await clerk_1.clerkClient.users.getUser(authUserId);
                const primaryEmail = clerkUser.emailAddresses.find((entry) => entry.id === clerkUser.primaryEmailAddressId)?.emailAddress ??
                    clerkUser.emailAddresses[0]?.emailAddress ??
                    data.email;
                email = primaryEmail;
            }
            try {
                const tenant = await (0, company_resolution_service_1.resolveAuthenticatedTenant)(authUserId, orgId);
                if (tenant) {
                    companyId = tenant.company.id;
                    if (!userId) {
                        userId = tenant.user.id;
                        email = tenant.user.email;
                    }
                }
            }
            catch {
            }
        }
        const request = await repo.create({
            name: data.name,
            email,
            reason: data.reason,
            planId: data.planId,
            planName: (0, contact_form_data_1.getContactPlanLabel)(data.planId),
            message: data.message,
            userId,
            companyId,
            clerkUserId,
        });
        return { success: true, requestId: request.id };
    }
    catch (error) {
        const message = error instanceof Error
            ? error.message
            : "Unable to submit your request right now.";
        console.error("submitContactRequest failed:", error);
        return { success: false, error: message };
    }
}
//# sourceMappingURL=contact-request.handler.js.map