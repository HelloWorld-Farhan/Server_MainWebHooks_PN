"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.redis = void 0;
exports.isRedisDisabled = isRedisDisabled;
exports.isRedisAvailable = isRedisAvailable;
exports.assertChannelRedisReady = assertChannelRedisReady;
exports.connectRedisOnStartup = connectRedisOnStartup;
const ioredis_1 = __importDefault(require("ioredis"));
const globalForRedis = globalThis;
function isRedisDisabled() {
    const flag = (process.env.REDIS_ENABLED ?? "true").trim().toLowerCase();
    return flag === "0" || flag === "false" || flag === "off" || flag === "no";
}
function resolveRedisUrl() {
    if (process.env.REDIS_URL) {
        return process.env.REDIS_URL;
    }
    const host = process.env.REDIS_HOST;
    const port = process.env.REDIS_PORT;
    const password = process.env.REDIS_PASSWORD;
    const user = process.env.REDIS_USER ?? "default";
    if (host && port && password) {
        return `redis://${encodeURIComponent(user)}:${encodeURIComponent(password)}@${host}:${port}`;
    }
    return null;
}
function createRedisClient() {
    if (isRedisDisabled()) {
        console.warn("[redis] REDIS_ENABLED=false; Redis and channel gating disabled");
        return null;
    }
    const url = resolveRedisUrl();
    if (!url) {
        if (process.env.NODE_ENV === "production") {
            console.warn("[redis] REDIS_URL is not set; caching disabled");
        }
        return null;
    }
    return new ioredis_1.default(url, {
        maxRetriesPerRequest: 3,
        lazyConnect: true,
        connectTimeout: 5000,
        commandTimeout: 3000,
        enableOfflineQueue: false,
    });
}
exports.redis = globalForRedis.redis ?? createRedisClient();
if (process.env.NODE_ENV !== "production" && exports.redis) {
    globalForRedis.redis = exports.redis;
}
function isRedisAvailable() {
    return exports.redis !== null && exports.redis.status === "ready";
}
function assertChannelRedisReady() {
}
async function connectRedisOnStartup() {
    if (isRedisDisabled() || !exports.redis || exports.redis.status === "ready") {
        return;
    }
    try {
        await exports.redis.connect();
    }
    catch (error) {
        console.warn("[redis] Failed to connect on startup; channel features will use in-memory fallback", error);
    }
}
//# sourceMappingURL=redis.client.js.map