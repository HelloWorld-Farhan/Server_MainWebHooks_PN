"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.telephonyService = exports.TelephonyService = void 0;
const prisma_1 = __importDefault(require("../lib/prisma"));
const credential_crypto_1 = require("../lib/credential-crypto");
const errors_1 = require("../lib/errors");
const setup_config_repository_1 = require("../repositories/setup-config.repository");
const permissions_1 = require("../types/permissions");
const telephony_1 = require("../types/telephony");
const tenant_service_1 = require("./tenant.service");
const E164_REGEX = /^\+[1-9]\d{1,14}$/;
function maskCredentials(credentials) {
    const mask = (value) => (value ? "••••••••" : "");
    return {
        twilio: {
            accountSid: credentials.twilio.accountSid,
            authToken: mask(credentials.twilio.authToken),
            defaultPhoneNumber: credentials.twilio.defaultPhoneNumber,
        },
        exotel: {
            apiKey: credentials.exotel.apiKey,
            apiSecret: mask(credentials.exotel.apiSecret),
            exophoneNumber: credentials.exotel.exophoneNumber,
        },
        propnex: { ...credentials.propnex },
    };
}
function validateProvider(provider, credentials) {
    switch (provider) {
        case "twilio": {
            const c = credentials.twilio;
            if (!c.accountSid.trim())
                return "Account SID is required.";
            if (!c.accountSid.trim().startsWith("AC")) {
                return "Account SID must start with AC.";
            }
            if (!c.authToken.trim())
                return "Auth Token is required.";
            if (!c.defaultPhoneNumber.trim())
                return "Default phone number is required.";
            if (!E164_REGEX.test(c.defaultPhoneNumber.trim())) {
                return "Default phone number must be in E.164 format.";
            }
            return null;
        }
        case "exotel": {
            const c = credentials.exotel;
            if (!c.apiKey.trim())
                return "API Key is required.";
            if (!c.apiSecret.trim())
                return "API Secret is required.";
            if (!c.exophoneNumber.trim())
                return "Exophone number is required.";
            return null;
        }
        case "propnex": {
            const c = credentials.propnex;
            if (!c.region.trim())
                return "Region is required.";
            if (!c.environment)
                return "Environment is required.";
            return null;
        }
        default:
            return "Unknown provider.";
    }
}
async function readTelephonySettings(companyId) {
    const company = await prisma_1.default.company.findUnique({
        where: { id: companyId },
        select: { settings: true },
    });
    const settings = (company?.settings ?? {});
    return {
        activeProvider: settings.telephony?.activeProvider ?? null,
        connectionTested: settings.telephony?.connectionTested ?? {},
        connectionStatus: settings.telephony?.connectionStatus ?? {},
        channelSettings: settings.telephony?.channelSettings ?? telephony_1.DEFAULT_CHANNEL_SETTINGS,
        encryptedCredentials: settings.telephony?.encryptedCredentials ?? null,
    };
}
async function writeTelephonySettings(companyId, telephony) {
    const company = await prisma_1.default.company.findUnique({
        where: { id: companyId },
        select: { settings: true },
    });
    const settings = (company?.settings ?? {});
    await prisma_1.default.company.update({
        where: { id: companyId },
        data: {
            settings: {
                ...settings,
                telephony,
            },
        },
    });
}
function readCredentials(settings) {
    if (!settings.encryptedCredentials) {
        return { ...telephony_1.DEFAULT_PROVIDER_CREDENTIALS };
    }
    return (0, credential_crypto_1.decryptCredentials)(settings.encryptedCredentials);
}
class TelephonyService {
    repo = new setup_config_repository_1.SetupConfigRepository(prisma_1.default);
    async getConfig(ctx) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.AGENTS_READ);
        const [telephony, setupConfig, channels] = await Promise.all([
            readTelephonySettings(ctx.companyId),
            this.repo.getSetupConfig(ctx.companyId),
            this.repo.listChannels(ctx.companyId),
        ]);
        const credentials = maskCredentials(readCredentials(telephony));
        return {
            activeProvider: telephony.activeProvider,
            connectionTested: telephony.connectionTested,
            connectionStatus: telephony.connectionStatus,
            channelSettings: telephony.channelSettings,
            providerConfigs: credentials,
            setupConfig: setupConfig
                ? {
                    totalChannels: setupConfig.totalChannels,
                    pulseTimeSeconds: setupConfig.pulseTimeSeconds,
                    deltaSeconds: setupConfig.deltaSeconds,
                    agentsAllocated: setupConfig.agentsAllocated,
                }
                : {
                    totalChannels: 0,
                    pulseTimeSeconds: 60,
                    deltaSeconds: 2,
                    agentsAllocated: 0,
                },
            channels: channels.map((channel) => ({
                id: channel.id,
                channelIndex: channel.channelIndex,
                label: channel.label,
                phoneNumberId: channel.phoneNumberId,
                phoneNumber: channel.phoneNumber?.number ?? null,
            })),
        };
    }
    async saveConfig(ctx, input) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.SETTINGS_WRITE);
        const validationError = validateProvider(input.activeProvider, input.providerConfigs);
        if (validationError) {
            throw new errors_1.ValidationError(validationError);
        }
        const current = await readTelephonySettings(ctx.companyId);
        if (!current.connectionTested[input.activeProvider]) {
            throw new errors_1.ValidationError("Run Test Connection before saving configuration.");
        }
        const encryptedCredentials = (0, credential_crypto_1.encryptCredentials)(input.providerConfigs);
        const telephony = {
            activeProvider: input.activeProvider,
            connectionTested: {
                ...current.connectionTested,
                [input.activeProvider]: true,
            },
            connectionStatus: {
                ...current.connectionStatus,
                [input.activeProvider]: "connected",
            },
            channelSettings: input.channelSettings ?? current.channelSettings,
            encryptedCredentials,
        };
        await writeTelephonySettings(ctx.companyId, telephony);
        if (input.totalChannels !== undefined) {
            await this.repo.upsertSetupConfig(ctx.companyId, {
                totalChannels: input.totalChannels,
                pulseTimeSeconds: input.pulseTimeSeconds,
                deltaSeconds: input.deltaSeconds,
            });
        }
        if (input.channels) {
            await this.repo.replaceChannels(ctx.companyId, input.channels);
        }
        return this.getConfig(ctx);
    }
    async testConnection(ctx, input) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.SETTINGS_WRITE);
        const validationError = validateProvider(input.provider, input.providerConfigs);
        if (validationError) {
            return {
                status: "error",
                responseTimeMs: 0,
                message: validationError,
            };
        }
        const started = Date.now();
        await new Promise((resolve) => setTimeout(resolve, 800));
        const responseTimeMs = Date.now() - started;
        const current = await readTelephonySettings(ctx.companyId);
        await writeTelephonySettings(ctx.companyId, {
            ...current,
            connectionTested: {
                ...current.connectionTested,
                [input.provider]: true,
            },
            connectionStatus: {
                ...current.connectionStatus,
                [input.provider]: "connected",
            },
            encryptedCredentials: (0, credential_crypto_1.encryptCredentials)(input.providerConfigs),
        });
        return {
            status: "success",
            responseTimeMs,
            message: `Successfully connected to ${input.provider}.`,
            connectionHealth: {
                providerStatus: "connected",
                sipStatus: responseTimeMs > 150 ? "warning" : "connected",
                apiConnectivity: "connected",
                voiceServiceStatus: "connected",
                lastSuccessfulConnection: new Date().toISOString(),
            },
        };
    }
    async testCall(ctx, input) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.SETTINGS_WRITE);
        const trimmed = input.phoneNumber.trim();
        if (!E164_REGEX.test(trimmed)) {
            throw new errors_1.ValidationError("Phone number must be in E.164 format.");
        }
        const telephony = await readTelephonySettings(ctx.companyId);
        const provider = input.provider ?? telephony.activeProvider;
        if (!provider) {
            throw new errors_1.ValidationError("Select and configure a provider first.");
        }
        if (!telephony.connectionTested[provider]) {
            throw new errors_1.ValidationError("Test and save provider connection before placing a test call.");
        }
        await new Promise((resolve) => setTimeout(resolve, 1200));
        return {
            status: "success",
            message: `Test call queued to ${trimmed}.`,
            provider,
            phoneNumber: trimmed,
            queuedAt: new Date().toISOString(),
        };
    }
}
exports.TelephonyService = TelephonyService;
exports.telephonyService = new TelephonyService();
//# sourceMappingURL=telephony.service.js.map