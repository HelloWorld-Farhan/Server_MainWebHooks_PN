import type { Request as ExpressRequest } from "express";
import type { GraphQLContext } from "../types/context";
export declare function createGraphQLContext(req?: ExpressRequest, fetchRequest?: Request): Promise<GraphQLContext>;
