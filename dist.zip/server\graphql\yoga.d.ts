import type { Request as ExpressRequest } from "express";
type YogaExpressServerContext = {
    req?: ExpressRequest;
};
export declare const yoga: import("graphql-yoga").YogaServerInstance<YogaExpressServerContext, {}>;
export {};
