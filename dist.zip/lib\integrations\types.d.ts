export type IntegrationId = "google-sheets" | "google-calendar" | "hubspot" | "salesforce" | "email" | "whatsapp";
export type IntegrationStatus = "connected" | "not_connected" | "syncing" | "error";
export type PropNexFieldId = "customerName" | "phoneNumber" | "budget" | "leadStatus" | "followUpDate" | "notes" | "callOutcome" | "aiSummary" | "leadScore" | "temperature" | string;
export type ColumnMapping = {
    propnexField: PropNexFieldId;
    spreadsheetColumn: string;
    label: string;
};
export type SyncResult = "success" | "partial" | "error";
export type SyncHistoryEntry = {
    id: string;
    startedAt: string;
    completedAt: string;
    result: SyncResult;
    rowsSynced: number;
    message: string;
};
export type GoogleSheetsConfig = {
    spreadsheetId: string | null;
    spreadsheetName: string | null;
    worksheetId: string | null;
    worksheetName: string | null;
    columnMappings: ColumnMapping[];
    autoSync: boolean;
    lastSyncResult: SyncResult | null;
    lastSyncMessage: string | null;
};
export type DayOfWeek = "monday" | "tuesday" | "wednesday" | "thursday" | "friday" | "saturday" | "sunday";
export type WorkingHoursDay = {
    enabled: boolean;
    start: string;
    end: string;
};
export type WorkingHours = Record<DayOfWeek, WorkingHoursDay>;
export type GoogleCalendarConfig = {
    calendarId: string | null;
    calendarName: string | null;
    timezone: string;
    workingHours: WorkingHours;
    meetingDurationMinutes: number;
    bufferMinutes: number;
};
export type WorkspaceIntegration = {
    id: IntegrationId;
    name: string;
    status: IntegrationStatus;
    connectedAccount: string | null;
    lastSyncAt: string | null;
    errorMessage: string | null;
    sheetsConfig?: GoogleSheetsConfig;
    calendarConfig?: GoogleCalendarConfig;
};
export type SpreadsheetOption = {
    id: string;
    name: string;
    modifiedAt: string;
    webViewLink?: string;
};
export type WorksheetOption = {
    id: string;
    name: string;
    rowCount: number;
};
export type CalendarOption = {
    id: string;
    name: string;
    primary: boolean;
    timezone: string;
};
export declare const PROPNEX_FIELD_PRESETS: {
    id: PropNexFieldId;
    label: string;
}[];
export declare const SHEET_COLUMN_PRESETS: string[];
export declare const DEFAULT_WORKING_HOURS: WorkingHours;
export declare const DEFAULT_SHEETS_CONFIG: GoogleSheetsConfig;
export declare const DEFAULT_CALENDAR_CONFIG: GoogleCalendarConfig;
export type SheetRow = Record<string, string>;
