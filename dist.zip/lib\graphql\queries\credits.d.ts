export declare const CREDITS_SUMMARY_QUERY = "\n  query CreditsSummary {\n    credits {\n      summary {\n        remaining\n        used\n        total\n        availablePercent\n        renewalAt\n        planId\n      }\n    }\n  }\n";
export type CreditsSummaryResult = {
    credits: {
        summary: {
            remaining: number;
            used: number;
            total: number;
            availablePercent: number;
            renewalAt: string | null;
            planId: string | null;
        };
    };
};
