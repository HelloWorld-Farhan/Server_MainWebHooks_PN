"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.gqlDebug = gqlDebug;
exports.gqlLogError = gqlLogError;
exports.gqlDebugTimed = gqlDebugTimed;
function isGqlTraceEnabled() {
    if (process.env.GRAPHQL_DEBUG === "0")
        return false;
    if (process.env.GRAPHQL_DEBUG === "1")
        return true;
    return process.env.VERCEL === "1";
}
function formatError(error) {
    if (error instanceof Error) {
        return { message: error.message, stack: error.stack };
    }
    return { message: String(error) };
}
function gqlDebug(label, data) {
    if (!isGqlTraceEnabled())
        return;
    console.log(`[gql] ${label}`, { ...data, ts: Date.now() });
}
function gqlLogError(label, error, data) {
    const { message, stack } = formatError(error);
    console.error(`[gql] ${label}`, {
        ...data,
        error: message,
        stack,
        ts: Date.now(),
    });
}
async function gqlDebugTimed(label, fn) {
    const trace = isGqlTraceEnabled();
    const start = performance.now();
    if (trace) {
        console.log(`[gql] ${label}:start`, { ts: Date.now() });
    }
    try {
        const result = await fn();
        if (trace) {
            console.log(`[gql] ${label}:done`, {
                ms: Math.round(performance.now() - start),
                ts: Date.now(),
            });
        }
        return result;
    }
    catch (error) {
        gqlLogError(`${label}:error`, error, {
            ms: Math.round(performance.now() - start),
        });
        throw error;
    }
}
//# sourceMappingURL=debug.js.map