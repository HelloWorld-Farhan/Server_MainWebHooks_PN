import type { CallStatus } from "@prisma/client";
import { type RetryPolicyFields } from "./retry-policy.service";
export type CampaignRetryStatistics = {
    totalCalls: number;
    initialCalls: number;
    retryCalls: number;
    retrySuccessRate: number;
    averageRetryCount: number;
    busy: number;
    noAnswer: number;
    failed: number;
    answered: number;
    completed: number;
    pendingRetries: number;
};
export type CampaignRetryPolicyView = RetryPolicyFields;
export type ContactRetryHistoryEntry = {
    retryNumber: number;
    createdAt: string;
    reason: CallStatus;
    callLogId: string | null;
    status: string;
    jobStatus: string;
};
export type CampaignRetrySummary = {
    policy: CampaignRetryPolicyView;
    statistics: CampaignRetryStatistics;
    pendingRetries: number;
    totalRetries: number;
    completedRetries: number;
    failedRetries: number;
};
export declare class RetryStatisticsService {
    getPolicy(companyId: string, campaignId: string): Promise<CampaignRetryPolicyView | null>;
    getStatistics(companyId: string, campaignId: string): Promise<CampaignRetryStatistics>;
    getHistory(companyId: string, campaignId: string, phoneNumber?: string): Promise<ContactRetryHistoryEntry[]>;
    getPendingRetries(companyId: string, campaignId: string): Promise<{
        id: string;
        phoneNumber: string;
        retryNumber: number;
        retryReason: import("@prisma/client").$Enums.CallStatus;
        scheduledAt: string;
        status: import("@prisma/client").$Enums.ContactRetryJobStatus;
        correlationId: string | null;
    }[]>;
    getSummary(companyId: string, campaignId: string): Promise<CampaignRetrySummary | null>;
}
export declare const retryStatisticsService: RetryStatisticsService;
