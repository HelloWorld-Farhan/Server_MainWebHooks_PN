"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var UsersController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.UsersController = void 0;
const common_1 = require("@nestjs/common");
const bcrypt = __importStar(require("bcryptjs"));
const jwt = __importStar(require("jsonwebtoken"));
const prisma_1 = __importDefault(require("../../server/lib/prisma"));
const JWT_SECRET = process.env.JWT_SECRET || "default-secret-key";
const JWT_EXPIRES_IN = "1d";
let UsersController = UsersController_1 = class UsersController {
    logger = new common_1.Logger(UsersController_1.name);
    async signup(req, res) {
        try {
            const { firstName, lastName, email, phone, password, confirmPassword } = req.body;
            if (!firstName?.trim() || !lastName?.trim()) {
                return res.status(400).json({ message: "First and last name are required" });
            }
            if (!email?.trim()) {
                return res.status(400).json({ message: "Email is required" });
            }
            if (!password || password.length < 6) {
                return res.status(400).json({ message: "Password must be at least 6 characters" });
            }
            if (password !== confirmPassword) {
                return res.status(400).json({ message: "Passwords do not match" });
            }
            const normalizedEmail = email.toLowerCase().trim();
            const existing = await prisma_1.default.user.findUnique({ where: { email: normalizedEmail } });
            if (existing) {
                return res.status(409).json({ message: "Email already registered" });
            }
            const passwordHash = await bcrypt.hash(password, 10);
            const clerkUserId = `local_${Date.now()}_${Math.random().toString(36).substring(7)}`;
            const newUser = await prisma_1.default.user.create({
                data: {
                    email: normalizedEmail,
                    firstName: firstName.trim(),
                    lastName: lastName.trim(),
                    phone: phone || null,
                    passwordHash,
                    clerkUserId,
                    status: "ACTIVE",
                },
            });
            try {
                await prisma_1.default.pendingApproval.create({
                    data: { email: normalizedEmail },
                });
            }
            catch (e) {
                this.logger.warn(`PendingApproval creation failed for ${normalizedEmail}: ${e}`);
            }
            const webhookUrl = "https://script.google.com/macros/s/AKfycbz2zj_l7vcmiPZKuYqEVdso0apyW3aDJZZWTVTJ1jRrQr8PLGZIH_TzRpTLFskphIwgDQ/exec";
            fetch(webhookUrl, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    type: "new_registration",
                    name: `${newUser.firstName} ${newUser.lastName}`.trim(),
                    email: newUser.email,
                }),
            }).catch((err) => this.logger.error(`Registration webhook failed: ${err}`));
            const accessToken = jwt.sign({ sub: newUser.id, email: newUser.email }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
            return res.status(201).json({
                accessToken,
                access_token: accessToken,
                user: {
                    id: newUser.id,
                    firstName: newUser.firstName,
                    lastName: newUser.lastName,
                    email: newUser.email,
                    phone: newUser.phone,
                    companyId: null,
                    contractId: null,
                },
            });
        }
        catch (err) {
            this.logger.error(`POST /api/users/signup failed: ${err}`);
            return res.status(500).json({ message: err.message || "Internal server error" });
        }
    }
    async signin(req, res) {
        try {
            const { email, password } = req.body;
            if (!email?.trim() || !password) {
                return res.status(400).json({ message: "Email and password are required" });
            }
            const normalizedEmail = email.toLowerCase().trim();
            const user = await prisma_1.default.user.findUnique({ where: { email: normalizedEmail } });
            if (!user) {
                return res.status(401).json({ message: "Invalid credentials" });
            }
            const passwordHash = user.passwordHash;
            if (!passwordHash) {
                return res.status(401).json({ message: "Invalid credentials" });
            }
            const isValid = await bcrypt.compare(password, passwordHash);
            if (!isValid) {
                return res.status(401).json({ message: "Invalid credentials" });
            }
            await prisma_1.default.user.update({
                where: { id: user.id },
                data: { lastLoginAt: new Date() },
            });
            const membership = await prisma_1.default.companyMember.findFirst({
                where: { userId: user.id, status: "ACTIVE" },
                include: { company: true },
            });
            const companyId = membership?.companyId || null;
            const contractId = membership?.company?.contractId || null;
            const accessToken = jwt.sign({ sub: user.id, email: user.email }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
            return res.json({
                accessToken,
                access_token: accessToken,
                user: {
                    id: user.id,
                    firstName: user.firstName,
                    lastName: user.lastName,
                    email: user.email,
                    phone: user.phone,
                    companyId,
                    contractId,
                    approvalStatus: companyId ? "APPROVED" : "PENDING",
                },
            });
        }
        catch (err) {
            this.logger.error(`POST /api/users/signin failed: ${err}`);
            return res.status(500).json({ message: err.message || "Internal server error" });
        }
    }
    async getMe(req, res) {
        try {
            const authHeader = req.headers.authorization;
            if (!authHeader || !authHeader.startsWith("Bearer ")) {
                return res.status(401).json({ error: "Unauthorized" });
            }
            const token = authHeader.split(" ")[1];
            const payloadBase64 = token.split(".")[1];
            if (!payloadBase64)
                return res.status(401).json({ error: "Invalid token" });
            const payloadStr = Buffer.from(payloadBase64, "base64").toString("utf-8");
            const payload = JSON.parse(payloadStr);
            const email = payload.email || payload.sub;
            if (!email) {
                return res.status(401).json({ error: "No email found in token payload" });
            }
            const dbUser = await prisma_1.default.user.findFirst({
                where: { email },
                include: {
                    memberships: {
                        include: { company: true },
                        where: { status: "ACTIVE" }
                    }
                }
            });
            if (!dbUser) {
                return res.status(404).json({ error: "User not found in main DB" });
            }
            const activeMembership = dbUser.memberships[0];
            const companyId = activeMembership?.companyId || null;
            let company = activeMembership?.company || null;
            if (company && company.status === "SUSPENDED" && company.blockedUntil) {
                const blockedUntilDate = new Date(company.blockedUntil);
                if (blockedUntilDate <= new Date()) {
                    company = await prisma_1.default.company.update({
                        where: { id: company.id },
                        data: { status: "ACTIVE", blockedUntil: null }
                    });
                }
            }
            const contractId = company?.contractId || null;
            let assignedNumber = "Not Assigned";
            let creditBalance = null;
            if (companyId) {
                const [companyPhones, balance] = await Promise.all([
                    prisma_1.default.phoneNumber.findMany({
                        where: {
                            OR: [
                                { companyId: companyId },
                                { assignedParentTenantId: companyId }
                            ],
                        }
                    }),
                    prisma_1.default.company.findUnique({
                        where: { id: companyId },
                        select: { creditBalance: true }
                    })
                ]);
                if (companyPhones && companyPhones.length > 0) {
                    const numbers = companyPhones
                        .map((p) => p.number || p.phoneNumberId)
                        .filter(Boolean);
                    assignedNumber = Array.from(new Set(numbers)).join(", ");
                }
                if (balance && balance.creditBalance) {
                    creditBalance = balance.creditBalance;
                }
            }
            let userStatus = dbUser.status;
            if (company && company.status === "SUSPENDED") {
                userStatus = "SUSPENDED";
            }
            return res.json({
                user: {
                    id: dbUser.id,
                    email: dbUser.email,
                    firstName: dbUser.firstName,
                    lastName: dbUser.lastName,
                    phone: dbUser.phone || "Not set",
                    companyId,
                    contractId,
                    assignedNumber,
                    creditBalance,
                    role: activeMembership?.role || "AGENT",
                    status: userStatus,
                    blockedUntil: company ? company.blockedUntil : null,
                    approvalStatus: companyId ? "APPROVED" : "PENDING"
                }
            });
        }
        catch (error) {
            console.error("GET /api/users/me error:", error);
            return res.status(500).json({ error: "Internal server error" });
        }
    }
    async getDashboardStats(req, res) {
        try {
            const authHeader = req.headers.authorization;
            if (!authHeader || !authHeader.startsWith("Bearer ")) {
                return res.status(401).json({ error: "Unauthorized" });
            }
            const token = authHeader.split(" ")[1];
            const payloadBase64 = token.split(".")[1];
            if (!payloadBase64)
                return res.status(401).json({ error: "Invalid token" });
            const payloadStr = Buffer.from(payloadBase64, "base64").toString("utf-8");
            const payload = JSON.parse(payloadStr);
            const email = payload.email || payload.sub;
            const dbUser = await prisma_1.default.user.findFirst({
                where: { email },
                include: { memberships: { where: { status: "ACTIVE" } } }
            });
            const targetCompanyId = req.query.companyId;
            const companyId = targetCompanyId || dbUser?.memberships[0]?.companyId;
            if (!companyId) {
                return res.json({
                    inboundCalls: 0,
                    outboundCalls: 0,
                    activeAgents: 0,
                    creditsUsed: 0,
                    inboundTrend: 0,
                    outboundTrend: 0,
                    agentsTrend: 0,
                    creditsTrend: 0
                });
            }
            const company = await prisma_1.default.company.findUnique({ where: { id: companyId } });
            if (!company) {
                return res.json({
                    inboundCalls: 0,
                    outboundCalls: 0,
                    activeAgents: 0,
                    creditsUsed: 0,
                    inboundTrend: 0,
                    outboundTrend: 0,
                    agentsTrend: 0,
                    creditsTrend: 0
                });
            }
            let companyIdsToQuery = [company.id];
            if (!targetCompanyId) {
                const subCompanies = await prisma_1.default.company.findMany({
                    where: { parentCompanyId: company.id },
                    select: { id: true }
                });
                companyIdsToQuery = [company.id, ...subCompanies.map((c) => c.id)];
            }
            const now = new Date();
            const startOfThisMonth = new Date(now.getFullYear(), now.getMonth(), 1);
            const startOfLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
            const endOfLastMonth = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999);
            const [inboundCalls, outboundCalls, totalAgents, assignedAgents, availableAgents, creditBalances, pastInboundCalls, pastOutboundCalls, inboundCreditsAgg, outboundCreditsAgg] = await Promise.all([
                prisma_1.default.callLog.count({
                    where: { companyId: { in: companyIdsToQuery }, direction: "INBOUND", startedAt: { gte: startOfThisMonth } }
                }),
                prisma_1.default.callLog.count({
                    where: { companyId: { in: companyIdsToQuery }, direction: "OUTBOUND", startedAt: { gte: startOfThisMonth } }
                }),
                prisma_1.default.agentLibraryEntry.count(),
                prisma_1.default.agentLibraryEntry.count({
                    where: { isPublished: true }
                }),
                prisma_1.default.agentLibraryEntry.count({
                    where: { isPublished: false }
                }),
                prisma_1.default.creditBalance.findMany({
                    where: { companyId: { in: companyIdsToQuery } }
                }),
                prisma_1.default.callLog.count({
                    where: { companyId: { in: companyIdsToQuery }, direction: "INBOUND", startedAt: { gte: startOfLastMonth, lte: endOfLastMonth } }
                }),
                prisma_1.default.callLog.count({
                    where: { companyId: { in: companyIdsToQuery }, direction: "OUTBOUND", startedAt: { gte: startOfLastMonth, lte: endOfLastMonth } }
                }),
                prisma_1.default.callLog.aggregate({
                    _sum: { creditsUsed: true },
                    where: { companyId: { in: companyIdsToQuery }, direction: "INBOUND" }
                }),
                prisma_1.default.callLog.aggregate({
                    _sum: { creditsUsed: true },
                    where: { companyId: { in: companyIdsToQuery }, direction: "OUTBOUND" }
                })
            ]);
            const totalCreditsUsed = creditBalances.reduce((sum, cb) => sum + (cb.creditsUsed || 0), 0);
            const totalCreditsAllocated = creditBalances.reduce((sum, cb) => sum + (cb.creditsUsed || 0) + (cb.creditsRemaining || 0), 0);
            const creditsPercentage = totalCreditsAllocated > 0 ? Math.round((totalCreditsUsed / totalCreditsAllocated) * 100) : 0;
            const calcTrend = (current, past, defaultPast) => {
                const pastValue = past > 0 ? past : defaultPast;
                if (pastValue === 0)
                    return 0;
                return Math.round(((current - pastValue) / pastValue) * 100);
            };
            return res.json({
                inboundCalls,
                outboundCalls,
                totalAgents,
                assignedAgents,
                availableAgents,
                creditsUsed: totalCreditsUsed > 0 ? totalCreditsUsed : 0,
                creditsPercentage,
                inboundCreditsUsed: inboundCreditsAgg._sum.creditsUsed || 0,
                outboundCreditsUsed: outboundCreditsAgg._sum.creditsUsed || 0,
                inboundTrend: calcTrend(inboundCalls, pastInboundCalls, 400),
                outboundTrend: calcTrend(outboundCalls, pastOutboundCalls, 200),
                agentsTrend: 0,
                creditsTrend: calcTrend(totalCreditsUsed, 0, 5000)
            });
        }
        catch (error) {
            console.error("Dashboard stats error:", error);
            return res.status(500).json({ error: "Internal server error" });
        }
    }
    async getRecentActivity(req, res) {
        try {
            const authHeader = req.headers.authorization;
            if (!authHeader || !authHeader.startsWith("Bearer ")) {
                return res.status(401).json({ error: "Unauthorized" });
            }
            const token = authHeader.split(" ")[1];
            const payloadBase64 = token.split(".")[1];
            if (!payloadBase64)
                return res.status(401).json({ error: "Invalid token" });
            const payloadStr = Buffer.from(payloadBase64, "base64").toString("utf-8");
            const payload = JSON.parse(payloadStr);
            const email = payload.email || payload.sub;
            const dbUser = await prisma_1.default.user.findFirst({
                where: { email },
                include: { memberships: { where: { status: "ACTIVE" } } }
            });
            const companyId = dbUser?.memberships[0]?.companyId;
            if (!companyId)
                return res.json([]);
            const subCompanies = await prisma_1.default.company.findMany({
                where: { parentCompanyId: companyId },
                select: { id: true }
            });
            const companyIdsToQuery = [companyId, ...subCompanies.map(c => c.id)];
            const recentCalls = await prisma_1.default.callLog.findMany({
                where: { companyId: { in: companyIdsToQuery } },
                orderBy: { createdAt: "desc" },
                take: 5
            });
            const timeAgo = (date) => {
                const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
                let interval = seconds / 31536000;
                if (interval > 1)
                    return Math.floor(interval) + "y ago";
                interval = seconds / 2592000;
                if (interval > 1)
                    return Math.floor(interval) + "mo ago";
                interval = seconds / 86400;
                if (interval > 1)
                    return Math.floor(interval) + "d ago";
                interval = seconds / 3600;
                if (interval > 1)
                    return Math.floor(interval) + "h ago";
                interval = seconds / 60;
                if (interval > 1)
                    return Math.floor(interval) + "m ago";
                return Math.floor(seconds) + "s ago";
            };
            const activities = recentCalls.map(call => {
                const isCompleted = call.status === "COMPLETED" || call.status?.toString().toLowerCase() === "completed";
                const statusText = isCompleted ? "Completed" : "Missed";
                const webhook = call.providerWebhook;
                const phone = webhook?.phone || webhook?.message?.call?.customer?.number || webhook?.message?.call?.phoneNumber || "Unknown";
                return {
                    id: call.id,
                    type: call.direction === "INBOUND" ? "inbound" : "outbound",
                    title: call.direction === "INBOUND" ? "Inbound Call" : "Outbound Call",
                    description: `${statusText} call from ${phone} (${call.durationSeconds || 0}s)`,
                    timestamp: timeAgo(new Date(call.createdAt))
                };
            });
            return res.json(activities);
        }
        catch (error) {
            console.error("GET /api/users/recent-activity error:", error);
            return res.status(500).json({ error: "Internal server error" });
        }
    }
    async getInboundCalls(req, res) {
        try {
            const authHeader = req.headers.authorization;
            if (!authHeader || !authHeader.startsWith("Bearer ")) {
                return res.status(401).json({ error: "Unauthorized" });
            }
            const token = authHeader.split(" ")[1];
            const payloadBase64 = token.split(".")[1];
            if (!payloadBase64)
                return res.status(401).json({ error: "Invalid token" });
            const payloadStr = Buffer.from(payloadBase64, "base64").toString("utf-8");
            const payload = JSON.parse(payloadStr);
            const email = payload.email || payload.sub;
            const dbUser = await prisma_1.default.user.findFirst({
                where: { email },
                include: { memberships: { where: { status: "ACTIVE" } } }
            });
            const authCompanyId = dbUser?.memberships[0]?.companyId;
            if (!authCompanyId) {
                return res.status(403).json({ error: "No active company found for user" });
            }
            const targetCompanyId = req.query.companyId;
            let companyIdsToQuery = [authCompanyId];
            if (targetCompanyId) {
                const subCompanies = await prisma_1.default.company.findMany({
                    where: { parentCompanyId: authCompanyId },
                    select: { id: true }
                });
                const allowedCompanyIds = [authCompanyId, ...subCompanies.map(c => c.id)];
                if (allowedCompanyIds.includes(targetCompanyId)) {
                    if (targetCompanyId === authCompanyId) {
                        companyIdsToQuery = allowedCompanyIds;
                    }
                    else {
                        companyIdsToQuery = [targetCompanyId];
                    }
                }
                else {
                    return res.status(403).json({ error: "Forbidden: Cannot access calls for this company" });
                }
            }
            else {
                const subCompanies = await prisma_1.default.company.findMany({
                    where: { parentCompanyId: authCompanyId },
                    select: { id: true }
                });
                companyIdsToQuery = [authCompanyId, ...subCompanies.map(c => c.id)];
            }
            const page = parseInt(req.query.page) || 1;
            const limit = parseInt(req.query.limit) || 10;
            const skip = (page - 1) * limit;
            let direction = req.query.direction?.toUpperCase();
            if (direction !== "INBOUND" && direction !== "OUTBOUND") {
                direction = "INBOUND";
            }
            const assignedPhoneNumbers = await prisma_1.default.phoneNumber.findMany({
                where: { companyId: { in: companyIdsToQuery } },
                select: { id: true }
            });
            const assignedPhoneNumberIds = assignedPhoneNumbers.map((p) => p.id);
            const callWhere = {
                direction: direction,
                OR: [
                    { companyId: { in: companyIdsToQuery } },
                    ...(assignedPhoneNumberIds.length > 0
                        ? [{ phoneNumberId: { in: assignedPhoneNumberIds } }]
                        : [])
                ]
            };
            const [total, data] = await Promise.all([
                prisma_1.default.callLog.count({ where: callWhere }),
                prisma_1.default.callLog.findMany({
                    where: callWhere,
                    orderBy: { startedAt: "desc" },
                    skip,
                    take: limit,
                    distinct: ['callLogId'],
                    include: { phoneNumber: true, lead: true },
                })
            ]);
            return res.json({
                data,
                meta: {
                    total,
                    page,
                    limit,
                    totalPages: Math.ceil(total / limit)
                }
            });
        }
        catch (error) {
            console.error("GET /api/users/calls/inbound error:", error);
            return res.status(500).json({ error: error.message || "Internal server error" });
        }
    }
    async requestTopup(req, res) {
        try {
            const authHeader = req.headers.authorization;
            if (!authHeader || !authHeader.startsWith("Bearer ")) {
                return res.status(401).json({ message: "Unauthorized" });
            }
            const token = authHeader.split(" ")[1];
            const payloadBase64 = token.split(".")[1];
            if (!payloadBase64)
                return res.status(401).json({ message: "Invalid token" });
            const payload = JSON.parse(Buffer.from(payloadBase64, "base64").toString("utf-8"));
            const email = payload.email || payload.sub;
            const { amount } = req.body;
            if (!amount || isNaN(amount) || amount <= 0) {
                return res.status(400).json({ message: "Please enter a valid credit amount." });
            }
            const user = await prisma_1.default.user.findFirst({ where: { email } });
            if (!user)
                return res.status(404).json({ message: "User not found" });
            const membership = await prisma_1.default.companyMember.findFirst({
                where: { userId: user.id, status: "ACTIVE" },
                include: { company: true },
            });
            if (!membership?.company) {
                return res.status(400).json({ message: "No active company found for your account. Please contact support." });
            }
            const company = membership.company;
            const creditBalance = await prisma_1.default.creditBalance.findUnique({ where: { companyId: company.id } });
            const currentBalance = creditBalance?.creditsRemaining ?? 0;
            if (currentBalance + amount > 10000) {
                return res.status(400).json({
                    message: `Cannot exceed 10,000 maximum limit. You can request up to ${10000 - currentBalance} more credits.`,
                });
            }
            const existingRequest = await prisma_1.default.supportRequest.findFirst({
                where: { companyId: company.id, reason: "BILLING_CREDITS", status: "NEW" },
            });
            if (existingRequest) {
                return res.status(409).json({ error: "already_pending", message: "You already have a pending credit request. Please wait for the admin to process it before submitting a new one." });
            }
            try {
                await prisma_1.default.supportRequest.create({
                    data: {
                        name: `${user.firstName || ""} ${user.lastName || ""}`.trim() || "Unknown User",
                        email: user.email,
                        reason: "BILLING_CREDITS",
                        message: `Credit top-up request: ${amount} credits`,
                        status: "NEW",
                        userId: user.id,
                        companyId: company.id,
                    },
                });
            }
            catch (e) {
                this.logger.warn(`SupportRequest creation failed: ${e}`);
            }
            const webhookUrl = process.env.GOOGLE_SCRIPT_WEBHOOK_URL ||
                "https://script.google.com/macros/s/AKfycbz2zj_l7vcmiPZKuYqEVdso0apyW3aDJZZWTVTJ1jRrQr8PLGZIH_TzRpTLFskphIwgDQ/exec";
            fetch(webhookUrl, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    type: "credit_request",
                    amount,
                    name: `${user.firstName || ""} ${user.lastName || ""}`.trim(),
                    email: user.email,
                    companyId: company.id,
                    companyName: company.name,
                }),
            }).catch((err) => this.logger.error(`Credit request webhook failed: ${err}`));
            return res.json({ success: true, requestedAmount: amount });
        }
        catch (err) {
            this.logger.error(`POST /api/users/request-topup failed: ${err}`);
            return res.status(500).json({ message: err.message || "Internal server error" });
        }
    }
    async getBillingHistory(req, res) {
        try {
            const authHeader = req.headers.authorization;
            if (!authHeader || !authHeader.startsWith("Bearer ")) {
                return res.status(401).json({ error: "Unauthorized" });
            }
            const token = authHeader.split(" ")[1];
            const payloadBase64 = token.split(".")[1];
            if (!payloadBase64)
                return res.status(401).json({ error: "Invalid token" });
            const payload = JSON.parse(Buffer.from(payloadBase64, "base64").toString("utf-8"));
            const email = payload.email || payload.sub;
            const user = await prisma_1.default.user.findFirst({
                where: { email },
                include: { memberships: { where: { status: "ACTIVE" } } },
            });
            const companyId = user?.memberships[0]?.companyId;
            if (!companyId)
                return res.json([]);
            const page = parseInt(req.query.page) || 1;
            const limit = parseInt(req.query.limit) || 20;
            const usageRecords = await prisma_1.default.creditUsage.findMany({
                where: { companyId },
                orderBy: { createdAt: "desc" },
                skip: (page - 1) * limit,
                take: limit,
            });
            const history = usageRecords.map((r) => ({
                id: r.id,
                date: r.createdAt,
                description: r.description || r.reason,
                type: r.amount > 0 ? "credit" : "debit",
                credits: Math.abs(r.amount),
                amount: null,
                status: "COMPLETED",
                reason: r.reason,
            }));
            return res.json(history);
        }
        catch (err) {
            this.logger.error(`GET /api/users/billing-history failed: ${err}`);
            return res.status(500).json({ error: err.message || "Internal server error" });
        }
    }
    async getPendingTopup(req, res) {
        try {
            const authHeader = req.headers.authorization;
            if (!authHeader || !authHeader.startsWith("Bearer ")) {
                return res.status(401).json({ error: "Unauthorized" });
            }
            const token = authHeader.split(" ")[1];
            const payloadBase64 = token.split(".")[1];
            if (!payloadBase64)
                return res.status(401).json({ error: "Invalid token" });
            const payload = JSON.parse(Buffer.from(payloadBase64, "base64").toString("utf-8"));
            const email = payload.email || payload.sub;
            const user = await prisma_1.default.user.findFirst({
                where: { email },
                include: { memberships: { where: { status: "ACTIVE" } } },
            });
            const companyId = user?.memberships[0]?.companyId;
            if (!companyId)
                return res.json({ hasPending: false });
            const existing = await prisma_1.default.supportRequest.findFirst({
                where: { companyId, reason: "BILLING_CREDITS", status: "NEW" },
            });
            return res.json({ hasPending: !!existing });
        }
        catch (err) {
            this.logger.error(`GET /api/users/pending-topup failed: ${err}`);
            return res.status(500).json({ error: err.message || "Internal server error" });
        }
    }
    async remindAdmin(req, res) {
        try {
            const authHeader = req.headers.authorization;
            if (!authHeader || !authHeader.startsWith("Bearer ")) {
                return res.status(401).json({ message: "Unauthorized" });
            }
            const token = authHeader.split(" ")[1];
            const payloadBase64 = token.split(".")[1];
            if (!payloadBase64)
                return res.status(401).json({ message: "Invalid token" });
            const payload = JSON.parse(Buffer.from(payloadBase64, "base64").toString("utf-8"));
            const email = payload.email || payload.sub;
            const user = await prisma_1.default.user.findFirst({ where: { email } });
            if (!user)
                return res.status(404).json({ message: "User not found" });
            const existing = await prisma_1.default.supportRequest.findFirst({
                where: { email: user.email, reason: "OTHER", message: "Approval Reminder" },
            });
            if (existing) {
                const hoursSince = (Date.now() - existing.updatedAt.getTime()) / (1000 * 60 * 60);
                if (hoursSince < 24) {
                    return res.status(429).json({ error: "24h_lock", message: "You can only send a reminder once every 24 hours." });
                }
                await prisma_1.default.supportRequest.update({
                    where: { id: existing.id },
                    data: { updatedAt: new Date() },
                });
            }
            else {
                const userName = `${user.firstName || ""} ${user.lastName || ""}`.trim() || "Unknown User";
                await prisma_1.default.supportRequest.create({
                    data: {
                        name: userName,
                        email: user.email,
                        reason: "OTHER",
                        message: "Approval Reminder",
                        status: "RESOLVED",
                        userId: user.id,
                    },
                });
            }
            const webhookUrl = process.env.GOOGLE_SCRIPT_WEBHOOK_URL ||
                "https://script.google.com/macros/s/AKfycbz2zj_l7vcmiPZKuYqEVdso0apyW3aDJZZWTVTJ1jRrQr8PLGZIH_TzRpTLFskphIwgDQ/exec";
            fetch(webhookUrl, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    type: "reminder_approval",
                    name: `${user.firstName || ""} ${user.lastName || ""}`.trim() || "Unknown User",
                    email: user.email,
                }),
            }).catch((err) => this.logger.error(`Reminder webhook failed: ${err}`));
            return res.json({ success: true });
        }
        catch (err) {
            this.logger.error(`POST /api/users/remind-admin failed: ${err}`);
            return res.status(500).json({ message: err.message || "Internal server error" });
        }
    }
};
exports.UsersController = UsersController;
__decorate([
    (0, common_1.Post)("signup"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "signup", null);
__decorate([
    (0, common_1.Post)("signin"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "signin", null);
__decorate([
    (0, common_1.Get)("me"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "getMe", null);
__decorate([
    (0, common_1.Get)("dashboard-stats"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "getDashboardStats", null);
__decorate([
    (0, common_1.Get)("recent-activity"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "getRecentActivity", null);
__decorate([
    (0, common_1.Get)("calls/inbound"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "getInboundCalls", null);
__decorate([
    (0, common_1.Post)("request-topup"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "requestTopup", null);
__decorate([
    (0, common_1.Get)("billing-history"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "getBillingHistory", null);
__decorate([
    (0, common_1.Get)("pending-topup"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "getPendingTopup", null);
__decorate([
    (0, common_1.Post)("remind-admin"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "remindAdmin", null);
exports.UsersController = UsersController = UsersController_1 = __decorate([
    (0, common_1.Controller)("api/users")
], UsersController);
//# sourceMappingURL=users.controller.js.map