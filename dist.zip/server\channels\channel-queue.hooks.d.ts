type CompanyQueueWakeFn = (companyId: string) => Promise<void>;
export declare function registerCompanyQueueWake(fn: CompanyQueueWakeFn): void;
export declare function wakeCompanyQueue(companyId: string): void;
export {};
