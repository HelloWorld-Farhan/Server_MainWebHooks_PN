import type { CampaignAccessType, MemberStatus, UserRole } from "@prisma/client";
import { type EmployeeFilter } from "../repositories/employees.repository";
import type { TenantContext } from "../types/context";
export type InvitationDisplayStatus = "PENDING" | "ACCEPTED" | "EXPIRED";
export type EmployeeConnectionArgs = {
    first?: number;
    after?: string;
    filter?: EmployeeFilter;
};
export declare class EmployeesService {
    private readonly repo;
    getConnection(ctx: TenantContext, args: EmployeeConnectionArgs): Promise<{
        edges: {
            node: {
                id: string;
                userId: string;
                name: string;
                email: string;
                phone: string | null;
                imageUrl: string | null;
                jobTitle: string | null;
                role: import("@prisma/client").$Enums.UserRole;
                customRole: {
                    id: string;
                    name: string;
                    slug: string;
                    permissions: string[];
                    isSystem: boolean;
                } | null;
                campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
                assignedCampaigns: {
                    id: string;
                    name: string;
                    status: import("@prisma/client").$Enums.CampaignStatus;
                }[];
                status: import("@prisma/client").$Enums.MemberStatus;
                invitationStatus: InvitationDisplayStatus;
                lastActiveAt: string | null;
                invitedAt: string | null;
                joinedAt: string | null;
                createdAt: string;
                updatedAt: string;
            };
            cursor: string;
        }[];
        pageInfo: import("../lib/pagination").PageInfo;
        totalCount: number;
    }>;
    getById(ctx: TenantContext, id: string): Promise<{
        id: string;
        userId: string;
        name: string;
        email: string;
        phone: string | null;
        imageUrl: string | null;
        jobTitle: string | null;
        role: import("@prisma/client").$Enums.UserRole;
        customRole: {
            id: string;
            name: string;
            slug: string;
            permissions: string[];
            isSystem: boolean;
        } | null;
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        assignedCampaigns: {
            id: string;
            name: string;
            status: import("@prisma/client").$Enums.CampaignStatus;
        }[];
        status: import("@prisma/client").$Enums.MemberStatus;
        invitationStatus: InvitationDisplayStatus;
        lastActiveAt: string | null;
        invitedAt: string | null;
        joinedAt: string | null;
        createdAt: string;
        updatedAt: string;
    }>;
    getPermissionsForRole(_ctx: TenantContext, role: UserRole): import("../types/permissions").Permission[];
    invite(ctx: TenantContext, input: {
        name: string;
        email: string;
        role: UserRole;
        jobTitle?: string | null;
        campaignAccessType: CampaignAccessType;
        campaignIds?: string[] | null;
    }): Promise<{
        id: string;
        userId: string;
        name: string;
        email: string;
        phone: string | null;
        imageUrl: string | null;
        jobTitle: string | null;
        role: import("@prisma/client").$Enums.UserRole;
        customRole: {
            id: string;
            name: string;
            slug: string;
            permissions: string[];
            isSystem: boolean;
        } | null;
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        assignedCampaigns: {
            id: string;
            name: string;
            status: import("@prisma/client").$Enums.CampaignStatus;
        }[];
        status: import("@prisma/client").$Enums.MemberStatus;
        invitationStatus: InvitationDisplayStatus;
        lastActiveAt: string | null;
        invitedAt: string | null;
        joinedAt: string | null;
        createdAt: string;
        updatedAt: string;
    }>;
    update(ctx: TenantContext, id: string, input: {
        jobTitle?: string | null;
        role?: UserRole;
        campaignAccessType?: CampaignAccessType;
        campaignIds?: string[] | null;
        status?: MemberStatus;
        firstName?: string | null;
        lastName?: string | null;
        phone?: string | null;
    }): Promise<{
        id: string;
        userId: string;
        name: string;
        email: string;
        phone: string | null;
        imageUrl: string | null;
        jobTitle: string | null;
        role: import("@prisma/client").$Enums.UserRole;
        customRole: {
            id: string;
            name: string;
            slug: string;
            permissions: string[];
            isSystem: boolean;
        } | null;
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        assignedCampaigns: {
            id: string;
            name: string;
            status: import("@prisma/client").$Enums.CampaignStatus;
        }[];
        status: import("@prisma/client").$Enums.MemberStatus;
        invitationStatus: InvitationDisplayStatus;
        lastActiveAt: string | null;
        invitedAt: string | null;
        joinedAt: string | null;
        createdAt: string;
        updatedAt: string;
    }>;
    deactivate(ctx: TenantContext, id: string): Promise<{
        id: string;
        userId: string;
        name: string;
        email: string;
        phone: string | null;
        imageUrl: string | null;
        jobTitle: string | null;
        role: import("@prisma/client").$Enums.UserRole;
        customRole: {
            id: string;
            name: string;
            slug: string;
            permissions: string[];
            isSystem: boolean;
        } | null;
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        assignedCampaigns: {
            id: string;
            name: string;
            status: import("@prisma/client").$Enums.CampaignStatus;
        }[];
        status: import("@prisma/client").$Enums.MemberStatus;
        invitationStatus: InvitationDisplayStatus;
        lastActiveAt: string | null;
        invitedAt: string | null;
        joinedAt: string | null;
        createdAt: string;
        updatedAt: string;
    }>;
    delete(ctx: TenantContext, id: string): Promise<boolean>;
    resendInvite(ctx: TenantContext, id: string): Promise<{
        id: string;
        userId: string;
        name: string;
        email: string;
        phone: string | null;
        imageUrl: string | null;
        jobTitle: string | null;
        role: import("@prisma/client").$Enums.UserRole;
        customRole: {
            id: string;
            name: string;
            slug: string;
            permissions: string[];
            isSystem: boolean;
        } | null;
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        assignedCampaigns: {
            id: string;
            name: string;
            status: import("@prisma/client").$Enums.CampaignStatus;
        }[];
        status: import("@prisma/client").$Enums.MemberStatus;
        invitationStatus: InvitationDisplayStatus;
        lastActiveAt: string | null;
        invitedAt: string | null;
        joinedAt: string | null;
        createdAt: string;
        updatedAt: string;
    }>;
    cancelInvite(ctx: TenantContext, id: string): Promise<boolean>;
}
export declare const employeesService: EmployeesService;
