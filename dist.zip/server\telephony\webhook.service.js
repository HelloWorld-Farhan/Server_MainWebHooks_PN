"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.obdWebhookService = exports.ObdWebhookService = void 0;
const zod_1 = require("zod");
const errors_1 = require("../lib/errors");
const public_id_1 = require("../lib/public-id");
const types_1 = require("../lib/public-id/types");
const prisma_1 = __importDefault(require("../lib/prisma"));
const call_log_provider_events_repository_1 = require("../repositories/call-log-provider-events.repository");
const call_logs_repository_1 = require("../repositories/call-logs.repository");
const call_status_lifecycle_1 = require("./call-status-lifecycle");
const webhook_payload_dto_1 = require("./dto/webhook-payload.dto");
const obd_config_1 = require("./obd-config");
const provider_audit_1 = require("./provider-audit");
const status_mapper_1 = require("./status-mapper");
const telephony_logger_1 = require("./telephony-logger");
const webhook_validation_1 = require("./webhook-validation");
const call_service_1 = require("../services/call.service");
const retry_scheduler_service_1 = require("../campaign-execution/retry/retry-scheduler.service");
const redis_client_1 = require("../queues/redis.client");
const campaign_gateway_1 = require("../../modules/websockets/campaign.gateway");
class ObdWebhookService {
    callLogsRepo = new call_logs_repository_1.CallLogsRepository(prisma_1.default);
    providerEventsRepo = new call_log_provider_events_repository_1.CallLogProviderEventsRepository(prisma_1.default);
    assertAuthorized(apiKeyHeader) {
        const expected = (0, obd_config_1.resolveWebhookApiKey)((0, obd_config_1.getObdConfig)());
        if (!expected) {
            throw new errors_1.UnauthorizedError("OBD webhook authentication is not configured");
        }
        if (!apiKeyHeader || apiKeyHeader !== expected) {
            throw new errors_1.UnauthorizedError("Invalid OBD webhook API key");
        }
    }
    async processWebhook(body) {
        const start = performance.now();
        let payload;
        try {
            payload = (0, webhook_payload_dto_1.validateObdWebhookPayload)(body);
        }
        catch (error) {
            if (error instanceof zod_1.z.ZodError) {
                throw new errors_1.ValidationError(error.issues[0]?.message ?? "Invalid OBD webhook payload");
            }
            throw error;
        }
        const callid = payload.callid.trim();
        if (!(0, public_id_1.validatePublicId)(callid, types_1.PublicResourceType.CALL_LOG)) {
            throw new errors_1.ValidationError("Invalid callid public ID format");
        }
        const parsed = (0, public_id_1.parsePublicId)(callid);
        if (!parsed) {
            throw new errors_1.ValidationError("Invalid callid public ID format");
        }
        const entityId = parsed.entityId;
        if (!entityId ||
            (0, public_id_1.inferResourceTypeFromKey)(entityId) !== types_1.PublicResourceType.CALL_LOG) {
            throw new errors_1.ValidationError("callid must reference a call log public ID");
        }
        const callLog = await this.callLogsRepo.findByPublicIdForWebhook(callid);
        if (!callLog || !callLog.company) {
            throw new errors_1.NotFoundError("Call log not found for callid");
        }
        (0, webhook_validation_1.validateWebhookCallLogChain)(payload, callLog);
        const providerEventId = (0, webhook_payload_dto_1.resolveProviderEventId)(payload);
        const correlationId = payload.correlation_id ??
            payload.correlationId ??
            callLog.correlationId ??
            undefined;
        const existingEvent = await this.providerEventsRepo.findExisting(callLog.id, providerEventId);
        if (existingEvent) {
            (0, telephony_logger_1.logObdWebhookDuplicate)({
                correlationId,
                callLogPublicId: callid,
                providerEventId,
                durationMs: Math.round(performance.now() - start),
            });
            return {
                received: true,
                duplicate: true,
                callLogPublicId: callid,
                correlationId,
            };
        }
        const webhookEntry = {
            at: new Date().toISOString(),
            correlationId,
            providerEventId,
            payload,
        };
        const providerWebhook = (0, provider_audit_1.appendProviderWebhook)(callLog.providerWebhook, webhookEntry);
        const mappedStatus = (0, status_mapper_1.mapProviderStatusToCallStatus)(payload.status);
        const isTerminal = (0, call_status_lifecycle_1.isTerminalCallStatus)(callLog.status);
        const canTransition = (0, call_status_lifecycle_1.canTransitionCallStatus)(callLog.status, mappedStatus);
        const inserted = await this.providerEventsRepo.tryInsert({
            callLogId: callLog.id,
            providerEventId,
            correlationId,
        });
        if (!inserted) {
            (0, telephony_logger_1.logObdWebhookDuplicate)({
                correlationId,
                callLogPublicId: callid,
                providerEventId,
                durationMs: Math.round(performance.now() - start),
            });
            return {
                received: true,
                duplicate: true,
                callLogPublicId: callid,
                correlationId,
            };
        }
        if (isTerminal || !canTransition) {
            await this.callLogsRepo.appendProviderWebhookOnly(callLog.companyId, callLog.id, { providerWebhook });
            (0, telephony_logger_1.logObdWebhook)({
                correlationId,
                callLogPublicId: callid,
                providerStatus: payload.status,
                durationSeconds: (0, webhook_payload_dto_1.parseWebhookDuration)(payload.duration),
                durationMs: Math.round(performance.now() - start),
            });
            return { received: true, callLogPublicId: callid, correlationId };
        }
        const durationSeconds = (0, webhook_payload_dto_1.parseWebhookDuration)(payload.duration);
        const answeredAt = (0, webhook_payload_dto_1.parseWebhookTimestamp)(payload.answered_at ?? payload.answeredAt) ??
            undefined;
        const endedAt = (0, webhook_payload_dto_1.parseWebhookTimestamp)(payload.ended_at ?? payload.endedAt) ?? undefined;
        const disconnectReason = payload.disconnect_reason ?? payload.disconnectReason ?? undefined;
        const webhookResult = await call_service_1.callService.handleProviderWebhook({
            companyId: callLog.companyId,
            callLogId: callLog.id,
            currentStatus: callLog.status,
            providerStatus: payload.status,
            durationSeconds: durationSeconds > callLog.durationSeconds
                ? durationSeconds
                : callLog.durationSeconds,
            answeredAt: answeredAt ?? callLog.answeredAt ?? undefined,
            endedAt: endedAt ?? callLog.endedAt ?? undefined,
            disconnectReason,
            providerWebhook,
        });
        if (!webhookResult.applied) {
            return { received: true, callLogPublicId: callid, correlationId };
        }
        if ((0, call_status_lifecycle_1.isTerminalCallStatus)(webhookResult.mappedStatus) &&
            callLog.campaignId) {
            await retry_scheduler_service_1.retrySchedulerService.handleTerminalCall({
                companyId: callLog.companyId,
                callLogId: callLog.id,
                campaignId: callLog.campaignId,
                phone: callLog.phoneNumber?.number,
                mappedStatus: webhookResult.mappedStatus,
                correlationId,
            });
            if (callLog.companyId && (callLog.phoneNumber?.number || callLog.lead?.phone || payload.call?.to)) {
                try {
                    const stateStr = await redis_client_1.redisConnection.get(`campaign-state:${callLog.companyId}`);
                    if (stateStr) {
                        const state = JSON.parse(stateStr);
                        if (state.leads) {
                            const callPhoneToMatch = callLog.lead?.phone || payload.call?.to || payload.call?.from || "";
                            const coreLogPhone = callPhoneToMatch.replace(/\D/g, "").slice(-10);
                            const leadIndex = state.leads.findIndex((l) => {
                                const coreLeadPhone = l.phone?.replace(/\D/g, "").slice(-10);
                                return coreLeadPhone === coreLogPhone && !l.called;
                            });
                            const lead = leadIndex !== -1 ? state.leads[leadIndex] : state.leads.find((l) => {
                                const coreLeadPhone = l.phone?.replace(/\D/g, "").slice(-10);
                                return coreLeadPhone === coreLogPhone;
                            });
                            if (lead) {
                                lead.called = true;
                                lead.isFailed = webhookResult.mappedStatus !== "COMPLETED" && webhookResult.mappedStatus !== "ANSWERED";
                                state.completedCalls = (state.completedCalls || 0) + 1;
                                if (lead.isFailed) {
                                    state.failedCalls = (state.failedCalls || 0) + 1;
                                }
                                else {
                                    state.successfulCalls = (state.successfulCalls || 0) + 1;
                                }
                                if (state.completedCalls >= (state.totalContacts || 0)) {
                                    state.status = "completed";
                                }
                                await redis_client_1.redisConnection.set(`campaign-state:${callLog.companyId}`, JSON.stringify(state));
                                const gateway = campaign_gateway_1.CampaignGateway.getInstance();
                                if (gateway) {
                                    gateway.broadcastCampaignUpdate(callLog.companyId, state);
                                }
                            }
                        }
                    }
                }
                catch (e) {
                    console.error("Failed to update websocket state for webhook", e);
                }
            }
        }
        (0, telephony_logger_1.logObdWebhook)({
            correlationId,
            callLogPublicId: callid,
            providerStatus: payload.status,
            durationSeconds,
            durationMs: Math.round(performance.now() - start),
        });
        return { received: true, callLogPublicId: callid, correlationId };
    }
}
exports.ObdWebhookService = ObdWebhookService;
exports.obdWebhookService = new ObdWebhookService();
//# sourceMappingURL=webhook.service.js.map