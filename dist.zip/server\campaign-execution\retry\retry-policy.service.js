"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.retryPolicyService = exports.RetryPolicyService = void 0;
const prisma_1 = __importDefault(require("../../lib/prisma"));
const RETRIABLE_STATUSES = new Set([
    "FAILED",
    "BUSY",
    "NO_ANSWER",
    "CANCELLED",
    "MISSED",
    "VOICEMAIL",
]);
const NON_RETRIABLE_STATUSES = new Set([
    "ANSWERED",
    "COMPLETED",
]);
class RetryPolicyService {
    isRetriableStatus(status) {
        if (NON_RETRIABLE_STATUSES.has(status)) {
            return false;
        }
        return RETRIABLE_STATUSES.has(status);
    }
    isStatusEnabledByPolicy(status, policy) {
        switch (status) {
            case "BUSY":
                return policy.retryOnBusy;
            case "NO_ANSWER":
                return policy.retryOnNoAnswer;
            case "FAILED":
                return policy.retryOnFailed;
            case "CANCELLED":
                return policy.retryOnCancelled;
            case "VOICEMAIL":
                return policy.retryOnVoicemail;
            case "MISSED":
                return policy.retryOnMissed;
            default:
                return false;
        }
    }
    shouldRetry(policy, status, currentRetryCount) {
        if (!policy.retryEnabled) {
            return false;
        }
        if (!this.isRetriableStatus(status)) {
            return false;
        }
        if (!this.isStatusEnabledByPolicy(status, policy)) {
            return false;
        }
        if (currentRetryCount >= policy.maxRetries) {
            return false;
        }
        return true;
    }
    async countRetriesForContact(companyId, campaignId, phone) {
        return prisma_1.default.callLog.count({
            where: {
                companyId,
                campaignId,
                isRetry: true,
                phoneNumber: { number: phone },
            },
        });
    }
    extractPolicy(execution) {
        return {
            retryEnabled: execution.retryEnabled,
            maxRetries: execution.maxRetries,
            retryDelaySeconds: execution.retryDelaySeconds,
            retryOnBusy: execution.retryOnBusy,
            retryOnNoAnswer: execution.retryOnNoAnswer,
            retryOnFailed: execution.retryOnFailed,
            retryOnCancelled: execution.retryOnCancelled,
            retryOnVoicemail: execution.retryOnVoicemail,
            retryOnMissed: execution.retryOnMissed,
        };
    }
}
exports.RetryPolicyService = RetryPolicyService;
exports.retryPolicyService = new RetryPolicyService();
//# sourceMappingURL=retry-policy.service.js.map