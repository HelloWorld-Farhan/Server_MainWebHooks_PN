type CompanyOrgFields = {
    id: string;
    name: string;
    clerkOrganizationId: string | null;
    ownerUserId: string | null;
};
type EnsureOrgOptions = {
    createdByClerkUserId?: string;
};
export declare function ensureRealClerkOrganizationId(company: CompanyOrgFields, options?: EnsureOrgOptions): Promise<string>;
export {};
