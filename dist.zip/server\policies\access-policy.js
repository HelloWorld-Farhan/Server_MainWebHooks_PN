"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PERMISSIONS = void 0;
exports.toAccessContext = toAccessContext;
exports.hasPermission = hasPermission;
exports.hasAnyPermission = hasAnyPermission;
exports.hasAllPermissions = hasAllPermissions;
exports.canAccessCampaign = canAccessCampaign;
exports.getAccessibleCampaignIds = getAccessibleCampaignIds;
exports.hasAllCampaignAccess = hasAllCampaignAccess;
exports.getAssignableRoles = getAssignableRoles;
exports.canAssignRole = canAssignRole;
exports.canManageUser = canManageUser;
exports.canManageEmployee = canManageEmployee;
exports.canInviteEmployee = canInviteEmployee;
exports.canResendInvitation = canResendInvitation;
exports.canCancelInvitation = canCancelInvitation;
exports.canDeactivateEmployee = canDeactivateEmployee;
exports.canDeleteEmployee = canDeleteEmployee;
exports.canViewEmployee = canViewEmployee;
exports.assertCanManageEmployee = assertCanManageEmployee;
exports.assertCanAssignRole = assertCanAssignRole;
exports.assertCanInviteRole = assertCanInviteRole;
const permissions_1 = require("../../lib/permissions");
Object.defineProperty(exports, "PERMISSIONS", { enumerable: true, get: function () { return permissions_1.PERMISSIONS; } });
const permissions_policy_1 = require("../../lib/permissions-policy");
const errors_1 = require("../lib/errors");
const campaign_access_service_1 = require("../services/campaign-access.service");
function toAccessContext(ctx) {
    return {
        membershipId: ctx.membershipId,
        userId: ctx.userId,
        role: ctx.role,
        permissions: ctx.permissions,
        campaignAccessType: ctx.campaignAccess.type,
        campaignIds: ctx.campaignAccess.campaignIds,
    };
}
function hasPermission(ctx, permission) {
    return (0, permissions_policy_1.ctxHasPermission)(toAccessContext(ctx), permission);
}
function hasAnyPermission(ctx, permissions) {
    return (0, permissions_policy_1.ctxHasAnyPermission)(toAccessContext(ctx), permissions);
}
function hasAllPermissions(ctx, permissions) {
    return (0, permissions_policy_1.ctxHasAllPermissions)(toAccessContext(ctx), permissions);
}
function canAccessCampaign(ctx, campaignId) {
    if (campaign_access_service_1.campaignAccessService.hasAllCampaignAccess(ctx))
        return true;
    return (0, permissions_policy_1.canAccessCampaign)(toAccessContext(ctx), campaignId);
}
function getAccessibleCampaignIds(ctx) {
    return (0, permissions_policy_1.getAccessibleCampaignIds)(toAccessContext(ctx));
}
function hasAllCampaignAccess(ctx) {
    return (0, permissions_policy_1.hasAllCampaignAccess)(toAccessContext(ctx));
}
function getAssignableRoles(ctx) {
    return (0, permissions_policy_1.getAssignableRoles)(toAccessContext(ctx));
}
function canAssignRole(ctx, role) {
    return (0, permissions_policy_1.canAssignRole)(toAccessContext(ctx), role);
}
function canManageUser(ctx, target) {
    return (0, permissions_policy_1.canManageEmployee)(toAccessContext(ctx), target);
}
function canManageEmployee(ctx, target) {
    return (0, permissions_policy_1.canManageEmployee)(toAccessContext(ctx), target);
}
function canInviteEmployee(ctx, roleToAssign, target) {
    return (0, permissions_policy_1.canInviteEmployee)(toAccessContext(ctx), roleToAssign, target);
}
function canResendInvitation(ctx, target) {
    return (0, permissions_policy_1.canResendInvitation)(toAccessContext(ctx), target);
}
function canCancelInvitation(ctx, target) {
    return (0, permissions_policy_1.canCancelInvitation)(toAccessContext(ctx), target);
}
function canDeactivateEmployee(ctx, target) {
    return (0, permissions_policy_1.canDeactivateEmployee)(toAccessContext(ctx), target);
}
function canDeleteEmployee(ctx, target) {
    return (0, permissions_policy_1.canDeleteEmployee)(toAccessContext(ctx), target);
}
function canViewEmployee(ctx, target) {
    return (0, permissions_policy_1.canViewEmployee)(toAccessContext(ctx), target);
}
function assertCanManageEmployee(ctx, target, action) {
    const access = toAccessContext(ctx);
    const allowed = action === "cancel"
        ? (0, permissions_policy_1.canCancelInvitation)(access, target)
        : (0, permissions_policy_1.canManageEmployee)(access, target);
    if (!allowed) {
        if (target.id === ctx.membershipId || target.userId === ctx.userId) {
            throw new errors_1.ForbiddenError(`You cannot ${action} your own account`);
        }
        if (target.role === "OWNER" && ctx.role !== "OWNER") {
            throw new errors_1.ForbiddenError("Only owners can manage owner accounts");
        }
        throw new errors_1.ForbiddenError(`Missing permission for action: ${action}`);
    }
}
function assertCanAssignRole(ctx, role) {
    if (!canAssignRole(ctx, role)) {
        if (role === "OWNER" && ctx.role !== "OWNER") {
            throw new errors_1.ForbiddenError("Only owners can assign the owner role");
        }
        throw new errors_1.ForbiddenError("You cannot assign this role");
    }
}
function assertCanInviteRole(ctx, role) {
    if (!canInviteEmployee(ctx, role)) {
        if (role === "OWNER" && ctx.role !== "OWNER") {
            throw new errors_1.ForbiddenError("Only owners can invite other owners");
        }
        throw new errors_1.ForbiddenError("You cannot invite with this role");
    }
}
//# sourceMappingURL=access-policy.js.map