type CounterKey = "channels_reserved_total" | "channels_released_total" | "calls_queued_total" | "calls_dispatched_from_queue_total";
export declare function incrementChannelMetric(key: CounterKey, amount?: number): void;
export declare function recordQueueWaitMs(ms: number): void;
export declare function getChannelMetricsSnapshot(): {
    average_queue_wait_ms: number;
    queue_wait_sample_count: number;
    channels_reserved_total: number;
    channels_released_total: number;
    calls_queued_total: number;
    calls_dispatched_from_queue_total: number;
};
export declare function logChannelEvent(label: string, data?: Record<string, unknown>): void;
export {};
