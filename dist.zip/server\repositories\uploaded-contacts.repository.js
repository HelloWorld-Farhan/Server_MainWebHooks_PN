"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UploadedContactsRepository = void 0;
const resource_key_1 = require("../lib/resource-key");
const types_1 = require("../lib/public-id/types");
const base_repository_1 = require("./base.repository");
function mergeIncomingContact(existing, incoming) {
    const campaignIds = [
        ...new Set([...existing.campaignIds, ...(incoming.campaignIds ?? [])]),
    ];
    const field1 = incoming.field1?.trim()
        ? incoming.field1.trim()
        : existing.field1;
    const field2 = incoming.field2?.trim()
        ? incoming.field2.trim()
        : existing.field2;
    const field3 = incoming.field3?.trim()
        ? incoming.field3.trim()
        : existing.field3;
    const changed = campaignIds.length !== existing.campaignIds.length ||
        field1 !== existing.field1 ||
        field2 !== existing.field2 ||
        field3 !== existing.field3;
    if (!changed) {
        return null;
    }
    return { field1, field2, field3, campaignIds };
}
class UploadedContactsRepository extends base_repository_1.BaseRepository {
    findMany(companyId) {
        return this.prisma.uploadedContact.findMany({
            where: this.scope(companyId),
            orderBy: { createdAt: "desc" },
        });
    }
    findById(companyId, id) {
        return this.prisma.uploadedContact.findFirst({
            where: { id, companyId },
        });
    }
    findByPhones(companyId, phones) {
        if (phones.length === 0) {
            return Promise.resolve([]);
        }
        return this.prisma.uploadedContact.findMany({
            where: { companyId, phone: { in: phones } },
            select: {
                id: true,
                phone: true,
                field1: true,
                field2: true,
                field3: true,
                campaignIds: true,
            },
        });
    }
    create(companyId, contact) {
        return this.prisma.$transaction(async (tx) => {
            const resourceKey = await (0, resource_key_1.allocateResourceKey)(tx, companyId, types_1.PublicResourceType.CONTACT);
            return tx.uploadedContact.create({
                data: {
                    phone: contact.phone,
                    field1: contact.field1 ?? null,
                    field2: contact.field2 ?? null,
                    field3: contact.field3 ?? null,
                    campaignIds: contact.campaignIds ?? [],
                    resourceKey,
                    company: { connect: { id: companyId } },
                },
            });
        });
    }
    async createMany(companyId, contacts) {
        const seen = new Set();
        const uniqueContacts = [];
        for (const contact of contacts) {
            if (seen.has(contact.phone)) {
                continue;
            }
            seen.add(contact.phone);
            uniqueContacts.push(contact);
        }
        if (uniqueContacts.length === 0) {
            return { created: 0, updated: 0, skipped: 0 };
        }
        const existingRows = await this.findByPhones(companyId, uniqueContacts.map((contact) => contact.phone));
        const existingByPhone = new Map(existingRows.map((row) => [row.phone, row]));
        const toCreate = [];
        const toUpdate = [];
        let skipped = 0;
        for (const contact of uniqueContacts) {
            const existing = existingByPhone.get(contact.phone);
            if (!existing) {
                toCreate.push(contact);
                continue;
            }
            const merged = mergeIncomingContact(existing, contact);
            if (!merged) {
                skipped++;
                continue;
            }
            toUpdate.push({
                id: existing.id,
                ...merged,
            });
        }
        if (toCreate.length > 0) {
            await this.prisma.$transaction(async (tx) => {
                const resourceKeys = await (0, resource_key_1.allocateResourceKeys)(tx, companyId, types_1.PublicResourceType.CONTACT, toCreate.length);
                await tx.uploadedContact.createMany({
                    data: toCreate.map((contact, index) => ({
                        companyId,
                        phone: contact.phone,
                        field1: contact.field1 ?? null,
                        field2: contact.field2 ?? null,
                        field3: contact.field3 ?? null,
                        campaignIds: contact.campaignIds ?? [],
                        resourceKey: resourceKeys[index],
                    })),
                });
            });
        }
        for (const update of toUpdate) {
            await this.prisma.uploadedContact.update({
                where: { id: update.id },
                data: {
                    field1: update.field1,
                    field2: update.field2,
                    field3: update.field3,
                    campaignIds: update.campaignIds,
                },
            });
        }
        return {
            created: toCreate.length,
            updated: toUpdate.length,
            skipped,
        };
    }
    async delete(companyId, id) {
        const existing = await this.findById(companyId, id);
        if (!existing) {
            return false;
        }
        await this.prisma.uploadedContact.delete({ where: { id } });
        return true;
    }
    async bulkDelete(companyId, ids) {
        if (ids.length === 0) {
            return 0;
        }
        const result = await this.prisma.uploadedContact.deleteMany({
            where: { companyId, id: { in: ids } },
        });
        return result.count;
    }
}
exports.UploadedContactsRepository = UploadedContactsRepository;
//# sourceMappingURL=uploaded-contacts.repository.js.map