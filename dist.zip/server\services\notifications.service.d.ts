import type { TenantContext } from "../types/context";
export declare class NotificationsService {
    private readonly repo;
    list(ctx: TenantContext, args: {
        first?: number;
        after?: string;
    }): Promise<import("../lib/pagination").Connection<{
        userId: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        type: import("@prisma/client").$Enums.NotificationType;
        title: string;
        body: string;
        readAt: Date | null;
        data: import("@prisma/client/runtime/library").JsonValue;
    }>>;
}
export declare class IntegrationsService {
    private readonly repo;
    list(ctx: TenantContext): Promise<{
        status: import("@prisma/client").$Enums.IntegrationStatus;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        type: import("@prisma/client").$Enums.IntegrationType;
        connectedAccount: string | null;
        config: import("@prisma/client/runtime/library").JsonValue;
        credentialsRef: string | null;
        lastSyncAt: Date | null;
        errorMessage: string | null;
    }[]>;
}
export declare class SchedulerService {
    private readonly repo;
    listUpcoming(ctx: TenantContext, limit?: number): Promise<{
        status: import("@prisma/client").$Enums.SchedulerEventStatus;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        type: import("@prisma/client").$Enums.SchedulerEventType;
        assignedUserId: string | null;
        description: string | null;
        leadId: string | null;
        title: string;
        startAt: Date;
        endAt: Date | null;
        timezone: string;
        externalCalendarId: string | null;
        externalEventId: string | null;
        reminderAt: Date | null;
        metadata: import("@prisma/client/runtime/library").JsonValue;
    }[]>;
}
export declare const notificationsService: NotificationsService;
export declare const integrationsService: IntegrationsService;
export declare const schedulerService: SchedulerService;
