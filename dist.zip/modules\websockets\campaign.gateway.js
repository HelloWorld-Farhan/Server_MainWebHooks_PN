"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var CampaignGateway_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.CampaignGateway = void 0;
const websockets_1 = require("@nestjs/websockets");
const socket_io_1 = require("socket.io");
const clerk_config_1 = require("../../auth/clerk-config");
let CampaignGateway = class CampaignGateway {
    static { CampaignGateway_1 = this; }
    server;
    static instance;
    constructor() {
        CampaignGateway_1.instance = this;
    }
    static getInstance() {
        return CampaignGateway_1.instance;
    }
    handleConnection(client) {
        const companyId = client.handshake.query.companyId;
        if (companyId) {
            client.join(`company:${companyId}`);
        }
    }
    handleDisconnect(client) {
    }
    broadcastCampaignUpdate(companyId, campaignState) {
        if (this.server) {
            this.server.to(`company:${companyId}`).emit('campaign-updated', campaignState);
        }
    }
};
exports.CampaignGateway = CampaignGateway;
__decorate([
    (0, websockets_1.WebSocketServer)(),
    __metadata("design:type", socket_io_1.Server)
], CampaignGateway.prototype, "server", void 0);
exports.CampaignGateway = CampaignGateway = CampaignGateway_1 = __decorate([
    (0, websockets_1.WebSocketGateway)({
        cors: {
            origin: (0, clerk_config_1.getClerkAuthorizedParties)(),
            credentials: true,
        },
    }),
    __metadata("design:paramtypes", [])
], CampaignGateway);
//# sourceMappingURL=campaign.gateway.js.map