import type { CallStatus } from "@prisma/client";
import { callService } from "./call.service";
import type { TenantContext } from "../types/context";
export type CreateOutboundCallInput = {
    campaignId: string;
    phoneNumber: string;
};
export type CreateOutboundCallResult = {
    callLogId: string;
    phoneNumberId: string;
    status: "QUEUED" | "QUEUED_AT_PROVIDER" | "FAILED";
};
export type CreateRetryOutboundCallInput = {
    campaignId: string;
    phoneNumber: string;
    parentCallLogId: string;
    retryNumber: number;
    retryReason: CallStatus;
    correlationId?: string;
};
export declare class OutboundCallsService {
    private readonly dispatchService;
    private readonly phoneNumbersRepo;
    private readonly callLogsRepo;
    constructor(dispatchService?: {
        requestDispatch: typeof callService.requestDispatch;
    });
    createOutboundCall(ctx: TenantContext, input: CreateOutboundCallInput): Promise<CreateOutboundCallResult>;
    createRetryOutboundCall(ctx: TenantContext, input: CreateRetryOutboundCallInput): Promise<CreateOutboundCallResult>;
    private createOutboundCallRecords;
}
export declare const outboundCallsService: OutboundCallsService;
