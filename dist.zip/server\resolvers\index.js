"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolvers = void 0;
const prisma_1 = __importDefault(require("../lib/prisma"));
const agents_service_1 = require("../services/agents.service");
const agent_library_service_1 = require("../services/agent-library.service");
const analytics_service_1 = require("../services/analytics.service");
const api_keys_service_1 = require("../services/api-keys.service");
const billing_service_1 = require("../services/billing.service");
const campaigns_service_1 = require("../services/campaigns.service");
const call_logs_service_1 = require("../services/call-logs.service");
const outbound_campaigns_service_1 = require("../services/outbound-campaigns.service");
const credits_service_1 = require("../services/credits.service");
const employees_service_1 = require("../services/employees.service");
const events_service_1 = require("../services/events.service");
const leads_service_1 = require("../services/leads.service");
const phone_numbers_service_1 = require("../services/phone-numbers.service");
const notifications_service_1 = require("../services/notifications.service");
const uploaded_contacts_service_1 = require("../services/uploaded-contacts.service");
const tenant_service_1 = require("../services/tenant.service");
function parseCallLogFilter(filter) {
    if (!filter)
        return undefined;
    return {
        direction: filter.direction,
        status: filter.status,
        aiAgentId: filter.aiAgentId,
        campaignId: filter.campaignId,
        phoneNumberId: filter.phoneNumberId,
        assignedUserId: filter.assignedUserId,
        dateFrom: filter.dateFrom ? new Date(filter.dateFrom) : undefined,
        dateTo: filter.dateTo ? new Date(filter.dateTo) : undefined,
        search: filter.search,
        callLogId: filter.callLogId,
    };
}
function parsePhoneNumberFilter(filter) {
    if (!filter)
        return undefined;
    return {
        number: filter.number,
        numberContains: filter.numberContains,
        labelContains: filter.labelContains,
        search: filter.search,
        provider: filter.provider,
        status: filter.status,
        inboundAgentId: filter.inboundAgentId,
        outboundAgentId: filter.outboundAgentId,
        hasInboundAgent: filter.hasInboundAgent,
        hasOutboundAgent: filter.hasOutboundAgent,
        channelIndex: filter.channelIndex,
        hasChannelAssignment: filter.hasChannelAssignment,
        createdFrom: filter.createdFrom
            ? new Date(filter.createdFrom)
            : undefined,
        createdTo: filter.createdTo ? new Date(filter.createdTo) : undefined,
        lastActivityFrom: filter.lastActivityFrom
            ? new Date(filter.lastActivityFrom)
            : undefined,
        lastActivityTo: filter.lastActivityTo
            ? new Date(filter.lastActivityTo)
            : undefined,
        ids: filter.ids,
    };
}
function parsePhoneNumberSort(sort) {
    if (!sort?.field)
        return undefined;
    return {
        field: sort.field,
        direction: (sort.direction === "ASC" ? "ASC" : "DESC"),
    };
}
function parseLeadFilter(filter) {
    if (!filter)
        return undefined;
    return {
        dormantOnly: filter.dormantOnly,
        minDaysInactive: filter.minDaysInactive,
        temperature: filter.temperature,
    };
}
exports.resolvers = {
    Query: {
        viewer: (_, __, ctx) => tenant_service_1.tenantService.getViewer(ctx),
        credits: () => ({}),
        billing: () => ({}),
        callLogs: () => ({}),
        analytics: () => ({}),
        agents: () => ({}),
        agentLibrary: () => ({}),
        phoneNumbers: () => ({}),
        uploadedContacts: () => ({}),
        leads: () => ({}),
        outboundCampaigns: () => ({}),
        notifications: () => ({}),
        integrations: () => ({}),
        scheduler: () => ({}),
        events: () => ({}),
        campaigns: () => ({}),
        employees: () => ({}),
        apiKeys: () => ({}),
    },
    Mutation: {
        credits: () => ({}),
        callLogs: () => ({}),
        agents: () => ({}),
        phoneNumbers: () => ({}),
        uploadedContacts: () => ({}),
        leads: () => ({}),
        outboundCampaigns: () => ({}),
        campaigns: () => ({}),
        employees: () => ({}),
        apiKeys: () => ({}),
    },
    CreditsQueries: {
        summary: (_, __, ctx) => credits_service_1.creditsService.getSummary(ctx),
        usageHistory: (_, args, ctx) => credits_service_1.creditsService.getUsageHistory(ctx, args),
    },
    CreditsMutations: {
        adjustCredits: (_, args, ctx) => credits_service_1.creditsService.adjustCredits(ctx, args.amount, args.description),
    },
    BillingQueries: {
        subscription: (_, __, ctx) => billing_service_1.billingService.getSubscription(ctx),
        invoices: (_, args, ctx) => billing_service_1.billingService.getInvoices(ctx, args),
        rates: (_, __, ctx) => billing_service_1.billingService.getRates(ctx),
    },
    CallLogsQueries: {
        recent: (_, args, ctx) => call_logs_service_1.callLogsService.getRecent(ctx, args.limit),
        connection: (_, args, ctx) => call_logs_service_1.callLogsService.getConnection(ctx, {
            first: args.first,
            after: args.after,
            filter: parseCallLogFilter(args.filter),
        }),
        detail: (_, args, ctx) => call_logs_service_1.callLogsService.getDetail(ctx, args.id),
    },
    CallLogsMutations: {
        recordCallCompleted: async (_, args, ctx) => call_logs_service_1.callLogsService.recordCompletedWithBilling(ctx, args.callLogId),
        updateOutcome: (_, args, ctx) => call_logs_service_1.callLogsService.updateOutcome(ctx, args.id, args.outcome, args.reactivationPlan),
        addInternalNote: (_, args, ctx) => call_logs_service_1.callLogsService.addInternalNote(ctx, args.callLogId, args.content),
        updateInternalNote: (_, args, ctx) => call_logs_service_1.callLogsService.updateInternalNote(ctx, args.id, args.content),
        deleteInternalNote: (_, args, ctx) => call_logs_service_1.callLogsService.deleteInternalNote(ctx, args.id),
    },
    AnalyticsQueries: {
        summary: (_, args, ctx) => analytics_service_1.analyticsService.getSummary(ctx, args.granularity, args.dateFrom ? new Date(args.dateFrom) : undefined, args.dateTo ? new Date(args.dateTo) : undefined),
        timeSeries: (_, args, ctx) => analytics_service_1.analyticsService.getTimeSeries(ctx, args.granularity, args.dateFrom ? new Date(args.dateFrom) : undefined, args.dateTo ? new Date(args.dateTo) : undefined),
    },
    AgentsQueries: {
        statusSummary: (_, __, ctx) => agents_service_1.agentsService.getStatusSummary(ctx),
        list: (_, __, ctx) => agents_service_1.agentsService.list(ctx),
        byId: (_, args, ctx) => agents_service_1.agentsService.getById(ctx, args.id),
    },
    AgentsMutations: {
        create: (_, args, ctx) => agents_service_1.agentsService.create(ctx, args.input),
        update: (_, args, ctx) => agents_service_1.agentsService.update(ctx, args.id, args.input),
    },
    AgentLibraryQueries: {
        list: (_, __, ctx) => agent_library_service_1.agentLibraryService.list(ctx),
        bySlug: (_, args, ctx) => agent_library_service_1.agentLibraryService.getBySlug(ctx, args.slug),
    },
    PhoneNumbersQueries: {
        list: (_, args, ctx) => phone_numbers_service_1.phoneNumbersService.list(ctx, parsePhoneNumberFilter(args.filter), parsePhoneNumberSort(args.sort)),
        connection: (_, args, ctx) => phone_numbers_service_1.phoneNumbersService.getConnection(ctx, {
            first: args.first,
            after: args.after,
            filter: parsePhoneNumberFilter(args.filter),
            sort: parsePhoneNumberSort(args.sort),
        }),
        byId: (_, args, ctx) => phone_numbers_service_1.phoneNumbersService.getById(ctx, args.id),
    },
    PhoneNumbersMutations: {
        create: (_, args, ctx) => phone_numbers_service_1.phoneNumbersService.create(ctx, args.input),
        update: (_, args, ctx) => phone_numbers_service_1.phoneNumbersService.update(ctx, args.id, args.input),
    },
    UploadedContactsQueries: {
        list: (_, __, ctx) => uploaded_contacts_service_1.uploadedContactsService.list(ctx),
    },
    UploadedContactsMutations: {
        create: (_, args, ctx) => uploaded_contacts_service_1.uploadedContactsService.create(ctx, args.phone),
        importContacts: (_, args, ctx) => uploaded_contacts_service_1.uploadedContactsService.importContacts(ctx, args.contacts),
        delete: (_, args, ctx) => uploaded_contacts_service_1.uploadedContactsService.delete(ctx, args.id),
        bulkDelete: (_, args, ctx) => uploaded_contacts_service_1.uploadedContactsService.bulkDelete(ctx, args.ids),
    },
    LeadsQueries: {
        connection: (_, args, ctx) => leads_service_1.leadsService.getConnection(ctx, {
            first: args.first,
            after: args.after,
            filter: parseLeadFilter(args.filter),
        }),
        byId: (_, args, ctx) => leads_service_1.leadsService.getById(ctx, args.id),
        temperatureBreakdown: (_, __, ctx) => leads_service_1.leadsService.getTemperatureBreakdown(ctx),
    },
    LeadsMutations: {
        importRows: (_, args, ctx) => leads_service_1.leadsService.importRows(ctx, args.rows),
    },
    OutboundCampaignsQueries: {
        list: (_, __, ctx) => outbound_campaigns_service_1.outboundCampaignsService.list(ctx),
    },
    OutboundCampaignsMutations: {
        create: (_, args, ctx) => outbound_campaigns_service_1.outboundCampaignsService.create(ctx, args.input),
        launch: (_, args, ctx) => outbound_campaigns_service_1.outboundCampaignsService.launch(ctx, args.id),
        pause: (_, args, ctx) => outbound_campaigns_service_1.outboundCampaignsService.pause(ctx, args.id),
    },
    NotificationQueries: {
        list: (_, args, ctx) => notifications_service_1.notificationsService.list(ctx, args),
    },
    IntegrationQueries: {
        list: (_, __, ctx) => notifications_service_1.integrationsService.list(ctx),
    },
    SchedulerQueries: {
        upcoming: (_, args, ctx) => notifications_service_1.schedulerService.listUpcoming(ctx, args.limit),
    },
    EventQueries: {
        recent: (_, args, ctx) => events_service_1.eventsService.listRecent(ctx, args.limit),
    },
    CampaignsQueries: {
        connection: (_, args, ctx) => campaigns_service_1.campaignsService.getConnection(ctx, {
            first: args.first,
            after: args.after,
            filter: args.filter
                ? {
                    search: args.filter.search,
                    status: args.filter.status,
                    aiEnabled: args.filter.aiEnabled,
                }
                : undefined,
        }),
        byId: (_, args, ctx) => campaigns_service_1.campaignsService.getById(ctx, args.id),
        contacts: (_, args, ctx) => campaigns_service_1.campaignsService.getContacts(ctx, args.campaignId, args.first, args.after),
        callLogs: (_, args, ctx) => campaigns_service_1.campaignsService.getCallLogs(ctx, args.campaignId, args.first, args.after),
        documents: (_, args, ctx) => campaigns_service_1.campaignsService.getDocuments(ctx, args.campaignId),
        activities: (_, args, ctx) => campaigns_service_1.campaignsService.getActivities(ctx, args.campaignId, args.limit),
        agents: (_, args, ctx) => campaigns_service_1.campaignsService.getAgents(ctx, args.campaignId),
    },
    CampaignsMutations: {
        create: (_, args, ctx) => campaigns_service_1.campaignsService.create(ctx, args.input),
        update: (_, args, ctx) => campaigns_service_1.campaignsService.update(ctx, args.id, args.input),
        updateAi: (_, args, ctx) => campaigns_service_1.campaignsService.updateAi(ctx, args.id, args.input),
        bulkUpdate: (_, args, ctx) => campaigns_service_1.campaignsService.bulkUpdate(ctx, args.input),
        bulkDelete: (_, args, ctx) => campaigns_service_1.campaignsService.bulkDelete(ctx, args.ids),
        archive: (_, args, ctx) => campaigns_service_1.campaignsService.archive(ctx, args.id),
        delete: (_, args, ctx) => campaigns_service_1.campaignsService.delete(ctx, args.id),
        resendInvitation: (_, args, ctx) => campaigns_service_1.campaignsService.resendInvitation(ctx, args.campaignId),
        cancelInvitation: (_, args, ctx) => campaigns_service_1.campaignsService.cancelInvitation(ctx, args.campaignId),
        generateNewInvitation: (_, args, ctx) => campaigns_service_1.campaignsService.generateNewInvitation(ctx, args.campaignId),
    },
    EmployeesQueries: {
        connection: (_, args, ctx) => employees_service_1.employeesService.getConnection(ctx, args),
        byId: (_, args, ctx) => employees_service_1.employeesService.getById(ctx, args.id),
        permissionsForRole: (_, args, ctx) => employees_service_1.employeesService.getPermissionsForRole(ctx, args.role),
    },
    EmployeesMutations: {
        invite: (_, args, ctx) => employees_service_1.employeesService.invite(ctx, args.input),
        update: (_, args, ctx) => employees_service_1.employeesService.update(ctx, args.id, args.input),
        deactivate: (_, args, ctx) => employees_service_1.employeesService.deactivate(ctx, args.id),
        delete: (_, args, ctx) => employees_service_1.employeesService.delete(ctx, args.id),
        resendInvite: (_, args, ctx) => employees_service_1.employeesService.resendInvite(ctx, args.id),
        cancelInvite: (_, args, ctx) => employees_service_1.employeesService.cancelInvite(ctx, args.id),
    },
    UploadedContact: {
        campaigns: (parent, _, ctx) => Promise.all((parent.campaignIds ?? []).map((id) => ctx.loaders.campaign.load(id))).then((campaigns) => campaigns.filter((campaign) => campaign !== null)),
    },
    Campaign: {
        execution: async (parent, _, ctx) => {
            const execution = await prisma_1.default.campaignExecution.findFirst({
                where: {
                    companyId: parent.companyId ?? ctx.companyId,
                    campaignId: parent.id,
                },
                select: {
                    status: true,
                    scheduledAt: true,
                    totalContacts: true,
                },
            });
            if (!execution)
                return null;
            return {
                status: execution.status,
                scheduledAt: execution.scheduledAt?.toISOString() ?? null,
                totalContacts: execution.totalContacts,
            };
        },
    },
    CallLog: {
        lead: (parent, _, ctx) => parent.leadId ? ctx.loaders.lead.load(parent.leadId) : null,
        aiAgent: (parent, _, ctx) => (parent.aiAgentId ? ctx.loaders.aiAgent.load(parent.aiAgentId) : null),
        phoneNumber: (parent, _, ctx) => parent.phoneNumberId
            ? ctx.loaders.phoneNumber.load(parent.phoneNumberId)
            : null,
        campaign: async (parent, _, ctx) => {
            if (!parent.campaignId)
                return null;
            const campaign = await ctx.loaders.campaign.load(parent.campaignId);
            if (!campaign)
                return null;
            return {
                ...campaign,
                createdAt: campaign.createdAt.toISOString(),
                updatedAt: campaign.updatedAt.toISOString(),
                lastActivityAt: campaign.lastActivityAt?.toISOString() ?? null,
            };
        },
    },
    CreditUsage: {
        createdAt: (parent) => typeof parent.createdAt === "string"
            ? parent.createdAt
            : parent.createdAt.toISOString(),
        reason: (parent) => parent.reason,
    },
    BillingInvoice: {
        issuedAt: (parent) => parent.issuedAt.toISOString(),
        dueAt: (parent) => parent.dueAt?.toISOString() ?? null,
        paidAt: (parent) => parent.paidAt?.toISOString() ?? null,
    },
    Notification: {
        createdAt: (parent) => parent.createdAt.toISOString(),
        readAt: (parent) => parent.readAt?.toISOString() ?? null,
    },
    Integration: {
        lastSyncAt: (parent) => parent.lastSyncAt?.toISOString() ?? null,
    },
    SchedulerEvent: {
        startAt: (parent) => parent.startAt.toISOString(),
        endAt: (parent) => parent.endAt?.toISOString() ?? null,
    },
    SystemEvent: {
        createdAt: (parent) => parent.createdAt.toISOString(),
    },
    ApiKeysQueries: {
        connection: (_, args, ctx) => api_keys_service_1.apiKeysService.getConnection(ctx, {
            first: args.first,
            after: args.after,
            filter: args.filter,
        }),
        byId: (_, args, ctx) => api_keys_service_1.apiKeysService.getById(ctx, args.id),
        availableScopes: (_, __, ctx) => api_keys_service_1.apiKeysService.listAvailableScopes(ctx),
        accessibleCampaigns: (_, __, ctx) => api_keys_service_1.apiKeysService.listAccessibleCampaigns(ctx),
    },
    ApiKeysMutations: {
        create: (_, args, ctx) => api_keys_service_1.apiKeysService.create(ctx, args.input),
        update: (_, args, ctx) => api_keys_service_1.apiKeysService.update(ctx, args.id, args.input),
        enable: (_, args, ctx) => api_keys_service_1.apiKeysService.enable(ctx, args.id),
        disable: (_, args, ctx) => api_keys_service_1.apiKeysService.disable(ctx, args.id),
        delete: (_, args, ctx) => api_keys_service_1.apiKeysService.delete(ctx, args.id),
        regenerate: (_, args, ctx) => api_keys_service_1.apiKeysService.regenerate(ctx, args.id),
        rotateSecret: (_, args, ctx) => api_keys_service_1.apiKeysService.rotateSecret(ctx, args.id),
        updateScopes: (_, args, ctx) => api_keys_service_1.apiKeysService.updateScopes(ctx, args.id, args.scopes),
        updateCampaignAccess: (_, args, ctx) => api_keys_service_1.apiKeysService.updateCampaignAccess(ctx, args.id, args.input),
        updateExpiration: (_, args, ctx) => api_keys_service_1.apiKeysService.updateExpiration(ctx, args.id, args.expiresAt === undefined ? null : args.expiresAt),
    },
};
//# sourceMappingURL=index.js.map