"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RetryWorker = void 0;
const common_1 = require("@nestjs/common");
const run_worker_task_1 = require("../../lib/run-worker-task");
const retry_config_1 = require("../retry/retry.config");
const retry_worker_service_1 = require("../retry/retry-worker.service");
let RetryWorker = class RetryWorker {
    interval = null;
    processing = false;
    onModuleInit() {
        (0, run_worker_task_1.runWorkerTask)("retry", () => this.tick());
        this.interval = setInterval(() => (0, run_worker_task_1.runWorkerTask)("retry", () => this.tick()), retry_config_1.retryConfig.workerIntervalMs);
    }
    onModuleDestroy() {
        if (this.interval) {
            clearInterval(this.interval);
            this.interval = null;
        }
    }
    async tick() {
        if (this.processing) {
            return;
        }
        this.processing = true;
        try {
            await retry_worker_service_1.retryWorkerService.processDueRetries();
        }
        finally {
            this.processing = false;
        }
    }
};
exports.RetryWorker = RetryWorker;
exports.RetryWorker = RetryWorker = __decorate([
    (0, common_1.Injectable)()
], RetryWorker);
//# sourceMappingURL=retry.worker.js.map