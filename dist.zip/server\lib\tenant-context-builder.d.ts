import type { CompanyMember, User } from "@prisma/client";
import type { TenantContext } from "../types/context";
type MembershipWithRelations = CompanyMember & {
    user: User;
    customRole?: {
        permissions: string[];
    } | null;
    campaignAccess?: {
        campaignId: string;
    }[];
};
export declare function buildTenantContext(clerkUserId: string, companyId: string, membership: MembershipWithRelations): Promise<TenantContext>;
export {};
