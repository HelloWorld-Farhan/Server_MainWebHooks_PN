import type { Request } from "express";
export declare function requireIntegrationsRead(req: Request): Promise<{
    error: null;
    ctx: import("../../server/types/context").TenantContext;
} | {
    error: {
        status: number;
        body: {
            error: string;
        };
    };
    ctx: null;
}>;
export declare function requireIntegrationsWrite(req: Request): Promise<{
    error: null;
    ctx: import("../../server/types/context").TenantContext;
} | {
    error: {
        status: number;
        body: {
            error: string;
        };
    };
    ctx: null;
}>;
export declare function requireAgentsRead(req: Request): Promise<{
    error: null;
    ctx: import("../../server/types/context").TenantContext;
} | {
    error: {
        status: number;
        body: {
            error: string;
        };
    };
    ctx: null;
}>;
export declare function requireAgentsWrite(req: Request): Promise<{
    error: null;
    ctx: import("../../server/types/context").TenantContext;
} | {
    error: {
        status: number;
        body: {
            error: string;
        };
    };
    ctx: null;
}>;
