import type { ObdWebhookPayload } from "./dto/webhook-payload.dto";
export type WebhookCallLogContext = {
    id: string;
    companyId: string | null;
    campaignId: string | null;
    publicId: string;
    status: import("@prisma/client").CallStatus;
    correlationId: string | null;
    phoneNumber: {
        id: string;
        number: string;
        campaignId: string | null;
        companyId: string | null;
    } | null;
    campaign: {
        id: string;
        resourceKey: string;
        companyId: string | null;
    } | null;
    company: {
        id: string;
        cli: string;
    };
};
export declare function validateWebhookCallLogChain(payload: ObdWebhookPayload, callLog: WebhookCallLogContext): void;
