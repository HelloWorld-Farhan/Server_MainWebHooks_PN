"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.creditsService = exports.CreditsService = void 0;
const cache_service_1 = require("../cache/cache.service");
const keys_1 = require("../cache/keys");
const pagination_1 = require("../lib/pagination");
const prisma_1 = __importDefault(require("../lib/prisma"));
const credits_repository_1 = require("../repositories/credits.repository");
const permissions_1 = require("../types/permissions");
const tenant_service_1 = require("./tenant.service");
const events_service_1 = require("./events.service");
class CreditsService {
    repo = new credits_repository_1.CreditsRepository(prisma_1.default);
    async getSummary(ctx) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CREDITS_READ);
        return cache_service_1.cacheService.getOrSet(keys_1.cacheKeys.companyCredits(ctx.companyId), keys_1.CACHE_TTL.CREDITS, async () => {
            const balance = await this.repo.ensureBalance(ctx.companyId);
            const total = balance.creditsRemaining + balance.creditsUsed;
            const availablePercent = total > 0
                ? Math.round((balance.creditsRemaining / total) * 100)
                : 0;
            return {
                remaining: balance.creditsRemaining,
                used: balance.creditsUsed,
                total,
                availablePercent,
                renewalAt: balance.renewalAt?.toISOString() ?? null,
                planId: balance.planId,
            };
        });
    }
    async getUsageHistory(ctx, args) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CREDITS_READ);
        const limit = Math.min(args.first ?? 20, 100);
        const items = await this.repo.listUsage(ctx.companyId, limit, args.after);
        return (0, pagination_1.buildConnection)(items, limit, (item) => (0, pagination_1.encodeIdCursor)(item.id, item.createdAt));
    }
    async debitForCall(ctx, callLogId, amount, description) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CREDITS_WRITE);
        const usage = await this.repo.recordUsage(ctx.companyId, {
            amount,
            reason: "CALL",
            callLogId,
            description,
        });
        await cache_service_1.cacheService.invalidateCompanyCredits(ctx.companyId);
        await cache_service_1.cacheService.invalidateBillingPages(ctx.companyId);
        await events_service_1.eventsService.emit(ctx, {
            type: "CALL_COMPLETED",
            entityType: "CallLog",
            entityId: callLogId,
            title: "Credits consumed for call",
            payload: { amount },
        });
        return usage;
    }
    async adjustCredits(ctx, amount, description) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CREDITS_WRITE);
        const usage = await this.repo.recordUsage(ctx.companyId, {
            amount,
            reason: "MANUAL_ADJUSTMENT",
            description,
        });
        await cache_service_1.cacheService.invalidateCompanyCredits(ctx.companyId);
        await cache_service_1.cacheService.invalidateBillingPages(ctx.companyId);
        return usage;
    }
}
exports.CreditsService = CreditsService;
exports.creditsService = new CreditsService();
//# sourceMappingURL=credits.service.js.map