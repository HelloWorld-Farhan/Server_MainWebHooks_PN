export declare const SETUP_PAGE_QUERY = "\n  query SetupPage {\n    integrations {\n      list {\n        id\n        type\n        status\n        connectedAccount\n        lastSyncAt\n      }\n    }\n    phoneNumbers {\n      list {\n        id\n        number\n        provider\n        status\n        inboundAgentId\n        outboundAgentId\n      }\n    }\n  }\n";
export type SetupPageResult = {
    integrations: {
        list: {
            id: string;
            type: string;
            status: string;
            connectedAccount: string | null;
            lastSyncAt: string | null;
        }[];
    };
    phoneNumbers: {
        list: {
            id: string;
            number: string;
            provider: string;
            status: string;
            inboundAgentId: string | null;
            outboundAgentId: string | null;
        }[];
    };
};
