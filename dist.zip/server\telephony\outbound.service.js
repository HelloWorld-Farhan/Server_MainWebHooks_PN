"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.obdOutboundService = exports.ObdOutboundService = void 0;
const contact_phone_validation_1 = require("../../lib/contact-phone-validation");
const prisma_1 = __importDefault(require("../lib/prisma"));
const call_logs_repository_1 = require("../repositories/call-logs.repository");
const correlation_id_1 = require("./correlation-id");
const provider_error_dto_1 = require("./dto/provider-error.dto");
const outbound_request_dto_1 = require("./dto/outbound-request.dto");
const obd_config_1 = require("./obd-config");
const provider_audit_1 = require("./provider-audit");
const provider_client_1 = require("./provider-client");
const telephony_logger_1 = require("./telephony-logger");
class ObdOutboundService {
    providerClient;
    callLogsRepo = new call_logs_repository_1.CallLogsRepository(prisma_1.default);
    constructor(providerClient = provider_client_1.obdProviderClient) {
        this.providerClient = providerClient;
    }
    async dispatch(input) {
        const config = await this.resolveDispatchConfig(input.companyId);
        const existing = await this.callLogsRepo.findByPublicIdForWebhook(input.callLogPublicId);
        const correlationId = existing?.correlationId ?? (0, correlation_id_1.generateCorrelationId)();
        const contactFields = await this.resolveContactFields(input.companyId, input.phone);
        const callInput = {
            callid: input.callLogPublicId,
            phone: input.phone,
            correlationId,
            contactFields,
        };
        const requestPayload = (0, outbound_request_dto_1.buildObdProviderOutboundPayload)(callInput, config);
        const providerRequest = (0, provider_audit_1.appendProviderRequest)(existing?.providerRequest, {
            at: new Date().toISOString(),
            correlationId,
            payload: requestPayload,
        });
        await this.callLogsRepo.startProviderDispatch(input.companyId, input.callLogId, {
            correlationId,
            providerRequest,
        });
        (0, telephony_logger_1.logObdOutbound)({
            correlationId,
            callLogPublicId: input.callLogPublicId,
            campaignPublicId: input.campaignPublicId,
            companyId: input.companyId,
            phone: input.phone,
            payload: requestPayload,
        });
        const result = await this.providerClient.sendOutboundCall(callInput, config);
        const refreshed = await this.callLogsRepo.findByPublicIdForWebhook(input.callLogPublicId);
        if (result.ok) {
            const providerResponse = (0, provider_audit_1.appendProviderResponse)(refreshed?.providerResponse, {
                at: new Date().toISOString(),
                correlationId,
                httpStatus: 200,
                providerCallId: result.providerCallId,
                payload: result.raw,
            });
            await this.callLogsRepo.completeProviderDispatchSuccess(input.companyId, input.callLogId, {
                providerCallId: result.providerCallId,
                providerResponse,
            });
            return {
                status: "QUEUED_AT_PROVIDER",
                providerCallId: result.providerCallId,
                correlationId,
            };
        }
        const providerResponse = (0, provider_audit_1.appendProviderResponse)(refreshed?.providerResponse, {
            at: new Date().toISOString(),
            correlationId,
            httpStatus: result.error.httpStatus,
            error: (0, provider_error_dto_1.toProviderErrorJson)(result.error),
        });
        await this.callLogsRepo.completeProviderDispatchFailure(input.companyId, input.callLogId, { providerResponse });
        (0, telephony_logger_1.logObdError)({
            correlationId,
            message: result.error.message,
            httpStatus: result.error.httpStatus,
            responseBody: result.error.responseBody,
        });
        return {
            status: "FAILED",
            providerCallId: null,
            correlationId,
        };
    }
    async resolveDispatchConfig(companyId) {
        const config = (0, obd_config_1.getObdConfig)();
        const setup = await prisma_1.default.companySetupConfig.findUnique({
            where: { companyId },
            select: { serviceNumber: true, ivrTemplateId: true },
        });
        let resolved = config;
        const configuredNumber = setup?.serviceNumber?.trim();
        if (configuredNumber &&
            (0, obd_config_1.getObdServiceNumbers)().includes(configuredNumber)) {
            resolved = { ...resolved, serviceNo: configuredNumber };
        }
        const configuredIvrTemplateId = setup?.ivrTemplateId?.trim();
        if (configuredIvrTemplateId) {
            resolved = { ...resolved, ivrTemplateId: configuredIvrTemplateId };
        }
        return resolved;
    }
    async resolveContactFields(companyId, phone) {
        const storedPhone = (0, contact_phone_validation_1.normalizeStoredContactPhone)(phone);
        const e164Phone = storedPhone ? `+${storedPhone}` : null;
        const phoneCandidates = [...new Set([storedPhone, e164Phone, phone.trim()].filter(Boolean))];
        if (phoneCandidates.length === 0) {
            return {};
        }
        const contact = await prisma_1.default.uploadedContact.findFirst({
            where: {
                companyId,
                phone: { in: phoneCandidates },
            },
            select: {
                field1: true,
                field2: true,
                field3: true,
            },
        });
        if (!contact) {
            return {};
        }
        return {
            userName: contact.field1,
            recordingUrl: contact.field2,
            transcripts: contact.field3,
        };
    }
}
exports.ObdOutboundService = ObdOutboundService;
exports.obdOutboundService = new ObdOutboundService();
//# sourceMappingURL=outbound.service.js.map