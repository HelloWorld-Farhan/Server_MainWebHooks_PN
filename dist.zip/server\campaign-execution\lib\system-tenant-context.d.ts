import type { TenantContext } from "../../types/context";
export declare function createSystemTenantContext(companyId: string): Promise<TenantContext>;
