"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SetupConfigRepository = void 0;
const base_repository_1 = require("./base.repository");
class SetupConfigRepository extends base_repository_1.BaseRepository {
    getSetupConfig(companyId) {
        return this.prisma.companySetupConfig.findUnique({
            where: { companyId },
        });
    }
    upsertSetupConfig(companyId, data) {
        return this.prisma.companySetupConfig.upsert({
            where: { companyId },
            create: {
                companyId,
                totalChannels: data.totalChannels,
                pulseTimeSeconds: data.pulseTimeSeconds ?? 60,
                deltaSeconds: data.deltaSeconds ?? 2,
                agentsAllocated: data.agentsAllocated ?? 0,
            },
            update: {
                totalChannels: data.totalChannels,
                ...(data.pulseTimeSeconds !== undefined
                    ? { pulseTimeSeconds: data.pulseTimeSeconds }
                    : {}),
                ...(data.deltaSeconds !== undefined
                    ? { deltaSeconds: data.deltaSeconds }
                    : {}),
                ...(data.agentsAllocated !== undefined
                    ? { agentsAllocated: data.agentsAllocated }
                    : {}),
            },
        });
    }
    listChannels(companyId) {
        return this.prisma.companyChannel.findMany({
            where: { companyId },
            orderBy: { channelIndex: "asc" },
            include: {
                phoneNumber: { select: { id: true, number: true, label: true } },
            },
        });
    }
    replaceChannels(companyId, channels) {
        return this.prisma.$transaction(async (tx) => {
            await tx.companyChannel.deleteMany({ where: { companyId } });
            if (channels.length === 0)
                return [];
            await tx.companyChannel.createMany({
                data: channels.map((channel) => ({
                    companyId,
                    channelIndex: channel.channelIndex,
                    label: channel.label ?? null,
                    phoneNumberId: channel.phoneNumberId ?? null,
                })),
            });
            return tx.companyChannel.findMany({
                where: { companyId },
                orderBy: { channelIndex: "asc" },
                include: {
                    phoneNumber: { select: { id: true, number: true, label: true } },
                },
            });
        });
    }
    getBillingRates(companyId) {
        return this.prisma.companyBillingRates.findUnique({
            where: { companyId },
        });
    }
    upsertBillingRates(companyId, data) {
        return this.prisma.companyBillingRates.upsert({
            where: { companyId },
            create: {
                companyId,
                costPerChannel: data.costPerChannel ?? 650,
                costPerCredit: data.costPerCredit ?? 0.31,
                pulseTimeSeconds: data.pulseTimeSeconds ?? 60,
                setupOneTimeCost: data.setupOneTimeCost ?? 0,
                currency: data.currency ?? "INR",
            },
            update: data,
        });
    }
}
exports.SetupConfigRepository = SetupConfigRepository;
//# sourceMappingURL=setup-config.repository.js.map