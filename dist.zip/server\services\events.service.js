"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.eventsService = exports.EventsService = void 0;
const prisma_1 = __importDefault(require("../lib/prisma"));
const events_repository_1 = require("../repositories/events.repository");
const permissions_1 = require("../types/permissions");
const tenant_service_1 = require("./tenant.service");
class EventsService {
    repo = new events_repository_1.EventsRepository(prisma_1.default);
    async listRecent(ctx, limit = 20) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.EVENTS_READ);
        return this.repo.listRecent(ctx.companyId, Math.min(limit, 50));
    }
    async emit(ctx, data) {
        if (data.type === "BILLING_ALERT") {
            tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.BILLING_READ);
        }
        else {
            tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.EVENTS_READ);
        }
        return this.repo.create(ctx.companyId, {
            ...data,
            actorId: ctx.userId,
        });
    }
}
exports.EventsService = EventsService;
exports.eventsService = new EventsService();
//# sourceMappingURL=events.service.js.map