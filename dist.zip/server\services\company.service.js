"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.companyService = exports.CompanyService = void 0;
const cache_service_1 = require("../cache/cache.service");
const errors_1 = require("../lib/errors");
const prisma_1 = __importDefault(require("../lib/prisma"));
const tenant_repository_1 = require("../repositories/tenant.repository");
const permissions_1 = require("../types/permissions");
const tenant_service_1 = require("./tenant.service");
class CompanyService {
    repo = new tenant_repository_1.TenantRepository(prisma_1.default);
    async getContact(ctx) {
        const contact = await this.repo.findCompanyContact(ctx.companyId);
        if (!contact)
            return null;
        return {
            name: contact.name,
            email: contact.email,
            phone: contact.phone,
            title: contact.title,
        };
    }
    async upsertContact(ctx, data) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.SETTINGS_WRITE);
        const company = await prisma_1.default.company.findUnique({
            where: { id: ctx.companyId },
            include: { contact: true },
        });
        if (company?.ownerUserId && company.contact?.email) {
            const existingEmail = company.contact.email.trim().toLowerCase();
            const submittedEmail = data.email.trim().toLowerCase();
            if (submittedEmail !== existingEmail) {
                throw new errors_1.ForbiddenError("Owner email cannot be changed after linking the Contract ID.");
            }
            data = { ...data, email: company.contact.email };
        }
        const contact = await this.repo.upsertCompanyContact(ctx.companyId, data);
        await cache_service_1.cacheService.invalidateSettingsPages(ctx.companyId);
        return {
            name: contact.name,
            email: contact.email,
            phone: contact.phone,
            title: contact.title,
        };
    }
}
exports.CompanyService = CompanyService;
exports.companyService = new CompanyService();
//# sourceMappingURL=company.service.js.map