export declare const CALL_LOGS_PAGE_QUERY = "\n  query CallLogsPage($after: String, $filter: CallLogFilter) {\n    callLogs {\n      connection(first: 100, after: $after, filter: $filter) {\n        edges {\n          node {\n            id\n            callLogId\n            publicId\n            direction\n            status\n            outcome\n            startedAt\n            durationSeconds\n            recordingUrl\n            transcriptUrl\n            cost\n            creditsUsed\n            provider\n            providerStatus\n            disconnectReason\n            aiSummary\n            sentiment\n            lead {\n              id\n              firstName\n              lastName\n              phone\n              temperature\n              score\n            }\n            aiAgent {\n              id\n              name\n            }\n            phoneNumber {\n              id\n              number\n              label\n            }\n            campaign {\n              id\n              name\n              status\n              customFields\n              createdAt\n              execution {\n                status\n                scheduledAt\n                totalContacts\n              }\n            }\n          }\n          cursor\n        }\n        pageInfo {\n          hasNextPage\n          endCursor\n        }\n      }\n    }\n  }\n";
export declare const CALL_DETAIL_QUERY = "\n  query CallDetail($id: ID!) {\n    callLogs {\n      detail(id: $id) {\n        id\n        direction\n        status\n        outcome\n        startedAt\n        durationSeconds\n        recordingUrl\n        cost\n        creditsUsed\n        provider\n        aiSummary\n        sentiment\n        engagement\n        reactivationPlan\n        lead {\n          id\n          firstName\n          lastName\n          phone\n          temperature\n          score\n        }\n        aiAgent {\n          id\n          name\n        }\n        phoneNumber {\n          id\n          number\n          label\n        }\n        transcript {\n          id\n          fullText\n          segments\n        }\n        internalNotes {\n          id\n          content\n          createdAt\n          updatedAt\n          author {\n            id\n            name\n            email\n          }\n        }\n      }\n    }\n  }\n";
export type CallLogsPageNode = {
    id: string;
    callLogId?: string;
    publicId?: string;
    direction: string;
    status: string;
    outcome: string | null;
    startedAt: string;
    durationSeconds: number;
    recordingUrl: string | null;
    transcriptUrl: string | null;
    cost: number | null;
    creditsUsed: number | null;
    provider: string | null;
    providerStatus?: string | null;
    disconnectReason?: string | null;
    aiSummary: Record<string, unknown> | null;
    sentiment: Record<string, unknown> | null;
    lead: {
        id: string;
        firstName: string | null;
        lastName: string | null;
        phone: string | null;
        temperature: string | null;
        score: number;
    } | null;
    aiAgent: {
        id: string;
        name: string;
    } | null;
    phoneNumber: {
        id: string;
        number: string;
        label: string | null;
    } | null;
    campaign: {
        id: string;
        name: string;
        status: string;
        customFields: Record<string, unknown> | null;
        createdAt: string;
        execution: {
            status: string;
            scheduledAt: string | null;
            totalContacts: number;
        } | null;
    } | null;
};
export type CallLogsPageResult = {
    callLogs: {
        connection: {
            edges: {
                node: CallLogsPageNode;
                cursor: string;
            }[];
            pageInfo: {
                hasNextPage: boolean;
                endCursor: string | null;
            };
        };
    };
};
