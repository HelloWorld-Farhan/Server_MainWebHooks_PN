export declare const PUBLIC_ID_VERSION: "v1";
export type PublicIdVersion = typeof PUBLIC_ID_VERSION | "v2";
export declare enum PublicResourceType {
    CALL_LOG = "CALL_LOG",
    PHONE_NUMBER = "PHONE_NUMBER",
    AGENT = "AGENT",
    CONTACT = "CONTACT",
    CAMPAIGN = "CAMPAIGN"
}
export type ParsedCampaignPublicIdV1 = {
    version: typeof PUBLIC_ID_VERSION;
    cli: string;
    campaignResourceKey: string;
};
export type ParsedPublicIdV1 = {
    version: typeof PUBLIC_ID_VERSION;
    cli: string;
    campaignId: string;
    entityId: string;
};
export type ParsedLegacyPublicIdV1 = {
    version: typeof PUBLIC_ID_VERSION;
    cli: string;
    companyCode: string;
    resourceKey: string;
};
export type CompanyPublicIdentity = {
    cli: string;
    companyCode: string;
};
export type GenerateCampaignPublicIdInput = {
    cli: string;
    campaignResourceKey: string;
};
export type GeneratePublicIdInput = {
    cli: string;
    campaignId: string;
    entityId: string;
};
export type GenerateLegacyPublicIdInput = CompanyPublicIdentity & {
    resourceKey: string;
};
export declare const CAMPAIGN_SCOPED_RESOURCE_TYPES: Set<PublicResourceType>;
