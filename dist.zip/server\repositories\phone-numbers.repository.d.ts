import type { PhoneNumberStatus, Prisma, PrismaClient, TelephonyProvider } from "@prisma/client";
import { BaseRepository } from "./base.repository";
type TransactionClient = Omit<PrismaClient, "$connect" | "$disconnect" | "$on" | "$transaction" | "$use" | "$extends">;
export type PhoneNumberFilter = {
    number?: string;
    numberContains?: string;
    labelContains?: string;
    search?: string;
    provider?: TelephonyProvider;
    status?: PhoneNumberStatus;
    inboundAgentId?: string;
    outboundAgentId?: string;
    hasInboundAgent?: boolean;
    hasOutboundAgent?: boolean;
    channelIndex?: number;
    hasChannelAssignment?: boolean;
    createdFrom?: Date;
    createdTo?: Date;
    lastActivityFrom?: Date;
    lastActivityTo?: Date;
    ids?: string[];
};
export type PhoneNumberSortField = "CREATED_AT" | "UPDATED_AT" | "LAST_ACTIVITY_AT" | "NUMBER" | "INBOUND_CALLS_COUNT" | "OUTBOUND_CALLS_COUNT";
export type PhoneNumberSort = {
    field: PhoneNumberSortField;
    direction: "ASC" | "DESC";
};
export declare class PhoneNumbersRepository extends BaseRepository {
    private buildWhere;
    private buildOrderBy;
    findMany(companyId: string, filter?: PhoneNumberFilter, sort?: PhoneNumberSort): Prisma.PrismaPromise<({
        inboundAgent: {
            name: string;
            id: string;
        } | null;
        outboundAgent: {
            name: string;
            id: string;
        } | null;
    } & {
        number: string;
        status: import("@prisma/client").$Enums.PhoneNumberStatus;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string | null;
        campaignId: string | null;
        assignedParentTenantId: string | null;
        phoneNumberId: string;
        publicId: string;
        channels: number | null;
        label: string | null;
        provider: import("@prisma/client").$Enums.TelephonyProvider;
        inboundAgentId: string | null;
        outboundAgentId: string | null;
        direction: import("@prisma/client").$Enums.CallDirection | null;
        inboundCallsCount: number;
        outboundCallsCount: number;
        lastActivityAt: Date | null;
    })[]>;
    findConnection(companyId: string, limit: number, after?: string, filter?: PhoneNumberFilter, sort?: PhoneNumberSort): Prisma.PrismaPromise<({
        inboundAgent: {
            name: string;
            id: string;
        } | null;
        outboundAgent: {
            name: string;
            id: string;
        } | null;
    } & {
        number: string;
        status: import("@prisma/client").$Enums.PhoneNumberStatus;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string | null;
        campaignId: string | null;
        assignedParentTenantId: string | null;
        phoneNumberId: string;
        publicId: string;
        channels: number | null;
        label: string | null;
        provider: import("@prisma/client").$Enums.TelephonyProvider;
        inboundAgentId: string | null;
        outboundAgentId: string | null;
        direction: import("@prisma/client").$Enums.CallDirection | null;
        inboundCallsCount: number;
        outboundCallsCount: number;
        lastActivityAt: Date | null;
    })[]>;
    count(companyId: string, filter?: PhoneNumberFilter): Prisma.PrismaPromise<number>;
    findById(companyId: string, id: string): Prisma.Prisma__PhoneNumberClient<({
        inboundAgent: {
            name: string;
            id: string;
        } | null;
        outboundAgent: {
            name: string;
            id: string;
        } | null;
    } & {
        number: string;
        status: import("@prisma/client").$Enums.PhoneNumberStatus;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string | null;
        campaignId: string | null;
        assignedParentTenantId: string | null;
        phoneNumberId: string;
        publicId: string;
        channels: number | null;
        label: string | null;
        provider: import("@prisma/client").$Enums.TelephonyProvider;
        inboundAgentId: string | null;
        outboundAgentId: string | null;
        direction: import("@prisma/client").$Enums.CallDirection | null;
        inboundCallsCount: number;
        outboundCallsCount: number;
        lastActivityAt: Date | null;
    }) | null, null, import("@prisma/client/runtime/library").DefaultArgs, Prisma.PrismaClientOptions>;
    findByIds(companyId: string, ids: string[]): Prisma.PrismaPromise<{
        number: string;
        id: string;
        label: string | null;
    }[]>;
    create(companyId: string, data: {
        number: string;
        provider: TelephonyProvider;
        label?: string;
        inboundAgentId?: string;
        outboundAgentId?: string;
        campaignId?: string;
        campaignResourceKey?: string;
        companyCli?: string;
    }): Promise<{
        inboundAgent: {
            name: string;
            id: string;
        } | null;
        outboundAgent: {
            name: string;
            id: string;
        } | null;
    } & {
        number: string;
        status: import("@prisma/client").$Enums.PhoneNumberStatus;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string | null;
        campaignId: string | null;
        assignedParentTenantId: string | null;
        phoneNumberId: string;
        publicId: string;
        channels: number | null;
        label: string | null;
        provider: import("@prisma/client").$Enums.TelephonyProvider;
        inboundAgentId: string | null;
        outboundAgentId: string | null;
        direction: import("@prisma/client").$Enums.CallDirection | null;
        inboundCallsCount: number;
        outboundCallsCount: number;
        lastActivityAt: Date | null;
    }>;
    update(companyId: string, id: string, data: Prisma.PhoneNumberUpdateInput): Prisma.Prisma__PhoneNumberClient<{
        inboundAgent: {
            name: string;
            id: string;
        } | null;
        outboundAgent: {
            name: string;
            id: string;
        } | null;
    } & {
        number: string;
        status: import("@prisma/client").$Enums.PhoneNumberStatus;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string | null;
        campaignId: string | null;
        assignedParentTenantId: string | null;
        phoneNumberId: string;
        publicId: string;
        channels: number | null;
        label: string | null;
        provider: import("@prisma/client").$Enums.TelephonyProvider;
        inboundAgentId: string | null;
        outboundAgentId: string | null;
        direction: import("@prisma/client").$Enums.CallDirection | null;
        inboundCallsCount: number;
        outboundCallsCount: number;
        lastActivityAt: Date | null;
    }, never, import("@prisma/client/runtime/library").DefaultArgs, Prisma.PrismaClientOptions>;
    findByCampaignAndNumber(tx: TransactionClient, companyId: string, campaignId: string, number: string): Prisma.Prisma__PhoneNumberClient<{
        number: string;
        status: import("@prisma/client").$Enums.PhoneNumberStatus;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string | null;
        campaignId: string | null;
        assignedParentTenantId: string | null;
        phoneNumberId: string;
        publicId: string;
        channels: number | null;
        label: string | null;
        provider: import("@prisma/client").$Enums.TelephonyProvider;
        inboundAgentId: string | null;
        outboundAgentId: string | null;
        direction: import("@prisma/client").$Enums.CallDirection | null;
        inboundCallsCount: number;
        outboundCallsCount: number;
        lastActivityAt: Date | null;
    } | null, null, import("@prisma/client/runtime/library").DefaultArgs, Prisma.PrismaClientOptions>;
    createForCampaign(tx: TransactionClient, companyId: string, campaignId: string, number: string, campaignResourceKey: string, companyCli: string): Promise<{
        number: string;
        status: import("@prisma/client").$Enums.PhoneNumberStatus;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string | null;
        campaignId: string | null;
        assignedParentTenantId: string | null;
        phoneNumberId: string;
        publicId: string;
        channels: number | null;
        label: string | null;
        provider: import("@prisma/client").$Enums.TelephonyProvider;
        inboundAgentId: string | null;
        outboundAgentId: string | null;
        direction: import("@prisma/client").$Enums.CallDirection | null;
        inboundCallsCount: number;
        outboundCallsCount: number;
        lastActivityAt: Date | null;
    }>;
}
export {};
