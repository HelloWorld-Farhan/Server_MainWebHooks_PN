import { OnModuleDestroy, OnModuleInit } from "@nestjs/common";
export declare const STALE_DISPATCHING_MS: number;
export declare const STALE_QUEUED_AT_PROVIDER_MS: number;
export declare class ChannelReconciliationService implements OnModuleInit, OnModuleDestroy {
    private readonly callLogsRepo;
    private interval;
    private processing;
    onModuleInit(): void;
    onModuleDestroy(): void;
    reconcileAll(): Promise<void>;
    private runReconcile;
}
