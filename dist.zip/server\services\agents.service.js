"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.agentsService = exports.AgentsService = void 0;
const cache_service_1 = require("../cache/cache.service");
const keys_1 = require("../cache/keys");
const errors_1 = require("../lib/errors");
const prisma_1 = __importDefault(require("../lib/prisma"));
const agents_repository_1 = require("../repositories/agents.repository");
const permissions_1 = require("../types/permissions");
const campaign_access_service_1 = require("./campaign-access.service");
const tenant_service_1 = require("./tenant.service");
function mapAgent(agent) {
    if (!agent)
        return null;
    return {
        id: agent.id,
        name: agent.name,
        type: agent.type,
        category: agent.category,
        status: agent.status,
        environment: agent.environment,
        enabled: agent.enabled,
        languages: agent.languages,
        firstMessage: agent.firstMessage,
        systemPrompt: agent.systemPrompt,
        voiceConfig: agent.voiceConfig,
        modelConfig: agent.modelConfig,
        transcriberConfig: agent.transcriberConfig,
        serverConfig: agent.serverConfig,
        structuredOutputs: agent.structuredOutputs,
        scorecards: agent.scorecards,
        monitors: agent.monitors,
        demoAudioUrl: agent.demoAudioUrl,
        campaignId: agent.campaignId,
        createdAt: agent.createdAt.toISOString(),
        updatedAt: agent.updatedAt.toISOString(),
    };
}
class AgentsService {
    repo = new agents_repository_1.AgentsRepository(prisma_1.default);
    async assertBranchInCompany(ctx, campaignId) {
        const campaign = await prisma_1.default.campaign.findFirst({
            where: { id: campaignId, companyId: ctx.companyId },
            select: { id: true },
        });
        if (!campaign)
            throw new errors_1.ValidationError("Campaign not found");
        campaign_access_service_1.campaignAccessService.assertCampaignAccess(ctx, campaignId);
    }
    async getStatusSummary(ctx) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.AGENTS_READ);
        return cache_service_1.cacheService.getOrSet(keys_1.cacheKeys.companyAgentStatus(ctx.companyId), keys_1.CACHE_TTL.AGENT_STATUS, async () => {
            const groups = await this.repo.findStatusSummary(ctx.companyId);
            const summary = {
                active: 0,
                inactive: 0,
                total: 0,
            };
            for (const group of groups) {
                const count = group._count.id;
                summary.total += count;
                if (group.status === "ACTIVE")
                    summary.active = count;
                if (group.status === "INACTIVE")
                    summary.inactive = count;
            }
            return summary;
        });
    }
    async list(ctx) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.AGENTS_READ);
        const agents = await this.repo.findMany(ctx.companyId);
        return agents.map((agent) => mapAgent(agent));
    }
    async getById(ctx, id) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.AGENTS_READ);
        const agent = await this.repo.findById(ctx.companyId, id);
        if (!agent) {
            throw new errors_1.NotFoundError("Agent not found");
        }
        return mapAgent(agent);
    }
    async create(ctx, input) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.AGENTS_WRITE);
        if (input.campaignId) {
            await this.assertBranchInCompany(ctx, input.campaignId);
        }
        const agent = await this.repo.create(ctx.companyId, {
            name: input.name,
            type: input.type,
            category: input.category,
            status: input.status ?? "ACTIVE",
            environment: input.environment ?? "PRODUCTION",
            enabled: input.enabled ?? true,
            languages: input.languages ?? ["English (US)"],
            firstMessage: input.firstMessage,
            systemPrompt: input.systemPrompt,
            voiceConfig: input.voiceConfig ?? {},
            modelConfig: input.modelConfig ?? {},
            transcriberConfig: input.transcriberConfig ?? {},
            serverConfig: input.serverConfig ?? {},
            structuredOutputs: input.structuredOutputs ?? [],
            scorecards: input.scorecards ?? [],
            monitors: input.monitors ?? [],
            demoAudioUrl: input.demoAudioUrl,
            ...(input.libraryEntryId
                ? { libraryEntry: { connect: { id: input.libraryEntryId } } }
                : {}),
            ...(input.campaignId
                ? { campaign: { connect: { id: input.campaignId } } }
                : {}),
        });
        await cache_service_1.cacheService.invalidateCompanyAgentStatus(ctx.companyId);
        await cache_service_1.cacheService.invalidateAgentPages(ctx.companyId);
        return mapAgent(agent);
    }
    async update(ctx, id, input) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.AGENTS_WRITE);
        const existing = await this.repo.findById(ctx.companyId, id);
        if (!existing)
            throw new errors_1.NotFoundError("Agent not found");
        if (input.campaignId) {
            await this.assertBranchInCompany(ctx, input.campaignId);
        }
        const data = {};
        if (input.name !== undefined)
            data.name = input.name;
        if (input.type !== undefined)
            data.type = input.type;
        if (input.category !== undefined)
            data.category = input.category;
        if (input.status !== undefined)
            data.status = input.status;
        if (input.environment !== undefined) {
            data.environment = input.environment;
        }
        if (input.enabled !== undefined)
            data.enabled = input.enabled;
        if (input.languages !== undefined)
            data.languages = input.languages;
        if (input.firstMessage !== undefined)
            data.firstMessage = input.firstMessage;
        if (input.systemPrompt !== undefined)
            data.systemPrompt = input.systemPrompt;
        if (input.voiceConfig !== undefined)
            data.voiceConfig = input.voiceConfig;
        if (input.modelConfig !== undefined)
            data.modelConfig = input.modelConfig;
        if (input.transcriberConfig !== undefined) {
            data.transcriberConfig = input.transcriberConfig;
        }
        if (input.serverConfig !== undefined)
            data.serverConfig = input.serverConfig;
        if (input.structuredOutputs !== undefined) {
            data.structuredOutputs = input.structuredOutputs;
        }
        if (input.scorecards !== undefined)
            data.scorecards = input.scorecards;
        if (input.monitors !== undefined)
            data.monitors = input.monitors;
        if (input.demoAudioUrl !== undefined)
            data.demoAudioUrl = input.demoAudioUrl;
        if (input.campaignId !== undefined) {
            data.campaign = input.campaignId
                ? { connect: { id: input.campaignId } }
                : { disconnect: true };
        }
        const agent = await this.repo.update(ctx.companyId, id, data);
        await cache_service_1.cacheService.invalidateCompanyAgentStatus(ctx.companyId);
        await cache_service_1.cacheService.invalidateAgentPages(ctx.companyId);
        return mapAgent(agent);
    }
}
exports.AgentsService = AgentsService;
exports.agentsService = new AgentsService();
//# sourceMappingURL=agents.service.js.map