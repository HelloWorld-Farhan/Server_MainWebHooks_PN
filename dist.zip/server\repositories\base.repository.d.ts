import type { PrismaClient } from "@prisma/client";
export declare abstract class BaseRepository {
    protected readonly prisma: PrismaClient;
    constructor(prisma: PrismaClient);
    protected scope(companyId: string): {
        companyId: string;
    };
}
