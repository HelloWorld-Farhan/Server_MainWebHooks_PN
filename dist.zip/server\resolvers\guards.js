"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.requirePermission = requirePermission;
const permissions_1 = require("../types/permissions");
const errors_1 = require("../lib/errors");
function requirePermission(ctx, permission) {
    if (!(0, permissions_1.hasPermission)(ctx.permissions, permission)) {
        throw new errors_1.ForbiddenError(`Missing permission: ${permission}`);
    }
}
//# sourceMappingURL=guards.js.map