export declare function isClerkOrganizationsDisabled(error: unknown): boolean;
export declare function isClerkOrganizationsForbidden(error: unknown): boolean;
export declare function isClerkOrganizationsUnavailable(error: unknown): boolean;
export declare function isClerkNotFound(error: unknown): boolean;
export declare function isClerkRateLimited(error: unknown): boolean;
export declare function getClerkRetryAfter(error: unknown): number;
export declare function sleep(ms: number): Promise<void>;
