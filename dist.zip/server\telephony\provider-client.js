"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.obdProviderClient = exports.ObdProviderClient = void 0;
const outbound_request_dto_1 = require("./dto/outbound-request.dto");
const outbound_response_dto_1 = require("./dto/outbound-response.dto");
const obd_config_1 = require("./obd-config");
const retry_policy_1 = require("./retry-policy");
const telephony_logger_1 = require("./telephony-logger");
async function parseResponseBody(response) {
    const text = await response.text();
    if (!text) {
        return null;
    }
    try {
        return JSON.parse(text);
    }
    catch {
        return text;
    }
}
function headersToRecord(headers) {
    const record = {};
    headers.forEach((value, key) => {
        record[key] = value;
    });
    return record;
}
class ObdProviderClient {
    fetchFn;
    configOverride;
    constructor(deps = {}) {
        this.fetchFn = deps.fetchFn ?? fetch;
        this.configOverride = deps.config;
    }
    async sendOutboundCall(input, configOverride) {
        const config = {
            ...(this.configOverride ?? (0, obd_config_1.getObdConfig)()),
            ...configOverride,
        };
        (0, obd_config_1.assertObdDispatchConfig)(config);
        const payload = (0, outbound_request_dto_1.buildObdProviderOutboundPayload)(input, config);
        const url = config.baseUrl;
        const requestHeaders = {
            "Content-Type": "application/json",
            "X-Correlation-Id": input.correlationId,
        };
        (0, telephony_logger_1.logObdProviderRequest)({
            correlationId: input.correlationId,
            url,
            method: "POST",
            headers: requestHeaders,
            payload,
        });
        let lastError = null;
        for (let attempt = 0; attempt <= config.maxRetries; attempt += 1) {
            const result = await this.executeRequest(url, payload, input.correlationId, config.timeoutMs, requestHeaders);
            if (result.ok) {
                return result;
            }
            lastError = result.error;
            const canRetry = attempt < config.maxRetries &&
                (0, retry_policy_1.isRetryableProviderError)(result.error);
            if (!canRetry) {
                break;
            }
            (0, telephony_logger_1.logObdRetry)({
                correlationId: input.correlationId,
                attempt: attempt + 1,
                httpStatus: result.error.httpStatus,
            });
        }
        (0, telephony_logger_1.logObdError)({
            correlationId: input.correlationId,
            message: lastError?.message ?? "Unknown OBD provider error",
            httpStatus: lastError?.httpStatus,
            responseBody: lastError?.responseBody,
        });
        return {
            ok: false,
            error: lastError ?? { message: "Unknown OBD provider error" },
        };
    }
    async executeRequest(url, payload, correlationId, timeoutMs, requestHeaders) {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
        try {
            const response = await this.fetchFn(url, {
                method: "POST",
                headers: requestHeaders,
                body: JSON.stringify(payload),
                signal: controller.signal,
            });
            const responseBody = await parseResponseBody(response);
            const responseHeaders = headersToRecord(response.headers);
            (0, telephony_logger_1.logObdProviderResponse)({
                correlationId,
                httpStatus: response.status,
                responseHeaders,
                responseBody,
                providerCallId: (0, outbound_response_dto_1.extractProviderCallId)(responseBody),
            });
            if (!response.ok) {
                return {
                    ok: false,
                    error: {
                        message: `OBD provider returned HTTP ${response.status}`,
                        httpStatus: response.status,
                        responseBody,
                    },
                };
            }
            const providerError = (0, outbound_response_dto_1.extractProviderErrorMessage)(responseBody);
            if (providerError) {
                (0, telephony_logger_1.logObdError)({
                    correlationId,
                    message: providerError,
                    httpStatus: response.status,
                    responseBody,
                });
                return {
                    ok: false,
                    error: {
                        message: providerError,
                        httpStatus: response.status,
                        responseBody,
                    },
                };
            }
            return {
                ok: true,
                providerCallId: (0, outbound_response_dto_1.extractProviderCallId)(responseBody),
                raw: responseBody,
            };
        }
        catch (error) {
            const isAbort = error instanceof Error && error.name === "AbortError";
            const message = isAbort
                ? `OBD provider request timed out after ${timeoutMs}ms`
                : error instanceof Error
                    ? error.message
                    : "OBD provider network error";
            (0, telephony_logger_1.logObdError)({
                correlationId,
                message,
            });
            return {
                ok: false,
                error: {
                    message,
                    isNetworkError: !isAbort,
                    isTimeout: isAbort,
                },
            };
        }
        finally {
            clearTimeout(timeoutId);
        }
    }
}
exports.ObdProviderClient = ObdProviderClient;
exports.obdProviderClient = new ObdProviderClient();
//# sourceMappingURL=provider-client.js.map