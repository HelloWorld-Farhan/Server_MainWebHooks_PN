import { type LeadFilter } from "../repositories/leads.repository";
import type { TenantContext } from "../types/context";
export declare class LeadsService {
    private readonly repo;
    getConnection(ctx: TenantContext, args: {
        first?: number;
        after?: string;
        filter?: LeadFilter;
    }): Promise<{
        edges: {
            cursor: string;
            node: {
                id: string;
                firstName: string | null;
                lastName: string | null;
                email: string | null;
                phone: string | null;
                temperature: import("@prisma/client").$Enums.LeadTemperature | null;
                score: number;
                lastContactedAt: string | null;
                createdAt: string;
                sourceName: string | null;
                stageName: string;
            };
        }[];
        pageInfo: import("../lib/pagination").PageInfo;
    }>;
    getById(ctx: TenantContext, id: string): Promise<{
        id: string;
        firstName: string | null;
        lastName: string | null;
        email: string | null;
        phone: string | null;
        temperature: import("@prisma/client").$Enums.LeadTemperature | null;
        score: number;
        lastContactedAt: string | null;
        createdAt: string;
        sourceName: string | null;
        stageName: string;
    }>;
    getTemperatureBreakdown(ctx: TenantContext): Promise<{
        hot: number;
        warm: number;
        cold: number;
        total: number;
    }>;
    importRows(ctx: TenantContext, rows: {
        firstName?: string | null;
        lastName?: string | null;
        email?: string | null;
        phone: string;
        temperature: string;
    }[]): Promise<{
        invalid: number;
        hot: number;
        warm: number;
        cold: number;
        total: number;
        created: number;
        updated: number;
    }>;
}
export declare const leadsService: LeadsService;
export type { LeadFilter };
