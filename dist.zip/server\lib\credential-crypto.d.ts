export declare function encryptCredentials<T>(value: T): string;
export declare function decryptCredentials<T>(payload: string): T;
