"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BonvoiceController = void 0;
const common_1 = require("@nestjs/common");
let BonvoiceController = class BonvoiceController {
    async addLeads(body) {
        const { leads, didNumber, companyId } = body;
        const BONVOICE_API_URL = process.env.BONVOICE_BASE_URL || "https://backend.pbx.bonvoice.com";
        const loginRes = await fetch(`${BONVOICE_API_URL}/usermanagement/external-auth/`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            body: JSON.stringify({
                username: process.env.BONVOICE_USERNAME || "PROP_NEXT",
                password: process.env.BONVOICE_PASSWORD || "PRopne##xt89",
            }),
        });
        if (!loginRes.ok) {
            throw new Error("Failed to authenticate with Bonvoice");
        }
        const loginData = await loginRes.json();
        const token = loginData.token || loginData.access_token || loginData.data?.token || loginData.data?.access_token;
        if (!token) {
            throw new Error("Invalid authentication response from Bonvoice");
        }
        const template_url = process.env.BONVOICE_VOICEBOT_URL || "wss://vineeth-inbound.onrender.com/ws/voice-agent";
        const responses = await Promise.all(leads.map(async (lead) => {
            try {
                const res = await fetch(`${BONVOICE_API_URL}/click2call/`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Accept": "application/json",
                        Authorization: `Token ${token}`,
                    },
                    body: JSON.stringify({
                        source_number: didNumber,
                        destination_number: lead.phone,
                        template_url: template_url,
                    }),
                });
                if (!res.ok) {
                    const text = await res.text();
                    throw new Error(`Bonvoice API Error: ${text}`);
                }
                return await res.json();
            }
            catch (err) {
                console.error(`Failed to add lead ${lead.phone}:`, err.message);
                throw err;
            }
        }));
        return { success: true, data: responses[0] };
    }
};
exports.BonvoiceController = BonvoiceController;
__decorate([
    (0, common_1.Post)("add-leads"),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], BonvoiceController.prototype, "addLeads", null);
exports.BonvoiceController = BonvoiceController = __decorate([
    (0, common_1.Controller)("api/obd/bonvoice")
], BonvoiceController);
//# sourceMappingURL=bonvoice.controller.js.map