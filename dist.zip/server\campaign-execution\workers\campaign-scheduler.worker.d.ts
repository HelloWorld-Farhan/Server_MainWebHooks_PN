import { OnModuleDestroy, OnModuleInit } from "@nestjs/common";
export declare class CampaignSchedulerWorker implements OnModuleInit, OnModuleDestroy {
    private interval;
    private processing;
    onModuleInit(): void;
    onModuleDestroy(): void;
    tick(): Promise<void>;
}
