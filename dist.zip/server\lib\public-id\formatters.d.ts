import { PublicResourceType } from "./types";
export declare function formatResourceKey(resourceType: PublicResourceType, sequence: number): string;
export declare function normalizeCallLogEntityId(entityId: string): string;
export declare function inferResourceTypeFromKey(resourceKey: string): PublicResourceType | null;
export declare function resourceKeyMatchesType(resourceKey: string, resourceType: PublicResourceType): boolean;
