"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.contractService = exports.ContractService = void 0;
const clerk_1 = require("../../auth/clerk");
const organization_1 = require("../../lib/clerk/organization");
const cache_service_1 = require("../cache/cache.service");
const clerk_errors_1 = require("../lib/clerk-errors");
const clerk_sync_1 = require("../lib/clerk-sync");
const contract_id_1 = require("../lib/contract-id");
const errors_1 = require("../lib/errors");
const prisma_1 = __importDefault(require("../lib/prisma"));
const tenant_repository_1 = require("../repositories/tenant.repository");
const tenantRepo = new tenant_repository_1.TenantRepository(prisma_1.default);
function getPrimaryEmail(clerkUser) {
    return (clerkUser.emailAddresses.find((e) => e.id === clerkUser.primaryEmailAddressId)?.emailAddress ?? clerkUser.emailAddresses[0]?.emailAddress ?? null);
}
async function ensureCreditBalance(companyId) {
    await prisma_1.default.creditBalance.upsert({
        where: { companyId },
        create: {
            companyId,
            creditsRemaining: 0,
            creditsUsed: 0,
        },
        update: {},
    });
}
function toPublicClerkOrganizationId(clerkOrganizationId) {
    if (!clerkOrganizationId?.startsWith("org_")) {
        return null;
    }
    return clerkOrganizationId;
}
async function resolveClerkOrganizationId(clerkUserId, companyName, existingOrgId) {
    if (existingOrgId) {
        return existingOrgId;
    }
    const client = clerk_1.clerkClient;
    try {
        const org = await client.organizations.createOrganization({
            name: companyName,
            createdBy: clerkUserId,
        });
        return org.id;
    }
    catch (error) {
        if ((0, clerk_errors_1.isClerkOrganizationsDisabled)(error)) {
            return (0, clerk_sync_1.localClerkOrganizationId)(clerkUserId);
        }
        throw error;
    }
}
class ContractService {
    async getContractLinkStatus(clerkUserId) {
        const ownedCompany = await tenantRepo.findCompanyByOwnerUserId(clerkUserId);
        if (ownedCompany) {
            return {
                linked: true,
                contractId: ownedCompany.contractId,
                claimedAt: ownedCompany.claimedAt?.toISOString() ?? null,
                clerkOrganizationId: toPublicClerkOrganizationId(ownedCompany.clerkOrganizationId),
            };
        }
        const dbUser = await tenantRepo.findUserByClerkId(clerkUserId);
        if (dbUser) {
            const activeMembership = await prisma_1.default.companyMember.findFirst({
                where: { userId: dbUser.id, status: "ACTIVE" },
                include: { company: true },
                orderBy: { joinedAt: "desc" },
            });
            if (activeMembership) {
                return {
                    linked: true,
                    contractId: activeMembership.company.contractId,
                    claimedAt: activeMembership.company.claimedAt?.toISOString() ?? null,
                    clerkOrganizationId: toPublicClerkOrganizationId(activeMembership.company.clerkOrganizationId),
                };
            }
            const invitedMembership = await prisma_1.default.companyMember.findFirst({
                where: { userId: dbUser.id, status: "INVITED" },
                include: { company: true },
                orderBy: { invitedAt: "desc" },
            });
            if (invitedMembership) {
                return {
                    linked: true,
                    contractId: invitedMembership.company.contractId,
                    claimedAt: invitedMembership.company.claimedAt?.toISOString() ?? null,
                    clerkOrganizationId: toPublicClerkOrganizationId(invitedMembership.company.clerkOrganizationId),
                };
            }
        }
        return { linked: false };
    }
    async linkContractId(clerkUserId, rawContractId) {
        const contractId = (0, contract_id_1.normalizeContractId)(rawContractId);
        if (!contractId) {
            throw new errors_1.AppError("Invalid Contract ID format", "INVALID_FORMAT", 400);
        }
        const existingUser = await tenantRepo.findUserByClerkId(clerkUserId);
        if (existingUser) {
            const activeMembership = await prisma_1.default.companyMember.findFirst({
                where: { userId: existingUser.id, status: "ACTIVE" },
            });
            if (activeMembership) {
                throw new errors_1.ConflictError("You have already linked a Contract ID");
            }
        }
        const existingLinked = await tenantRepo.findCompanyByOwnerUserId(clerkUserId);
        if (existingLinked && existingLinked.contractId !== contractId) {
            throw new errors_1.ConflictError("You have already linked a Contract ID");
        }
        const company = await prisma_1.default.company.findFirst({
            where: { contractId },
            include: { contact: true },
        });
        if (!company) {
            throw new errors_1.ContractNotFoundError();
        }
        const isDemo = company.isDemo;
        if (!isDemo &&
            company.ownerUserId != null &&
            company.ownerUserId !== clerkUserId) {
            throw new errors_1.ConflictError("This Contract ID has already been linked");
        }
        const client = clerk_1.clerkClient;
        const clerkUser = await client.users.getUser(clerkUserId);
        const primaryEmail = getPrimaryEmail(clerkUser);
        if (!primaryEmail) {
            throw new errors_1.AppError("User email is required", "INVALID_USER", 400);
        }
        const ownerDisplayName = [clerkUser.firstName, clerkUser.lastName]
            .filter(Boolean)
            .join(" ")
            .trim();
        const clerkOrganizationId = isDemo
            ? (company.clerkOrganizationId ?? (0, clerk_sync_1.localClerkOrganizationId)(clerkUserId))
            : await resolveClerkOrganizationId(clerkUserId, company.name, company.clerkOrganizationId);
        const dbUser = await tenantRepo.upsertUser({
            clerkUserId,
            email: primaryEmail,
            firstName: clerkUser.firstName,
            lastName: clerkUser.lastName,
            imageUrl: clerkUser.imageUrl,
            phone: clerkUser.phoneNumbers[0]?.phoneNumber,
        });
        const claimedAt = new Date();
        if (!isDemo) {
            const claimData = { ownerUserId: clerkUserId, claimedAt };
            if (!company.clerkOrganizationId) {
                claimData.clerkOrganizationId = clerkOrganizationId;
            }
            const claimResult = await prisma_1.default.company.updateMany({
                where: {
                    id: company.id,
                    OR: [{ ownerUserId: null }, { ownerUserId: { isSet: false } }],
                },
                data: claimData,
            });
            if (claimResult.count === 0) {
                const current = await prisma_1.default.company.findUnique({
                    where: { id: company.id },
                });
                if (!current || current.ownerUserId !== clerkUserId) {
                    throw new errors_1.ConflictError("This Contract ID has already been linked");
                }
            }
        }
        await prisma_1.default.companyMember.upsert({
            where: {
                companyId_userId: {
                    companyId: company.id,
                    userId: dbUser.id,
                },
            },
            create: {
                companyId: company.id,
                userId: dbUser.id,
                role: "OWNER",
                status: "ACTIVE",
                joinedAt: claimedAt,
            },
            update: {
                role: "OWNER",
                status: "ACTIVE",
            },
        });
        if (!isDemo) {
            await prisma_1.default.companyContact.upsert({
                where: { companyId: company.id },
                create: {
                    companyId: company.id,
                    name: ownerDisplayName || primaryEmail.split("@")[0] || "Owner",
                    email: primaryEmail.toLowerCase(),
                    phone: clerkUser.phoneNumbers[0]?.phoneNumber ?? null,
                },
                update: {
                    name: ownerDisplayName || undefined,
                    email: primaryEmail.toLowerCase(),
                    phone: clerkUser.phoneNumbers[0]?.phoneNumber ?? undefined,
                },
            });
        }
        await ensureCreditBalance(company.id);
        await cache_service_1.cacheService.invalidateSettingsPages(company.id);
        if (!isDemo && clerkOrganizationId.startsWith("org_")) {
            await (0, organization_1.ensureClerkOrganizationMember)({
                organizationId: clerkOrganizationId,
                userId: clerkUserId,
                propnexRole: "OWNER",
            });
        }
        const linkedCompany = await prisma_1.default.company.findUnique({
            where: { id: company.id },
        });
        const resolvedClerkOrganizationId = linkedCompany?.clerkOrganizationId ?? clerkOrganizationId;
        return {
            linked: true,
            contractId: linkedCompany?.contractId ?? company.contractId,
            claimedAt: (linkedCompany?.claimedAt ?? claimedAt).toISOString(),
            clerkOrganizationId: toPublicClerkOrganizationId(resolvedClerkOrganizationId),
        };
    }
}
exports.ContractService = ContractService;
exports.contractService = new ContractService();
//# sourceMappingURL=contract.service.js.map