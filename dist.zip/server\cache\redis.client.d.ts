import Redis from "ioredis";
export declare function isRedisDisabled(): boolean;
export declare const redis: Redis | null;
export declare function isRedisAvailable(): boolean;
export declare function assertChannelRedisReady(): void;
export declare function connectRedisOnStartup(): Promise<void>;
