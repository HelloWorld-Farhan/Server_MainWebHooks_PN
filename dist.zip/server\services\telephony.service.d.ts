import type { TenantContext } from "../types/context";
import { type ChannelSettings, type ProviderCredentials, type TelephonyProvider } from "../types/telephony";
export declare class TelephonyService {
    private readonly repo;
    getConfig(ctx: TenantContext): Promise<{
        activeProvider: TelephonyProvider | null;
        connectionTested: Partial<Record<TelephonyProvider, boolean>>;
        connectionStatus: Partial<Record<TelephonyProvider, string>>;
        channelSettings: ChannelSettings;
        providerConfigs: ProviderCredentials;
        setupConfig: {
            totalChannels: number;
            pulseTimeSeconds: number;
            deltaSeconds: number;
            agentsAllocated: number;
        };
        channels: {
            id: string;
            channelIndex: number;
            label: string | null;
            phoneNumberId: string | null;
            phoneNumber: string | null;
        }[];
    }>;
    saveConfig(ctx: TenantContext, input: {
        activeProvider: TelephonyProvider;
        providerConfigs: ProviderCredentials;
        channelSettings?: ChannelSettings;
        totalChannels?: number;
        pulseTimeSeconds?: number;
        deltaSeconds?: number;
        channels?: {
            channelIndex: number;
            label?: string;
            phoneNumberId?: string;
        }[];
    }): Promise<{
        activeProvider: TelephonyProvider | null;
        connectionTested: Partial<Record<TelephonyProvider, boolean>>;
        connectionStatus: Partial<Record<TelephonyProvider, string>>;
        channelSettings: ChannelSettings;
        providerConfigs: ProviderCredentials;
        setupConfig: {
            totalChannels: number;
            pulseTimeSeconds: number;
            deltaSeconds: number;
            agentsAllocated: number;
        };
        channels: {
            id: string;
            channelIndex: number;
            label: string | null;
            phoneNumberId: string | null;
            phoneNumber: string | null;
        }[];
    }>;
    testConnection(ctx: TenantContext, input: {
        provider: TelephonyProvider;
        providerConfigs: ProviderCredentials;
    }): Promise<{
        status: "error";
        responseTimeMs: number;
        message: string;
        connectionHealth?: undefined;
    } | {
        status: "success";
        responseTimeMs: number;
        message: string;
        connectionHealth: {
            providerStatus: string;
            sipStatus: string;
            apiConnectivity: string;
            voiceServiceStatus: string;
            lastSuccessfulConnection: string;
        };
    }>;
    testCall(ctx: TenantContext, input: {
        phoneNumber: string;
        provider?: TelephonyProvider;
    }): Promise<{
        status: "success";
        message: string;
        provider: TelephonyProvider;
        phoneNumber: string;
        queuedAt: string;
    }>;
}
export declare const telephonyService: TelephonyService;
