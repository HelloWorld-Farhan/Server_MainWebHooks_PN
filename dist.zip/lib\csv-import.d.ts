export type CsvFieldKey = "contactName" | "phoneNumber" | "agentId" | "country";
export type ColumnMapping = Record<CsvFieldKey, string | null>;
export type ParsedCsv = {
    headers: string[];
    rows: string[][];
};
export type PreviewRow = {
    index: number;
    cells: Record<string, string>;
    phoneInvalid: boolean;
};
export declare const CSV_FIELD_LABELS: Record<CsvFieldKey, string>;
export declare const SAMPLE_CSV_FILENAME = "propnex-contacts-sample.csv";
export declare const SAMPLE_CSV_CONTENT = "full_name,phone_e164,email,agent_id\nJohn Smith,+15550123456,john.smith@example.com,\nJane Doe,+15550987654,jane.doe@example.com,agent-001\nK-2SO,999-999-invalid,invalid@example.com,\nAlex Rivera,+447911123456,alex.rivera@example.com,agent-002\nMaria Chen,+61412345678,maria.chen@example.com,\nSam Wilson,+15551234567,sam.wilson@example.com,agent-001\n";
export declare function parseCsv(text: string): ParsedCsv;
export declare function isValidE164Phone(value: string): boolean;
export declare function guessColumnMapping(headers: string[]): ColumnMapping;
export declare function buildPreviewRows(parsed: ParsedCsv, mapping: ColumnMapping, limit?: number): PreviewRow[];
export declare function countValidRecords(parsed: ParsedCsv, mapping: ColumnMapping): number;
export declare function downloadSampleCsv(): void;
export type LeadCategory = "hot" | "warm" | "cold";
export type CategorizedLeadImport = {
    hot: number;
    warm: number;
    cold: number;
    total: number;
    invalid: number;
    created?: number;
    updated?: number;
};
export type LeadImportRow = {
    firstName: string | null;
    lastName: string | null;
    email: string | null;
    phone: string;
    temperature: LeadCategory;
};
export declare function categorizeLeads(parsed: ParsedCsv, mapping: ColumnMapping): CategorizedLeadImport;
export declare function buildLeadImportRows(parsed: ParsedCsv, mapping: ColumnMapping): LeadImportRow[];
export declare function autoProcessCsv(text: string): {
    parsed: ParsedCsv;
    mapping: ColumnMapping;
    categories: CategorizedLeadImport;
    rows: LeadImportRow[];
};
