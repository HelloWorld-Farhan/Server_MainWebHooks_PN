import type { Request, Response } from "express";
export declare class SubCompaniesController {
    private readonly logger;
    getSubCompanies(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    createSubCompany(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    transferCredits(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
}
