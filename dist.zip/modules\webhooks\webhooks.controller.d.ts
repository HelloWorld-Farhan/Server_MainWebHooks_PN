import type { Request, Response } from "express";
export declare class WebhooksController {
    handleClerkWebhook(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
}
