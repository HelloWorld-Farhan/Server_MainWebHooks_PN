import type { CampaignAccessType, InvitationStatus, MemberStatus, Prisma, UserRole } from "@prisma/client";
import { BaseRepository } from "./base.repository";
export type EmployeeFilter = {
    search?: string;
    role?: UserRole;
    status?: MemberStatus;
    campaignId?: string;
};
declare const memberInclude: {
    user: true;
    customRole: true;
    campaignAccess: {
        include: {
            campaign: true;
        };
    };
};
export type EmployeeRow = Prisma.CompanyMemberGetPayload<{
    include: typeof memberInclude;
}> & {
    latestInvitation?: {
        id: string;
        status: InvitationStatus;
        expiresAt: Date;
        clerkInvitationId: string | null;
        clerkOrganizationId: string | null;
    } | null;
};
export declare class EmployeesRepository extends BaseRepository {
    private buildWhere;
    private attachLatestInvitations;
    findConnection(companyId: string, limit: number, after?: string, filter?: EmployeeFilter, scope?: Prisma.CompanyMemberWhereInput): Promise<EmployeeRow[]>;
    count(companyId: string, filter?: EmployeeFilter, scope?: Prisma.CompanyMemberWhereInput): Prisma.PrismaPromise<number>;
    findById(companyId: string, memberId: string): Promise<EmployeeRow | null>;
    findByEmail(companyId: string, email: string): Prisma.Prisma__CompanyMemberClient<({
        user: {
            status: import("@prisma/client").$Enums.UserStatus;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            email: string;
            firstName: string | null;
            lastName: string | null;
            phone: string | null;
            clerkUserId: string;
            imageUrl: string | null;
            passwordHash: string | null;
            lastLoginAt: Date | null;
        };
        customRole: {
            name: string;
            id: string;
            slug: string;
            createdAt: Date;
            updatedAt: Date;
            companyId: string | null;
            permissions: string[];
            isSystem: boolean;
        } | null;
        campaignAccess: ({
            campaign: {
                status: import("@prisma/client").$Enums.CampaignStatus;
                name: string;
                id: string;
                createdAt: Date;
                updatedAt: Date;
                companyId: string;
                email: string | null;
                phone: string | null;
                customFields: Prisma.JsonValue;
                direction: import("@prisma/client").$Enums.CampaignDirection;
                lastActivityAt: Date | null;
                resourceKey: string;
                systemPrompt: string | null;
                stage: import("@prisma/client").$Enums.CampaignStage;
                parentCampaignId: string | null;
                currentQStage: string | null;
                q1ScheduledAt: Date | null;
                q2ScheduledAt: Date | null;
                q3ScheduledAt: Date | null;
                qStatus: string | null;
                address: string | null;
                notes: string | null;
                aiEnabled: boolean;
                aiConfig: Prisma.JsonValue;
            };
        } & {
            id: string;
            createdAt: Date;
            campaignId: string;
            memberId: string;
        })[];
    } & {
        role: import("@prisma/client").$Enums.UserRole;
        userId: string;
        status: import("@prisma/client").$Enums.MemberStatus;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        roleId: string | null;
        jobTitle: string | null;
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        invitedAt: Date | null;
        joinedAt: Date | null;
    }) | null, null, import("@prisma/client/runtime/library").DefaultArgs, Prisma.PrismaClientOptions>;
    countActiveOwners(companyId: string, excludeMemberId?: string): Prisma.PrismaPromise<number>;
    setCampaignAccess(memberId: string, campaignIds: string[]): Promise<void>;
    updateMember(companyId: string, memberId: string, data: Prisma.CompanyMemberUpdateInput): Promise<{
        user: {
            status: import("@prisma/client").$Enums.UserStatus;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            email: string;
            firstName: string | null;
            lastName: string | null;
            phone: string | null;
            clerkUserId: string;
            imageUrl: string | null;
            passwordHash: string | null;
            lastLoginAt: Date | null;
        };
        customRole: {
            name: string;
            id: string;
            slug: string;
            createdAt: Date;
            updatedAt: Date;
            companyId: string | null;
            permissions: string[];
            isSystem: boolean;
        } | null;
        campaignAccess: ({
            campaign: {
                status: import("@prisma/client").$Enums.CampaignStatus;
                name: string;
                id: string;
                createdAt: Date;
                updatedAt: Date;
                companyId: string;
                email: string | null;
                phone: string | null;
                customFields: Prisma.JsonValue;
                direction: import("@prisma/client").$Enums.CampaignDirection;
                lastActivityAt: Date | null;
                resourceKey: string;
                systemPrompt: string | null;
                stage: import("@prisma/client").$Enums.CampaignStage;
                parentCampaignId: string | null;
                currentQStage: string | null;
                q1ScheduledAt: Date | null;
                q2ScheduledAt: Date | null;
                q3ScheduledAt: Date | null;
                qStatus: string | null;
                address: string | null;
                notes: string | null;
                aiEnabled: boolean;
                aiConfig: Prisma.JsonValue;
            };
        } & {
            id: string;
            createdAt: Date;
            campaignId: string;
            memberId: string;
        })[];
    } & {
        role: import("@prisma/client").$Enums.UserRole;
        userId: string;
        status: import("@prisma/client").$Enums.MemberStatus;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        roleId: string | null;
        jobTitle: string | null;
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        invitedAt: Date | null;
        joinedAt: Date | null;
    }>;
    createInvitation(data: {
        companyId: string;
        email: string;
        role: UserRole;
        roleId?: string | null;
        jobTitle?: string | null;
        campaignAccessType: CampaignAccessType;
        campaignIds: string[];
        token: string;
        expiresAt: Date;
        invitedById: string;
        clerkInvitationId?: string | null;
        clerkOrganizationId?: string | null;
    }): Prisma.Prisma__InvitationClient<{
        role: import("@prisma/client").$Enums.UserRole;
        status: import("@prisma/client").$Enums.InvitationStatus;
        token: string;
        id: string;
        clerkOrganizationId: string | null;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        roleId: string | null;
        jobTitle: string | null;
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        email: string;
        campaignIds: string[];
        clerkInvitationId: string | null;
        expiresAt: Date;
        invitedById: string;
    }, never, import("@prisma/client/runtime/library").DefaultArgs, Prisma.PrismaClientOptions>;
    findLatestInvitationByEmail(companyId: string, email: string): Prisma.Prisma__InvitationClient<{
        role: import("@prisma/client").$Enums.UserRole;
        status: import("@prisma/client").$Enums.InvitationStatus;
        token: string;
        id: string;
        clerkOrganizationId: string | null;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        roleId: string | null;
        jobTitle: string | null;
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        email: string;
        campaignIds: string[];
        clerkInvitationId: string | null;
        expiresAt: Date;
        invitedById: string;
    } | null, null, import("@prisma/client/runtime/library").DefaultArgs, Prisma.PrismaClientOptions>;
    findPendingInvitation(companyId: string, email: string): Prisma.Prisma__InvitationClient<{
        role: import("@prisma/client").$Enums.UserRole;
        status: import("@prisma/client").$Enums.InvitationStatus;
        token: string;
        id: string;
        clerkOrganizationId: string | null;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        roleId: string | null;
        jobTitle: string | null;
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        email: string;
        campaignIds: string[];
        clerkInvitationId: string | null;
        expiresAt: Date;
        invitedById: string;
    } | null, null, import("@prisma/client/runtime/library").DefaultArgs, Prisma.PrismaClientOptions>;
    updateInvitation(id: string, data: Prisma.InvitationUpdateInput): Prisma.Prisma__InvitationClient<{
        role: import("@prisma/client").$Enums.UserRole;
        status: import("@prisma/client").$Enums.InvitationStatus;
        token: string;
        id: string;
        clerkOrganizationId: string | null;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        roleId: string | null;
        jobTitle: string | null;
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        email: string;
        campaignIds: string[];
        clerkInvitationId: string | null;
        expiresAt: Date;
        invitedById: string;
    }, never, import("@prisma/client/runtime/library").DefaultArgs, Prisma.PrismaClientOptions>;
    updateInvitationStatus(id: string, status: InvitationStatus): Prisma.Prisma__InvitationClient<{
        role: import("@prisma/client").$Enums.UserRole;
        status: import("@prisma/client").$Enums.InvitationStatus;
        token: string;
        id: string;
        clerkOrganizationId: string | null;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        roleId: string | null;
        jobTitle: string | null;
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        email: string;
        campaignIds: string[];
        clerkInvitationId: string | null;
        expiresAt: Date;
        invitedById: string;
    }, never, import("@prisma/client/runtime/library").DefaultArgs, Prisma.PrismaClientOptions>;
    revokePendingInvitation(companyId: string, email: string): Prisma.PrismaPromise<Prisma.BatchPayload>;
    markInvitationAccepted(companyId: string, email: string): Prisma.PrismaPromise<Prisma.BatchPayload>;
    validateCampaignIds(companyId: string, campaignIds: string[]): Promise<never[]> | Prisma.PrismaPromise<{
        id: string;
    }[]>;
}
export {};
