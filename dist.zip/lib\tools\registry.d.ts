import { type LucideIcon } from "lucide-react";
import type { IntegrationId } from "../integrations/types";
import type { AgentToolId } from "./types";
export type ToolRegistryEntry = {
    id: AgentToolId;
    name: string;
    description: string;
    icon: LucideIcon;
    requiredIntegrationId?: IntegrationId;
    examples: string[];
};
export declare const TOOL_REGISTRY: ToolRegistryEntry[];
export declare function getToolDefinition(id: AgentToolId): ToolRegistryEntry | undefined;
