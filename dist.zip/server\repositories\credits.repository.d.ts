import type { CreditUsageReason } from "@prisma/client";
import { BaseRepository } from "./base.repository";
export declare class CreditsRepository extends BaseRepository {
    getBalance(companyId: string): import("@prisma/client").Prisma.Prisma__CreditBalanceClient<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        creditsUsed: number;
        planId: string | null;
        creditsRemaining: number;
        renewalAt: Date | null;
    } | null, null, import("@prisma/client/runtime/library").DefaultArgs, import("@prisma/client").Prisma.PrismaClientOptions>;
    ensureBalance(companyId: string): import("@prisma/client").Prisma.Prisma__CreditBalanceClient<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        creditsUsed: number;
        planId: string | null;
        creditsRemaining: number;
        renewalAt: Date | null;
    }, never, import("@prisma/client/runtime/library").DefaultArgs, import("@prisma/client").Prisma.PrismaClientOptions>;
    listUsage(companyId: string, limit: number, after?: string): import("@prisma/client").Prisma.PrismaPromise<{
        reason: import("@prisma/client").$Enums.CreditUsageReason;
        id: string;
        createdAt: Date;
        companyId: string;
        description: string | null;
        callLogId: string | null;
        metadata: import("@prisma/client/runtime/library").JsonValue;
        amount: number;
    }[]>;
    recordUsage(companyId: string, data: {
        amount: number;
        reason: CreditUsageReason;
        callLogId?: string;
        description?: string;
    }): Promise<{
        reason: import("@prisma/client").$Enums.CreditUsageReason;
        id: string;
        createdAt: Date;
        companyId: string;
        description: string | null;
        callLogId: string | null;
        metadata: import("@prisma/client/runtime/library").JsonValue;
        amount: number;
    }>;
}
