import type { CallStatus } from "@prisma/client";
export declare function isTerminalCallStatus(status: CallStatus): boolean;
export declare function canTransitionCallStatus(from: CallStatus, to: CallStatus): boolean;
export declare function isProviderCompletedStatus(status: CallStatus): boolean;
