export declare function logObdOutbound(fields: {
    correlationId: string;
    callLogPublicId: string;
    campaignPublicId?: string;
    companyId: string;
    phone: string;
    payload?: unknown;
}): void;
export declare function logObdProviderRequest(fields: {
    correlationId: string;
    url: string;
    method: string;
    headers: Record<string, string>;
    payload: unknown;
}): void;
export declare function logObdProviderResponse(fields: {
    correlationId: string;
    httpStatus: number;
    responseHeaders: Record<string, string>;
    responseBody: unknown;
    providerCallId?: string | null;
    warning?: string;
}): void;
export declare function logObdWebhook(fields: {
    correlationId?: string;
    callLogPublicId: string;
    providerStatus: string;
    durationSeconds: number;
    durationMs: number;
}): void;
export declare function logObdRetry(fields: {
    correlationId: string;
    attempt: number;
    httpStatus?: number;
}): void;
export declare function logObdError(fields: {
    correlationId: string;
    message: string;
    httpStatus?: number;
    responseBody?: unknown;
}): void;
export declare function logObdWebhookDuplicate(fields: {
    correlationId?: string;
    callLogPublicId: string;
    providerEventId: string;
    durationMs: number;
}): void;
