import type { Request, Response } from "express";
export declare class InvitationsController {
    getInvitation(token: string, res: Response): Promise<Response<any, Record<string, any>>>;
    acceptInvitation(token: string, req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
}
