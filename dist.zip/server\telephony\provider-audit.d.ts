import type { Prisma } from "@prisma/client";
export type ProviderRequestEntry = {
    at: string;
    correlationId: string;
    payload: unknown;
};
export type ProviderResponseEntry = {
    at: string;
    correlationId: string;
    httpStatus?: number;
    providerCallId?: string | null;
    payload?: unknown;
    error?: Record<string, unknown>;
};
export type ProviderWebhookEntry = {
    at: string;
    correlationId?: string;
    providerEventId: string;
    payload: unknown;
};
export declare function appendProviderRequest(existing: Prisma.JsonValue | null | undefined, entry: ProviderRequestEntry): Prisma.InputJsonValue;
export declare function appendProviderResponse(existing: Prisma.JsonValue | null | undefined, entry: ProviderResponseEntry): Prisma.InputJsonValue;
export declare function appendProviderWebhook(existing: Prisma.JsonValue | null | undefined, entry: ProviderWebhookEntry): Prisma.InputJsonValue;
