"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.callService = exports.CallService = void 0;
const channel_keys_1 = require("../channels/channel-keys");
const channel_queue_hooks_1 = require("../channels/channel-queue.hooks");
const channel_service_1 = require("../channels/channel.service");
const channel_metrics_1 = require("../channels/channel-metrics");
const redis_client_1 = require("../cache/redis.client");
const errors_1 = require("../lib/errors");
const prisma_1 = __importDefault(require("../lib/prisma"));
const call_logs_repository_1 = require("../repositories/call-logs.repository");
const call_status_lifecycle_1 = require("../telephony/call-status-lifecycle");
const status_mapper_1 = require("../telephony/status-mapper");
const outbound_service_1 = require("../telephony/outbound.service");
const MAX_DISPATCH_RETRIES = 3;
const ACTIVE_CHANNEL_STATUSES = [
    "DISPATCHING",
    "QUEUED_AT_PROVIDER",
    "RINGING",
    "ANSWERED",
];
class CallService {
    callLogsRepo = new call_logs_repository_1.CallLogsRepository(prisma_1.default);
    async requestDispatch(input) {
        const callLog = await this.callLogsRepo.findByIdForDispatch(input.companyId, input.callLogId);
        if (!callLog) {
            throw new errors_1.ValidationError("Call log not found");
        }
        if (callLog.status !== "PENDING") {
            throw new errors_1.ValidationError(`Call log must be PENDING to dispatch (current: ${callLog.status})`);
        }
        if ((0, redis_client_1.isRedisDisabled)()) {
            (0, channel_metrics_1.logChannelEvent)("channels:bypass", {
                companyId: input.companyId,
                callLogId: input.callLogId,
                reason: "REDIS_ENABLED=false",
            });
            return this.dispatchDirect(input);
        }
        (0, redis_client_1.assertChannelRedisReady)();
        await this.ensureChannelState(input.companyId);
        const allocated = await this.getAllocatedChannels(input.companyId);
        if (allocated <= 0) {
            return this.queueCall(input.companyId, input.callLogId);
        }
        const reserved = await channel_service_1.channelService.tryReserve(input.companyId);
        if (!reserved) {
            return this.queueCall(input.companyId, input.callLogId);
        }
        (0, channel_metrics_1.logChannelEvent)("channels:reserved", {
            companyId: input.companyId,
            callLogId: input.callLogId,
        });
        return this.dispatchWithReservedChannel(input);
    }
    async dispatchQueuedCall(callLogId) {
        if (!/^[a-fA-F0-9]{24}$/.test(callLogId)) {
            return false;
        }
        let callLog;
        try {
            callLog = await prisma_1.default.callLog.findFirst({
                where: { id: callLogId, status: "QUEUED" },
                select: {
                    id: true,
                    companyId: true,
                    publicId: true,
                    createdAt: true,
                    phoneNumber: { select: { number: true } },
                    campaign: { select: { resourceKey: true } },
                },
            });
        }
        catch {
            return false;
        }
        if (!callLog?.phoneNumber?.number || !callLog.companyId) {
            return false;
        }
        const lockAcquired = await channel_service_1.channelService.acquireDispatchLock(callLog.id);
        if (!lockAcquired) {
            return false;
        }
        try {
            const result = await outbound_service_1.obdOutboundService.dispatch({
                companyId: callLog.companyId,
                callLogId: callLog.id,
                callLogPublicId: callLog.publicId,
                phone: callLog.phoneNumber.number,
            });
            if (result.status === "FAILED") {
                const retryCount = await this.incrementRetryCount(callLog.companyId, callLog.id);
                if (retryCount < MAX_DISPATCH_RETRIES) {
                    await this.callLogsRepo.transitionStatus(callLog.companyId, callLog.id, { from: "FAILED", to: "QUEUED" });
                    await channel_service_1.channelService.enqueueFront(callLog.companyId, callLog.id);
                }
                return false;
            }
            (0, channel_metrics_1.incrementChannelMetric)("calls_dispatched_from_queue_total");
            (0, channel_metrics_1.recordQueueWaitMs)(Date.now() - callLog.createdAt.getTime());
            (0, channel_metrics_1.logChannelEvent)("channels:dispatch:queued-call", {
                companyId: callLog.companyId,
                callLogId: callLog.id,
            });
            return true;
        }
        finally {
            await channel_service_1.channelService.releaseDispatchLock(callLog.id);
        }
    }
    async handleProviderWebhook(input) {
        const mappedStatus = (0, status_mapper_1.mapProviderStatusToCallStatus)(input.providerStatus);
        const canTransition = (0, call_status_lifecycle_1.canTransitionCallStatus)(input.currentStatus, mappedStatus);
        if ((0, call_status_lifecycle_1.isTerminalCallStatus)(input.currentStatus) || !canTransition) {
            await this.callLogsRepo.appendProviderWebhookOnly(input.companyId, input.callLogId, { providerWebhook: input.providerWebhook });
            return { applied: false, mappedStatus };
        }
        await this.callLogsRepo.updateFromProviderWebhook(input.companyId, input.callLogId, {
            status: mappedStatus,
            providerStatus: input.providerStatus,
            durationSeconds: input.durationSeconds,
            answeredAt: input.answeredAt,
            endedAt: input.endedAt,
            disconnectReason: input.disconnectReason,
            providerWebhook: input.providerWebhook,
            ...((0, call_status_lifecycle_1.isProviderCompletedStatus)(mappedStatus)
                ? { providerCompletedAt: new Date() }
                : {}),
        });
        if ((0, call_status_lifecycle_1.isTerminalCallStatus)(mappedStatus)) {
            await channel_service_1.channelService.startCooldown(input.companyId, input.callLogId, (0, channel_keys_1.getChannelCooldownMs)());
        }
        return { applied: true, mappedStatus };
    }
    async queueCall(companyId, callLogId) {
        await this.callLogsRepo.transitionStatus(companyId, callLogId, {
            from: "PENDING",
            to: "QUEUED",
        });
        await channel_service_1.channelService.enqueue(companyId, callLogId);
        return { status: "QUEUED" };
    }
    async dispatchDirect(input) {
        const result = await outbound_service_1.obdOutboundService.dispatch({
            companyId: input.companyId,
            callLogId: input.callLogId,
            callLogPublicId: input.callLogPublicId,
            phone: input.phone,
            campaignPublicId: input.campaignPublicId,
        });
        if (result.status === "FAILED") {
            return { status: "FAILED" };
        }
        return { status: "QUEUED_AT_PROVIDER" };
    }
    async dispatchWithReservedChannel(input) {
        const lockAcquired = await channel_service_1.channelService.acquireDispatchLock(input.callLogId);
        if (!lockAcquired) {
            await channel_service_1.channelService.release(input.companyId);
            (0, channel_queue_hooks_1.wakeCompanyQueue)(input.companyId);
            return this.queueCall(input.companyId, input.callLogId);
        }
        try {
            const result = await outbound_service_1.obdOutboundService.dispatch({
                companyId: input.companyId,
                callLogId: input.callLogId,
                callLogPublicId: input.callLogPublicId,
                phone: input.phone,
                campaignPublicId: input.campaignPublicId,
            });
            if (result.status === "FAILED") {
                await channel_service_1.channelService.release(input.companyId);
                (0, channel_queue_hooks_1.wakeCompanyQueue)(input.companyId);
                return { status: "FAILED" };
            }
            return { status: "QUEUED_AT_PROVIDER" };
        }
        catch (error) {
            await channel_service_1.channelService.release(input.companyId);
            (0, channel_queue_hooks_1.wakeCompanyQueue)(input.companyId);
            throw error;
        }
        finally {
            await channel_service_1.channelService.releaseDispatchLock(input.callLogId);
        }
    }
    async markCancelled(companyId, callLogId) {
        await this.callLogsRepo.transitionStatus(companyId, callLogId, {
            from: "QUEUED",
            to: "CANCELLED",
        });
        await channel_service_1.channelService.releaseDispatchLock(callLogId);
    }
    async retryQueuedCall(companyId, callLogId, retryCount) {
        if (retryCount >= MAX_DISPATCH_RETRIES) {
            await this.callLogsRepo.transitionStatus(companyId, callLogId, {
                from: "QUEUED",
                to: "FAILED",
            });
            return;
        }
        await channel_service_1.channelService.enqueueFront(companyId, callLogId);
    }
    async incrementRetryCount(companyId, callLogId) {
        const callLog = await prisma_1.default.callLog.findFirst({
            where: { id: callLogId, companyId },
            select: { providerMetadata: true },
        });
        const metadata = callLog?.providerMetadata &&
            typeof callLog.providerMetadata === "object" &&
            !Array.isArray(callLog.providerMetadata)
            ? callLog.providerMetadata
            : {};
        const retryCount = Number(metadata.retryCount ?? 0) + 1;
        await prisma_1.default.callLog.updateMany({
            where: { id: callLogId, companyId },
            data: {
                providerMetadata: {
                    ...metadata,
                    retryCount,
                },
            },
        });
        return retryCount;
    }
    async getAllocatedChannels(companyId) {
        const config = await prisma_1.default.companySetupConfig.findUnique({
            where: { companyId },
            select: { totalChannels: true },
        });
        return config?.totalChannels ?? 0;
    }
    async ensureChannelState(companyId) {
        const metrics = await channel_service_1.channelService.getMetrics(companyId);
        if (metrics.allocated > 0) {
            return;
        }
        const allocated = await this.getAllocatedChannels(companyId);
        if (allocated <= 0) {
            return;
        }
        const active = await this.callLogsRepo.countByStatuses(companyId, ACTIVE_CHANNEL_STATUSES);
        const queued = await this.callLogsRepo.findQueuedCallLogIds(companyId);
        await channel_service_1.channelService.initializeCompany(companyId, allocated, active, queued);
    }
}
exports.CallService = CallService;
exports.callService = new CallService();
//# sourceMappingURL=call.service.js.map