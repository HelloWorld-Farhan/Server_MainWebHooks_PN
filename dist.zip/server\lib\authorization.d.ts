import type { Permission } from "../../lib/permissions";
import type { TenantContext } from "../types/context";
export declare function requireScope(ctx: TenantContext, scope: Permission): void;
export declare function requireAllScopes(ctx: TenantContext, scopes: Permission[]): void;
export declare function requireAnyScope(ctx: TenantContext, scopes: Permission[]): void;
export declare function requireCampaignAccess(ctx: TenantContext, campaignId: string): void;
export type ResourceRestriction = {
    type: "branch";
    id: string;
};
export declare function assertResourceAccess(ctx: TenantContext, resource: ResourceRestriction): void;
export declare function assertScopesAreSubset(principalScopes: string[], grantedScopes: string[]): void;
export declare function assertCampaignsAreSubset(ctx: TenantContext, campaignIds: string[]): void;
