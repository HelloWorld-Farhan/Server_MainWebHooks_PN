import type { Request, Response } from "express";
export declare class InboundWebhooksController {
    handleInboundWebhook(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
}
