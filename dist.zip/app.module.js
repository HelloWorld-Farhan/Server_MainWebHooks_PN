"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppModule = void 0;
const common_1 = require("@nestjs/common");
const app_controller_1 = require("./app.controller");
const config_module_1 = require("./config/config.module");
const logging_interceptor_1 = require("./common/interceptors/logging.interceptor");
const prisma_module_1 = require("./database/prisma/prisma.module");
const api_module_1 = require("./modules/api/api.module");
const campaign_execution_module_1 = require("./server/campaign-execution/campaign-execution.module");
const channels_module_1 = require("./server/channels/channels.module");
const websockets_module_1 = require("./modules/websockets/websockets.module");
let AppModule = class AppModule {
};
exports.AppModule = AppModule;
exports.AppModule = AppModule = __decorate([
    (0, common_1.Module)({
        imports: [
            config_module_1.AppConfigModule,
            prisma_module_1.PrismaModule,
            api_module_1.ApiModule,
            channels_module_1.ChannelsModule,
            campaign_execution_module_1.CampaignExecutionModule,
            websockets_module_1.WebsocketsModule,
        ],
        controllers: [app_controller_1.AppController],
        providers: [logging_interceptor_1.LoggingInterceptor],
    })
], AppModule);
//# sourceMappingURL=app.module.js.map