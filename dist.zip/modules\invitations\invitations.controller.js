"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InvitationsController = void 0;
const common_1 = require("@nestjs/common");
const clerk_1 = require("../../auth/clerk");
const campaign_invitation_service_1 = require("./campaign-invitation.service");
let InvitationsController = class InvitationsController {
    async getInvitation(token, res) {
        const result = await (0, campaign_invitation_service_1.getCampaignInvitationByToken)(token);
        return res.json(result);
    }
    async acceptInvitation(token, req, res) {
        const { userId } = await (0, clerk_1.getAuthFromRequest)(req);
        if (!userId) {
            return res.status(401).json({ error: "Unauthorized" });
        }
        const result = await (0, campaign_invitation_service_1.acceptCampaignInvitation)(token, userId);
        if (!result.success) {
            return res.status(result.statusCode).json({ error: result.error });
        }
        return res.json({ success: true });
    }
};
exports.InvitationsController = InvitationsController;
__decorate([
    (0, common_1.Get)(":token"),
    __param(0, (0, common_1.Param)("token")),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], InvitationsController.prototype, "getInvitation", null);
__decorate([
    (0, common_1.Post)(":token/accept"),
    __param(0, (0, common_1.Param)("token")),
    __param(1, (0, common_1.Req)()),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], InvitationsController.prototype, "acceptInvitation", null);
exports.InvitationsController = InvitationsController = __decorate([
    (0, common_1.Controller)("api/invitations/campaign")
], InvitationsController);
//# sourceMappingURL=invitations.controller.js.map