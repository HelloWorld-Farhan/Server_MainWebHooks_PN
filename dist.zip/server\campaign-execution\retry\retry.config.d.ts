export declare const retryConfig: {
    defaultMaxRetries: number;
    defaultRetryDelaySeconds: number;
    workerIntervalMs: number;
    maxPendingRetries: number;
    processBatchSize: number;
};
export declare const DEFAULT_RETRY_POLICY: {
    readonly retryEnabled: true;
    readonly maxRetries: number;
    readonly retryDelaySeconds: number;
    readonly retryOnBusy: true;
    readonly retryOnNoAnswer: true;
    readonly retryOnFailed: true;
    readonly retryOnCancelled: false;
    readonly retryOnVoicemail: false;
    readonly retryOnMissed: true;
};
