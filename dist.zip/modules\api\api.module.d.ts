export declare class ApiModule {
}
