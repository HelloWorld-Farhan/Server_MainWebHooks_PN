export declare class WebsocketsModule {
}
