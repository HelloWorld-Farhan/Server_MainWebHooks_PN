"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.callLogsService = exports.CallLogsService = void 0;
const cache_service_1 = require("../cache/cache.service");
const keys_1 = require("../cache/keys");
const errors_1 = require("../lib/errors");
const pagination_1 = require("../lib/pagination");
const prisma_1 = __importDefault(require("../lib/prisma"));
const call_logs_repository_1 = require("../repositories/call-logs.repository");
const call_internal_note_repository_1 = require("../repositories/call-internal-note.repository");
const permissions_1 = require("../types/permissions");
const tenant_service_1 = require("./tenant.service");
const campaign_access_service_1 = require("./campaign-access.service");
const analytics_service_1 = require("./analytics.service");
const billing_service_1 = require("./billing.service");
const credits_service_1 = require("./credits.service");
const credits_repository_1 = require("../repositories/credits.repository");
function mapNote(note) {
    return {
        id: note.id,
        content: note.content,
        createdAt: note.createdAt.toISOString(),
        updatedAt: note.updatedAt.toISOString(),
        author: {
            id: note.author.id,
            name: [note.author.firstName, note.author.lastName]
                .filter(Boolean)
                .join(' ') || note.author.email,
            email: note.author.email,
        },
    };
}
class CallLogsService {
    repo = new call_logs_repository_1.CallLogsRepository(prisma_1.default);
    notesRepo = new call_internal_note_repository_1.CallInternalNoteRepository(prisma_1.default);
    async getRecent(ctx, limit = 10) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CALL_LOGS_READ);
        const capped = Math.min(limit, 20);
        return cache_service_1.cacheService.getOrSet(keys_1.cacheKeys.companyTopCallLogs(ctx.companyId), keys_1.CACHE_TTL.TOP_CALL_LOGS, async () => {
            const logs = await this.repo.findRecent(ctx.companyId, capped, campaign_access_service_1.campaignAccessService.callLogCampaignFilter(ctx));
            return logs.map((log) => ({
                ...log,
                startedAt: log.startedAt.toISOString(),
            }));
        });
    }
    async getConnection(ctx, args) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CALL_LOGS_READ);
        const limit = Math.min(args.first ?? 20, 100);
        const items = await this.repo.findConnection(ctx.companyId, limit, args.after, args.filter, campaign_access_service_1.campaignAccessService.callLogCampaignFilter(ctx));
        const connection = (0, pagination_1.buildConnection)(items, limit, (item) => (0, pagination_1.encodeCursor)(item.startedAt, item.id));
        return {
            ...connection,
            edges: connection.edges.map(({ node, cursor }) => ({
                cursor,
                node: {
                    ...node,
                    startedAt: node.startedAt.toISOString(),
                },
            })),
        };
    }
    async getDetail(ctx, id) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CALL_LOGS_READ);
        const log = await this.repo.findById(ctx.companyId, id);
        if (!log) {
            throw new errors_1.NotFoundError('Call log not found');
        }
        campaign_access_service_1.campaignAccessService.assertCallLogCampaignAccess(ctx, log.campaignId);
        const internalNotes = await this.notesRepo.listByCallLog(ctx.companyId, id);
        return {
            ...log,
            startedAt: log.startedAt.toISOString(),
            outcome: log.outcome,
            aiSummary: log.aiSummary,
            sentiment: log.sentiment,
            engagement: log.engagement,
            reactivationPlan: log.reactivationPlan,
            recordingUrl: log.recordingUrl,
            cost: log.cost,
            creditsUsed: log.creditsUsed,
            provider: log.provider,
            transcript: log.transcript,
            internalNotes: internalNotes.map(mapNote),
            phoneNumber: log.phoneNumber
                ? {
                    id: log.phoneNumber.id,
                    number: log.phoneNumber.number,
                    label: log.phoneNumber.label,
                }
                : null,
        };
    }
    async updateOutcome(ctx, id, outcome, reactivationPlan) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CALL_LOGS_WRITE);
        const log = await this.repo.findById(ctx.companyId, id);
        if (!log) {
            throw new errors_1.NotFoundError('Call log not found');
        }
        campaign_access_service_1.campaignAccessService.assertCallLogCampaignAccess(ctx, log.campaignId);
        await this.repo.updateOutcome(ctx.companyId, id, outcome, reactivationPlan);
        await cache_service_1.cacheService.invalidateCallRelated(ctx.companyId);
        return this.getDetail(ctx, id);
    }
    async addInternalNote(ctx, callLogId, content) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CALL_LOGS_WRITE);
        const log = await this.repo.findById(ctx.companyId, callLogId);
        if (!log) {
            throw new errors_1.NotFoundError('Call log not found');
        }
        campaign_access_service_1.campaignAccessService.assertCallLogCampaignAccess(ctx, log.campaignId);
        const note = await this.notesRepo.create(ctx.companyId, callLogId, ctx.userId, content.trim());
        return mapNote(note);
    }
    async updateInternalNote(ctx, id, content) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CALL_LOGS_WRITE);
        const result = await this.notesRepo.update(ctx.companyId, id, content.trim());
        if (result.count === 0) {
            throw new errors_1.NotFoundError('Note not found');
        }
        const notes = await prisma_1.default.callInternalNote.findFirst({
            where: { id, companyId: ctx.companyId },
            include: {
                author: {
                    select: {
                        id: true,
                        firstName: true,
                        lastName: true,
                        email: true,
                    },
                },
            },
        });
        if (!notes) {
            throw new errors_1.NotFoundError('Note not found');
        }
        return mapNote(notes);
    }
    async deleteInternalNote(ctx, id) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CALL_LOGS_WRITE);
        const result = await this.notesRepo.delete(ctx.companyId, id);
        if (result.count === 0) {
            throw new errors_1.NotFoundError('Note not found');
        }
        return true;
    }
    async onCallCompleted(companyId, delta) {
        await analytics_service_1.analyticsService.incrementDailyMetrics(companyId, delta);
        await cache_service_1.cacheService.invalidateCallRelated(companyId);
    }
    async recordCompletedWithBilling(ctx, callLogId) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CREDITS_WRITE);
        const log = await this.repo.findForBilling(ctx.companyId, callLogId);
        if (!log) {
            throw new errors_1.NotFoundError('Call log not found');
        }
        campaign_access_service_1.campaignAccessService.assertCallLogCampaignAccess(ctx, log.campaignId);
        const existingUsage = await prisma_1.default.creditUsage.findFirst({
            where: { companyId: ctx.companyId, callLogId, reason: 'CALL' },
            select: { id: true, amount: true },
        });
        if (existingUsage || (log.creditsUsed != null && log.creditsUsed > 0)) {
            if (existingUsage && (log.creditsUsed == null || log.creditsUsed <= 0)) {
                const config = await billing_service_1.billingService.loadCompanyBillingConfig(ctx.companyId);
                await this.repo.updateBilling(ctx.companyId, callLogId, {
                    creditsUsed: existingUsage.amount,
                    cost: existingUsage.amount * config.costPerCredit,
                });
            }
            return true;
        }
        const shouldBill = log.status === 'COMPLETED';
        if (shouldBill) {
            const config = await billing_service_1.billingService.loadCompanyBillingConfig(ctx.companyId);
            const { credits, costInr } = billing_service_1.billingService.calculateCallBilling(log.durationSeconds, config);
            if (credits > 0) {
                const creditsRepo = new credits_repository_1.CreditsRepository(prisma_1.default);
                const balance = await creditsRepo.ensureBalance(ctx.companyId);
                await credits_service_1.creditsService.debitForCall(ctx, callLogId, credits, `Call billing: ${credits} credit(s), ₹${costInr.toFixed(2)}`);
                await this.repo.updateBilling(ctx.companyId, callLogId, {
                    creditsUsed: credits,
                    cost: costInr,
                });
            }
        }
        await this.onCallCompleted(ctx.companyId, {
            totalCalls: 1,
            connectedCalls: shouldBill ? 1 : 0,
        });
        return true;
    }
}
exports.CallLogsService = CallLogsService;
exports.callLogsService = new CallLogsService();
//# sourceMappingURL=call-logs.service.js.map