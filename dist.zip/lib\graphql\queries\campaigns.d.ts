export type CampaignStatus = "ACTIVE" | "INACTIVE" | "ARCHIVED";
export type CampaignDirection = "INBOUND" | "OUTBOUND";
export type ViewerRoleResult = {
    viewer: {
        id: string;
        membershipId: string;
        role: string;
        permissions: string[];
        campaignAccessType: "ALL" | "SELECTED";
        campaignIds: string[];
        company: {
            name: string;
        };
    };
};
export declare const VIEWER_ROLE_QUERY = "\n  query ViewerRole {\n    viewer {\n      id\n      membershipId\n      role\n      permissions\n      campaignAccessType\n      campaignIds\n      company {\n        name\n      }\n    }\n  }\n";
export type ViewerCampaignNameResult = {
    campaigns: {
        byId: {
            name: string;
        } | null;
    };
};
export declare const VIEWER_CAMPAIGN_NAME_QUERY = "\n  query ViewerCampaignName($id: ID!) {\n    campaigns {\n      byId(id: $id) {\n        name\n      }\n    }\n  }\n";
export type CampaignInvitationNode = {
    id: string;
    email: string;
    token: string;
    status: "PENDING" | "ACCEPTED" | "EXPIRED" | "CANCELLED";
    createdAt: string;
    updatedAt: string;
    sentAt: string;
    acceptedAt: string | null;
    expiresAt: string;
};
export type CampaignNode = {
    id: string;
    name: string;
    status: CampaignStatus;
    direction: CampaignDirection;
    address: string | null;
    phone: string | null;
    email: string | null;
    notes: string | null;
    customFields: Record<string, unknown> | null;
    aiEnabled: boolean;
    systemPrompt: string | null;
    aiConfig: Record<string, unknown> | null;
    contactsCount: number;
    callLogsCount: number;
    documentsCount: number;
    agentsCount: number;
    lastActivityAt: string | null;
    createdAt: string;
    updatedAt: string;
    invitationEmailSent: boolean | null;
    invitation: CampaignInvitationNode | null;
    execution?: {
        status: "DRAFT" | "SCHEDULED" | "RUNNING" | "PAUSED" | "COMPLETED" | "FAILED" | "CANCELLED";
        scheduledAt: string | null;
        totalContacts: number;
    } | null;
};
export type CampaignsConnectionResult = {
    campaigns: {
        connection: {
            edges: {
                node: CampaignNode;
                cursor: string;
            }[];
            pageInfo: {
                hasNextPage: boolean;
                endCursor: string | null;
            };
            totalCount: number;
        };
    };
};
export type CampaignContactNode = {
    id: string;
    phone: string | null;
    field1: string | null;
    field2: string | null;
    field3: string | null;
    createdAt: string | null;
};
export type CampaignCallLogNode = {
    id: string;
    direction: string;
    status: string;
    durationSeconds: number;
    startedAt: string;
    leadPhone: string | null;
    leadName: string | null;
};
export type CampaignDocumentNode = {
    id: string;
    name: string;
    url: string;
    mimeType: string | null;
    sizeBytes: number | null;
    createdAt: string;
};
export type CampaignActivityNode = {
    id: string;
    type: string;
    summary: string;
    metadata: Record<string, unknown> | null;
    createdAt: string;
};
export type CampaignAgentNode = {
    id: string;
    name: string;
    type: string;
    category: string | null;
    status: string;
    environment: string;
    enabled: boolean;
    demoAudioUrl: string | null;
    campaignId: string | null;
    systemPrompt: string | null;
    createdAt: string;
    updatedAt: string;
};
export type CampaignDetailResult = {
    campaigns: {
        byId: CampaignNode | null;
        activities: CampaignActivityNode[];
    };
};
export declare const BRANCHES_PAGE_QUERY = "\n  query CampaignsPage($first: Int, $after: String, $filter: CampaignFilter) {\n    campaigns {\n      connection(first: $first, after: $after, filter: $filter) {\n        edges {\n          node {\n  id\n  name\n  status\n  direction\n  address\n  phone\n  email\n  notes\n  customFields\n  aiEnabled\n  systemPrompt\n  aiConfig\n  contactsCount\n  callLogsCount\n  documentsCount\n  agentsCount\n  lastActivityAt\n  createdAt\n  updatedAt\n  invitationEmailSent\n  execution {\n    status\n    scheduledAt\n    totalContacts\n  }\n  invitation {\n    id\n    email\n    token\n    status\n    createdAt\n    updatedAt\n    sentAt\n    acceptedAt\n    expiresAt\n  }\n}\n          cursor\n        }\n        pageInfo {\n          hasNextPage\n          endCursor\n        }\n        totalCount\n      }\n    }\n  }\n";
export declare const CAMPAIGN_DETAIL_QUERY = "\n  query CampaignDetail($id: ID!) {\n    campaigns {\n      byId(id: $id) {\n  id\n  name\n  status\n  direction\n  address\n  phone\n  email\n  notes\n  customFields\n  aiEnabled\n  systemPrompt\n  aiConfig\n  contactsCount\n  callLogsCount\n  documentsCount\n  agentsCount\n  lastActivityAt\n  createdAt\n  updatedAt\n  invitationEmailSent\n  execution {\n    status\n    scheduledAt\n    totalContacts\n  }\n  invitation {\n    id\n    email\n    token\n    status\n    createdAt\n    updatedAt\n    sentAt\n    acceptedAt\n    expiresAt\n  }\n}\n      activities(campaignId: $id, limit: 50) {\n        id\n        type\n        summary\n        metadata\n        createdAt\n      }\n    }\n  }\n";
export declare const CAMPAIGN_CONTACTS_QUERY = "\n  query CampaignContacts($campaignId: ID!, $first: Int, $after: String) {\n    campaigns {\n      contacts(campaignId: $campaignId, first: $first, after: $after) {\n        id\n        phone\n        field1\n        field2\n        field3\n        createdAt\n      }\n    }\n  }\n";
export declare const CAMPAIGN_CALL_LOGS_QUERY = "\n  query CampaignCallLogs($campaignId: ID!, $first: Int, $after: String) {\n    campaigns {\n      callLogs(campaignId: $campaignId, first: $first, after: $after) {\n        id\n        direction\n        status\n        durationSeconds\n        startedAt\n        leadPhone\n        leadName\n      }\n    }\n  }\n";
export declare const CAMPAIGN_DOCUMENTS_QUERY = "\n  query CampaignDocuments($campaignId: ID!) {\n    campaigns {\n      documents(campaignId: $campaignId) {\n        id\n        name\n        url\n        mimeType\n        sizeBytes\n        createdAt\n      }\n    }\n  }\n";
export declare const CAMPAIGN_AGENTS_QUERY = "\n  query CampaignAgents($campaignId: ID!) {\n    campaigns {\n      agents(campaignId: $campaignId) {\n        id\n        name\n        type\n        category\n        status\n        environment\n        enabled\n        demoAudioUrl\n        campaignId\n        systemPrompt\n        createdAt\n        updatedAt\n      }\n    }\n  }\n";
export declare const CREATE_BRANCH_MUTATION = "\n  mutation CreateCampaign($input: CreateCampaignInput!) {\n    campaigns {\n      create(input: $input) {\n  id\n  name\n  status\n  direction\n  address\n  phone\n  email\n  notes\n  customFields\n  aiEnabled\n  systemPrompt\n  aiConfig\n  contactsCount\n  callLogsCount\n  documentsCount\n  agentsCount\n  lastActivityAt\n  createdAt\n  updatedAt\n  invitationEmailSent\n  execution {\n    status\n    scheduledAt\n    totalContacts\n  }\n  invitation {\n    id\n    email\n    token\n    status\n    createdAt\n    updatedAt\n    sentAt\n    acceptedAt\n    expiresAt\n  }\n}\n    }\n  }\n";
export declare const UPDATE_BRANCH_MUTATION = "\n  mutation UpdateCampaign($id: ID!, $input: UpdateCampaignInput!) {\n    campaigns {\n      update(id: $id, input: $input) {\n  id\n  name\n  status\n  direction\n  address\n  phone\n  email\n  notes\n  customFields\n  aiEnabled\n  systemPrompt\n  aiConfig\n  contactsCount\n  callLogsCount\n  documentsCount\n  agentsCount\n  lastActivityAt\n  createdAt\n  updatedAt\n  invitationEmailSent\n  execution {\n    status\n    scheduledAt\n    totalContacts\n  }\n  invitation {\n    id\n    email\n    token\n    status\n    createdAt\n    updatedAt\n    sentAt\n    acceptedAt\n    expiresAt\n  }\n}\n    }\n  }\n";
export declare const UPDATE_BRANCH_AI_MUTATION = "\n  mutation UpdateCampaignAi($id: ID!, $input: UpdateCampaignAiInput!) {\n    campaigns {\n      updateAi(id: $id, input: $input) {\n  id\n  name\n  status\n  direction\n  address\n  phone\n  email\n  notes\n  customFields\n  aiEnabled\n  systemPrompt\n  aiConfig\n  contactsCount\n  callLogsCount\n  documentsCount\n  agentsCount\n  lastActivityAt\n  createdAt\n  updatedAt\n  invitationEmailSent\n  execution {\n    status\n    scheduledAt\n    totalContacts\n  }\n  invitation {\n    id\n    email\n    token\n    status\n    createdAt\n    updatedAt\n    sentAt\n    acceptedAt\n    expiresAt\n  }\n}\n    }\n  }\n";
export declare const BULK_UPDATE_BRANCHES_MUTATION = "\n  mutation BulkUpdateCampaigns($input: BulkCampaignUpdateInput!) {\n    campaigns {\n      bulkUpdate(input: $input) {\n        updated\n      }\n    }\n  }\n";
export declare const ARCHIVE_BRANCH_MUTATION = "\n  mutation ArchiveCampaign($id: ID!) {\n    campaigns {\n      archive(id: $id) {\n  id\n  name\n  status\n  direction\n  address\n  phone\n  email\n  notes\n  customFields\n  aiEnabled\n  systemPrompt\n  aiConfig\n  contactsCount\n  callLogsCount\n  documentsCount\n  agentsCount\n  lastActivityAt\n  createdAt\n  updatedAt\n  invitationEmailSent\n  execution {\n    status\n    scheduledAt\n    totalContacts\n  }\n  invitation {\n    id\n    email\n    token\n    status\n    createdAt\n    updatedAt\n    sentAt\n    acceptedAt\n    expiresAt\n  }\n}\n    }\n  }\n";
export declare const RESEND_BRANCH_INVITATION_MUTATION = "\n  mutation ResendCampaignInvitation($campaignId: ID!) {\n    campaigns {\n      resendInvitation(campaignId: $campaignId) {\n  id\n  name\n  status\n  direction\n  address\n  phone\n  email\n  notes\n  customFields\n  aiEnabled\n  systemPrompt\n  aiConfig\n  contactsCount\n  callLogsCount\n  documentsCount\n  agentsCount\n  lastActivityAt\n  createdAt\n  updatedAt\n  invitationEmailSent\n  execution {\n    status\n    scheduledAt\n    totalContacts\n  }\n  invitation {\n    id\n    email\n    token\n    status\n    createdAt\n    updatedAt\n    sentAt\n    acceptedAt\n    expiresAt\n  }\n}\n    }\n  }\n";
export declare const CANCEL_BRANCH_INVITATION_MUTATION = "\n  mutation CancelCampaignInvitation($campaignId: ID!) {\n    campaigns {\n      cancelInvitation(campaignId: $campaignId) {\n  id\n  name\n  status\n  direction\n  address\n  phone\n  email\n  notes\n  customFields\n  aiEnabled\n  systemPrompt\n  aiConfig\n  contactsCount\n  callLogsCount\n  documentsCount\n  agentsCount\n  lastActivityAt\n  createdAt\n  updatedAt\n  invitationEmailSent\n  execution {\n    status\n    scheduledAt\n    totalContacts\n  }\n  invitation {\n    id\n    email\n    token\n    status\n    createdAt\n    updatedAt\n    sentAt\n    acceptedAt\n    expiresAt\n  }\n}\n    }\n  }\n";
export declare const GENERATE_NEW_BRANCH_INVITATION_MUTATION = "\n  mutation GenerateNewCampaignInvitation($campaignId: ID!) {\n    campaigns {\n      generateNewInvitation(campaignId: $campaignId) {\n  id\n  name\n  status\n  direction\n  address\n  phone\n  email\n  notes\n  customFields\n  aiEnabled\n  systemPrompt\n  aiConfig\n  contactsCount\n  callLogsCount\n  documentsCount\n  agentsCount\n  lastActivityAt\n  createdAt\n  updatedAt\n  invitationEmailSent\n  execution {\n    status\n    scheduledAt\n    totalContacts\n  }\n  invitation {\n    id\n    email\n    token\n    status\n    createdAt\n    updatedAt\n    sentAt\n    acceptedAt\n    expiresAt\n  }\n}\n    }\n  }\n";
