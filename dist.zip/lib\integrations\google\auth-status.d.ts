import type { TenantContext } from "../../../server/types/context";
export declare function resolveGoogleClerkUserId(ctx: TenantContext): Promise<string | null>;
export declare function isGoogleIntegrationAuthorized(ctx: TenantContext): Promise<boolean>;
export declare function reconcileGoogleIntegrationStatus(ctx: TenantContext): Promise<void>;
export declare function markGoogleIntegrationsConnected(ctx: TenantContext, account: string | null, authSource: "clerk" | "oauth"): Promise<void>;
