export declare function drainCompanyQueue(companyId: string): Promise<void>;
