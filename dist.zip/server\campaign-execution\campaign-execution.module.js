"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CampaignExecutionModule = void 0;
const common_1 = require("@nestjs/common");
const campaign_progress_worker_1 = require("./workers/campaign-progress.worker");
const campaign_runner_worker_1 = require("./workers/campaign-runner.worker");
const campaign_scheduler_worker_1 = require("./workers/campaign-scheduler.worker");
const retry_worker_1 = require("./workers/retry.worker");
let CampaignExecutionModule = class CampaignExecutionModule {
};
exports.CampaignExecutionModule = CampaignExecutionModule;
exports.CampaignExecutionModule = CampaignExecutionModule = __decorate([
    (0, common_1.Module)({
        providers: [
            campaign_scheduler_worker_1.CampaignSchedulerWorker,
            retry_worker_1.RetryWorker,
            campaign_runner_worker_1.CampaignRunnerWorker,
            campaign_progress_worker_1.CampaignProgressWorker,
        ],
    })
], CampaignExecutionModule);
//# sourceMappingURL=campaign-execution.module.js.map