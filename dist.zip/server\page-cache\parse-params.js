"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parsePageCacheParams = parsePageCacheParams;
function parsePageCacheParams(searchParams) {
    const filterRaw = searchParams.get("filter");
    let filter;
    if (filterRaw) {
        try {
            filter = JSON.parse(filterRaw);
        }
        catch {
            filter = undefined;
        }
    }
    return {
        id: searchParams.get("id") ?? undefined,
        slug: searchParams.get("slug") ?? undefined,
        after: searchParams.get("after") ?? undefined,
        filter,
    };
}
//# sourceMappingURL=parse-params.js.map