import { Worker } from "bullmq";
import { CampaignExecutionJobData } from "./campaign-execution.queue";
export declare const campaignExecutionWorker: Worker<CampaignExecutionJobData, any, string, import("bullmq").RedisQueueBackend, import("bullmq").JobProgress> | null;
