"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.retryWorkerService = exports.RetryWorkerService = void 0;
const campaign_execution_repository_1 = require("../campaign-execution.repository");
const retry_logger_1 = require("../lib/retry-logger");
const mapper_1 = require("../../lib/public-id/mapper");
const prisma_1 = __importDefault(require("../../lib/prisma"));
const outbound_calls_service_1 = require("../../services/outbound-calls.service");
const call_status_lifecycle_1 = require("../../telephony/call-status-lifecycle");
const system_tenant_context_1 = require("../lib/system-tenant-context");
const retry_config_1 = require("./retry.config");
const contact_completion_service_1 = require("./contact-completion.service");
const retry_job_repository_1 = require("./retry-job.repository");
const retry_policy_service_1 = require("./retry-policy.service");
class RetryWorkerService {
    async processDueRetries(limit = retry_config_1.retryConfig.processBatchSize) {
        const now = new Date();
        const jobs = await retry_job_repository_1.retryJobRepository.findDuePending(limit, now);
        let processed = 0;
        for (const job of jobs) {
            const didProcess = await this.processJob(job.id);
            if (didProcess) {
                processed += 1;
            }
        }
        return processed;
    }
    async processJob(jobId) {
        const claimed = await retry_job_repository_1.retryJobRepository.claimJob(jobId);
        if (claimed.count === 0) {
            return false;
        }
        const job = await prisma_1.default.contactRetryJob.findUnique({ where: { id: jobId } });
        if (!job) {
            return false;
        }
        const execution = await campaign_execution_repository_1.campaignExecutionRepository.findByCampaignId(job.companyId, job.campaignId);
        const ctx = await (0, system_tenant_context_1.createSystemTenantContext)(job.companyId);
        const campaignPublicId = execution
            ? await (0, mapper_1.toCampaignPublicId)(ctx, execution.campaign.resourceKey)
            : undefined;
        (0, retry_logger_1.logRetryEvent)("retry:started", {
            campaignPublicId,
            phoneNumber: job.phoneNumber,
            retryNumber: job.retryNumber,
            correlationId: job.correlationId ?? undefined,
            parentCallLogId: job.parentCallLogId,
        });
        if (!execution || execution.status !== "RUNNING") {
            await this.skipJob(job, "campaign_not_running", campaignPublicId);
            return true;
        }
        const parentCall = await prisma_1.default.callLog.findFirst({
            where: { id: job.parentCallLogId, companyId: job.companyId },
            select: { status: true, retryNumber: true },
        });
        if (!parentCall || !(0, call_status_lifecycle_1.isTerminalCallStatus)(parentCall.status)) {
            await this.skipJob(job, "parent_call_not_terminal", campaignPublicId);
            return true;
        }
        if (job.createdCallLogId) {
            await this.skipJob(job, "retry_already_executed", campaignPublicId);
            return true;
        }
        const policy = retry_policy_service_1.retryPolicyService.extractPolicy(execution);
        const currentRetryCount = await retry_policy_service_1.retryPolicyService.countRetriesForContact(job.companyId, job.campaignId, job.phoneNumber);
        if (!retry_policy_service_1.retryPolicyService.shouldRetry(policy, job.retryReason, currentRetryCount)) {
            await this.skipJob(job, "retry_no_longer_eligible", campaignPublicId);
            await contact_completion_service_1.contactCompletionService.markContactCompleteIfDone(job.companyId, job.campaignId, job.phoneNumber);
            return true;
        }
        try {
            const result = await outbound_calls_service_1.outboundCallsService.createRetryOutboundCall(ctx, {
                campaignId: campaignPublicId,
                phoneNumber: job.phoneNumber,
                parentCallLogId: job.parentCallLogId,
                retryNumber: job.retryNumber,
                retryReason: job.retryReason,
                correlationId: job.correlationId ?? undefined,
            });
            const createdCallLog = await prisma_1.default.callLog.findFirst({
                where: { companyId: job.companyId, publicId: result.callLogId },
                select: { id: true },
            });
            await retry_job_repository_1.retryJobRepository.completeJob(job.id, {
                createdCallLogId: createdCallLog?.id ?? job.parentCallLogId,
                processedAt: new Date(),
            });
            await retry_job_repository_1.retryJobRepository.incrementExecutionCounters(job.companyId, job.campaignId, {
                pendingRetries: { decrement: 1 },
                completedRetries: { increment: 1 },
            });
            (0, retry_logger_1.logRetryEvent)("retry:completed", {
                campaignPublicId,
                phoneNumber: job.phoneNumber,
                retryNumber: job.retryNumber,
                correlationId: job.correlationId ?? undefined,
                parentCallLogId: job.parentCallLogId,
                createdCallLogId: result.callLogId,
            });
        }
        catch (error) {
            const message = error instanceof Error ? error.message : "Unknown retry error";
            await retry_job_repository_1.retryJobRepository.failJob(job.id, message);
            await retry_job_repository_1.retryJobRepository.incrementExecutionCounters(job.companyId, job.campaignId, {
                pendingRetries: { decrement: 1 },
                failedRetries: { increment: 1 },
            });
            (0, retry_logger_1.logRetryEvent)("retry:failed", {
                campaignPublicId,
                phoneNumber: job.phoneNumber,
                retryNumber: job.retryNumber,
                correlationId: job.correlationId ?? undefined,
                parentCallLogId: job.parentCallLogId,
                error: message,
            });
            await contact_completion_service_1.contactCompletionService.markContactCompleteIfDone(job.companyId, job.campaignId, job.phoneNumber);
        }
        return true;
    }
    async skipJob(job, skipReason, campaignPublicId) {
        await retry_job_repository_1.retryJobRepository.skipJob(job.id, skipReason);
        await retry_job_repository_1.retryJobRepository.incrementExecutionCounters(job.companyId, job.campaignId, {
            pendingRetries: { decrement: 1 },
        });
        (0, retry_logger_1.logRetryEvent)("retry:skipped", {
            campaignPublicId,
            phoneNumber: job.phoneNumber,
            retryNumber: job.retryNumber,
            correlationId: job.correlationId ?? undefined,
            skipReason,
            parentCallLogId: job.parentCallLogId,
        });
    }
}
exports.RetryWorkerService = RetryWorkerService;
exports.retryWorkerService = new RetryWorkerService();
//# sourceMappingURL=retry-worker.service.js.map