"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isRetryableHttpStatus = isRetryableHttpStatus;
exports.isRetryableProviderError = isRetryableProviderError;
const RETRYABLE_HTTP_STATUSES = new Set([408, 429, 500, 502, 503, 504]);
const NON_RETRYABLE_HTTP_STATUSES = new Set([400, 401, 403, 404, 422]);
function isRetryableHttpStatus(httpStatus) {
    if (NON_RETRYABLE_HTTP_STATUSES.has(httpStatus)) {
        return false;
    }
    return RETRYABLE_HTTP_STATUSES.has(httpStatus);
}
function isRetryableProviderError(error) {
    if (error.isNetworkError || error.isTimeout) {
        return true;
    }
    if (error.httpStatus === undefined) {
        return false;
    }
    return isRetryableHttpStatus(error.httpStatus);
}
//# sourceMappingURL=retry-policy.js.map