import type { CallStatus } from "@prisma/client";
export declare function mapProviderStatusToCallStatus(providerStatus: string): CallStatus;
