import type { SupportRequestReason } from "@prisma/client";
export declare const CONTACT_REASON_OPTIONS: {
    value: SupportRequestReason;
    label: string;
}[];
export declare const CONTACT_PLAN_OPTIONS: {
    id: string;
    label: string;
}[];
export declare function getContactPlanLabel(planId: string): string;
export declare function parseContactIntentReason(intent: string | null): SupportRequestReason | null;
export declare function parseContactPlanId(plan: string | null): string | null;
