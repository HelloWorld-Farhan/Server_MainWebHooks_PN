export declare class NotificationService {
    private readonly gasUrl;
    sendSubCompanyCreatedEmail(payload: {
        companyName: string;
        parentCompanyName: string;
        allocatedCredits: number;
        email: string;
    }): Promise<void>;
    sendCreditUpdateEmail(payload: {
        companyName: string;
        amount: number;
        newBalance: number;
        type: "TOP_UP" | "DEDUCTION";
    }): Promise<void>;
    sendCreditZeroWarningEmail(payload: {
        email: string;
        name: string;
    }): Promise<void>;
    sendSubCompanyCreditZeroWarningEmail(payload: {
        email: string;
        companyName: string;
    }): Promise<void>;
}
export declare const notificationService: NotificationService;
