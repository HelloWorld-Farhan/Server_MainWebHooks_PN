import type { ApiKeyEnvironment, ApiKeyStatus, CampaignAccessType, Prisma } from "@prisma/client";
import { BaseRepository } from "./base.repository";
export type ApiKeyFilter = {
    search?: string;
    status?: ApiKeyStatus;
    environment?: ApiKeyEnvironment;
};
declare const apiKeyInclude: {
    campaignAccess: true;
    createdBy: {
        select: {
            id: true;
            email: true;
            firstName: true;
            lastName: true;
        };
    };
};
export type ApiKeyRecord = Prisma.ApiKeyGetPayload<{
    include: typeof apiKeyInclude;
}>;
export declare class ApiKeysRepository extends BaseRepository {
    private notDeleted;
    private buildWhere;
    findConnection(companyId: string, limit: number, after?: string, filter?: ApiKeyFilter): Prisma.PrismaPromise<({
        campaignAccess: {
            id: string;
            createdAt: Date;
            campaignId: string;
            apiKeyId: string;
        }[];
        createdBy: {
            id: string;
            email: string;
            firstName: string | null;
            lastName: string | null;
        };
    } & {
        status: import("@prisma/client").$Enums.ApiKeyStatus;
        keyId: string;
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        expiresAt: Date | null;
        description: string | null;
        environment: import("@prisma/client").$Enums.ApiKeyEnvironment;
        keyPrefix: string;
        hashedSecret: string;
        scopes: string[];
        lastUsedAt: Date | null;
        createdById: string;
        deletedAt: Date | null;
        previousHashedSecret: string | null;
        previousSecretExpiresAt: Date | null;
        rateLimitPerMinute: number | null;
        allowedIpCidrs: string[];
    })[]>;
    count(companyId: string, filter?: ApiKeyFilter): Prisma.PrismaPromise<number>;
    findById(companyId: string, id: string): Prisma.Prisma__ApiKeyClient<({
        campaignAccess: {
            id: string;
            createdAt: Date;
            campaignId: string;
            apiKeyId: string;
        }[];
        createdBy: {
            id: string;
            email: string;
            firstName: string | null;
            lastName: string | null;
        };
    } & {
        status: import("@prisma/client").$Enums.ApiKeyStatus;
        keyId: string;
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        expiresAt: Date | null;
        description: string | null;
        environment: import("@prisma/client").$Enums.ApiKeyEnvironment;
        keyPrefix: string;
        hashedSecret: string;
        scopes: string[];
        lastUsedAt: Date | null;
        createdById: string;
        deletedAt: Date | null;
        previousHashedSecret: string | null;
        previousSecretExpiresAt: Date | null;
        rateLimitPerMinute: number | null;
        allowedIpCidrs: string[];
    }) | null, null, import("@prisma/client/runtime/library").DefaultArgs, Prisma.PrismaClientOptions>;
    findByName(companyId: string, name: string): Prisma.Prisma__ApiKeyClient<{
        status: import("@prisma/client").$Enums.ApiKeyStatus;
        keyId: string;
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        expiresAt: Date | null;
        description: string | null;
        environment: import("@prisma/client").$Enums.ApiKeyEnvironment;
        keyPrefix: string;
        hashedSecret: string;
        scopes: string[];
        lastUsedAt: Date | null;
        createdById: string;
        deletedAt: Date | null;
        previousHashedSecret: string | null;
        previousSecretExpiresAt: Date | null;
        rateLimitPerMinute: number | null;
        allowedIpCidrs: string[];
    } | null, null, import("@prisma/client/runtime/library").DefaultArgs, Prisma.PrismaClientOptions>;
    findByKeyId(keyId: string): Prisma.Prisma__ApiKeyClient<({
        campaignAccess: {
            id: string;
            createdAt: Date;
            campaignId: string;
            apiKeyId: string;
        }[];
    } & {
        status: import("@prisma/client").$Enums.ApiKeyStatus;
        keyId: string;
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        expiresAt: Date | null;
        description: string | null;
        environment: import("@prisma/client").$Enums.ApiKeyEnvironment;
        keyPrefix: string;
        hashedSecret: string;
        scopes: string[];
        lastUsedAt: Date | null;
        createdById: string;
        deletedAt: Date | null;
        previousHashedSecret: string | null;
        previousSecretExpiresAt: Date | null;
        rateLimitPerMinute: number | null;
        allowedIpCidrs: string[];
    }) | null, null, import("@prisma/client/runtime/library").DefaultArgs, Prisma.PrismaClientOptions>;
    create(data: {
        companyId: string;
        name: string;
        description?: string | null;
        keyId: string;
        keyPrefix: string;
        hashedSecret: string;
        environment: ApiKeyEnvironment;
        scopes: string[];
        campaignAccessType: CampaignAccessType;
        campaignIds: string[];
        expiresAt?: Date | null;
        createdById: string;
    }): Prisma.Prisma__ApiKeyClient<{
        campaignAccess: {
            id: string;
            createdAt: Date;
            campaignId: string;
            apiKeyId: string;
        }[];
        createdBy: {
            id: string;
            email: string;
            firstName: string | null;
            lastName: string | null;
        };
    } & {
        status: import("@prisma/client").$Enums.ApiKeyStatus;
        keyId: string;
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        expiresAt: Date | null;
        description: string | null;
        environment: import("@prisma/client").$Enums.ApiKeyEnvironment;
        keyPrefix: string;
        hashedSecret: string;
        scopes: string[];
        lastUsedAt: Date | null;
        createdById: string;
        deletedAt: Date | null;
        previousHashedSecret: string | null;
        previousSecretExpiresAt: Date | null;
        rateLimitPerMinute: number | null;
        allowedIpCidrs: string[];
    }, never, import("@prisma/client/runtime/library").DefaultArgs, Prisma.PrismaClientOptions>;
    update(companyId: string, id: string, data: Prisma.ApiKeyUpdateInput): Promise<ApiKeyRecord | null>;
    replaceBranchAccess(companyId: string, apiKeyId: string, campaignAccessType: CampaignAccessType, campaignIds: string[]): Promise<ApiKeyRecord | null>;
    softDelete(companyId: string, id: string): Prisma.PrismaPromise<Prisma.BatchPayload>;
    createAuditLog(data: {
        companyId: string;
        userId: string | null;
        action: string;
        entityType: string;
        entityId: string;
        changes: Record<string, unknown>;
    }): Prisma.Prisma__AuditLogClient<{
        userAgent: string | null;
        userId: string | null;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        action: string;
        entityType: string;
        entityId: string;
        changes: Prisma.JsonValue;
        ipAddress: string | null;
    }, never, import("@prisma/client/runtime/library").DefaultArgs, Prisma.PrismaClientOptions>;
    findCampaignsByIds(companyId: string, ids: string[]): Promise<never[]> | Prisma.PrismaPromise<{
        status: import("@prisma/client").$Enums.CampaignStatus;
        name: string;
        id: string;
    }[]>;
    findAccessibleCampaigns(companyId: string, campaignIds: string[] | null): Prisma.PrismaPromise<{
        status: import("@prisma/client").$Enums.CampaignStatus;
        name: string;
        id: string;
    }[]>;
}
export {};
