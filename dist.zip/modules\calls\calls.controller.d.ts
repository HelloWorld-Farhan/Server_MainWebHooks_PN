import type { Request, Response } from "express";
export declare class CallsController {
    methodNotAllowed(res: Response): Response<any, Record<string, any>>;
    createOutbound(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    getInboundCalls(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    getRecording(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    getTranscript(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    rescheduleCalls(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
}
