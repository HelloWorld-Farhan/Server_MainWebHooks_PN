"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.incrementChannelMetric = incrementChannelMetric;
exports.recordQueueWaitMs = recordQueueWaitMs;
exports.getChannelMetricsSnapshot = getChannelMetricsSnapshot;
exports.logChannelEvent = logChannelEvent;
const debug_1 = require("../graphql/debug");
const counters = {
    channels_reserved_total: 0,
    channels_released_total: 0,
    calls_queued_total: 0,
    calls_dispatched_from_queue_total: 0,
};
const queueWaitSamples = [];
const MAX_QUEUE_WAIT_SAMPLES = 500;
function incrementChannelMetric(key, amount = 1) {
    counters[key] += amount;
}
function recordQueueWaitMs(ms) {
    queueWaitSamples.push(ms);
    if (queueWaitSamples.length > MAX_QUEUE_WAIT_SAMPLES) {
        queueWaitSamples.shift();
    }
}
function getChannelMetricsSnapshot() {
    const waitCount = queueWaitSamples.length;
    const averageQueueWaitMs = waitCount === 0
        ? 0
        : Math.round(queueWaitSamples.reduce((sum, value) => sum + value, 0) / waitCount);
    return {
        ...counters,
        average_queue_wait_ms: averageQueueWaitMs,
        queue_wait_sample_count: waitCount,
    };
}
function logChannelEvent(label, data) {
    (0, debug_1.gqlDebug)(label, {
        ...data,
        channelMetrics: getChannelMetricsSnapshot(),
    });
}
//# sourceMappingURL=channel-metrics.js.map