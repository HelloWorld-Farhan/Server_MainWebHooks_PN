import type { CallStatus } from "@prisma/client";
export type HandleTerminalCallInput = {
    companyId: string;
    callLogId: string;
    campaignId: string;
    phone?: string;
    mappedStatus: CallStatus;
    correlationId?: string;
};
export declare class RetrySchedulerService {
    handleTerminalCall(input: HandleTerminalCallInput): Promise<void>;
}
export declare const retrySchedulerService: RetrySchedulerService;
