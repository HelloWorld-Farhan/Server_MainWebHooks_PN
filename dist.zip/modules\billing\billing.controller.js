"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BillingController = void 0;
const common_1 = require("@nestjs/common");
const zod_1 = require("zod");
const http_1 = require("../../lib/api/http");
const tenant_context_1 = require("../../lib/api/tenant-context");
const permissions_1 = require("../../lib/permissions");
const errors_1 = require("../../server/lib/errors");
const billing_service_1 = require("../../server/services/billing.service");
const createQuoteSchema = zod_1.z.object({
    channelQty: zod_1.z.number().int().nonnegative(),
    virtualNumberQty: zod_1.z.number().int().nonnegative(),
    expectedMonthlyCalls: zod_1.z.number().int().nonnegative(),
});
let BillingController = class BillingController {
    async getRates(req, res) {
        const result = await (0, tenant_context_1.requireTenantContext)(req);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        try {
            const rates = await billing_service_1.billingService.getRates(result.ctx);
            return res.json({ rates });
        }
        catch (err) {
            if ((0, errors_1.isAppError)(err)) {
                return res.status(err.statusCode).json({ error: err.message });
            }
            return res.status(500).json({ error: "Internal server error" });
        }
    }
    async listQuotes(req, res) {
        const result = await (0, tenant_context_1.requireTenantContext)(req);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        try {
            const quotes = await billing_service_1.billingService.listQuotes(result.ctx);
            return res.json({ quotes });
        }
        catch (err) {
            if ((0, errors_1.isAppError)(err)) {
                return res.status(err.statusCode).json({ error: err.message });
            }
            return res.status(500).json({ error: "Internal server error" });
        }
    }
    async createQuote(req, res) {
        const result = await (0, tenant_context_1.requireTenantPermission)(req, permissions_1.PERMISSIONS.BILLING_WRITE);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        try {
            const body = createQuoteSchema.parse(req.body);
            const quote = await billing_service_1.billingService.createQuote(result.ctx, body);
            return res.status(201).json({ quote });
        }
        catch (err) {
            if (err instanceof zod_1.z.ZodError) {
                return res
                    .status(400)
                    .json({ error: err.issues[0]?.message ?? err.message });
            }
            if ((0, errors_1.isAppError)(err)) {
                return res.status(err.statusCode).json({ error: err.message });
            }
            return res.status(500).json({ error: "Internal server error" });
        }
    }
    async purchaseQuote(req, res, id) {
        const result = await (0, tenant_context_1.requireTenantPermission)(req, permissions_1.PERMISSIONS.BILLING_WRITE);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        try {
            const purchase = await billing_service_1.billingService.purchaseQuote(result.ctx, id);
            return res.json(purchase);
        }
        catch (err) {
            if ((0, errors_1.isAppError)(err)) {
                return res.status(err.statusCode).json({ error: err.message });
            }
            return res.status(500).json({ error: "Internal server error" });
        }
    }
};
exports.BillingController = BillingController;
__decorate([
    (0, common_1.Get)("rates"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], BillingController.prototype, "getRates", null);
__decorate([
    (0, common_1.Get)("quotes"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], BillingController.prototype, "listQuotes", null);
__decorate([
    (0, common_1.Post)("quotes"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], BillingController.prototype, "createQuote", null);
__decorate([
    (0, common_1.Post)("quotes/:id/purchase"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __param(2, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, String]),
    __metadata("design:returntype", Promise)
], BillingController.prototype, "purchaseQuote", null);
exports.BillingController = BillingController = __decorate([
    (0, common_1.Controller)("api/billing")
], BillingController);
//# sourceMappingURL=billing.controller.js.map