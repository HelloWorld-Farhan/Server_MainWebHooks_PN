import { BaseRepository } from "./base.repository";
export declare class SetupConfigRepository extends BaseRepository {
    getSetupConfig(companyId: string): import("@prisma/client").Prisma.Prisma__CompanySetupConfigClient<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        totalChannels: number;
        serviceNumber: string | null;
        ivrTemplateId: string | null;
        pulseTimeSeconds: number;
        deltaSeconds: number;
        agentsAllocated: number;
    } | null, null, import("@prisma/client/runtime/library").DefaultArgs, import("@prisma/client").Prisma.PrismaClientOptions>;
    upsertSetupConfig(companyId: string, data: {
        totalChannels: number;
        pulseTimeSeconds?: number;
        deltaSeconds?: number;
        agentsAllocated?: number;
    }): import("@prisma/client").Prisma.Prisma__CompanySetupConfigClient<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        totalChannels: number;
        serviceNumber: string | null;
        ivrTemplateId: string | null;
        pulseTimeSeconds: number;
        deltaSeconds: number;
        agentsAllocated: number;
    }, never, import("@prisma/client/runtime/library").DefaultArgs, import("@prisma/client").Prisma.PrismaClientOptions>;
    listChannels(companyId: string): import("@prisma/client").Prisma.PrismaPromise<({
        phoneNumber: {
            number: string;
            id: string;
            label: string | null;
        } | null;
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        phoneNumberId: string | null;
        label: string | null;
        channelIndex: number;
    })[]>;
    replaceChannels(companyId: string, channels: {
        channelIndex: number;
        label?: string;
        phoneNumberId?: string;
    }[]): Promise<({
        phoneNumber: {
            number: string;
            id: string;
            label: string | null;
        } | null;
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        phoneNumberId: string | null;
        label: string | null;
        channelIndex: number;
    })[]>;
    getBillingRates(companyId: string): import("@prisma/client").Prisma.Prisma__CompanyBillingRatesClient<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        currency: string;
        pulseTimeSeconds: number;
        costPerChannel: number;
        costPerCredit: number;
        setupOneTimeCost: number;
    } | null, null, import("@prisma/client/runtime/library").DefaultArgs, import("@prisma/client").Prisma.PrismaClientOptions>;
    upsertBillingRates(companyId: string, data: {
        costPerChannel?: number;
        costPerCredit?: number;
        pulseTimeSeconds?: number;
        setupOneTimeCost?: number;
        currency?: string;
    }): import("@prisma/client").Prisma.Prisma__CompanyBillingRatesClient<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        currency: string;
        pulseTimeSeconds: number;
        costPerChannel: number;
        costPerCredit: number;
        setupOneTimeCost: number;
    }, never, import("@prisma/client/runtime/library").DefaultArgs, import("@prisma/client").Prisma.PrismaClientOptions>;
}
