type ClerkAuthEnvironment = {
    NODE_ENV?: string;
    MAIN_WEBSITE_URL?: string;
    CLERK_AUTHORIZED_PARTIES?: string;
};
export declare function getClerkAuthorizedParties(env?: ClerkAuthEnvironment): string[];
export {};
