import { GridFSBucket } from "mongodb";
export declare function getDb(): Promise<import("mongodb").Db>;
export declare function getGridFS(): Promise<GridFSBucket>;
