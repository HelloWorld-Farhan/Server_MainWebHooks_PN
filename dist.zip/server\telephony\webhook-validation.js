"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateWebhookCallLogChain = validateWebhookCallLogChain;
const phone_validation_1 = require("../../lib/phone-validation");
const errors_1 = require("../lib/errors");
const public_id_1 = require("../lib/public-id");
const types_1 = require("../lib/public-id/types");
function validateWebhookCallLogChain(payload, callLog) {
    const callid = payload.callid.trim();
    if (!(0, public_id_1.validatePublicId)(callid, types_1.PublicResourceType.CALL_LOG)) {
        throw new errors_1.ValidationError("Invalid callid public ID format");
    }
    const parsed = (0, public_id_1.parsePublicId)(callid);
    if (!parsed) {
        throw new errors_1.ValidationError("Invalid callid public ID format");
    }
    const entityId = parsed.entityId;
    if (!entityId ||
        (0, public_id_1.inferResourceTypeFromKey)(entityId) !== types_1.PublicResourceType.CALL_LOG) {
        throw new errors_1.ValidationError("callid must reference a call log public ID");
    }
    if (parsed.cli !== callLog.company.cli) {
        throw new errors_1.ValidationError("Webhook company does not match call log company");
    }
    if (!callLog.campaign) {
        throw new errors_1.ValidationError("Call log campaign is missing");
    }
    if (parsed.campaignId !== callLog.campaign.resourceKey) {
        throw new errors_1.ValidationError("Webhook campaign does not match call log campaign");
    }
    if (callLog.campaignId !== callLog.campaign.id) {
        throw new errors_1.ValidationError("Call log campaign relationship is invalid");
    }
    if (!callLog.phoneNumber) {
        throw new errors_1.ValidationError("Call log phone number is missing");
    }
    if (callLog.phoneNumber.companyId !== callLog.companyId) {
        throw new errors_1.ValidationError("Phone number company does not match call log company");
    }
    if (callLog.phoneNumber.campaignId !== callLog.campaignId) {
        throw new errors_1.ValidationError("Phone number campaign does not match call log campaign");
    }
    const normalizedWebhookPhone = (0, phone_validation_1.normalizeE164Phone)(payload.phone);
    if (!normalizedWebhookPhone) {
        throw new errors_1.ValidationError("Invalid phone number in webhook payload");
    }
    if (callLog.phoneNumber.number !== normalizedWebhookPhone) {
        throw new errors_1.ValidationError("Webhook phone number does not match call log phone number");
    }
    const webhookCorrelationId = payload.correlation_id ?? payload.correlationId ?? null;
    if (webhookCorrelationId &&
        callLog.correlationId &&
        webhookCorrelationId !== callLog.correlationId) {
        throw new errors_1.ValidationError("Webhook correlation ID does not match call log correlation ID");
    }
}
//# sourceMappingURL=webhook-validation.js.map