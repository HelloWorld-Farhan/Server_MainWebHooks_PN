"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebhooksController = void 0;
const common_1 = require("@nestjs/common");
const svix_1 = require("svix");
const cache_service_1 = require("../../server/cache/cache.service");
const debug_1 = require("../../server/graphql/debug");
const clerk_config_1 = require("../../server/lib/clerk-config");
const prisma_1 = __importDefault(require("../../server/lib/prisma"));
const resolution_metrics_1 = require("../../server/lib/resolution-metrics");
const clerk_provision_service_1 = require("../../server/services/clerk-provision.service");
let WebhooksController = class WebhooksController {
    async handleClerkWebhook(req, res) {
        if (!(0, clerk_config_1.isClerkWebhooksEnabled)()) {
            return res.json({
                received: true,
                skipped: true,
                reason: "Clerk webhooks disabled; use direct API provisioning in dev",
            });
        }
        const webhookSecret = process.env.CLERK_WEBHOOK_SECRET;
        if (!webhookSecret) {
            return res.status(500).json({
                error: "CLERK_WEBHOOKS_ENABLED is true but CLERK_WEBHOOK_SECRET is missing",
            });
        }
        const svixId = req.headers["svix-id"];
        const svixTimestamp = req.headers["svix-timestamp"];
        const svixSignature = req.headers["svix-signature"];
        if (!svixId || !svixTimestamp || !svixSignature) {
            return res.status(400).json({ error: "Missing svix headers" });
        }
        const payload = Buffer.isBuffer(req.body)
            ? req.body.toString("utf8")
            : typeof req.body === "string"
                ? req.body
                : JSON.stringify(req.body ?? {});
        const wh = new svix_1.Webhook(webhookSecret);
        let event;
        try {
            event = wh.verify(payload, {
                "svix-id": svixId,
                "svix-timestamp": svixTimestamp,
                "svix-signature": svixSignature,
            });
        }
        catch {
            return res.status(400).json({ error: "Invalid signature" });
        }
        const start = performance.now();
        try {
            await (0, clerk_provision_service_1.handleClerkWebhookEvent)(event.type, event.data);
        }
        catch (error) {
            (0, debug_1.gqlLogError)("clerk:webhook:handler-failed", error, { type: event.type });
            return res.status(500).json({ error: "Webhook handler failed" });
        }
        const durationMs = Math.round(performance.now() - start);
        if (event.type === "organizationMembership.created" ||
            event.type === "organizationMembership.updated" ||
            event.type === "organizationMembership.deleted") {
            const clerkUserId = event.data.public_user_data
                ? event.data.public_user_data.user_id
                : event.data.user_id;
            const orgId = event.data.organization_id;
            if (clerkUserId) {
                await cache_service_1.cacheService.invalidateClerkMembershipCaches(clerkUserId, orgId);
                const user = await prisma_1.default.user.findUnique({
                    where: { clerkUserId },
                });
                if (user) {
                    await cache_service_1.cacheService.invalidateUserPermissions(user.id);
                }
            }
            (0, resolution_metrics_1.logResolutionEvent)("clerk:webhook:membership", {
                type: event.type,
                clerkUserId,
                orgId,
                durationMs,
            });
        }
        else {
            (0, debug_1.gqlDebug)("clerk:webhook:processed", { type: event.type, durationMs });
        }
        return res.json({ received: true });
    }
};
exports.WebhooksController = WebhooksController;
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], WebhooksController.prototype, "handleClerkWebhook", null);
exports.WebhooksController = WebhooksController = __decorate([
    (0, common_1.Controller)("api/webhooks/clerk")
], WebhooksController);
//# sourceMappingURL=webhooks.controller.js.map