import type { PrismaClient } from "@prisma/client";
import { Prisma } from "@prisma/client";
import { BaseRepository } from "./base.repository";
export declare class CallLogProviderEventsRepository extends BaseRepository {
    findExisting(callLogId: string, providerEventId: string): Prisma.Prisma__CallLogProviderEventClient<{
        id: string;
    } | null, null, import("@prisma/client/runtime/library").DefaultArgs, Prisma.PrismaClientOptions>;
    tryInsert(data: {
        callLogId: string;
        providerEventId: string;
        correlationId?: string;
    }): Promise<boolean>;
}
export declare function createCallLogProviderEventsRepository(prisma: PrismaClient): CallLogProviderEventsRepository;
