export declare function getAppOrigin(): string;
export declare function getInviteAcceptRedirectUrl(): string;
export declare function getCampaignInviteRedirectUrl(token: string): string;
