import { type ParsedPhoneImport, type ParsePhonesOptions } from "./contact-phone-import";
export declare const SERVER_PARSE_EXTENSIONS: readonly [".xlsx", ".xls", ".pdf", ".docx"];
export declare function normalizePhoneCandidate(raw: string, defaultCountry?: string): string | null;
export declare function parsePhonesFromText(text: string, defaultCountry?: string): ParsedPhoneImport;
export declare function parsePhonesFromExcel(buffer: Buffer, options?: ParsePhonesOptions): ParsedPhoneImport;
export declare function parsePhonesFromPdf(buffer: Buffer, defaultCountry?: string): Promise<ParsedPhoneImport>;
export declare function parsePhonesFromDocx(buffer: Buffer, defaultCountry?: string): Promise<ParsedPhoneImport>;
export declare function parseContactPhoneUpload(buffer: Buffer, filename: string, options?: ParsePhonesOptions): Promise<ParsedPhoneImport>;
export declare function hasPhoneColumn(headers: string[]): boolean;
