import { Worker } from "bullmq";
import { DelayedCallJobData } from "./delayed-calls.queue";
export declare const delayedCallsWorker: Worker<DelayedCallJobData, any, string, import("bullmq").RedisQueueBackend, import("bullmq").JobProgress> | null;
