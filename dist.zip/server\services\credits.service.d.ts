import type { TenantContext } from "../types/context";
export declare class CreditsService {
    private readonly repo;
    getSummary(ctx: TenantContext): Promise<{
        remaining: number;
        used: number;
        total: number;
        availablePercent: number;
        renewalAt: string | null;
        planId: string | null;
    }>;
    getUsageHistory(ctx: TenantContext, args: {
        first?: number;
        after?: string;
    }): Promise<import("../lib/pagination").Connection<{
        reason: import("@prisma/client").$Enums.CreditUsageReason;
        id: string;
        createdAt: Date;
        companyId: string;
        description: string | null;
        callLogId: string | null;
        metadata: import("@prisma/client/runtime/library").JsonValue;
        amount: number;
    }>>;
    debitForCall(ctx: TenantContext, callLogId: string, amount: number, description?: string): Promise<{
        reason: import("@prisma/client").$Enums.CreditUsageReason;
        id: string;
        createdAt: Date;
        companyId: string;
        description: string | null;
        callLogId: string | null;
        metadata: import("@prisma/client/runtime/library").JsonValue;
        amount: number;
    }>;
    adjustCredits(ctx: TenantContext, amount: number, description: string): Promise<{
        reason: import("@prisma/client").$Enums.CreditUsageReason;
        id: string;
        createdAt: Date;
        companyId: string;
        description: string | null;
        callLogId: string | null;
        metadata: import("@prisma/client/runtime/library").JsonValue;
        amount: number;
    }>;
}
export declare const creditsService: CreditsService;
