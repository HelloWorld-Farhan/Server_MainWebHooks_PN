"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmployeesRepository = void 0;
const base_repository_1 = require("./base.repository");
const pagination_1 = require("../lib/pagination");
const memberInclude = {
    user: true,
    customRole: true,
    campaignAccess: {
        include: { campaign: true },
    },
};
class EmployeesRepository extends base_repository_1.BaseRepository {
    buildWhere(companyId, filter) {
        const where = {
            companyId,
            status: { not: "REMOVED" },
        };
        if (filter?.role) {
            where.role = filter.role;
        }
        if (filter?.status) {
            where.status = filter.status;
        }
        if (filter?.campaignId) {
            where.OR = [
                { campaignAccessType: "ALL" },
                {
                    campaignAccess: {
                        some: { campaignId: filter.campaignId },
                    },
                },
            ];
        }
        const search = filter?.search?.trim();
        if (search) {
            where.user = {
                OR: [
                    { email: { contains: search, mode: "insensitive" } },
                    { firstName: { contains: search, mode: "insensitive" } },
                    { lastName: { contains: search, mode: "insensitive" } },
                    { phone: { contains: search, mode: "insensitive" } },
                ],
            };
        }
        return where;
    }
    async attachLatestInvitations(companyId, rows) {
        if (rows.length === 0)
            return [];
        const emails = [...new Set(rows.map((row) => row.user.email.toLowerCase()))];
        const invitations = await this.prisma.invitation.findMany({
            where: {
                companyId,
                email: { in: emails, mode: "insensitive" },
            },
            orderBy: { createdAt: "desc" },
            select: {
                id: true,
                email: true,
                status: true,
                expiresAt: true,
                clerkInvitationId: true,
                clerkOrganizationId: true,
            },
        });
        const latestByEmail = new Map();
        for (const invitation of invitations) {
            const key = invitation.email.toLowerCase();
            if (!latestByEmail.has(key)) {
                latestByEmail.set(key, invitation);
            }
        }
        return rows.map((row) => ({
            ...row,
            latestInvitation: latestByEmail.get(row.user.email.toLowerCase()) ?? null,
        }));
    }
    async findConnection(companyId, limit, after, filter, scope) {
        const cursor = after ? (0, pagination_1.decodeIdCursor)(after) : undefined;
        const baseWhere = this.buildWhere(companyId, filter);
        const where = scope ? { AND: [baseWhere, scope] } : baseWhere;
        const rows = await this.prisma.companyMember.findMany({
            where,
            include: memberInclude,
            orderBy: [{ createdAt: "desc" }, { id: "desc" }],
            take: limit + 1,
            ...(cursor
                ? {
                    cursor: { id: cursor.id },
                    skip: 1,
                }
                : {}),
        });
        return this.attachLatestInvitations(companyId, rows);
    }
    count(companyId, filter, scope) {
        const baseWhere = this.buildWhere(companyId, filter);
        const where = scope ? { AND: [baseWhere, scope] } : baseWhere;
        return this.prisma.companyMember.count({
            where,
        });
    }
    async findById(companyId, memberId) {
        const row = await this.prisma.companyMember.findFirst({
            where: { id: memberId, companyId, status: { not: "REMOVED" } },
            include: memberInclude,
        });
        if (!row)
            return null;
        const [withInvitation] = await this.attachLatestInvitations(companyId, [row]);
        return withInvitation;
    }
    findByEmail(companyId, email) {
        return this.prisma.companyMember.findFirst({
            where: {
                companyId,
                status: { not: "REMOVED" },
                user: { email: { equals: email, mode: "insensitive" } },
            },
            include: memberInclude,
        });
    }
    countActiveOwners(companyId, excludeMemberId) {
        return this.prisma.companyMember.count({
            where: {
                companyId,
                role: "OWNER",
                status: "ACTIVE",
                ...(excludeMemberId ? { id: { not: excludeMemberId } } : {}),
            },
        });
    }
    async setCampaignAccess(memberId, campaignIds) {
        await this.prisma.memberCampaignAccess.deleteMany({
            where: { memberId },
        });
        if (campaignIds.length === 0)
            return;
        await this.prisma.memberCampaignAccess.createMany({
            data: campaignIds.map((campaignId) => ({ memberId, campaignId })),
        });
    }
    async updateMember(companyId, memberId, data) {
        const existing = await this.prisma.companyMember.findFirst({
            where: { id: memberId, companyId },
        });
        if (!existing) {
            throw new Error("Employee not found");
        }
        return this.prisma.companyMember.update({
            where: { id: memberId },
            data,
            include: memberInclude,
        });
    }
    createInvitation(data) {
        return this.prisma.invitation.create({ data });
    }
    findLatestInvitationByEmail(companyId, email) {
        return this.prisma.invitation.findFirst({
            where: {
                companyId,
                email: { equals: email, mode: "insensitive" },
            },
            orderBy: { createdAt: "desc" },
        });
    }
    findPendingInvitation(companyId, email) {
        return this.prisma.invitation.findFirst({
            where: {
                companyId,
                email: { equals: email, mode: "insensitive" },
                status: "PENDING",
            },
            orderBy: { createdAt: "desc" },
        });
    }
    updateInvitation(id, data) {
        return this.prisma.invitation.update({
            where: { id },
            data,
        });
    }
    updateInvitationStatus(id, status) {
        return this.prisma.invitation.update({
            where: { id },
            data: { status },
        });
    }
    revokePendingInvitation(companyId, email) {
        return this.prisma.invitation.updateMany({
            where: {
                companyId,
                email: { equals: email, mode: "insensitive" },
                status: "PENDING",
            },
            data: { status: "REVOKED" },
        });
    }
    markInvitationAccepted(companyId, email) {
        return this.prisma.invitation.updateMany({
            where: {
                companyId,
                email: { equals: email, mode: "insensitive" },
                status: "PENDING",
            },
            data: { status: "ACCEPTED" },
        });
    }
    validateCampaignIds(companyId, campaignIds) {
        if (campaignIds.length === 0)
            return Promise.resolve([]);
        return this.prisma.campaign.findMany({
            where: { companyId, id: { in: campaignIds } },
            select: { id: true },
        });
    }
}
exports.EmployeesRepository = EmployeesRepository;
//# sourceMappingURL=employees.repository.js.map