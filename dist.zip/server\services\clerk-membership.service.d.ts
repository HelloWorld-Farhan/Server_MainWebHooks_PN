export type ClerkMembershipSnapshot = {
    role: string;
    organization: {
        id: string;
        name: string;
    };
    publicMetadata?: Record<string, unknown>;
    publicUserData?: {
        userId: string;
        identifier?: string;
    } | null;
};
export type ClerkMembershipList = {
    data: ClerkMembershipSnapshot[];
    totalCount: number;
};
export declare class ClerkMembershipService {
    getUserMemberships(clerkUserId: string): Promise<ClerkMembershipList>;
    private refreshUserMemberships;
    getOrgMemberships(orgId: string): Promise<ClerkMembershipList>;
    private refreshOrgMemberships;
    getMembershipInOrg(clerkUserId: string, clerkOrganizationId: string): Promise<ClerkMembershipSnapshot | null>;
    isOrganizationMember(organizationId: string, userId: string): Promise<boolean>;
    invalidateUser(clerkUserId: string): Promise<void>;
    invalidateOrg(orgId: string): Promise<void>;
}
export declare const clerkMembershipService: ClerkMembershipService;
