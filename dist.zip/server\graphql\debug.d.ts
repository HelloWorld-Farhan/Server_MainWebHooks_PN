export declare function gqlDebug(label: string, data?: Record<string, unknown>): void;
export declare function gqlLogError(label: string, error: unknown, data?: Record<string, unknown>): void;
export declare function gqlDebugTimed<T>(label: string, fn: () => Promise<T>): Promise<T>;
