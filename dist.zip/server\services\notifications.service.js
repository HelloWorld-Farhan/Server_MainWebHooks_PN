"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.schedulerService = exports.integrationsService = exports.notificationsService = exports.SchedulerService = exports.IntegrationsService = exports.NotificationsService = void 0;
const pagination_1 = require("../lib/pagination");
const prisma_1 = __importDefault(require("../lib/prisma"));
const notifications_repository_1 = require("../repositories/notifications.repository");
const permissions_1 = require("../types/permissions");
const campaign_access_service_1 = require("./campaign-access.service");
const tenant_service_1 = require("./tenant.service");
class NotificationsService {
    repo = new notifications_repository_1.NotificationsRepository(prisma_1.default);
    async list(ctx, args) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.NOTIFICATIONS_READ);
        const limit = Math.min(args.first ?? 20, 100);
        const items = await this.repo.listForUser(ctx.companyId, ctx.userId, limit, args.after);
        return (0, pagination_1.buildConnection)(items, limit, (item) => (0, pagination_1.encodeIdCursor)(item.id, item.createdAt));
    }
}
exports.NotificationsService = NotificationsService;
class IntegrationsService {
    repo = new notifications_repository_1.IntegrationsRepository(prisma_1.default);
    async list(ctx) {
        if (ctx.campaignAccess.type === "SELECTED") {
            return [];
        }
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.INTEGRATIONS_READ);
        return this.repo.findAll(ctx.companyId);
    }
}
exports.IntegrationsService = IntegrationsService;
class SchedulerService {
    repo = new notifications_repository_1.SchedulerRepository(prisma_1.default);
    async listUpcoming(ctx, limit = 20) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.SCHEDULER_READ);
        const leadBranchIds = campaign_access_service_1.campaignAccessService.hasAllCampaignAccess(ctx)
            ? undefined
            : ctx.campaignAccess.campaignIds;
        return this.repo.listUpcoming(ctx.companyId, Math.min(limit, 50), leadBranchIds);
    }
}
exports.SchedulerService = SchedulerService;
exports.notificationsService = new NotificationsService();
exports.integrationsService = new IntegrationsService();
exports.schedulerService = new SchedulerService();
//# sourceMappingURL=notifications.service.js.map