"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.campaignExecutionService = exports.CampaignExecutionService = void 0;
const crypto_1 = require("crypto");
const errors_1 = require("../lib/errors");
const mapper_1 = require("../lib/public-id/mapper");
const types_1 = require("../lib/public-id/types");
const prisma_1 = __importDefault(require("../lib/prisma"));
const campaign_execution_config_1 = require("./campaign-execution.config");
const campaign_execution_lock_service_1 = require("./campaign-execution-lock.service");
const campaign_execution_repository_1 = require("./campaign-execution.repository");
const retry_job_repository_1 = require("./retry/retry-job.repository");
const retry_statistics_service_1 = require("./retry/retry-statistics.service");
const campaign_execution_logger_1 = require("./lib/campaign-execution-logger");
const system_tenant_context_1 = require("./lib/system-tenant-context");
const campaigns_repository_1 = require("../repositories/campaigns.repository");
const campaign_access_service_1 = require("../services/campaign-access.service");
const tenant_service_1 = require("../services/tenant.service");
const permissions_1 = require("../types/permissions");
function mapExecution(row, campaignPublicId) {
    return {
        id: row.id,
        campaignId: campaignPublicId,
        status: row.status,
        scheduledAt: row.scheduledAt?.toISOString() ?? null,
        startedAt: row.startedAt?.toISOString() ?? null,
        pausedAt: row.pausedAt?.toISOString() ?? null,
        completedAt: row.completedAt?.toISOString() ?? null,
        failedAt: row.failedAt?.toISOString() ?? null,
        cancelledAt: row.cancelledAt?.toISOString() ?? null,
        processedCount: row.processedCount,
        totalContacts: row.totalContacts,
        correlationId: row.correlationId,
        failureReason: row.failureReason,
        estimatedCompletionAt: row.estimatedCompletionAt?.toISOString() ?? null,
        createdAt: row.createdAt.toISOString(),
        updatedAt: row.updatedAt.toISOString(),
    };
}
class CampaignExecutionService {
    campaignsRepo = new campaigns_repository_1.CampaignsRepository(prisma_1.default);
    async resolveCampaign(ctx, campaignPublicId) {
        const internalId = await (0, mapper_1.resolveResourceId)(ctx, campaignPublicId, types_1.PublicResourceType.CAMPAIGN);
        const campaign = await prisma_1.default.campaign.findFirst({
            where: { id: internalId, companyId: ctx.companyId },
            select: { id: true, resourceKey: true },
        });
        if (!campaign) {
            throw new errors_1.NotFoundError("Campaign not found");
        }
        campaign_access_service_1.campaignAccessService.assertCampaignAccess(ctx, campaign.id);
        const publicId = await (0, mapper_1.toCampaignPublicId)(ctx, campaign.resourceKey);
        return {
            internalId: campaign.id,
            publicId,
            resourceKey: campaign.resourceKey,
        };
    }
    async getOrCreateExecution(companyId, campaignId, correlationId) {
        const existing = await campaign_execution_repository_1.campaignExecutionRepository.findByCampaignId(companyId, campaignId);
        if (existing) {
            return existing;
        }
        return campaign_execution_repository_1.campaignExecutionRepository.createDraft(companyId, campaignId, correlationId ?? (0, crypto_1.randomUUID)());
    }
    async loadExecutionView(ctx, campaignPublicId) {
        const campaign = await this.resolveCampaign(ctx, campaignPublicId);
        const row = await this.getOrCreateExecution(ctx.companyId, campaign.internalId);
        return mapExecution(row, campaign.publicId);
    }
    async writeActivity(companyId, campaignId, type, summary, actorId, metadata) {
        await this.campaignsRepo.createActivity(companyId, campaignId, {
            type,
            summary,
            actorId,
            metadata,
        });
    }
    async getStatus(ctx, campaignPublicId) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_READ);
        return this.loadExecutionView(ctx, campaignPublicId);
    }
    async getStatistics(ctx, campaignPublicId) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_READ);
        const campaign = await this.resolveCampaign(ctx, campaignPublicId);
        const row = await campaign_execution_repository_1.campaignExecutionRepository.findByCampaignId(ctx.companyId, campaign.internalId);
        if (!row) {
            const totalContacts = await this.campaignsRepo.countContacts(ctx.companyId, campaign.internalId);
            return {
                totalContacts,
                processed: 0,
                pending: totalContacts,
                queued: 0,
                dialing: 0,
                answered: 0,
                busy: 0,
                noAnswer: 0,
                failed: 0,
                completed: 0,
                completedContacts: 0,
                initialCalls: 0,
                retryCalls: 0,
                pendingRetries: 0,
                totalRetries: 0,
                retrySuccessRate: 0,
                averageRetryCount: 0,
            };
        }
        const retryStats = await retry_statistics_service_1.retryStatisticsService.getStatistics(ctx.companyId, campaign.internalId);
        return {
            totalContacts: row.totalContacts,
            processed: row.processedCount,
            pending: Math.max(row.totalContacts - row.completedContactsCount, 0),
            queued: row.statsQueued,
            dialing: row.statsDialing,
            answered: row.statsAnswered,
            busy: row.statsBusy,
            noAnswer: row.statsNoAnswer,
            failed: row.statsFailed,
            completed: row.statsCompleted,
            completedContacts: row.completedContactsCount,
            initialCalls: retryStats.initialCalls,
            retryCalls: retryStats.retryCalls,
            pendingRetries: retryStats.pendingRetries,
            totalRetries: row.totalRetries,
            retrySuccessRate: retryStats.retrySuccessRate,
            averageRetryCount: retryStats.averageRetryCount,
        };
    }
    async getProgress(ctx, campaignPublicId) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_READ);
        const campaign = await this.resolveCampaign(ctx, campaignPublicId);
        const row = await campaign_execution_repository_1.campaignExecutionRepository.findByCampaignId(ctx.companyId, campaign.internalId);
        const totalContacts = row?.totalContacts ??
            (await this.campaignsRepo.countContacts(ctx.companyId, campaign.internalId));
        const processedCount = row?.processedCount ?? 0;
        const percentComplete = totalContacts > 0
            ? Math.min(100, Math.round(((row?.completedContactsCount ?? 0) / totalContacts) * 100))
            : 0;
        return {
            processedCount: row?.completedContactsCount ?? 0,
            totalContacts,
            percentComplete,
            estimatedCompletionAt: row?.estimatedCompletionAt?.toISOString() ?? null,
        };
    }
    async schedule(ctx, campaignPublicId, scheduledAtInput) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_WRITE);
        const campaign = await this.resolveCampaign(ctx, campaignPublicId);
        const scheduledAt = new Date(scheduledAtInput);
        if (Number.isNaN(scheduledAt.getTime())) {
            throw new errors_1.ValidationError("Invalid scheduledAt value");
        }
        await this.getOrCreateExecution(ctx.companyId, campaign.internalId);
        const result = await campaign_execution_repository_1.campaignExecutionRepository.transitionStatus(ctx.companyId, campaign.internalId, ["DRAFT", "SCHEDULED"], {
            status: "SCHEDULED",
            scheduledAt,
            pausedAt: null,
            failureReason: null,
        });
        if (result.count === 0) {
            throw new errors_1.ValidationError("Campaign cannot be scheduled from its current state");
        }
        (0, campaign_execution_logger_1.logCampaignExecutionEvent)("campaign:scheduled", {
            campaignPublicId: campaign.publicId,
            scheduledAt: scheduledAt.toISOString(),
        });
        await this.writeActivity(ctx.companyId, campaign.internalId, "CAMPAIGN_EXECUTION_SCHEDULED", `Campaign scheduled for ${scheduledAt.toISOString()}`, ctx.userId, { scheduledAt: scheduledAt.toISOString() });
        return this.loadExecutionView(ctx, campaignPublicId);
    }
    async start(ctx, campaignPublicId, scheduledAtInput) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_WRITE);
        const campaign = await this.resolveCampaign(ctx, campaignPublicId);
        if (scheduledAtInput) {
            const scheduledAt = new Date(scheduledAtInput);
            if (Number.isNaN(scheduledAt.getTime())) {
                throw new errors_1.ValidationError("Invalid scheduledAt value");
            }
            if (scheduledAt.getTime() > Date.now()) {
                return this.schedule(ctx, campaignPublicId, scheduledAtInput);
            }
        }
        const correlationId = (0, crypto_1.randomUUID)();
        await this.getOrCreateExecution(ctx.companyId, campaign.internalId, correlationId);
        const totalContacts = await this.campaignsRepo.countContacts(ctx.companyId, campaign.internalId);
        const now = new Date();
        const lockExpiresAt = new Date(now.getTime() + campaign_execution_config_1.campaignExecutionConfig.lockTtlMs);
        const result = await campaign_execution_repository_1.campaignExecutionRepository.transitionStatus(ctx.companyId, campaign.internalId, ["DRAFT", "SCHEDULED", "PAUSED"], {
            status: "RUNNING",
            startedAt: now,
            scheduledAt: null,
            pausedAt: null,
            completedAt: null,
            failedAt: null,
            cancelledAt: null,
            failureReason: null,
            correlationId,
            totalContacts,
            workerId: campaign_execution_config_1.campaignExecutionConfig.workerId,
            lockExpiresAt,
        });
        if (result.count === 0) {
            const current = await campaign_execution_repository_1.campaignExecutionRepository.findByCampaignId(ctx.companyId, campaign.internalId);
            if (current?.status === "RUNNING") {
                return mapExecution(current, campaign.publicId);
            }
            throw new errors_1.ValidationError("Campaign cannot be started from its current state");
        }
        (0, campaign_execution_logger_1.logCampaignExecutionEvent)("campaign:started", {
            campaignPublicId: campaign.publicId,
            correlationId,
            totalContacts,
        });
        await this.writeActivity(ctx.companyId, campaign.internalId, "CAMPAIGN_EXECUTION_STARTED", "Campaign execution started", ctx.userId, { correlationId, totalContacts });
        return this.loadExecutionView(ctx, campaignPublicId);
    }
    async pause(ctx, campaignPublicId) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_WRITE);
        const campaign = await this.resolveCampaign(ctx, campaignPublicId);
        const now = new Date();
        const result = await campaign_execution_repository_1.campaignExecutionRepository.transitionStatus(ctx.companyId, campaign.internalId, ["RUNNING"], {
            status: "PAUSED",
            pausedAt: now,
        });
        if (result.count === 0) {
            throw new errors_1.ValidationError("Campaign is not running");
        }
        await campaign_execution_lock_service_1.campaignExecutionLockService.release(campaign.internalId, campaign_execution_config_1.campaignExecutionConfig.workerId);
        (0, campaign_execution_logger_1.logCampaignExecutionEvent)("campaign:paused", {
            campaignPublicId: campaign.publicId,
        });
        await this.writeActivity(ctx.companyId, campaign.internalId, "CAMPAIGN_EXECUTION_PAUSED", "Campaign execution paused", ctx.userId);
        return this.loadExecutionView(ctx, campaignPublicId);
    }
    async resume(ctx, campaignPublicId) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_WRITE);
        const campaign = await this.resolveCampaign(ctx, campaignPublicId);
        const now = new Date();
        const lockExpiresAt = new Date(now.getTime() + campaign_execution_config_1.campaignExecutionConfig.lockTtlMs);
        const totalContacts = await this.campaignsRepo.countContacts(ctx.companyId, campaign.internalId);
        const result = await campaign_execution_repository_1.campaignExecutionRepository.transitionStatus(ctx.companyId, campaign.internalId, ["PAUSED"], {
            status: "RUNNING",
            pausedAt: null,
            workerId: campaign_execution_config_1.campaignExecutionConfig.workerId,
            lockExpiresAt,
            totalContacts,
            lastProcessedContactId: null,
            processedCount: 0,
        });
        if (result.count === 0) {
            throw new errors_1.ValidationError("Campaign is not paused");
        }
        (0, campaign_execution_logger_1.logCampaignExecutionEvent)("campaign:resumed", {
            campaignPublicId: campaign.publicId,
            totalContacts,
        });
        await this.writeActivity(ctx.companyId, campaign.internalId, "CAMPAIGN_EXECUTION_RESUMED", "Campaign execution resumed", ctx.userId, { totalContacts });
        return this.loadExecutionView(ctx, campaignPublicId);
    }
    async reset(ctx, campaignPublicId) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_WRITE);
        const campaign = await this.resolveCampaign(ctx, campaignPublicId);
        const totalContacts = await this.campaignsRepo.countContacts(ctx.companyId, campaign.internalId);
        if (totalContacts === 0) {
            throw new errors_1.ValidationError("Upload contacts before resetting the campaign.");
        }
        const existing = await campaign_execution_repository_1.campaignExecutionRepository.findByCampaignId(ctx.companyId, campaign.internalId);
        if (!existing) {
            throw new errors_1.ValidationError("Campaign has not been started yet");
        }
        if (existing.status === "DRAFT" || existing.status === "SCHEDULED") {
            throw new errors_1.ValidationError("Campaign has not started yet — use Start instead");
        }
        const correlationId = (0, crypto_1.randomUUID)();
        const now = new Date();
        const lockExpiresAt = new Date(now.getTime() + campaign_execution_config_1.campaignExecutionConfig.lockTtlMs);
        await prisma_1.default.callLog.updateMany({
            where: {
                companyId: ctx.companyId,
                campaignId: campaign.internalId,
                status: {
                    in: [
                        "PENDING",
                        "QUEUED",
                        "DISPATCHING",
                        "QUEUED_AT_PROVIDER",
                        "RINGING",
                        "ANSWERED",
                    ],
                },
            },
            data: {
                status: "CANCELLED",
                endedAt: now,
                disconnectReason: "Campaign execution reset",
                providerCompletedAt: now,
            },
        });
        const cancelledJobs = await retry_job_repository_1.retryJobRepository.cancelPendingForCampaign(ctx.companyId, campaign.internalId);
        const result = await campaign_execution_repository_1.campaignExecutionRepository.transitionStatus(ctx.companyId, campaign.internalId, ["RUNNING", "PAUSED", "COMPLETED", "FAILED", "CANCELLED"], {
            status: "RUNNING",
            startedAt: now,
            scheduledAt: null,
            pausedAt: null,
            completedAt: null,
            failedAt: null,
            cancelledAt: null,
            failureReason: null,
            correlationId,
            totalContacts,
            lastProcessedContactId: null,
            processedCount: 0,
            completedContactsCount: 0,
            pendingRetries: 0,
            workerId: campaign_execution_config_1.campaignExecutionConfig.workerId,
            lockExpiresAt,
        });
        if (result.count === 0) {
            throw new errors_1.ValidationError("Campaign cannot be reset from its current state");
        }
        await campaign_execution_lock_service_1.campaignExecutionLockService.release(campaign.internalId, campaign_execution_config_1.campaignExecutionConfig.workerId);
        (0, campaign_execution_logger_1.logCampaignExecutionEvent)("campaign:reset", {
            campaignPublicId: campaign.publicId,
            correlationId,
            totalContacts,
            cancelledRetryJobs: cancelledJobs.count,
        });
        await this.writeActivity(ctx.companyId, campaign.internalId, "CAMPAIGN_EXECUTION_RESET", "Campaign execution reset — dialing restarted", ctx.userId, { correlationId, totalContacts });
        return this.loadExecutionView(ctx, campaignPublicId);
    }
    async retry(ctx, campaignPublicId) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_WRITE);
        const campaign = await this.resolveCampaign(ctx, campaignPublicId);
        const totalContacts = await this.campaignsRepo.countContacts(ctx.companyId, campaign.internalId);
        if (totalContacts === 0) {
            throw new errors_1.ValidationError("Upload contacts before retrying the campaign.");
        }
        const correlationId = (0, crypto_1.randomUUID)();
        const now = new Date();
        const lockExpiresAt = new Date(now.getTime() + campaign_execution_config_1.campaignExecutionConfig.lockTtlMs);
        const result = await campaign_execution_repository_1.campaignExecutionRepository.transitionStatus(ctx.companyId, campaign.internalId, ["FAILED"], {
            status: "RUNNING",
            failedAt: null,
            failureReason: null,
            correlationId,
            totalContacts,
            workerId: campaign_execution_config_1.campaignExecutionConfig.workerId,
            lockExpiresAt,
        });
        if (result.count === 0) {
            throw new errors_1.ValidationError("Campaign is not in a failed state");
        }
        (0, campaign_execution_logger_1.logCampaignExecutionEvent)("campaign:retried", {
            campaignPublicId: campaign.publicId,
            correlationId,
            totalContacts,
        });
        await this.writeActivity(ctx.companyId, campaign.internalId, "CAMPAIGN_EXECUTION_RETRIED", "Campaign execution retried after failure", ctx.userId, { correlationId, totalContacts });
        return this.loadExecutionView(ctx, campaignPublicId);
    }
    async cancel(ctx, campaignPublicId) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_WRITE);
        const campaign = await this.resolveCampaign(ctx, campaignPublicId);
        const now = new Date();
        const result = await campaign_execution_repository_1.campaignExecutionRepository.transitionStatus(ctx.companyId, campaign.internalId, ["DRAFT", "SCHEDULED", "RUNNING", "PAUSED"], {
            status: "CANCELLED",
            cancelledAt: now,
            pausedAt: null,
            workerId: null,
            lockExpiresAt: null,
        });
        if (result.count === 0) {
            throw new errors_1.ValidationError("Campaign cannot be cancelled");
        }
        await prisma_1.default.callLog.updateMany({
            where: {
                companyId: ctx.companyId,
                campaignId: campaign.internalId,
                status: "QUEUED",
            },
            data: { status: "CANCELLED" },
        });
        const cancelledJobs = await retry_job_repository_1.retryJobRepository.cancelPendingForCampaign(ctx.companyId, campaign.internalId);
        if (cancelledJobs.count > 0) {
            await campaign_execution_repository_1.campaignExecutionRepository.updateStatistics(ctx.companyId, campaign.internalId, {
                pendingRetries: { decrement: cancelledJobs.count },
            });
        }
        await campaign_execution_lock_service_1.campaignExecutionLockService.release(campaign.internalId, campaign_execution_config_1.campaignExecutionConfig.workerId);
        (0, campaign_execution_logger_1.logCampaignExecutionEvent)("campaign:cancelled", {
            campaignPublicId: campaign.publicId,
        });
        await this.writeActivity(ctx.companyId, campaign.internalId, "CAMPAIGN_EXECUTION_CANCELLED", "Campaign execution cancelled", ctx.userId);
        return this.loadExecutionView(ctx, campaignPublicId);
    }
    async promoteScheduledToRunning(executionId) {
        const row = await prisma_1.default.campaignExecution.findUnique({
            where: { id: executionId },
            include: { campaign: { select: { resourceKey: true } } },
        });
        if (!row || row.status !== "SCHEDULED") {
            return false;
        }
        const totalContacts = await this.campaignsRepo.countContacts(row.companyId, row.campaignId);
        const now = new Date();
        const lockExpiresAt = new Date(now.getTime() + campaign_execution_config_1.campaignExecutionConfig.lockTtlMs);
        const result = await campaign_execution_repository_1.campaignExecutionRepository.transitionStatus(row.companyId, row.campaignId, ["SCHEDULED"], {
            status: "RUNNING",
            startedAt: now,
            totalContacts,
            workerId: campaign_execution_config_1.campaignExecutionConfig.workerId,
            lockExpiresAt,
            correlationId: row.correlationId ?? (0, crypto_1.randomUUID)(),
        });
        if (result.count > 0) {
            const campaignPublicId = await (0, mapper_1.toCampaignPublicId)(await (0, system_tenant_context_1.createSystemTenantContext)(row.companyId), row.campaign.resourceKey);
            (0, campaign_execution_logger_1.logCampaignExecutionEvent)("campaign:started", {
                campaignPublicId,
                correlationId: row.correlationId ?? undefined,
                totalContacts,
                source: "scheduler",
            });
            await this.writeActivity(row.companyId, row.campaignId, "CAMPAIGN_EXECUTION_STARTED", "Campaign execution started by scheduler");
        }
        return result.count > 0;
    }
    async getRetryPolicy(ctx, campaignPublicId) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_READ);
        const campaign = await this.resolveCampaign(ctx, campaignPublicId);
        const policy = await retry_statistics_service_1.retryStatisticsService.getPolicy(ctx.companyId, campaign.internalId);
        if (!policy) {
            throw new errors_1.NotFoundError("Campaign execution not found");
        }
        return policy;
    }
    async updateRetryPolicy(ctx, campaignPublicId, input) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_WRITE);
        const campaign = await this.resolveCampaign(ctx, campaignPublicId);
        await this.getOrCreateExecution(ctx.companyId, campaign.internalId);
        if (input.maxRetries !== undefined && input.maxRetries < 0) {
            throw new errors_1.ValidationError("maxRetries must be non-negative");
        }
        if (input.retryDelaySeconds !== undefined &&
            input.retryDelaySeconds < 0) {
            throw new errors_1.ValidationError("retryDelaySeconds must be non-negative");
        }
        await campaign_execution_repository_1.campaignExecutionRepository.updateStatistics(ctx.companyId, campaign.internalId, {
            ...(input.retryEnabled !== undefined
                ? { retryEnabled: input.retryEnabled }
                : {}),
            ...(input.maxRetries !== undefined
                ? { maxRetries: input.maxRetries }
                : {}),
            ...(input.retryDelaySeconds !== undefined
                ? { retryDelaySeconds: input.retryDelaySeconds }
                : {}),
            ...(input.retryOnBusy !== undefined
                ? { retryOnBusy: input.retryOnBusy }
                : {}),
            ...(input.retryOnNoAnswer !== undefined
                ? { retryOnNoAnswer: input.retryOnNoAnswer }
                : {}),
            ...(input.retryOnFailed !== undefined
                ? { retryOnFailed: input.retryOnFailed }
                : {}),
            ...(input.retryOnCancelled !== undefined
                ? { retryOnCancelled: input.retryOnCancelled }
                : {}),
            ...(input.retryOnVoicemail !== undefined
                ? { retryOnVoicemail: input.retryOnVoicemail }
                : {}),
            ...(input.retryOnMissed !== undefined
                ? { retryOnMissed: input.retryOnMissed }
                : {}),
        });
        return this.getRetryPolicy(ctx, campaignPublicId);
    }
    async getRetryHistory(ctx, campaignPublicId, phoneNumber) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_READ);
        const campaign = await this.resolveCampaign(ctx, campaignPublicId);
        return retry_statistics_service_1.retryStatisticsService.getHistory(ctx.companyId, campaign.internalId, phoneNumber);
    }
    async getPendingRetries(ctx, campaignPublicId) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_READ);
        const campaign = await this.resolveCampaign(ctx, campaignPublicId);
        return retry_statistics_service_1.retryStatisticsService.getPendingRetries(ctx.companyId, campaign.internalId);
    }
    async getRetryStatistics(ctx, campaignPublicId) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_READ);
        const campaign = await this.resolveCampaign(ctx, campaignPublicId);
        return retry_statistics_service_1.retryStatisticsService.getStatistics(ctx.companyId, campaign.internalId);
    }
    async getRetrySummary(ctx, campaignPublicId) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_READ);
        const campaign = await this.resolveCampaign(ctx, campaignPublicId);
        const summary = await retry_statistics_service_1.retryStatisticsService.getSummary(ctx.companyId, campaign.internalId);
        if (!summary) {
            throw new errors_1.NotFoundError("Campaign execution not found");
        }
        return summary;
    }
    async markCompleted(companyId, campaignId) {
        const now = new Date();
        await campaign_execution_repository_1.campaignExecutionRepository.transitionStatus(companyId, campaignId, ["RUNNING"], {
            status: "COMPLETED",
            completedAt: now,
            workerId: null,
            lockExpiresAt: null,
        });
        await campaign_execution_lock_service_1.campaignExecutionLockService.release(campaignId, campaign_execution_config_1.campaignExecutionConfig.workerId);
        const row = await campaign_execution_repository_1.campaignExecutionRepository.findByCampaignId(companyId, campaignId);
        if (row) {
            const campaignPublicId = await (0, mapper_1.toCampaignPublicId)(await (0, system_tenant_context_1.createSystemTenantContext)(companyId), row.campaign.resourceKey);
            (0, campaign_execution_logger_1.logCampaignExecutionEvent)("campaign:completed", {
                campaignPublicId,
                correlationId: row.correlationId ?? undefined,
                processedCount: row.processedCount,
            });
            await this.writeActivity(companyId, campaignId, "CAMPAIGN_EXECUTION_COMPLETED", "Campaign execution completed");
        }
    }
    async markFailed(companyId, campaignId, failureReason) {
        const now = new Date();
        await campaign_execution_repository_1.campaignExecutionRepository.transitionStatus(companyId, campaignId, ["RUNNING"], {
            status: "FAILED",
            failedAt: now,
            failureReason,
            workerId: null,
            lockExpiresAt: null,
        });
        await campaign_execution_lock_service_1.campaignExecutionLockService.release(campaignId, campaign_execution_config_1.campaignExecutionConfig.workerId);
        const row = await campaign_execution_repository_1.campaignExecutionRepository.findByCampaignId(companyId, campaignId);
        if (row) {
            const campaignPublicId = await (0, mapper_1.toCampaignPublicId)(await (0, system_tenant_context_1.createSystemTenantContext)(companyId), row.campaign.resourceKey);
            (0, campaign_execution_logger_1.logCampaignExecutionEvent)("campaign:failed", {
                campaignPublicId,
                correlationId: row.correlationId ?? undefined,
                failureReason,
            });
            await this.writeActivity(companyId, campaignId, "CAMPAIGN_EXECUTION_FAILED", `Campaign execution failed: ${failureReason}`, undefined, { failureReason });
        }
    }
    async isRunning(companyId, campaignId) {
        const row = await campaign_execution_repository_1.campaignExecutionRepository.findByCampaignId(companyId, campaignId);
        return row?.status === "RUNNING";
    }
}
exports.CampaignExecutionService = CampaignExecutionService;
exports.campaignExecutionService = new CampaignExecutionService();
//# sourceMappingURL=campaign-execution.service.js.map