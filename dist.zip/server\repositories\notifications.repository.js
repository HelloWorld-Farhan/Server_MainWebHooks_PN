"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SchedulerRepository = exports.IntegrationsRepository = exports.NotificationsRepository = void 0;
const base_repository_1 = require("./base.repository");
const pagination_1 = require("../lib/pagination");
class NotificationsRepository extends base_repository_1.BaseRepository {
    listForUser(companyId, userId, limit, after) {
        const cursor = after ? (0, pagination_1.decodeIdCursor)(after) : undefined;
        return this.prisma.notification.findMany({
            where: { companyId, userId },
            orderBy: [{ createdAt: "desc" }, { id: "desc" }],
            take: limit + 1,
            ...(cursor
                ? {
                    cursor: { id: cursor.id },
                    skip: 1,
                }
                : {}),
        });
    }
}
exports.NotificationsRepository = NotificationsRepository;
class IntegrationsRepository extends base_repository_1.BaseRepository {
    findAll(companyId) {
        return this.prisma.integration.findMany({
            where: this.scope(companyId),
            orderBy: { type: "asc" },
        });
    }
    findByType(companyId, type) {
        return this.prisma.integration.findFirst({
            where: { companyId, type },
        });
    }
}
exports.IntegrationsRepository = IntegrationsRepository;
class SchedulerRepository extends base_repository_1.BaseRepository {
    listUpcoming(companyId, limit, leadBranchIds) {
        return this.prisma.schedulerEvent.findMany({
            where: {
                companyId,
                startAt: { gte: new Date() },
                status: "SCHEDULED",
                ...(leadBranchIds?.length
                    ? { lead: { campaignId: { in: leadBranchIds } } }
                    : {}),
            },
            orderBy: { startAt: "asc" },
            take: limit,
        });
    }
}
exports.SchedulerRepository = SchedulerRepository;
//# sourceMappingURL=notifications.repository.js.map