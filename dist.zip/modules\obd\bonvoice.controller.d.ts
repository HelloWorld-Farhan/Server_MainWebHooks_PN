export declare class BonvoiceController {
    addLeads(body: {
        leads: any[];
        didNumber: string;
        companyId: string;
    }): Promise<{
        success: boolean;
        data: any;
    }>;
}
