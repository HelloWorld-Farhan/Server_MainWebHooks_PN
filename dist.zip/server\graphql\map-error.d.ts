import { GraphQLError } from "graphql";
export declare function toGraphQLError(error: unknown, isDev: boolean): GraphQLError;
export declare function maskGraphQLError(error: unknown, message: string, isDev: boolean): Error;
