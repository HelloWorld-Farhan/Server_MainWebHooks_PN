"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.delayedCallsWorker = void 0;
const bullmq_1 = require("bullmq");
const redis_client_1 = require("./redis.client");
const delayed_calls_queue_1 = require("./delayed-calls.queue");
const outbound_calls_service_1 = require("../services/outbound-calls.service");
exports.delayedCallsWorker = redis_client_1.redisConnection
    ? new bullmq_1.Worker(delayed_calls_queue_1.DELAYED_CALLS_QUEUE_NAME, async (job) => {
        const { type, ctx, newInput, retryInput, didNumber } = job.data;
        try {
            if (type === "RETRY" && retryInput) {
                await outbound_calls_service_1.outboundCallsService.createRetryOutboundCall(ctx, retryInput);
            }
            else if (type === "NEW" && newInput) {
                await outbound_calls_service_1.outboundCallsService.createOutboundCall(ctx, newInput);
            }
            console.log(`✅ Dispatched ${type} call via BullMQ for DID ${didNumber}`);
        }
        catch (error) {
            console.error(`❌ Failed to dispatch ${type} call via BullMQ for DID ${didNumber}:`, error.message);
            throw error;
        }
    }, {
        connection: redis_client_1.redisConnection,
        concurrency: 10,
    })
    : null;
if (exports.delayedCallsWorker) {
    exports.delayedCallsWorker.on("failed", (job, err) => {
        console.error(`Job ${job?.id} failed with error ${err.message}`);
    });
}
//# sourceMappingURL=delayed-calls.worker.js.map