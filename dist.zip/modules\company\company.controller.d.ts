import type { Request, Response } from "express";
export declare class CompanyController {
    private readonly logger;
    getContact(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    putContact(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    getContract(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    linkContract(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
}
export declare class ContactRequestsController {
    submit(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
}
