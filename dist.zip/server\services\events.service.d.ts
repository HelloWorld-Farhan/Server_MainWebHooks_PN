import type { TenantContext } from "../types/context";
import type { Prisma, SystemEventType } from "@prisma/client";
export declare class EventsService {
    private readonly repo;
    listRecent(ctx: TenantContext, limit?: number): Promise<{
        id: string;
        createdAt: Date;
        companyId: string;
        type: import("@prisma/client").$Enums.SystemEventType;
        title: string;
        entityType: string | null;
        entityId: string | null;
        actorId: string | null;
        payload: Prisma.JsonValue;
    }[]>;
    emit(ctx: TenantContext, data: {
        type: SystemEventType;
        entityType?: string;
        entityId?: string;
        title: string;
        payload?: Prisma.InputJsonValue;
    }): Promise<{
        id: string;
        createdAt: Date;
        companyId: string;
        type: import("@prisma/client").$Enums.SystemEventType;
        title: string;
        entityType: string | null;
        entityId: string | null;
        actorId: string | null;
        payload: Prisma.JsonValue;
    }>;
}
export declare const eventsService: EventsService;
