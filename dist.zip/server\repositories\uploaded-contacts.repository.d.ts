import { BaseRepository } from "./base.repository";
export type UploadedContactCreateInput = {
    phone: string;
    field1?: string | null;
    field2?: string | null;
    field3?: string | null;
    campaignIds?: string[];
};
type ExistingUploadedContact = {
    id: string;
    phone: string;
    field1: string | null;
    field2: string | null;
    field3: string | null;
    campaignIds: string[];
};
export declare class UploadedContactsRepository extends BaseRepository {
    findMany(companyId: string): import("@prisma/client").Prisma.PrismaPromise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        campaignIds: string[];
        phone: string;
        resourceKey: string;
        field1: string | null;
        field2: string | null;
        field3: string | null;
    }[]>;
    findById(companyId: string, id: string): import("@prisma/client").Prisma.Prisma__UploadedContactClient<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        campaignIds: string[];
        phone: string;
        resourceKey: string;
        field1: string | null;
        field2: string | null;
        field3: string | null;
    } | null, null, import("@prisma/client/runtime/library").DefaultArgs, import("@prisma/client").Prisma.PrismaClientOptions>;
    findByPhones(companyId: string, phones: string[]): Promise<ExistingUploadedContact[]>;
    create(companyId: string, contact: UploadedContactCreateInput): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        campaignIds: string[];
        phone: string;
        resourceKey: string;
        field1: string | null;
        field2: string | null;
        field3: string | null;
    }>;
    createMany(companyId: string, contacts: UploadedContactCreateInput[]): Promise<{
        created: number;
        updated: number;
        skipped: number;
    }>;
    delete(companyId: string, id: string): Promise<boolean>;
    bulkDelete(companyId: string, ids: string[]): Promise<number>;
}
export {};
