import { BaseRepository } from "./base.repository";
export declare class OutboundCampaignsRepository extends BaseRepository {
    findMany(companyId: string): import("@prisma/client").Prisma.PrismaPromise<({
        aiAgent: {
            name: string;
            id: string;
        } | null;
    } & {
        status: import("@prisma/client").$Enums.OutboundCampaignStatus;
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        aiAgentId: string | null;
        totalCalls: number;
        connectedCalls: number;
        conversionRate: number;
        generatedLeads: number;
    })[]>;
    findById(companyId: string, id: string): import("@prisma/client").Prisma.Prisma__OutboundCampaignClient<({
        aiAgent: {
            name: string;
            id: string;
        } | null;
    } & {
        status: import("@prisma/client").$Enums.OutboundCampaignStatus;
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        aiAgentId: string | null;
        totalCalls: number;
        connectedCalls: number;
        conversionRate: number;
        generatedLeads: number;
    }) | null, null, import("@prisma/client/runtime/library").DefaultArgs, import("@prisma/client").Prisma.PrismaClientOptions>;
    create(companyId: string, data: {
        name: string;
        aiAgentId?: string | null;
    }): import("@prisma/client").Prisma.Prisma__OutboundCampaignClient<{
        aiAgent: {
            name: string;
            id: string;
        } | null;
    } & {
        status: import("@prisma/client").$Enums.OutboundCampaignStatus;
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        aiAgentId: string | null;
        totalCalls: number;
        connectedCalls: number;
        conversionRate: number;
        generatedLeads: number;
    }, never, import("@prisma/client/runtime/library").DefaultArgs, import("@prisma/client").Prisma.PrismaClientOptions>;
    updateStatus(companyId: string, id: string, status: "ACTIVE" | "PAUSED" | "DRAFT" | "COMPLETED"): import("@prisma/client").Prisma.PrismaPromise<import("@prisma/client").Prisma.BatchPayload>;
}
