import type { IntegrationId } from "../types";
export declare const GOOGLE_OAUTH_SCOPES: string[];
export declare const GOOGLE_INTEGRATION_IDS: Set<IntegrationId>;
export declare function isGoogleIntegration(id: IntegrationId): boolean;
export declare function spreadsheetWebViewLink(spreadsheetId: string): string;
export declare function columnIndexToLetter(index: number): string;
export declare function columnLetterToPreset(letter: string): string;
