"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.uploadedContactsService = exports.UploadedContactsService = void 0;
const errors_1 = require("../lib/errors");
const cache_service_1 = require("../cache/cache.service");
const prisma_1 = __importDefault(require("../lib/prisma"));
const campaigns_repository_1 = require("../repositories/campaigns.repository");
const uploaded_contacts_repository_1 = require("../repositories/uploaded-contacts.repository");
const permissions_1 = require("../types/permissions");
const tenant_service_1 = require("./tenant.service");
const contact_phone_validation_1 = require("../../lib/contact-phone-validation");
const MAX_IMPORT_ROWS = 5000;
function mapUploadedContact(row) {
    return {
        id: row.id,
        phone: row.phone,
        field1: row.field1,
        field2: row.field2,
        field3: row.field3,
        campaignIds: row.campaignIds,
        createdAt: row.createdAt.toISOString(),
    };
}
function normalizeImportedContact(contact) {
    const normalized = (0, contact_phone_validation_1.normalizeStoredContactPhone)(contact.phone);
    if (!normalized) {
        return null;
    }
    return {
        phone: normalized,
        field1: contact.field1?.trim() || null,
        field2: contact.field2?.trim() || null,
        field3: contact.field3?.trim() || null,
        campaignNames: (contact.campaignNames ?? [])
            .map((name) => name.trim())
            .filter((name) => name.length > 0),
        campaignIds: (contact.campaignIds ?? []).filter((id) => id.length > 0),
    };
}
class UploadedContactsService {
    repo = new uploaded_contacts_repository_1.UploadedContactsRepository(prisma_1.default);
    campaignsRepo = new campaigns_repository_1.CampaignsRepository(prisma_1.default);
    async list(ctx) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.LEADS_READ);
        const rows = await this.repo.findMany(ctx.companyId);
        return rows.map(mapUploadedContact);
    }
    async create(ctx, phone) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.LEADS_WRITE);
        const normalized = (0, contact_phone_validation_1.normalizeStoredContactPhone)(phone);
        if (!normalized) {
            throw new errors_1.AppError("Phone number must be a valid 10-digit local number with a supported country code.", "INVALID_PHONE");
        }
        const existing = await this.repo.findByPhones(ctx.companyId, [normalized]);
        if (existing.length > 0) {
            throw new errors_1.AppError("This phone number already exists.", "DUPLICATE_PHONE");
        }
        const row = await this.repo.create(ctx.companyId, { phone: normalized });
        await cache_service_1.cacheService.invalidateUploadedContactPages(ctx.companyId);
        return mapUploadedContact(row);
    }
    async importContacts(ctx, contacts) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.LEADS_WRITE);
        const normalizedRows = [];
        let invalid = 0;
        const seen = new Set();
        for (const raw of contacts.slice(0, MAX_IMPORT_ROWS)) {
            const normalized = normalizeImportedContact(raw);
            if (!normalized) {
                invalid++;
                continue;
            }
            if (seen.has(normalized.phone)) {
                continue;
            }
            seen.add(normalized.phone);
            normalizedRows.push(normalized);
        }
        const campaigns = await this.campaignsRepo.findAllNames(ctx.companyId);
        const branchByName = new Map(campaigns.map((campaign) => [campaign.name.trim().toLowerCase(), campaign.id]));
        const unmatchedCampaigns = new Set();
        const validContacts = normalizedRows.map((row) => {
            const campaignIds = [...row.campaignIds];
            for (const name of row.campaignNames) {
                const campaignId = branchByName.get(name.toLowerCase());
                if (campaignId) {
                    campaignIds.push(campaignId);
                }
                else {
                    unmatchedCampaigns.add(name);
                }
            }
            return {
                phone: row.phone,
                field1: row.field1,
                field2: row.field2,
                field3: row.field3,
                campaignIds: [...new Set(campaignIds)],
            };
        });
        const { created, updated, skipped } = await this.repo.createMany(ctx.companyId, validContacts);
        if (created > 0 || updated > 0) {
            await cache_service_1.cacheService.invalidateUploadedContactPages(ctx.companyId);
        }
        return {
            created,
            updated,
            skipped,
            invalid,
            unmatchedCampaigns: [...unmatchedCampaigns],
        };
    }
    async delete(ctx, id) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.LEADS_WRITE);
        const deleted = await this.repo.delete(ctx.companyId, id);
        if (!deleted) {
            throw new errors_1.NotFoundError("Contact not found");
        }
        await cache_service_1.cacheService.invalidateUploadedContactPages(ctx.companyId);
        return true;
    }
    async bulkDelete(ctx, ids) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.LEADS_WRITE);
        const count = await this.repo.bulkDelete(ctx.companyId, ids);
        if (count > 0) {
            await cache_service_1.cacheService.invalidateUploadedContactPages(ctx.companyId);
        }
        return count;
    }
}
exports.UploadedContactsService = UploadedContactsService;
exports.uploadedContactsService = new UploadedContactsService();
//# sourceMappingURL=uploaded-contacts.service.js.map