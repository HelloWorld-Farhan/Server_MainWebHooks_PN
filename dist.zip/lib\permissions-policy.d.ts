import { type CampaignAccessType, type Permission, type UserRole } from "./permissions";
export type AccessContext = {
    membershipId: string;
    userId: string;
    role: UserRole;
    permissions: string[];
    campaignAccessType: CampaignAccessType;
    campaignIds: string[];
};
export type EmployeeTarget = {
    id: string;
    userId: string;
    role: UserRole;
};
export declare function ctxHasPermission(ctx: AccessContext, permission: Permission): boolean;
export declare function ctxHasAnyPermission(ctx: AccessContext, permissions: Permission[]): boolean;
export declare function ctxHasAllPermissions(ctx: AccessContext, permissions: Permission[]): boolean;
export declare function hasAllCampaignAccess(ctx: AccessContext): boolean;
export declare function canAccessCampaign(ctx: AccessContext, campaignId: string): boolean;
export declare function getAccessibleCampaignIds(ctx: AccessContext): string[];
export declare function getAssignableRoles(ctx: AccessContext): UserRole[];
export declare function canAssignRole(ctx: AccessContext, role: UserRole): boolean;
export declare function canManageEmployee(ctx: AccessContext, target: EmployeeTarget): boolean;
export declare function canInviteEmployee(ctx: AccessContext, roleToAssign: UserRole, target?: EmployeeTarget): boolean;
export declare function canResendInvitation(ctx: AccessContext, target: EmployeeTarget): boolean;
export declare function canCancelInvitation(ctx: AccessContext, target: EmployeeTarget): boolean;
export declare function canDeactivateEmployee(ctx: AccessContext, target: EmployeeTarget): boolean;
export declare function canDeleteEmployee(ctx: AccessContext, target: EmployeeTarget): boolean;
export declare function canViewEmployee(ctx: AccessContext, _target?: EmployeeTarget): boolean;
