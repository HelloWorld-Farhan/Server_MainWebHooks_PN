"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InboundWebhooksController = void 0;
const common_1 = require("@nestjs/common");
const prisma_1 = __importDefault(require("../../server/lib/prisma"));
const cache_service_1 = require("../../server/cache/cache.service");
let InboundWebhooksController = class InboundWebhooksController {
    async handleInboundWebhook(req, res) {
        try {
            const body = req.body || {};
            const query = req.query || {};
            const apiKey = req.headers["x-obd-api-key"] ||
                req.headers["x-api-key"] ||
                body["x-obd-api-key"] ||
                body["x-api-key"] ||
                query["x-obd-api-key"] ||
                query["x-api-key"];
            const expectedKey = process.env.INBOUND_WEBHOOK_SECRET || process.env.OBD_WEBHOOK_SECRET;
            if (!expectedKey || apiKey !== expectedKey) {
                console.warn(`[Inbound Webhook] Unauthorized request. Provided Key: ${apiKey}`);
                return res.status(401).json({ error: "Invalid OBD webhook API key" });
            }
            console.log(`[Inbound Webhook] Received payload:`, JSON.stringify(body));
            console.log(`[Inbound Webhook] Key fields - agentNumber(callid/calledno): ${body.callid || body.calledno}, callerNo(phone): ${body.phone || body.callingNo}, status: ${body.status}`);
            const callObj = body.call || {};
            const messageObj = body.message || {};
            const callingNo = body.phone || body["Calling No"] || body.callingNo || body.calling_no || body.caller_id || body.caller_number || callObj.from || messageObj.customer?.number || "Unknown";
            const callDurationRaw = body.duration ?? body["Call Duration"] ?? body.callDuration ?? body.call_duration ?? callObj.durationSec ?? messageObj.call?.duration;
            const statusRaw = body.status ?? body.event ?? body.type ?? body.call_status ?? body.callStatus ?? body["Status"] ?? callObj.status ?? messageObj.status ?? messageObj.type;
            const logId = body.log_id || body.logId || body.call_id || body.callId || body["Log ID"] || body.callid || body.calledno || callObj.id || messageObj.call?.id || `webhook-${Date.now()}`;
            const recordingUrl = body.recording_url || body.recordingUrl || body.recording || callObj.recordingUrl || messageObj.call?.recordingUrl || null;
            const transcriptUrl = body.transcript_url || body.transcriptUrl || body.transcript || messageObj.call?.transcriptUrl || null;
            const agentNumber = body.callid || body.calledno || body.assigned_number || callObj.to || messageObj.call?.phoneNumber || "Unknown";
            const getNumberVariants = (num) => {
                if (!num || num === "Unknown")
                    return [num];
                const digits = num.replace(/\D/g, "");
                const variants = new Set([num, digits]);
                if (digits.startsWith("00")) {
                    const stripped = digits.substring(2);
                    variants.add(stripped);
                    variants.add("+" + stripped);
                    if (stripped.startsWith("91")) {
                        const national = stripped.substring(2);
                        variants.add(national);
                        variants.add("0" + national);
                    }
                }
                else if (digits.startsWith("0")) {
                    const stripped = digits.substring(1);
                    variants.add(stripped);
                    variants.add("+" + stripped);
                }
                if (digits.startsWith("0") && digits.length === 11) {
                    const without0 = digits.substring(1);
                    variants.add(without0);
                    variants.add("91" + without0);
                    variants.add("+91" + without0);
                    variants.add("9191" + without0);
                }
                if (!digits.startsWith("91") && digits.length === 10) {
                    variants.add("91" + digits);
                    variants.add("+91" + digits);
                    variants.add("0" + digits);
                }
                if (digits.startsWith("9191") && digits.length >= 14) {
                    const stripped = digits.substring(2);
                    variants.add(stripped);
                    variants.add("+" + stripped);
                }
                if (digits.startsWith("91") && digits.length >= 12) {
                    variants.add("+" + digits);
                    const stripped = digits.substring(2);
                    if (stripped.length >= 10) {
                        variants.add(stripped);
                        variants.add("0" + stripped);
                        variants.add("+" + stripped);
                        variants.add("91" + stripped);
                        variants.add("+91" + stripped);
                    }
                }
                variants.forEach(v => { if (v.startsWith("+"))
                    variants.add(v.substring(1)); });
                return Array.from(variants);
            };
            const agentVariants = getNumberVariants(agentNumber);
            const callingVariants = getNumberVariants(callingNo);
            const normalizedCallingNo = callingVariants.find(v => v.startsWith("+")) || callingVariants[0];
            const normalizedAgentNumber = agentVariants.find(v => v.startsWith("+")) || agentVariants[0];
            let companies = [];
            let resolvedPhoneNumber = null;
            const customParamsStr = body.custom_parameters || callObj.customParameters || callObj.custom_parameters;
            let customParams = {};
            try {
                if (typeof customParamsStr === 'string')
                    customParams = JSON.parse(customParamsStr);
                else if (typeof customParamsStr === 'object')
                    customParams = customParamsStr;
            }
            catch (e) { }
            let direction = "INBOUND";
            const payloadCompanyId = customParams?.companyId || customParams?.company_id;
            if (payloadCompanyId) {
                const exactCompany = await prisma_1.default.company.findUnique({ where: { id: payloadCompanyId } });
                if (exactCompany) {
                    companies = [exactCompany];
                    direction = customParams.callType === "outbound" || callObj.direction === "outbound" ? "OUTBOUND" : "INBOUND";
                }
            }
            if (direction === "INBOUND") {
                const allVariants = [...agentVariants, ...callingVariants];
                const pendingOutbound = await prisma_1.default.callLog.findFirst({
                    where: {
                        direction: "OUTBOUND",
                        status: "PENDING",
                        lead: { phone: { in: allVariants } },
                        ...(companies.length > 0 ? { companyId: { in: companies.map(c => c.id) } } : {})
                    },
                    orderBy: { startedAt: 'desc' },
                    include: { company: true }
                });
                if (pendingOutbound && pendingOutbound.company) {
                    direction = "OUTBOUND";
                    if (companies.length === 0) {
                        companies = [pendingOutbound.company];
                    }
                }
            }
            let phoneNumbers = [];
            if (companies.length === 0) {
                phoneNumbers = await prisma_1.default.phoneNumber.findMany({
                    where: {
                        OR: agentVariants.map(v => ({ number: { contains: v } })),
                        status: "ACTIVE",
                        direction: { not: "OUTBOUND" }
                    }
                });
                if (phoneNumbers.length === 0) {
                    phoneNumbers = await prisma_1.default.phoneNumber.findMany({
                        where: {
                            OR: callingVariants.map(v => ({ number: { contains: v } })),
                            status: "ACTIVE"
                        }
                    });
                    if (phoneNumbers.length > 0) {
                        direction = "OUTBOUND";
                    }
                }
                if (phoneNumbers.length > 0) {
                    resolvedPhoneNumber = phoneNumbers[0];
                    const companyIds = Array.from(new Set(phoneNumbers.map((p) => p.companyId).filter(Boolean)));
                    if (companyIds.length > 0) {
                        companies = await prisma_1.default.company.findMany({ where: { id: { in: companyIds } } });
                    }
                }
            }
            if (companies.length === 0) {
                console.warn(`Webhook rejected: No matching company found for inbound call to ${agentNumber} from ${callingNo}`);
                return res.status(404).json({ error: "No company found for this number" });
            }
            let durationSeconds = 0;
            if (callDurationRaw !== undefined) {
                if (typeof callDurationRaw === "number") {
                    durationSeconds = callDurationRaw;
                }
                else if (typeof callDurationRaw === "string") {
                    durationSeconds = parseInt(callDurationRaw, 10);
                    if (isNaN(durationSeconds))
                        durationSeconds = 0;
                }
            }
            let status = "COMPLETED";
            if (statusRaw !== undefined) {
                const normalizedStatus = statusRaw.toString().toUpperCase();
                if (normalizedStatus.includes("RING") || normalizedStatus.includes("INITIAT") || normalizedStatus.includes("QUEUE") || normalizedStatus.includes("DISPATCH")) {
                    status = "RINGING";
                }
                else if (normalizedStatus.includes("ANSWER") || normalizedStatus.includes("CONNECT") || normalizedStatus.includes("ACTIVE") || normalizedStatus.includes("IN_PROGRESS")) {
                    status = "ANSWERED";
                }
                else if (normalizedStatus.includes("FAIL") || normalizedStatus.includes("ERROR") || normalizedStatus.includes("REJECT") || normalizedStatus.includes("CANCEL")) {
                    status = "FAILED";
                }
                else if (normalizedStatus.includes("BUSY") || normalizedStatus.includes("NO ANSWER") || normalizedStatus.includes("NO_ANSWER") || normalizedStatus.includes("MISSED") || normalizedStatus.includes("VOICEMAIL")) {
                    status = "MISSED";
                }
            }
            const isCallLive = status === "RINGING" || status === "ANSWERED";
            if (!isCallLive && durationSeconds === 0) {
                status = "FAILED";
            }
            const publicId = `INB-${logId}`;
            const finalRecordingUrl = recordingUrl || `/api/calls/${logId}/recording`;
            const finalTranscriptUrl = transcriptUrl || `/api/calls/${logId}/transcript`;
            let creditsToDeduct = 0;
            if (status === "COMPLETED" && durationSeconds > 0) {
                const minutes = Math.floor(durationSeconds / 60);
                const remainder = durationSeconds % 60;
                creditsToDeduct = minutes * 3.5;
                if (remainder > 0 && remainder <= 30) {
                    creditsToDeduct += 1.75;
                }
                else if (remainder > 30) {
                    creditsToDeduct += 3.5;
                }
            }
            let primaryCallLogId;
            for (const company of companies) {
                let stage = await prisma_1.default.leadPipelineStage.findFirst({
                    where: { companyId: company.id, slug: "new" }
                });
                if (!stage) {
                    stage = await prisma_1.default.leadPipelineStage.create({
                        data: { companyId: company.id, name: "New", slug: "new", order: 1 }
                    });
                }
                const customerNumber = direction === "OUTBOUND" ? normalizedAgentNumber : normalizedCallingNo;
                let lead = await prisma_1.default.lead.findFirst({
                    where: { companyId: company.id, phone: customerNumber }
                });
                if (!lead) {
                    lead = await prisma_1.default.lead.create({
                        data: {
                            companyId: company.id,
                            phone: customerNumber,
                            firstName: direction === "OUTBOUND" ? "Outbound" : "Incoming",
                            lastName: direction === "OUTBOUND" ? "Contact" : "Caller",
                            stageId: stage.id
                        }
                    });
                }
                let existingCall = await prisma_1.default.callLog.findFirst({
                    where: {
                        companyId: company.id,
                        OR: [
                            { callLogId: logId },
                            { providerCallId: logId }
                        ]
                    }
                });
                let callLogIdToUse = logId;
                if (existingCall) {
                    callLogIdToUse = existingCall.callLogId;
                }
                else if (direction === "OUTBOUND") {
                    const pendingCallIdFromParams = customParams?.pendingCallId;
                    if (pendingCallIdFromParams) {
                        const byId = await prisma_1.default.callLog.findFirst({
                            where: {
                                companyId: company.id,
                                callLogId: pendingCallIdFromParams,
                                direction: "OUTBOUND"
                            }
                        });
                        if (byId) {
                            existingCall = byId;
                            callLogIdToUse = byId.callLogId;
                        }
                    }
                    if (!existingCall) {
                        const allVariants = [...agentVariants, ...callingVariants];
                        const pendingCall = await prisma_1.default.callLog.findFirst({
                            where: {
                                companyId: company.id,
                                lead: { phone: { in: allVariants } },
                                direction: "OUTBOUND",
                                status: { in: ["PENDING", "RINGING", "ANSWERED"] }
                            },
                            orderBy: { startedAt: 'desc' }
                        });
                        if (pendingCall) {
                            existingCall = pendingCall;
                            callLogIdToUse = pendingCall.callLogId;
                        }
                    }
                }
                const alreadyCharged = existingCall?.creditsUsed ? existingCall.creditsUsed > 0 : false;
                let localCreditsToDeduct = creditsToDeduct;
                if (alreadyCharged || isCallLive) {
                    localCreditsToDeduct = 0;
                }
                const updateData = {};
                if (statusRaw !== undefined) {
                    updateData.status = status;
                    if (existingCall) {
                        const terminalStatuses = ["COMPLETED", "FAILED", "MISSED", "CANCELED"];
                        if (terminalStatuses.includes(existingCall.status) && isCallLive) {
                            delete updateData.status;
                        }
                    }
                }
                if (existingCall && existingCall.status === "PENDING" && isCallLive) {
                    updateData.startedAt = new Date();
                }
                if (!isCallLive) {
                    if (callDurationRaw !== undefined)
                        updateData.durationSeconds = durationSeconds;
                    updateData.recordingUrl = finalRecordingUrl;
                    updateData.transcriptUrl = finalTranscriptUrl;
                }
                if (!alreadyCharged && !isCallLive) {
                    updateData.creditsUsed = localCreditsToDeduct;
                }
                if (resolvedPhoneNumber?.id) {
                    updateData.phoneNumberId = resolvedPhoneNumber.id;
                }
                updateData.providerWebhook = body;
                if (logId) {
                    updateData.providerCallId = logId;
                }
                const callLog = await prisma_1.default.callLog.upsert({
                    where: {
                        companyId_callLogId: {
                            companyId: company.id,
                            callLogId: callLogIdToUse
                        }
                    },
                    update: updateData,
                    create: {
                        companyId: company.id,
                        callLogId: logId,
                        publicId: publicId,
                        direction: direction,
                        status: status,
                        startedAt: new Date(),
                        durationSeconds: isCallLive ? 0 : durationSeconds,
                        recordingUrl: isCallLive ? null : finalRecordingUrl,
                        transcriptUrl: isCallLive ? null : finalTranscriptUrl,
                        creditsUsed: localCreditsToDeduct,
                        provider: "webhook",
                        providerCallId: logId,
                        providerWebhook: body,
                        leadId: lead.id,
                        ...(resolvedPhoneNumber?.id ? { phoneNumberId: resolvedPhoneNumber.id } : {})
                    }
                });
                if (!primaryCallLogId) {
                    primaryCallLogId = callLog.id;
                }
                if (localCreditsToDeduct > 0) {
                    let balance = await prisma_1.default.creditBalance.findFirst({
                        where: { companyId: company.id }
                    });
                    if (!balance) {
                        balance = await prisma_1.default.creditBalance.create({
                            data: {
                                companyId: company.id,
                                creditsRemaining: 0,
                                creditsUsed: 0
                            }
                        });
                    }
                    const txOps = [
                        prisma_1.default.creditBalance.update({
                            where: { id: balance.id },
                            data: {
                                creditsRemaining: { decrement: localCreditsToDeduct },
                                creditsUsed: { increment: localCreditsToDeduct }
                            }
                        }),
                        prisma_1.default.creditUsage.create({
                            data: {
                                companyId: company.id,
                                amount: localCreditsToDeduct,
                                reason: "CALL",
                                callLogId: callLog.id,
                                description: `Inbound call duration: ${durationSeconds}s`
                            }
                        })
                    ];
                    await prisma_1.default.$transaction(txOps);
                    try {
                        await cache_service_1.cacheService.invalidateCompanyCredits(company.id);
                        await cache_service_1.cacheService.invalidateBillingPages(company.id);
                    }
                    catch (cacheErr) {
                        console.error("Cache invalidation error:", cacheErr);
                    }
                }
            }
            return res.status(200).json({ success: true, callLogId: primaryCallLogId });
        }
        catch (error) {
            console.error("Inbound webhook error:", error);
            return res.status(500).json({ error: "Internal server error" });
        }
    }
};
exports.InboundWebhooksController = InboundWebhooksController;
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], InboundWebhooksController.prototype, "handleInboundWebhook", null);
exports.InboundWebhooksController = InboundWebhooksController = __decorate([
    (0, common_1.Controller)("api/webhooks/inbound")
], InboundWebhooksController);
//# sourceMappingURL=inbound-webhooks.controller.js.map