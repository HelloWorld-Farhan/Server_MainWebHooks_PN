"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CallInternalNoteRepository = void 0;
const base_repository_1 = require("./base.repository");
class CallInternalNoteRepository extends base_repository_1.BaseRepository {
    listByCallLog(companyId, callLogId) {
        return this.prisma.callInternalNote.findMany({
            where: { companyId, callLogId },
            orderBy: { createdAt: "desc" },
            include: {
                author: {
                    select: {
                        id: true,
                        firstName: true,
                        lastName: true,
                        email: true,
                    },
                },
            },
        });
    }
    create(companyId, callLogId, authorId, content) {
        return this.prisma.callInternalNote.create({
            data: { companyId, callLogId, authorId, content },
            include: {
                author: {
                    select: {
                        id: true,
                        firstName: true,
                        lastName: true,
                        email: true,
                    },
                },
            },
        });
    }
    update(companyId, id, content) {
        return this.prisma.callInternalNote.updateMany({
            where: { id, companyId },
            data: { content },
        });
    }
    delete(companyId, id) {
        return this.prisma.callInternalNote.deleteMany({
            where: { id, companyId },
        });
    }
}
exports.CallInternalNoteRepository = CallInternalNoteRepository;
//# sourceMappingURL=call-internal-note.repository.js.map