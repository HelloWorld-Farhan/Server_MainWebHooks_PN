import type { Permission } from "../types/permissions";
import type { TenantContext } from "../types/context";
export declare function requirePermission(ctx: TenantContext, permission: Permission): void;
