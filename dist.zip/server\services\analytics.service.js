"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.analyticsService = exports.AnalyticsService = void 0;
const cache_service_1 = require("../cache/cache.service");
const keys_1 = require("../cache/keys");
const prisma_1 = __importDefault(require("../lib/prisma"));
const billing_repository_1 = require("../repositories/billing.repository");
const call_logs_repository_1 = require("../repositories/call-logs.repository");
const permissions_1 = require("../types/permissions");
const tenant_service_1 = require("./tenant.service");
const campaign_access_service_1 = require("./campaign-access.service");
function startOfDay(date = new Date()) {
    const d = new Date(date);
    d.setUTCHours(0, 0, 0, 0);
    return d;
}
function endOfDay(date = new Date()) {
    const d = new Date(date);
    d.setUTCHours(23, 59, 59, 999);
    return d;
}
function resolvePeriod(granularity, dateFrom, dateTo) {
    if (dateFrom || dateTo) {
        return {
            start: dateFrom ?? startOfDay(),
            end: dateTo ?? endOfDay(),
        };
    }
    const end = endOfDay();
    const dayMs = 24 * 60 * 60 * 1000;
    switch (granularity) {
        case "WEEKLY":
            return { start: new Date(end.getTime() - 7 * dayMs), end };
        case "MONTHLY":
            return { start: new Date(end.getTime() - 30 * dayMs), end };
        default:
            return { start: startOfDay(), end };
    }
}
class AnalyticsService {
    repo = new billing_repository_1.AnalyticsRepository(prisma_1.default);
    callLogsRepo = new call_logs_repository_1.CallLogsRepository(prisma_1.default);
    async getSummary(ctx, granularity = "DAILY", dateFrom, dateTo) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.ANALYTICS_READ);
        const period = resolvePeriod(granularity, dateFrom, dateTo);
        const cacheKey = `${keys_1.cacheKeys.companyAnalytics(ctx.companyId)}:${granularity}:${period.start.toISOString()}:${period.end.toISOString()}`;
        return cache_service_1.cacheService.getOrSet(cacheKey, keys_1.CACHE_TTL.ANALYTICS, async () => {
            const { totalCalls, connectedCalls } = await this.callLogsRepo.countSummary(ctx.companyId, period.start, period.end, campaign_access_service_1.campaignAccessService.callLogCampaignFilter(ctx));
            const conversionRate = totalCalls > 0
                ? Math.round((connectedCalls / totalCalls) * 1000) / 10
                : 0;
            const snapshot = await this.repo.getLatestSnapshot(ctx.companyId, granularity);
            const metrics = snapshot?.metrics ?? {};
            return {
                totalCalls,
                connectedCalls,
                conversionRate,
                generatedLeads: metrics.generatedLeads ?? 0,
                periodStart: period.start.toISOString(),
                periodEnd: period.end.toISOString(),
            };
        });
    }
    async getTimeSeries(ctx, granularity = "DAILY", dateFrom, dateTo) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.ANALYTICS_READ);
        const period = resolvePeriod(granularity, dateFrom, dateTo);
        const logs = await this.callLogsRepo.findForTimeSeries(ctx.companyId, period.start, period.end, campaign_access_service_1.campaignAccessService.callLogCampaignFilter(ctx));
        const buckets = new Map();
        for (const log of logs) {
            const bucketDate = this.resolveBucketDate(log.startedAt, granularity);
            const key = bucketDate.toISOString();
            const existing = buckets.get(key) ?? {
                label: this.formatBucketLabel(bucketDate, granularity),
                calls: 0,
                connectedCalls: 0,
                leads: 0,
                conversions: 0,
            };
            existing.calls += 1;
            if (log.status === "COMPLETED") {
                existing.connectedCalls += 1;
            }
            if (log.leadId) {
                existing.leads += 1;
            }
            if (log.outcome === "CONVERTED" || log.outcome === "INTERESTED") {
                existing.conversions += 1;
            }
            buckets.set(key, existing);
        }
        const points = Array.from(buckets.entries())
            .sort(([a], [b]) => a.localeCompare(b))
            .map(([periodStart, metrics]) => ({
            periodStart,
            label: metrics.label,
            calls: metrics.calls,
            connectedCalls: metrics.connectedCalls,
            leads: metrics.leads,
            conversions: metrics.conversions,
            conversionRate: metrics.calls > 0
                ? Math.round((metrics.conversions / metrics.calls) * 1000) / 10
                : 0,
        }));
        return {
            granularity,
            periodStart: period.start.toISOString(),
            periodEnd: period.end.toISOString(),
            points,
        };
    }
    resolveBucketDate(date, granularity) {
        const bucket = new Date(date);
        bucket.setUTCHours(0, 0, 0, 0);
        if (granularity === "WEEKLY") {
            const day = bucket.getUTCDay();
            bucket.setUTCDate(bucket.getUTCDate() - day);
        }
        if (granularity === "MONTHLY") {
            bucket.setUTCDate(1);
        }
        return bucket;
    }
    formatBucketLabel(date, granularity) {
        if (granularity === "MONTHLY") {
            return date.toLocaleDateString("en-US", {
                month: "short",
                year: "numeric",
                timeZone: "UTC",
            });
        }
        return date.toLocaleDateString("en-US", {
            month: "short",
            day: "numeric",
            timeZone: "UTC",
        });
    }
    async incrementDailyMetrics(companyId, delta) {
        const periodStart = startOfDay();
        const periodEnd = endOfDay();
        await this.repo.upsertDailySnapshot(companyId, periodStart, periodEnd, delta);
        await cache_service_1.cacheService.invalidateCompanyAnalytics(companyId);
    }
}
exports.AnalyticsService = AnalyticsService;
exports.analyticsService = new AnalyticsService();
//# sourceMappingURL=analytics.service.js.map