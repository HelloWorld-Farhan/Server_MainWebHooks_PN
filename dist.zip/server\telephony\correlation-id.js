"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateCorrelationId = generateCorrelationId;
const node_crypto_1 = require("node:crypto");
function generateCorrelationId() {
    return (0, node_crypto_1.randomUUID)();
}
//# sourceMappingURL=correlation-id.js.map