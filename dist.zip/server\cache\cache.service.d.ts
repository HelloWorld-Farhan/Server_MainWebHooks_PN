import { type PageCacheKey, type ResolvedCompanyCache } from "./keys";
export interface CachedPayload<T> {
    cachedAt: number;
    data: T;
}
export declare class CacheService {
    get<T>(key: string): Promise<T | null>;
    set(key: string, value: unknown, ttlSeconds: number): Promise<void>;
    del(...keys: string[]): Promise<void>;
    getOrSet<T>(key: string, ttlSeconds: number, factory: () => Promise<T>): Promise<T>;
    getCachedPayload<T>(key: string): Promise<CachedPayload<T> | null>;
    setCachedPayload<T>(key: string, data: T, ttlSeconds: number): Promise<void>;
    getWithStaleFallback<T>(key: string): Promise<T | null>;
    getResolvedCompany(clerkUserId: string): Promise<ResolvedCompanyCache | null>;
    setResolvedCompany(clerkUserId: string, value: Omit<ResolvedCompanyCache, "cachedAt">, ttlSeconds: number): Promise<void>;
    invalidateClerkMembershipCaches(clerkUserId: string, orgId?: string | null): Promise<void>;
    invalidateCompanyCredits(companyId: string): Promise<void>;
    invalidateCompanyCallLogs(companyId: string): Promise<void>;
    invalidateCompanyAnalytics(companyId: string): Promise<void>;
    invalidateCompanyAgentStatus(companyId: string): Promise<void>;
    invalidateUserPermissions(userId: string): Promise<void>;
    invalidateCallRelated(companyId: string): Promise<void>;
    invalidatePage(companyId: string, pageKey: PageCacheKey): Promise<void>;
    invalidatePagePrefix(companyId: string, pageKey: PageCacheKey): Promise<void>;
    invalidateAgentPages(companyId: string): Promise<void>;
    invalidatePhoneNumberPages(companyId: string): Promise<void>;
    invalidateLeadPages(companyId: string): Promise<void>;
    invalidateUploadedContactPages(companyId: string): Promise<void>;
    invalidateBillingPages(companyId: string): Promise<void>;
    invalidateSettingsPages(companyId: string): Promise<void>;
}
export declare const cacheService: CacheService;
