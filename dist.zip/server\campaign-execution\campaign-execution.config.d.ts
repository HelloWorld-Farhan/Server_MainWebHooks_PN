export declare const campaignExecutionConfig: {
    batchSize: number;
    schedulerIntervalMs: number;
    runnerIntervalMs: number;
    progressIntervalMs: number;
    maxConcurrentCampaigns: number;
    lockTtlMs: number;
    workerId: string;
};
