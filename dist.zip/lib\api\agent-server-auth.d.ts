import type { Request } from "express";
import type { ApiErrorBody } from "./tenant-context";
export declare function validateAgentServerRequest(req: Request): {
    companyId: string;
    error?: ApiErrorBody;
};
