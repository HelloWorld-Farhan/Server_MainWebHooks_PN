"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.obdWebhookPayloadSchema = void 0;
exports.validateObdWebhookPayload = validateObdWebhookPayload;
exports.parseWebhookDuration = parseWebhookDuration;
exports.resolveProviderEventId = resolveProviderEventId;
exports.parseWebhookTimestamp = parseWebhookTimestamp;
const zod_1 = require("zod");
exports.obdWebhookPayloadSchema = zod_1.z
    .object({
    callid: zod_1.z.string().min(1),
    phone: zod_1.z.string().min(1),
    status: zod_1.z.string().min(1),
    duration: zod_1.z.union([zod_1.z.number(), zod_1.z.string()]).optional(),
    event_id: zod_1.z.string().optional(),
    eventId: zod_1.z.string().optional(),
    correlation_id: zod_1.z.string().optional(),
    correlationId: zod_1.z.string().optional(),
    answered_at: zod_1.z.string().optional(),
    answeredAt: zod_1.z.string().optional(),
    ended_at: zod_1.z.string().optional(),
    endedAt: zod_1.z.string().optional(),
    disconnect_reason: zod_1.z.string().optional(),
    disconnectReason: zod_1.z.string().optional(),
})
    .passthrough();
function validateObdWebhookPayload(body) {
    return exports.obdWebhookPayloadSchema.parse(body);
}
function parseWebhookDuration(duration) {
    if (duration === undefined || duration === null || duration === "") {
        return 0;
    }
    const parsed = typeof duration === "number" ? duration : Number(duration);
    return Number.isFinite(parsed) && parsed >= 0 ? Math.floor(parsed) : 0;
}
function resolveProviderEventId(payload) {
    const explicit = payload.event_id ?? payload.eventId;
    if (explicit) {
        return explicit;
    }
    const endedAt = payload.ended_at ?? payload.endedAt ?? "";
    return `${payload.status}:${endedAt}:${payload.duration ?? 0}`;
}
function parseWebhookTimestamp(value) {
    if (!value) {
        return null;
    }
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? null : date;
}
//# sourceMappingURL=webhook-payload.dto.js.map