import type { TenantContext } from "../types/context";
export declare class OutboundCampaignsService {
    private readonly repo;
    list(ctx: TenantContext): Promise<{
        id: string;
        name: string;
        status: string;
        agentId: string | null;
        agentName: string;
        totalCalls: number;
        connectedCalls: number;
        conversionRate: number;
        generatedLeads: number;
        createdAt: string;
    }[]>;
    create(ctx: TenantContext, input: {
        name: string;
        aiAgentId?: string | null;
    }): Promise<{
        id: string;
        name: string;
        status: string;
        agentId: string | null;
        agentName: string;
        totalCalls: number;
        connectedCalls: number;
        conversionRate: number;
        generatedLeads: number;
        createdAt: string;
    }>;
    launch(ctx: TenantContext, id: string): Promise<{
        id: string;
        name: string;
        status: string;
        agentId: string | null;
        agentName: string;
        totalCalls: number;
        connectedCalls: number;
        conversionRate: number;
        generatedLeads: number;
        createdAt: string;
    }>;
    pause(ctx: TenantContext, id: string): Promise<{
        id: string;
        name: string;
        status: string;
        agentId: string | null;
        agentName: string;
        totalCalls: number;
        connectedCalls: number;
        conversionRate: number;
        generatedLeads: number;
        createdAt: string;
    }>;
}
export declare const outboundCampaignsService: OutboundCampaignsService;
