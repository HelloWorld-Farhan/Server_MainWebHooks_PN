export declare class CampaignSchedulerService {
    recoverOnStartup(): Promise<void>;
    processDueScheduled(): Promise<number>;
}
export declare const campaignSchedulerService: CampaignSchedulerService;
