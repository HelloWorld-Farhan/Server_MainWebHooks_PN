import type { TenantContext } from "../../../server/types/context";
export declare class GoogleSheetsScopeError extends Error {
    constructor(message: string);
}
export declare function ensureGoogleSheetsAuthorized(ctx: TenantContext): Promise<void>;
export declare function getGoogleAuthClient(ctx: TenantContext): Promise<import("googleapis-common").OAuth2Client>;
export declare function getSheetsClient(ctx: TenantContext): Promise<import("googleapis").sheets_v4.Sheets>;
export declare function getDriveClient(ctx: TenantContext): Promise<import("googleapis").drive_v3.Drive>;
export declare function getCalendarClient(ctx: TenantContext): Promise<import("googleapis").calendar_v3.Calendar>;
