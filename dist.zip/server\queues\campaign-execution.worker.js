"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.campaignExecutionWorker = void 0;
const bullmq_1 = require("bullmq");
const redis_client_1 = require("./redis.client");
const campaign_execution_queue_1 = require("./campaign-execution.queue");
const prisma_1 = __importDefault(require("../lib/prisma"));
const campaign_gateway_1 = require("../../modules/websockets/campaign.gateway");
const BONVOICE_API_URL = process.env.BONVOICE_BASE_URL || "https://backend.pbx.bonvoice.com";
async function loginToBonvoice() {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000);
    try {
        const loginRes = await fetch(`${BONVOICE_API_URL}/usermanagement/external-auth/`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            body: JSON.stringify({
                username: process.env.BONVOICE_USERNAME || "PROP_NEXT",
                password: process.env.BONVOICE_PASSWORD || "PRopne##xt89",
            }),
            signal: controller.signal,
        });
        clearTimeout(timeoutId);
        if (!loginRes.ok) {
            throw new Error("Failed to authenticate with Bonvoice");
        }
        const loginData = await loginRes.json();
        const token = loginData.token || loginData.access_token || loginData.data?.token || loginData.data?.access_token;
        if (!token) {
            throw new Error("Invalid authentication response from Bonvoice");
        }
        return token;
    }
    catch (error) {
        clearTimeout(timeoutId);
        throw error;
    }
}
exports.campaignExecutionWorker = redis_client_1.redisConnection
    ? new bullmq_1.Worker(campaign_execution_queue_1.CAMPAIGN_EXECUTION_QUEUE_NAME, async (job) => {
        const { companyId, campaignId, didNumber: rawDidNumber, leads, channels: rawChannels } = job.data;
        const channels = Number(rawChannels) || 1;
        let didNumber = rawDidNumber ? rawDidNumber.trim() : "";
        if (didNumber && !didNumber.startsWith("+")) {
            if (didNumber.length === 10)
                didNumber = "+91" + didNumber;
            else if (didNumber.length === 12 && didNumber.startsWith("91"))
                didNumber = "+" + didNumber;
            else
                didNumber = "+" + didNumber;
        }
        console.log(`Starting Campaign Execution for company: ${companyId}`);
        try {
            const currentStateStr = await redis_client_1.redisConnection.get(`campaign-state:${companyId}`);
            if (currentStateStr) {
                const state = JSON.parse(currentStateStr);
                if (state.status === "running" && state.activeJobId && state.activeJobId !== job.id) {
                    console.log(`[Queueing] Company ${companyId} is already running a campaign. Re-queueing job ${job.name} for 5 minutes later.`);
                    await campaign_execution_queue_1.campaignExecutionQueue?.add(job.name, job.data, {
                        jobId: job.id,
                        delay: 5 * 60 * 1000,
                        removeOnComplete: true,
                        removeOnFail: true
                    });
                    return;
                }
            }
        }
        catch (e) {
            console.error("Error checking campaign state during worker startup:", e);
        }
        try {
            const currentStateStr = await redis_client_1.redisConnection.get(`campaign-state:${companyId}`);
            if (currentStateStr) {
                const state = JSON.parse(currentStateStr);
                await redis_client_1.redisConnection.set(`campaign-state:${companyId}`, JSON.stringify({ ...state, activeJobId: job.id }));
            }
        }
        catch (e) {
            console.error("Failed to set activeJobId:", e);
        }
        try {
            const token = await loginToBonvoice();
            let activeCallIds = new Set();
            let activeCallTimeouts = new Map();
            let activeCallCount = 0;
            let completedCount = 0;
            let currentIndex = 0;
            let leadPhoneMap = new Map();
            const CALL_TIMEOUT_MS = 120000;
            const markAsFailed = async (phone, assignedNumber) => {
                try {
                    console.error(`Marked ${phone} as failed immediately`);
                }
                catch (e) {
                    console.error("Failed to mark call as failed in DB", e);
                }
            };
            const updateRedisState = async (updateFn) => {
                const stateStr = await redis_client_1.redisConnection.get(`campaign-state:${companyId}`);
                if (stateStr) {
                    const state = JSON.parse(stateStr);
                    const newState = updateFn(state);
                    await redis_client_1.redisConnection.set(`campaign-state:${companyId}`, JSON.stringify(newState));
                    const gateway = campaign_gateway_1.CampaignGateway.getInstance();
                    if (gateway) {
                        gateway.broadcastCampaignUpdate(companyId, newState);
                    }
                }
            };
            await updateRedisState(prev => ({ ...prev, status: "running" }));
            let shouldAbort = false;
            let isPaused = false;
            while (currentIndex < leads.length || activeCallCount > 0) {
                let isPreempted = false;
                const currentStateStr = await redis_client_1.redisConnection.get(`campaign-state:${companyId}`);
                if (!currentStateStr) {
                    shouldAbort = true;
                }
                else {
                    const state = JSON.parse(currentStateStr);
                    if (state.status === "force_stopped" && state.activeJobId === job.id) {
                        shouldAbort = true;
                    }
                    else if (state.activeJobId !== job.id) {
                        const pausedStateStr = await redis_client_1.redisConnection.get(`campaign-state:paused:${companyId}`);
                        if (pausedStateStr) {
                            const pausedState = JSON.parse(pausedStateStr);
                            if (pausedState.activeJobId === job.id) {
                                isPaused = true;
                                isPreempted = true;
                            }
                            else {
                                shouldAbort = true;
                            }
                        }
                        else {
                            shouldAbort = true;
                        }
                    }
                    else {
                        isPaused = state.status === "paused";
                    }
                }
                if (shouldAbort) {
                    console.log(`Campaign force stopped for company: ${companyId}. Aborting worker.`);
                    try {
                        await prisma_1.default.callLog.updateMany({
                            where: {
                                companyId,
                                direction: "OUTBOUND",
                                status: "PENDING"
                            },
                            data: { status: "FAILED", durationSeconds: 0 }
                        });
                    }
                    catch (e) {
                        console.error("Cleanup error on force stop", e);
                    }
                    break;
                }
                if (isPaused) {
                    await new Promise(res => setTimeout(res, 2000));
                    continue;
                }
                const batchPromises = [];
                while (activeCallCount < channels && currentIndex < leads.length) {
                    const lead = leads[currentIndex];
                    currentIndex++;
                    if (lead.isInvalid) {
                        continue;
                    }
                    activeCallCount++;
                    batchPromises.push((async () => {
                        try {
                            let leadRecordId = lead.id;
                            if (!leadRecordId) {
                                const corePhone = lead.phone.replace(/\D/g, "").slice(-10);
                                const foundLead = await prisma_1.default.lead.findFirst({
                                    where: { companyId, phone: { contains: corePhone } }
                                });
                                if (foundLead) {
                                    leadRecordId = foundLead.id;
                                }
                                else {
                                    let stage = await prisma_1.default.leadPipelineStage.findFirst({ where: { companyId, slug: "new" } });
                                    if (!stage) {
                                        stage = await prisma_1.default.leadPipelineStage.create({ data: { companyId, name: "New", slug: "new", order: 1 } });
                                    }
                                    const newLead = await prisma_1.default.lead.create({
                                        data: { companyId, phone: lead.phone, firstName: lead.name || "Outbound", lastName: "Contact", stageId: stage.id }
                                    });
                                    leadRecordId = newLead.id;
                                }
                            }
                            const publicId = `OUT-${Date.now()}-${Math.floor(Math.random() * 10000)}`;
                            const isValidObjectId = /^[0-9a-fA-F]{24}$/.test(campaignId);
                            const callLog = await prisma_1.default.callLog.create({
                                data: {
                                    publicId,
                                    callLogId: publicId,
                                    direction: "OUTBOUND",
                                    status: "PENDING",
                                    startedAt: new Date(),
                                    companyId,
                                    campaignId: isValidObjectId ? campaignId : null,
                                    durationSeconds: 0,
                                    provider: "BONVOICE",
                                    providerCallId: `pending-${publicId}`,
                                    leadId: leadRecordId
                                }
                            });
                            const controller = new AbortController();
                            const timeoutId = setTimeout(() => controller.abort(), 15000);
                            const template_url = process.env.BONVOICE_VOICEBOT_URL || "wss://vineeth-inbound.onrender.com/ws/voice-agent";
                            const res = await fetch(`${BONVOICE_API_URL}/click2call/`, {
                                method: "POST",
                                headers: {
                                    "Content-Type": "application/json",
                                    "Accept": "application/json",
                                    Authorization: `Token ${token}`,
                                },
                                body: JSON.stringify({
                                    source_number: didNumber,
                                    destination_number: lead.phone.replace(/\D/g, "").slice(-10),
                                    template_url: template_url,
                                    reference_id: callLog.id
                                }),
                                signal: controller.signal,
                            });
                            clearTimeout(timeoutId);
                            if (!res.ok) {
                                const errText = await res.text();
                                console.error(`Failed to push lead ${lead.phone} to Bonvoice:`, errText);
                                await markAsFailed(lead.phone, didNumber);
                                await updateRedisState((prev) => {
                                    const updatedLeads = (prev.leads || []).map((l) => l.phone === lead.phone ? { ...l, called: true, isFailed: true } : l);
                                    return { ...prev, leads: updatedLeads, failedCalls: updatedLeads.filter((l) => l.isFailed).length, completedCalls: prev.completedCalls + 1 };
                                });
                                activeCallCount--;
                                completedCount++;
                            }
                            else {
                                try {
                                    const responseData = await res.json();
                                    const returnedCallId = responseData.uuid || responseData.callID || responseData.call_id || responseData.data?.uuid || responseData.data?.callID;
                                    if (returnedCallId) {
                                        await prisma_1.default.callLog.update({
                                            where: { id: callLog.id },
                                            data: { providerCallId: String(returnedCallId) }
                                        });
                                    }
                                }
                                catch (e) {
                                    console.error("Failed to parse Bonvoice response", e);
                                }
                                activeCallIds.add(callLog.id);
                                leadPhoneMap.set(callLog.id, lead.phone);
                                activeCallTimeouts.set(callLog.id, Date.now());
                            }
                        }
                        catch (err) {
                            console.error(`Failed to push lead ${lead.phone}:`, err.message);
                            await markAsFailed(lead.phone, didNumber);
                            await updateRedisState((prev) => {
                                const updatedLeads = (prev.leads || []).map((l) => l.phone === lead.phone ? { ...l, called: true, isFailed: true } : l);
                                return { ...prev, leads: updatedLeads, failedCalls: updatedLeads.filter((l) => l.isFailed).length, completedCalls: prev.completedCalls + 1 };
                            });
                            activeCallCount--;
                            completedCount++;
                        }
                    })());
                }
                if (batchPromises.length > 0) {
                    await Promise.all(batchPromises);
                }
                if (activeCallCount === 0 && currentIndex < leads.length) {
                    await new Promise(resolve => setTimeout(resolve, 1000));
                }
                if (activeCallCount > 0) {
                    await new Promise(resolve => setTimeout(resolve, 3000));
                    try {
                        if (activeCallIds.size > 0) {
                            const dbCalls = await prisma_1.default.callLog.findMany({
                                where: { id: { in: Array.from(activeCallIds) } }
                            });
                            let newlyFinishedCount = 0;
                            const finishedPhones = [];
                            for (const callLogId of Array.from(activeCallIds)) {
                                const c = dbCalls.find(dbC => dbC.id === callLogId);
                                const phone = leadPhoneMap.get(callLogId) || "";
                                const timeElapsed = Date.now() - (activeCallTimeouts.get(callLogId) || 0);
                                const hasTimedOut = timeElapsed > CALL_TIMEOUT_MS;
                                let isFinished = false;
                                let isFailed = false;
                                if (!c || hasTimedOut) {
                                    isFinished = true;
                                    isFailed = true;
                                    if (hasTimedOut && c) {
                                        await prisma_1.default.callLog.update({ where: { id: callLogId }, data: { status: "FAILED" } }).catch(() => { });
                                    }
                                }
                                else {
                                    const status = c.status?.toLowerCase() || "";
                                    if (!["pending", "ringing", "queued", "dispatching", "queued_at_provider", "answered", "in-progress"].includes(status)) {
                                        isFinished = true;
                                        if (["failed", "missed", "busy", "no-answer", "cancelled"].includes(status)) {
                                            isFailed = true;
                                        }
                                    }
                                }
                                if (isFinished) {
                                    activeCallIds.delete(callLogId);
                                    activeCallTimeouts.delete(callLogId);
                                    leadPhoneMap.delete(callLogId);
                                    activeCallCount--;
                                    completedCount++;
                                    newlyFinishedCount++;
                                    finishedPhones.push({ phone, isFailed });
                                }
                            }
                            if (newlyFinishedCount > 0) {
                                await updateRedisState(prev => {
                                    const updatedLeads = (prev.leads || []).map((l) => {
                                        const finishedEntry = finishedPhones.find(fp => fp.phone === l.phone);
                                        if (finishedEntry) {
                                            return { ...l, called: true, isFailed: finishedEntry.isFailed };
                                        }
                                        return l;
                                    });
                                    const totalFailed = updatedLeads.filter((l) => l.isFailed).length;
                                    const totalSuccessful = updatedLeads.filter((l) => l.called && !l.isFailed).length;
                                    return {
                                        ...prev,
                                        completedCalls: completedCount,
                                        leads: updatedLeads,
                                        failedCalls: totalFailed,
                                        successfulCalls: totalSuccessful
                                    };
                                });
                            }
                        }
                    }
                    catch (pollErr) {
                        console.error("Failed to poll call status in worker", pollErr);
                    }
                }
            }
            if (!shouldAbort) {
                let finalState = null;
                await updateRedisState(prev => {
                    if (prev.status === "force_stopped" || prev.status === "idle")
                        return prev;
                    finalState = {
                        ...prev,
                        status: "completed",
                        completedCalls: prev.leads?.length || 0,
                    };
                    return finalState;
                });
                console.log(`Campaign completed for company: ${companyId}`);
                if (finalState && finalState.leads) {
                    const failedLeads = finalState.leads.filter((l) => l.isFailed);
                    if (failedLeads.length > 0) {
                        const dbCampaign = await prisma_1.default.campaign.findUnique({ where: { id: campaignId } });
                        if (dbCampaign) {
                            let nextStage = null;
                            let nextHour = 0;
                            if (dbCampaign.stage === "MAIN") {
                                nextStage = "Q1";
                                nextHour = 11;
                            }
                            else if (dbCampaign.stage === "Q1") {
                                nextStage = "Q2";
                                nextHour = 14;
                            }
                            else if (dbCampaign.stage === "Q2") {
                                nextStage = "Q3";
                                nextHour = 17;
                            }
                            if (nextStage) {
                                try {
                                    const nextResourceKey = `${dbCampaign.resourceKey}-${nextStage}-${Date.now().toString().slice(-4)}`;
                                    const nextCampaign = await prisma_1.default.campaign.create({
                                        data: {
                                            companyId,
                                            resourceKey: nextResourceKey,
                                            name: `${dbCampaign.name} - Reactivation ${nextStage}`,
                                            stage: nextStage,
                                            parentCampaignId: dbCampaign.parentCampaignId || dbCampaign.id,
                                            direction: dbCampaign.direction,
                                            aiEnabled: dbCampaign.aiEnabled,
                                            systemPrompt: dbCampaign.systemPrompt,
                                            aiConfig: dbCampaign.aiConfig || {},
                                            status: "ACTIVE"
                                        }
                                    });
                                    const now = new Date();
                                    const nextDay = new Date(now);
                                    nextDay.setDate(nextDay.getDate() + 1);
                                    nextDay.setHours(nextHour, 0, 0, 0);
                                    if (nextDay.getTime() <= now.getTime()) {
                                        nextDay.setDate(nextDay.getDate() + 1);
                                    }
                                    const delayMs = nextDay.getTime() - now.getTime();
                                    const { startCampaignJob } = require('./campaign-execution.queue');
                                    await startCampaignJob({
                                        companyId,
                                        campaignId: nextCampaign.id,
                                        didNumber,
                                        leads: failedLeads.map((l) => ({ phone: l.phone, name: l.name })),
                                        channels,
                                        isReactivation: true,
                                        qStage: nextStage,
                                        scheduledAt: nextDay.toISOString(),
                                        uploadedFileName: job.data.uploadedFileName
                                    }, delayMs);
                                    console.log(`[Reactivation Engine] Scheduled ${nextStage} for Campaign ${campaignId} at ${nextDay.toISOString()} with ${failedLeads.length} leads.`);
                                }
                                catch (reactivationError) {
                                    console.error(`[Reactivation Engine] Failed to schedule ${nextStage} for Campaign ${campaignId}:`, reactivationError);
                                }
                            }
                            else {
                                console.log(`[Reactivation Engine] Campaign ${campaignId} reached final stage (Q3). No further reactivations.`);
                            }
                        }
                    }
                    else {
                        console.log(`[Reactivation Engine] Campaign ${campaignId} had 100% success! No reactivation needed.`);
                    }
                }
            }
            else {
                console.log(`Campaign loop aborted for company: ${companyId}, skipping completion state.`);
            }
            try {
                const pausedStateStr = await redis_client_1.redisConnection.get(`campaign-state:paused:${companyId}`);
                if (pausedStateStr) {
                    const pausedState = JSON.parse(pausedStateStr);
                    if (!job.data.isReactivation) {
                        console.log(`[Traffic Cop] Live Campaign finished. Auto-resuming Reactivation for company ${companyId}`);
                        const resumedState = { ...pausedState, status: "running" };
                        await redis_client_1.redisConnection.set(`campaign-state:${companyId}`, JSON.stringify(resumedState));
                        await redis_client_1.redisConnection.del(`campaign-state:paused:${companyId}`);
                        const gateway = campaign_gateway_1.CampaignGateway.getInstance();
                        if (gateway)
                            gateway.broadcastCampaignUpdate(companyId, resumedState);
                    }
                }
                else {
                    const currentStateStr = await redis_client_1.redisConnection.get(`campaign-state:${companyId}`);
                    if (currentStateStr) {
                        const currentState = JSON.parse(currentStateStr);
                        if (currentState.status === "completed" || currentState.status === "force_stopped" || shouldAbort) {
                        }
                    }
                }
            }
            catch (resumeErr) {
                console.error("Failed to auto-resume paused reactivation:", resumeErr);
            }
        }
        catch (error) {
            console.error("Campaign worker error:", error);
            const stateStr = await redis_client_1.redisConnection.get(`campaign-state:${companyId}`);
            if (stateStr) {
                const state = JSON.parse(stateStr);
                state.status = "failed";
                state.error = error.message;
                await redis_client_1.redisConnection.set(`campaign-state:${companyId}`, JSON.stringify(state));
            }
            throw error;
        }
    }, {
        connection: redis_client_1.redisConnection,
        concurrency: 5,
    })
    : null;
//# sourceMappingURL=campaign-execution.worker.js.map