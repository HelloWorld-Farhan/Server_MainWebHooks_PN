"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveOrMergeUserFromClerk = resolveOrMergeUserFromClerk;
exports.syncTenantFromClerk = syncTenantFromClerk;
exports.activateMembershipFromClerkOrg = activateMembershipFromClerkOrg;
exports.reconcileInviteMembershipOnLogin = reconcileInviteMembershipOnLogin;
exports.ensureActiveCompanyMembership = ensureActiveCompanyMembership;
exports.handleClerkWebhookEvent = handleClerkWebhookEvent;
const clerk_1 = require("../../auth/clerk");
const user_metadata_1 = require("../../lib/user-metadata");
const clerk_config_1 = require("../lib/clerk-config");
const clerk_sync_1 = require("../lib/clerk-sync");
const prisma_1 = require("../lib/prisma");
const tenant_repository_1 = require("../repositories/tenant.repository");
const cache_service_1 = require("../cache/cache.service");
const clerk_membership_service_1 = require("./clerk-membership.service");
const resolution_metrics_1 = require("../lib/resolution-metrics");
const tenantRepo = new tenant_repository_1.TenantRepository(prisma_1.prisma);
const pendingReconciles = new Map();
function reconcileKey(clerkUserId, orgId) {
    return `${clerkUserId}:${orgId ?? ""}`;
}
async function ensureCreditBalance(companyId) {
    await prisma_1.prisma.creditBalance.upsert({
        where: { companyId },
        create: {
            companyId,
            creditsRemaining: 0,
            creditsUsed: 0,
        },
        update: {},
    });
}
function getPrimaryEmail(clerkUser) {
    return (clerkUser.emailAddresses.find((e) => e.id === clerkUser.primaryEmailAddressId)?.emailAddress ?? clerkUser.emailAddresses[0]?.emailAddress ?? null);
}
async function upsertDbUserFromClerk(clerkUserId, clerkUser, phone) {
    const primaryEmail = getPrimaryEmail(clerkUser);
    if (!primaryEmail) {
        throw new Error("User email is required");
    }
    return tenantRepo.upsertUser({
        clerkUserId,
        email: primaryEmail,
        firstName: clerkUser.firstName,
        lastName: clerkUser.lastName,
        imageUrl: clerkUser.imageUrl,
        phone: phone?.trim() || clerkUser.phoneNumbers[0]?.phoneNumber,
    });
}
function isPendingClerkUserId(clerkUserId) {
    return clerkUserId.startsWith("pending:");
}
async function mergePendingUserWithClerkId(clerkUserId, clerkUser, phone) {
    const primaryEmail = getPrimaryEmail(clerkUser);
    if (!primaryEmail) {
        return null;
    }
    const pendingUser = await tenantRepo.findUserByEmail(primaryEmail);
    if (!pendingUser || !isPendingClerkUserId(pendingUser.clerkUserId)) {
        return null;
    }
    return prisma_1.prisma.user.update({
        where: { id: pendingUser.id },
        data: {
            clerkUserId,
            status: "ACTIVE",
            firstName: clerkUser.firstName,
            lastName: clerkUser.lastName,
            imageUrl: clerkUser.imageUrl,
            phone: phone?.trim() || clerkUser.phoneNumbers[0]?.phoneNumber,
        },
    });
}
async function resolveOrMergeUserFromClerk(clerkUserId, phone) {
    const existing = await tenantRepo.findUserByClerkId(clerkUserId);
    if (existing) {
        return existing;
    }
    const client = clerk_1.clerkClient;
    let clerkUser;
    try {
        clerkUser = await client.users.getUser(clerkUserId);
    }
    catch {
        return null;
    }
    const merged = await mergePendingUserWithClerkId(clerkUserId, clerkUser, phone);
    if (merged) {
        return merged;
    }
    try {
        return await upsertDbUserFromClerk(clerkUserId, clerkUser, phone);
    }
    catch {
        const primaryEmail = getPrimaryEmail(clerkUser);
        if (!primaryEmail) {
            return null;
        }
        const byEmail = await tenantRepo.findUserByEmail(primaryEmail);
        if (!byEmail) {
            return null;
        }
        return prisma_1.prisma.user.update({
            where: { id: byEmail.id },
            data: {
                clerkUserId,
                status: "ACTIVE",
                firstName: clerkUser.firstName,
                lastName: clerkUser.lastName,
                imageUrl: clerkUser.imageUrl,
                phone: phone?.trim() || clerkUser.phoneNumbers[0]?.phoneNumber,
            },
        });
    }
}
async function ensureCompanyForClerkOrg(clerkOrganizationId, data) {
    return tenantRepo.upsertCompany({
        clerkOrganizationId,
        name: data.name,
        slug: data.slug,
        primaryUseCase: data.primaryUseCase,
        callVolume: data.callVolume,
    });
}
async function linkUserToCompany(dbUser, company, role = "OWNER") {
    await tenantRepo.upsertMembership({
        companyId: company.id,
        userId: dbUser.id,
        role,
    });
    await ensureCreditBalance(company.id);
}
async function getActiveCompanyForUser(userId) {
    const membership = await prisma_1.prisma.companyMember.findFirst({
        where: { userId, status: "ACTIVE" },
        include: { company: true },
        orderBy: { joinedAt: "desc" },
    });
    return membership?.company ?? null;
}
async function provisionFromClerkOrgMembership(dbUser, membership, metadata) {
    const org = membership.organization;
    const company = await ensureCompanyForClerkOrg(org.id, {
        name: org.name,
        slug: (0, clerk_sync_1.companySlugFromName)(org.name),
        primaryUseCase: metadata?.primaryUseCase,
        callVolume: metadata?.callVolume,
    });
    const role = membership.role === "org:admin"
        ? "OWNER"
        : (0, clerk_sync_1.mapClerkRoleToUserRole)(membership.role);
    await linkUserToCompany(dbUser, company, role);
    return company;
}
async function getClerkOrgMemberships(clerkUserId) {
    return clerk_membership_service_1.clerkMembershipService.getUserMemberships(clerkUserId);
}
async function getClerkMembershipInOrg(clerkUserId, clerkOrganizationId) {
    return clerk_membership_service_1.clerkMembershipService.getMembershipInOrg(clerkUserId, clerkOrganizationId);
}
async function syncTenantFromClerk(clerkUserId) {
    const client = clerk_1.clerkClient;
    let clerkUser;
    try {
        clerkUser = await client.users.getUser(clerkUserId);
    }
    catch {
        return null;
    }
    const metadata = (0, user_metadata_1.getUserMetadata)(clerkUser.unsafeMetadata);
    let dbUser;
    try {
        dbUser = await resolveOrMergeUserFromClerk(clerkUserId, metadata.phone);
    }
    catch {
        return null;
    }
    if (!dbUser) {
        return null;
    }
    const existingCompany = await getActiveCompanyForUser(dbUser.id);
    if (existingCompany) {
        return existingCompany;
    }
    const orgMemberships = await getClerkOrgMemberships(clerkUserId);
    if (orgMemberships.data.length > 0) {
        return provisionFromClerkOrgMembership(dbUser, orgMemberships.data[0], {
            primaryUseCase: metadata.primaryUseCase,
            callVolume: metadata.callVolume,
        });
    }
    return null;
}
async function applyBranchAccessFromInvitation(memberId, campaignAccessType, campaignIds) {
    await prisma_1.prisma.memberCampaignAccess.deleteMany({ where: { memberId } });
    if (campaignAccessType === "SELECTED" && campaignIds.length > 0) {
        await prisma_1.prisma.memberCampaignAccess.createMany({
            data: campaignIds.map((campaignId) => ({ memberId, campaignId })),
        });
    }
}
async function resolveCompanyForClerkOrgActivation(clerkOrganizationId, userEmail, userId) {
    const byOrgId = await tenantRepo.findCompanyByClerkOrgId(clerkOrganizationId);
    if (byOrgId) {
        return byOrgId;
    }
    const invitation = await prisma_1.prisma.invitation.findFirst({
        where: {
            clerkOrganizationId,
            email: { equals: userEmail, mode: "insensitive" },
            status: { in: ["PENDING", "ACCEPTED"] },
        },
        orderBy: { createdAt: "desc" },
    });
    if (invitation) {
        const fromInvite = await prisma_1.prisma.company.findUnique({
            where: { id: invitation.companyId },
        });
        if (fromInvite) {
            return fromInvite;
        }
    }
    const campaignInvitation = await prisma_1.prisma.campaignInvitation.findFirst({
        where: {
            clerkOrganizationId,
            email: { equals: userEmail, mode: "insensitive" },
            status: { in: ["PENDING", "ACCEPTED"] },
        },
        orderBy: { createdAt: "desc" },
    });
    if (campaignInvitation) {
        const fromBranchInvite = await prisma_1.prisma.company.findUnique({
            where: { id: campaignInvitation.companyId },
        });
        if (fromBranchInvite) {
            return fromBranchInvite;
        }
    }
    const invitedMembership = await prisma_1.prisma.companyMember.findFirst({
        where: { userId, status: "INVITED" },
        include: { company: true },
        orderBy: { invitedAt: "desc" },
    });
    return invitedMembership?.company ?? null;
}
async function activateMembershipFromClerkOrg(clerkOrganizationId, clerkUserId, role, metadata, targetCompanyId) {
    const user = await resolveOrMergeUserFromClerk(clerkUserId);
    if (!user) {
        return;
    }
    let company = targetCompanyId
        ? await prisma_1.prisma.company.findUnique({ where: { id: targetCompanyId } })
        : null;
    if (!company) {
        company = await resolveCompanyForClerkOrgActivation(clerkOrganizationId, user.email, user.id);
    }
    if (!company) {
        return;
    }
    if (company.clerkOrganizationId !== clerkOrganizationId) {
        company = await prisma_1.prisma.company.update({
            where: { id: company.id },
            data: { clerkOrganizationId },
        });
    }
    const resolvedRole = metadata?.propnexRole ?? role;
    let campaignAccessType = metadata?.campaignAccessType ?? "ALL";
    let campaignIds = metadata?.campaignIds ?? [];
    let finalRole = resolvedRole;
    if (!metadata?.propnexRole || !metadata?.campaignAccessType) {
        const pendingInvite = await prisma_1.prisma.invitation.findFirst({
            where: {
                companyId: company.id,
                email: { equals: user.email, mode: "insensitive" },
                status: { in: ["PENDING", "ACCEPTED"] },
            },
            orderBy: { createdAt: "desc" },
        });
        if (pendingInvite) {
            if (!metadata?.propnexRole) {
                finalRole = pendingInvite.role;
            }
            if (!metadata?.campaignAccessType) {
                campaignAccessType = pendingInvite.campaignAccessType;
                campaignIds = pendingInvite.campaignIds;
            }
        }
        else {
            const pendingCampaignInvite = await prisma_1.prisma.campaignInvitation.findFirst({
                where: {
                    companyId: company.id,
                    email: { equals: user.email, mode: "insensitive" },
                    status: { in: ["PENDING", "ACCEPTED"] },
                },
                orderBy: { createdAt: "desc" },
            });
            if (pendingCampaignInvite) {
                if (!metadata?.propnexRole) {
                    finalRole = "ADMIN";
                }
                if (!metadata?.campaignAccessType) {
                    campaignAccessType = "SELECTED";
                    campaignIds = [pendingCampaignInvite.campaignId];
                }
            }
        }
    }
    const existingMembership = await prisma_1.prisma.companyMember.findFirst({
        where: { companyId: company.id, userId: user.id },
    });
    const wasAlreadyActive = existingMembership?.status === "ACTIVE";
    let membership;
    if (existingMembership) {
        membership = await prisma_1.prisma.companyMember.update({
            where: { id: existingMembership.id },
            data: {
                role: finalRole,
                status: "ACTIVE",
                jobTitle: metadata?.jobTitle ?? undefined,
                campaignAccessType,
                joinedAt: new Date(),
            },
        });
    }
    else {
        membership = await prisma_1.prisma.companyMember.create({
            data: {
                companyId: company.id,
                userId: user.id,
                role: finalRole,
                status: "ACTIVE",
                jobTitle: metadata?.jobTitle ?? null,
                campaignAccessType,
                joinedAt: new Date(),
            },
        });
    }
    await applyBranchAccessFromInvitation(membership.id, campaignAccessType, campaignIds);
    await prisma_1.prisma.invitation.updateMany({
        where: {
            companyId: company.id,
            email: { equals: user.email, mode: "insensitive" },
            status: "PENDING",
        },
        data: { status: "ACCEPTED" },
    });
    await prisma_1.prisma.campaignInvitation.updateMany({
        where: {
            companyId: company.id,
            email: { equals: user.email, mode: "insensitive" },
            status: "PENDING",
        },
        data: {
            status: "ACCEPTED",
            acceptedAt: new Date(),
        },
    });
    if (isPendingClerkUserId(user.clerkUserId)) {
        await prisma_1.prisma.user.update({
            where: { id: user.id },
            data: { clerkUserId, status: "ACTIVE" },
        });
    }
    await ensureCreditBalance(company.id);
    if (!wasAlreadyActive) {
        await cache_service_1.cacheService.invalidateClerkMembershipCaches(clerkUserId, clerkOrganizationId);
    }
}
async function ensureMembershipFromWebhook(clerkOrganizationId, clerkUserId, role, metadata) {
    await activateMembershipFromClerkOrg(clerkOrganizationId, clerkUserId, role, metadata);
}
async function tryActivateInvitedMembershipFromInvitation(companyId, clerkUserId, user, orgId) {
    if (!clerkUserId.startsWith("user_")) {
        return false;
    }
    const invitedMembership = await prisma_1.prisma.companyMember.findFirst({
        where: { companyId, userId: user.id, status: "INVITED" },
    });
    if (!invitedMembership) {
        return false;
    }
    const company = await prisma_1.prisma.company.findUnique({ where: { id: companyId } });
    const invitation = await prisma_1.prisma.invitation.findFirst({
        where: {
            companyId,
            email: { equals: user.email, mode: "insensitive" },
            status: { in: ["PENDING", "ACCEPTED"] },
        },
        orderBy: { createdAt: "desc" },
    });
    if (!invitation) {
        return false;
    }
    const clerkOrganizationId = orgId ??
        invitation.clerkOrganizationId ??
        company?.clerkOrganizationId;
    if (!clerkOrganizationId?.startsWith("org_")) {
        return false;
    }
    await activateMembershipFromClerkOrg(clerkOrganizationId, clerkUserId, invitation.role, {
        propnexRole: invitation.role,
        campaignAccessType: invitation.campaignAccessType,
        campaignIds: invitation.campaignIds,
        jobTitle: invitation.jobTitle,
    }, companyId);
    const activated = await prisma_1.prisma.companyMember.findFirst({
        where: { companyId, userId: user.id, status: "ACTIVE" },
    });
    return Boolean(activated);
}
async function activateInvitedMembershipForCompany(companyId, clerkUserId, user, orgId) {
    const activeMembership = await prisma_1.prisma.companyMember.findFirst({
        where: { companyId, userId: user.id, status: "ACTIVE" },
    });
    if (activeMembership) {
        return true;
    }
    const invitedMembership = await prisma_1.prisma.companyMember.findFirst({
        where: { companyId, userId: user.id, status: "INVITED" },
    });
    if (!invitedMembership) {
        return false;
    }
    const company = await prisma_1.prisma.company.findUnique({ where: { id: companyId } });
    const invitation = await prisma_1.prisma.invitation.findFirst({
        where: {
            companyId,
            email: { equals: user.email, mode: "insensitive" },
            status: { in: ["PENDING", "ACCEPTED"] },
        },
        orderBy: { createdAt: "desc" },
    });
    const clerkOrgIds = [
        orgId,
        company?.clerkOrganizationId,
        invitation?.clerkOrganizationId,
    ].filter((id) => Boolean(id?.startsWith("org_")));
    const uniqueClerkOrgIds = [...new Set(clerkOrgIds)];
    for (const clerkOrganizationId of uniqueClerkOrgIds) {
        const clerkMembership = await getClerkMembershipInOrg(clerkUserId, clerkOrganizationId);
        if (!clerkMembership) {
            continue;
        }
        const role = (0, clerk_sync_1.mapClerkRoleToUserRole)(clerkMembership.role);
        const publicMetadata = (clerkMembership.publicMetadata ??
            {});
        await activateMembershipFromClerkOrg(clerkOrganizationId, clerkUserId, role, publicMetadata, companyId);
        const activated = await prisma_1.prisma.companyMember.findFirst({
            where: { companyId, userId: user.id, status: "ACTIVE" },
        });
        if (activated) {
            return true;
        }
    }
    return tryActivateInvitedMembershipFromInvitation(companyId, clerkUserId, user, orgId);
}
async function reconcilePendingCampaignInvitations(user, clerkUserId, orgId) {
    const pendingCampaignInvitations = await prisma_1.prisma.campaignInvitation.findMany({
        where: {
            email: { equals: user.email, mode: "insensitive" },
            status: "PENDING",
        },
        select: { id: true, companyId: true, clerkOrganizationId: true },
    });
    if (pendingCampaignInvitations.length === 0) {
        return;
    }
    for (const campaignInvite of pendingCampaignInvitations) {
        const activeMembership = await prisma_1.prisma.companyMember.findFirst({
            where: { companyId: campaignInvite.companyId, userId: user.id, status: "ACTIVE" },
        });
        if (!activeMembership) {
            continue;
        }
        await prisma_1.prisma.campaignInvitation.update({
            where: { id: campaignInvite.id },
            data: {
                status: "ACCEPTED",
                acceptedAt: new Date(),
            },
        });
        (0, resolution_metrics_1.logResolutionEvent)("clerk:reconcile:campaign-invitation-accepted", {
            clerkUserId,
            orgId,
            campaignInvitationId: campaignInvite.id,
            companyId: campaignInvite.companyId,
        });
    }
}
async function reconcileInviteMembershipOnLoginInner(clerkUserId, orgId) {
    const start = performance.now();
    const user = await resolveOrMergeUserFromClerk(clerkUserId);
    if (!user) {
        return;
    }
    const invitedMembership = await prisma_1.prisma.companyMember.findFirst({
        where: { userId: user.id, status: "INVITED" },
    });
    const pendingCampaignInvite = await prisma_1.prisma.campaignInvitation.findFirst({
        where: {
            email: { equals: user.email, mode: "insensitive" },
            status: "PENDING",
        },
    });
    if (!invitedMembership && !pendingCampaignInvite) {
        await reconcilePendingCampaignInvitations(user, clerkUserId, orgId);
        return;
    }
    const orgMemberships = await getClerkOrgMemberships(clerkUserId);
    if (orgMemberships.data.length === 0) {
        const invitedMemberships = await prisma_1.prisma.companyMember.findMany({
            where: { userId: user.id, status: "INVITED" },
            select: { companyId: true },
        });
        for (const invited of invitedMemberships) {
            await activateInvitedMembershipForCompany(invited.companyId, clerkUserId, user, orgId);
        }
        const pendingCampaignInvites = await prisma_1.prisma.campaignInvitation.findMany({
            where: {
                email: { equals: user.email, mode: "insensitive" },
                status: "PENDING",
            },
            select: { companyId: true },
        });
        for (const campaignInv of pendingCampaignInvites) {
            await activateInvitedMembershipForCompany(campaignInv.companyId, clerkUserId, user, orgId);
        }
        (0, resolution_metrics_1.recordReconciliationDuration)(Math.round(performance.now() - start));
        (0, resolution_metrics_1.logResolutionEvent)("clerk:reconcile:fallback", {
            clerkUserId,
            orgId,
            invitedCount: invitedMemberships.length + pendingCampaignInvites.length,
        });
        return;
    }
    const ordered = orgId
        ? [
            ...orgMemberships.data.filter((membership) => membership.organization.id === orgId),
            ...orgMemberships.data.filter((membership) => membership.organization.id !== orgId),
        ]
        : orgMemberships.data;
    for (const clerkMembership of ordered) {
        const role = (0, clerk_sync_1.mapClerkRoleToUserRole)(clerkMembership.role);
        const publicMetadata = (clerkMembership.publicMetadata ??
            {});
        await activateMembershipFromClerkOrg(clerkMembership.organization.id, clerkUserId, role, publicMetadata);
    }
    (0, resolution_metrics_1.recordReconciliationDuration)(Math.round(performance.now() - start));
    (0, resolution_metrics_1.logResolutionEvent)("clerk:reconcile:done", {
        clerkUserId,
        orgId,
        membershipCount: ordered.length,
    });
}
async function reconcileInviteMembershipOnLogin(clerkUserId, orgId) {
    const key = reconcileKey(clerkUserId, orgId);
    const pending = pendingReconciles.get(key);
    if (pending) {
        return pending;
    }
    const promise = reconcileInviteMembershipOnLoginInner(clerkUserId, orgId);
    pendingReconciles.set(key, promise);
    try {
        await promise;
    }
    finally {
        pendingReconciles.delete(key);
    }
}
async function ensureActiveCompanyMembership(companyId, clerkUserId, orgId) {
    const user = await resolveOrMergeUserFromClerk(clerkUserId);
    if (!user) {
        return;
    }
    const activeMembership = await prisma_1.prisma.companyMember.findFirst({
        where: { companyId, userId: user.id, status: "ACTIVE" },
    });
    if (activeMembership) {
        return;
    }
    await reconcileInviteMembershipOnLogin(clerkUserId, orgId);
    const activeAfterReconcile = await prisma_1.prisma.companyMember.findFirst({
        where: { companyId, userId: user.id, status: "ACTIVE" },
    });
    if (activeAfterReconcile) {
        return;
    }
    await activateInvitedMembershipForCompany(companyId, clerkUserId, user, orgId);
}
async function handleClerkWebhookEvent(type, data) {
    if (!(0, clerk_config_1.isClerkWebhooksEnabled)()) {
        return;
    }
    switch (type) {
        case "user.created":
        case "user.updated": {
            const clerkUserId = data.id;
            if (!clerkUserId)
                return;
            await resolveOrMergeUserFromClerk(clerkUserId);
            break;
        }
        case "organization.created":
        case "organization.updated": {
            const clerkOrganizationId = data.id;
            const name = data.name ?? "Company";
            if (!clerkOrganizationId)
                return;
            const existing = await tenantRepo.findCompanyByClerkOrgId(clerkOrganizationId);
            if (!existing) {
                return;
            }
            await tenantRepo.upsertCompany({
                clerkOrganizationId,
                name,
                slug: (0, clerk_sync_1.companySlugFromName)(name),
            });
            break;
        }
        case "organizationMembership.created":
        case "organizationMembership.updated": {
            const clerkOrganizationId = data.organization_id;
            const clerkUserId = data.public_user_data
                ? data.public_user_data.user_id
                : data.user_id;
            const role = (0, clerk_sync_1.mapClerkRoleToUserRole)(data.role ?? "org:member");
            const publicMetadata = (data.public_metadata ?? {});
            if (!clerkOrganizationId || !clerkUserId)
                return;
            await ensureMembershipFromWebhook(clerkOrganizationId, clerkUserId, role, publicMetadata);
            break;
        }
        case "organizationMembership.deleted": {
            const clerkOrganizationId = data.organization_id;
            const clerkUserId = data.public_user_data
                ? data.public_user_data.user_id
                : data.user_id;
            const company = await tenantRepo.findCompanyByClerkOrgId(clerkOrganizationId);
            const user = await tenantRepo.findUserByClerkId(clerkUserId);
            if (!company || !user)
                return;
            await prisma_1.prisma.companyMember.updateMany({
                where: { companyId: company.id, userId: user.id },
                data: { status: "REMOVED" },
            });
            await cache_service_1.cacheService.invalidateClerkMembershipCaches(clerkUserId, clerkOrganizationId);
            break;
        }
        case "session.created": {
            const clerkUserId = data.user_id;
            if (!clerkUserId)
                return;
            await prisma_1.prisma.user.updateMany({
                where: { clerkUserId },
                data: { lastLoginAt: new Date() },
            });
            break;
        }
        default:
            break;
    }
}
//# sourceMappingURL=clerk-provision.service.js.map