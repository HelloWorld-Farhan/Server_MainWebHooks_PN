"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChannelsModule = void 0;
const common_1 = require("@nestjs/common");
const redis_client_1 = require("../cache/redis.client");
const channel_queue_worker_1 = require("./channel-queue.worker");
const channel_reconciliation_service_1 = require("./channel-reconciliation.service");
let ChannelsModule = class ChannelsModule {
    reconciliation;
    constructor(reconciliation) {
        this.reconciliation = reconciliation;
    }
    async onModuleInit() {
        if ((0, redis_client_1.isRedisDisabled)()) {
            console.warn("[channels] REDIS_ENABLED=false; skipping Redis connect, reconcile, and queue worker gating");
            return;
        }
        await (0, redis_client_1.connectRedisOnStartup)();
        void this.reconciliation.reconcileAll().catch((error) => {
            console.error("[channels] startup reconciliation failed; workers will continue with current Redis state", error);
        });
    }
};
exports.ChannelsModule = ChannelsModule;
exports.ChannelsModule = ChannelsModule = __decorate([
    (0, common_1.Module)({
        providers: [channel_reconciliation_service_1.ChannelReconciliationService, channel_queue_worker_1.ChannelQueueWorker],
    }),
    __metadata("design:paramtypes", [channel_reconciliation_service_1.ChannelReconciliationService])
], ChannelsModule);
//# sourceMappingURL=channels.module.js.map