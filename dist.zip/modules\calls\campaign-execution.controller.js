"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OutboundCampaignExecutionController = void 0;
const common_1 = require("@nestjs/common");
const jwt = __importStar(require("jsonwebtoken"));
const prisma_1 = __importDefault(require("../../server/lib/prisma"));
const campaign_execution_queue_1 = require("../../server/queues/campaign-execution.queue");
const JWT_SECRET = process.env.JWT_SECRET || "propnex_secret_jwt_key_2026_key";
async function getCompanyIdFromToken(req) {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer "))
        return null;
    const token = authHeader.split(" ")[1];
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        const userId = decoded.sub || decoded.id;
        if (!userId)
            return null;
        const member = await prisma_1.default.companyMember.findFirst({
            where: { userId, status: "ACTIVE" }
        });
        return member?.companyId || null;
    }
    catch (err) {
        return null;
    }
}
let OutboundCampaignExecutionController = class OutboundCampaignExecutionController {
    async startCampaign(req, res) {
        const tokenCompanyId = await getCompanyIdFromToken(req);
        if (!tokenCompanyId) {
            return res.status(401).json({ error: "Unauthorized" });
        }
        try {
            const { campaignId, didNumber, leads, channels, companyId: requestedCompanyId, uploadedFileName } = req.body;
            let finalCompanyId = tokenCompanyId;
            if (requestedCompanyId && requestedCompanyId !== tokenCompanyId) {
                const subCompany = await prisma_1.default.company.findFirst({
                    where: { id: requestedCompanyId, parentCompanyId: tokenCompanyId }
                });
                if (!subCompany) {
                    return res.status(403).json({ error: "Forbidden: Not a valid sub-company" });
                }
                finalCompanyId = requestedCompanyId;
            }
            if (!didNumber || !leads || leads.length === 0) {
                return res.status(400).json({ error: "Missing required parameters" });
            }
            await (0, campaign_execution_queue_1.startCampaignJob)({
                companyId: finalCompanyId,
                campaignId: campaignId || "manual",
                didNumber,
                leads,
                channels: channels || 2,
                uploadedFileName
            });
            return res.json({ success: true, message: "Campaign queued successfully" });
        }
        catch (e) {
            console.error("Failed to start campaign", e);
            return res.status(500).json({ error: e.message });
        }
    }
    async getStatus(req, res) {
        const tokenCompanyId = await getCompanyIdFromToken(req);
        if (!tokenCompanyId) {
            return res.status(401).json({ error: "Unauthorized" });
        }
        try {
            const requestedCompanyId = req.query.companyId;
            let finalCompanyId = tokenCompanyId;
            if (requestedCompanyId && requestedCompanyId !== tokenCompanyId) {
                const subCompany = await prisma_1.default.company.findFirst({
                    where: { id: requestedCompanyId, parentCompanyId: tokenCompanyId }
                });
                if (!subCompany) {
                    return res.status(403).json({ error: "Forbidden: Not a valid sub-company" });
                }
                finalCompanyId = requestedCompanyId;
            }
            const state = await (0, campaign_execution_queue_1.getCampaignState)(finalCompanyId);
            return res.json({ success: true, data: state });
        }
        catch (e) {
            console.error("Failed to fetch campaign state", e);
            return res.status(500).json({ error: e.message });
        }
    }
    async clearCampaign(req, res) {
        const tokenCompanyId = await getCompanyIdFromToken(req);
        if (!tokenCompanyId) {
            return res.status(401).json({ error: "Unauthorized" });
        }
        try {
            const requestedCompanyId = req.body?.companyId;
            let finalCompanyId = tokenCompanyId;
            if (requestedCompanyId && requestedCompanyId !== tokenCompanyId) {
                const subCompany = await prisma_1.default.company.findFirst({
                    where: { id: requestedCompanyId, parentCompanyId: tokenCompanyId }
                });
                if (!subCompany) {
                    return res.status(403).json({ error: "Forbidden: Not a valid sub-company" });
                }
                finalCompanyId = requestedCompanyId;
            }
            await (0, campaign_execution_queue_1.clearCampaignState)(finalCompanyId);
            return res.json({ success: true, message: "Campaign state cleared" });
        }
        catch (e) {
            console.error("Failed to clear campaign state", e);
            return res.status(500).json({ error: e.message });
        }
    }
    async forceStopCampaign(req, res) {
        const tokenCompanyId = await getCompanyIdFromToken(req);
        if (!tokenCompanyId) {
            return res.status(401).json({ error: "Unauthorized" });
        }
        try {
            const requestedCompanyId = req.body?.companyId;
            let finalCompanyId = tokenCompanyId;
            if (requestedCompanyId && requestedCompanyId !== tokenCompanyId) {
                const subCompany = await prisma_1.default.company.findFirst({
                    where: { id: requestedCompanyId, parentCompanyId: tokenCompanyId }
                });
                if (!subCompany) {
                    return res.status(403).json({ error: "Forbidden: Not a valid sub-company" });
                }
                finalCompanyId = requestedCompanyId;
            }
            const newState = await (0, campaign_execution_queue_1.forceStopCampaignState)(finalCompanyId);
            return res.json({ success: true, message: "Campaign forcefully stopped", state: newState });
        }
        catch (e) {
            console.error("Failed to force stop campaign", e);
            return res.status(500).json({ error: e.message });
        }
    }
    async pauseCampaign(req, res) {
        const tokenCompanyId = await getCompanyIdFromToken(req);
        if (!tokenCompanyId) {
            return res.status(401).json({ error: "Unauthorized" });
        }
        try {
            const requestedCompanyId = req.body?.companyId;
            let finalCompanyId = tokenCompanyId;
            if (requestedCompanyId && requestedCompanyId !== tokenCompanyId) {
                const subCompany = await prisma_1.default.company.findFirst({
                    where: { id: requestedCompanyId, parentCompanyId: tokenCompanyId }
                });
                if (!subCompany) {
                    return res.status(403).json({ error: "Forbidden: Not a valid sub-company" });
                }
                finalCompanyId = requestedCompanyId;
            }
            const newState = await (0, campaign_execution_queue_1.pauseCampaignState)(finalCompanyId);
            return res.json({ success: true, message: "Campaign paused", state: newState });
        }
        catch (e) {
            console.error("Failed to pause campaign", e);
            return res.status(500).json({ error: e.message });
        }
    }
    async resumeCampaign(req, res) {
        const tokenCompanyId = await getCompanyIdFromToken(req);
        if (!tokenCompanyId) {
            return res.status(401).json({ error: "Unauthorized" });
        }
        try {
            const requestedCompanyId = req.body?.companyId;
            let finalCompanyId = tokenCompanyId;
            if (requestedCompanyId && requestedCompanyId !== tokenCompanyId) {
                const subCompany = await prisma_1.default.company.findFirst({
                    where: { id: requestedCompanyId, parentCompanyId: tokenCompanyId }
                });
                if (!subCompany) {
                    return res.status(403).json({ error: "Forbidden: Not a valid sub-company" });
                }
                finalCompanyId = requestedCompanyId;
            }
            const newState = await (0, campaign_execution_queue_1.resumeCampaignState)(finalCompanyId);
            return res.json({ success: true, message: "Campaign resumed", state: newState });
        }
        catch (e) {
            console.error("Failed to resume campaign", e);
            return res.status(500).json({ error: e.message });
        }
    }
};
exports.OutboundCampaignExecutionController = OutboundCampaignExecutionController;
__decorate([
    (0, common_1.Post)("start"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], OutboundCampaignExecutionController.prototype, "startCampaign", null);
__decorate([
    (0, common_1.Get)("status"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], OutboundCampaignExecutionController.prototype, "getStatus", null);
__decorate([
    (0, common_1.Post)("clear"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], OutboundCampaignExecutionController.prototype, "clearCampaign", null);
__decorate([
    (0, common_1.Post)("force-stop"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], OutboundCampaignExecutionController.prototype, "forceStopCampaign", null);
__decorate([
    (0, common_1.Post)("pause"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], OutboundCampaignExecutionController.prototype, "pauseCampaign", null);
__decorate([
    (0, common_1.Post)("resume"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], OutboundCampaignExecutionController.prototype, "resumeCampaign", null);
exports.OutboundCampaignExecutionController = OutboundCampaignExecutionController = __decorate([
    (0, common_1.Controller)("api/campaign-execution")
], OutboundCampaignExecutionController);
//# sourceMappingURL=campaign-execution.controller.js.map