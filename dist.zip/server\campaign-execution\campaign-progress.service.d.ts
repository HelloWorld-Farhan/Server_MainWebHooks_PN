export declare class CampaignProgressService {
    private readonly lastProcessedSnapshots;
    updateAllActive(): Promise<number>;
    updateExecution(companyId: string, campaignId: string): Promise<void>;
    resetSnapshotsForTests(): void;
}
export declare const campaignProgressService: CampaignProgressService;
