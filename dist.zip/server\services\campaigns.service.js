"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.campaignsService = exports.CampaignsService = void 0;
const crypto_1 = require("crypto");
const errors_1 = require("../lib/errors");
const prisma_1 = __importDefault(require("../lib/prisma"));
const campaigns_repository_1 = require("../repositories/campaigns.repository");
const pagination_1 = require("../lib/pagination");
const permissions_1 = require("../types/permissions");
const campaign_access_service_1 = require("./campaign-access.service");
const tenant_service_1 = require("./tenant.service");
const organization_1 = require("../../lib/clerk/organization");
const app_url_1 = require("../../lib/app-url");
function mapBranch(row, counts, invitationEmailSent) {
    const r = row;
    return {
        id: r.id,
        name: r.name,
        status: r.status,
        direction: r.direction ?? "OUTBOUND",
        address: r.address,
        phone: r.phone,
        email: r.email,
        notes: r.notes,
        customFields: r.customFields,
        aiEnabled: r.aiEnabled,
        systemPrompt: r.systemPrompt,
        aiConfig: r.aiConfig,
        contactsCount: counts?.contactsCount ?? 0,
        callLogsCount: counts?.callLogsCount ?? 0,
        documentsCount: counts?.documentsCount ?? 0,
        agentsCount: counts?.agentsCount ?? 0,
        lastActivityAt: r.lastActivityAt?.toISOString() ?? null,
        createdAt: r.createdAt.toISOString(),
        updatedAt: r.updatedAt.toISOString(),
        invitationEmailSent: typeof invitationEmailSent === "boolean" ? invitationEmailSent : null,
        invitation: r.invitation
            ? {
                id: r.invitation.id,
                email: r.invitation.email,
                token: r.invitation.token,
                status: r.invitation.status,
                createdAt: r.invitation.createdAt.toISOString(),
                updatedAt: r.invitation.updatedAt.toISOString(),
                sentAt: r.invitation.sentAt.toISOString(),
                acceptedAt: r.invitation.acceptedAt?.toISOString() ?? null,
                expiresAt: r.invitation.expiresAt.toISOString(),
            }
            : null,
    };
}
function mapAgent(row) {
    return {
        id: row.id,
        name: row.name,
        type: row.type,
        category: row.category,
        status: row.status,
        environment: row.environment,
        enabled: row.enabled,
        languages: row.languages,
        firstMessage: row.firstMessage,
        systemPrompt: row.systemPrompt,
        voiceConfig: row.voiceConfig,
        modelConfig: row.modelConfig,
        transcriberConfig: row.transcriberConfig,
        serverConfig: row.serverConfig,
        structuredOutputs: row.structuredOutputs,
        scorecards: row.scorecards,
        monitors: row.monitors,
        demoAudioUrl: row.demoAudioUrl,
        campaignId: row.campaignId,
        createdAt: row.createdAt.toISOString(),
        updatedAt: row.updatedAt.toISOString(),
    };
}
class CampaignsService {
    repo = new campaigns_repository_1.CampaignsRepository(prisma_1.default);
    async getConnection(ctx, args) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_READ);
        const limit = Math.min(Math.max(args.first ?? 25, 1), 200);
        const scopeWhere = campaign_access_service_1.campaignAccessService.campaignIdScopeFilter(ctx);
        const [rows, totalCount] = await Promise.all([
            this.repo.findConnection(ctx.companyId, limit, args.after, args.filter, scopeWhere),
            this.repo.count(ctx.companyId, args.filter, scopeWhere),
        ]);
        const connection = (0, pagination_1.buildConnection)(rows, limit, (row) => (0, pagination_1.encodeIdCursor)(row.id, row.createdAt));
        return {
            edges: connection.edges.map((edge) => ({
                node: mapBranch(edge.node),
                cursor: edge.cursor,
            })),
            pageInfo: connection.pageInfo,
            totalCount,
        };
    }
    async getById(ctx, id) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_READ);
        campaign_access_service_1.campaignAccessService.assertCampaignAccess(ctx, id);
        const row = await this.repo.findById(ctx.companyId, id);
        if (!row)
            throw new errors_1.NotFoundError("Campaign not found");
        const counts = await this.repo.countRelations(ctx.companyId, id);
        return mapBranch(row, counts);
    }
    async create(ctx, input) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_WRITE);
        const name = input.name?.trim();
        if (!name)
            throw new errors_1.ValidationError("Campaign name is required");
        const creator = await prisma_1.default.user.findUnique({
            where: { id: ctx.userId },
            select: { firstName: true, lastName: true, email: true },
        });
        const createdByName = creator
            ? [creator.firstName, creator.lastName].filter(Boolean).join(" ") ||
                creator.email
            : undefined;
        const row = await this.repo.create(ctx.companyId, {
            name,
            status: input.status,
            direction: input.direction ?? "OUTBOUND",
            address: input.address ?? undefined,
            phone: input.phone ?? undefined,
            email: input.email ?? undefined,
            notes: input.notes ?? undefined,
            customFields: {
                ...(input.customFields ?? {}),
                ...(createdByName ? { createdByName } : {}),
            },
            aiEnabled: input.aiEnabled ?? false,
            systemPrompt: input.systemPrompt ?? undefined,
            aiConfig: input.aiConfig ?? {},
            lastActivityAt: new Date(),
        });
        await this.repo.createActivity(ctx.companyId, row.id, {
            type: "CAMPAIGN_CREATED",
            summary: `Campaign "${row.name}" created`,
            actorId: ctx.userId,
        });
        let invitationEmailSent = false;
        const emailVal = input.email?.trim().toLowerCase();
        if (emailVal) {
            const company = await prisma_1.default.company.findUnique({
                where: { id: ctx.companyId },
            });
            if (!company)
                throw new errors_1.NotFoundError("Company not found");
            const clerkOrganizationId = await organization_1.clerkOrgLib.getActiveClerkOrganizationId(company, {
                createdByClerkUserId: ctx.clerkUserId,
            });
            await organization_1.clerkOrgLib.removeClerkOrganizationAccess({
                organizationId: clerkOrganizationId,
                email: emailVal,
                requestingUserId: ctx.clerkUserId,
            });
            const token = (0, crypto_1.randomUUID)();
            const clerkInvite = await organization_1.clerkOrgLib.sendClerkOrganizationInvitation({
                organizationId: clerkOrganizationId,
                email: emailVal,
                role: "ADMIN",
                inviterUserId: ctx.clerkUserId,
                redirectUrl: (0, app_url_1.getCampaignInviteRedirectUrl)(token),
                metadata: {
                    propnexRole: "ADMIN",
                    campaignAccessType: "SELECTED",
                    campaignIds: [row.id],
                    jobTitle: "Campaign Admin",
                    inviteName: row.name,
                },
            });
            const expiresAt = clerkInvite.expiresAt;
            await prisma_1.default.campaignInvitation.create({
                data: {
                    companyId: ctx.companyId,
                    campaignId: row.id,
                    email: emailVal,
                    token,
                    expiresAt,
                    clerkInvitationId: clerkInvite.invitationId,
                    clerkOrganizationId,
                },
            });
            invitationEmailSent = true;
            const reloaded = await this.repo.findById(ctx.companyId, row.id);
            if (reloaded) {
                return mapBranch(reloaded, undefined, invitationEmailSent);
            }
        }
        return mapBranch(row);
    }
    async update(ctx, id, input) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_WRITE);
        const existing = await this.repo.findById(ctx.companyId, id);
        if (!existing)
            throw new errors_1.NotFoundError("Campaign not found");
        campaign_access_service_1.campaignAccessService.assertCampaignAccess(ctx, id);
        await this.repo.update(ctx.companyId, id, {
            name: input.name?.trim(),
            status: input.status,
            direction: input.direction,
            address: input.address,
            phone: input.phone,
            email: input.email,
            notes: input.notes,
            customFields: input.customFields,
            lastActivityAt: new Date(),
        });
        await this.repo.createActivity(ctx.companyId, id, {
            type: "CAMPAIGN_UPDATED",
            summary: "Campaign details updated",
            actorId: ctx.userId,
        });
        return this.getById(ctx, id);
    }
    async updateAi(ctx, id, input) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_WRITE);
        const existing = await this.repo.findById(ctx.companyId, id);
        if (!existing)
            throw new errors_1.NotFoundError("Campaign not found");
        campaign_access_service_1.campaignAccessService.assertCampaignAccess(ctx, id);
        await this.repo.update(ctx.companyId, id, {
            aiEnabled: input.aiEnabled,
            systemPrompt: input.systemPrompt,
            aiConfig: input.aiConfig,
            lastActivityAt: new Date(),
        });
        await this.repo.createActivity(ctx.companyId, id, {
            type: "AI_CONFIG_UPDATED",
            summary: typeof input.aiEnabled === "boolean"
                ? `AI agent ${input.aiEnabled ? "enabled" : "disabled"}`
                : "AI configuration updated",
            actorId: ctx.userId,
        });
        return this.getById(ctx, id);
    }
    async archive(ctx, id) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_WRITE);
        const existing = await this.repo.findById(ctx.companyId, id);
        if (!existing)
            throw new errors_1.NotFoundError("Campaign not found");
        campaign_access_service_1.campaignAccessService.assertCampaignAccess(ctx, id);
        await this.repo.update(ctx.companyId, id, {
            status: "ARCHIVED",
            lastActivityAt: new Date(),
        });
        await this.repo.createActivity(ctx.companyId, id, {
            type: "CAMPAIGN_ARCHIVED",
            summary: "Campaign archived",
            actorId: ctx.userId,
        });
        return this.getById(ctx, id);
    }
    async delete(ctx, id) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_WRITE);
        const existing = await this.repo.findById(ctx.companyId, id);
        if (!existing)
            throw new errors_1.NotFoundError("Campaign not found");
        campaign_access_service_1.campaignAccessService.assertCampaignAccess(ctx, id);
        const deleted = await this.repo.deleteByIds(ctx.companyId, [id]);
        if (deleted === 0) {
            throw new errors_1.NotFoundError("Campaign not found");
        }
        return true;
    }
    async bulkDelete(ctx, idsInput) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_BULK);
        const ids = [...new Set(idsInput)].filter(Boolean);
        if (ids.length === 0)
            throw new errors_1.ValidationError("No campaigns selected");
        campaign_access_service_1.campaignAccessService.assertCampaignIdsAccess(ctx, ids);
        const deleted = await this.repo.deleteByIds(ctx.companyId, ids);
        return { deleted };
    }
    async bulkUpdate(ctx, input) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_BULK);
        const ids = [...new Set(input.ids)].filter(Boolean);
        if (ids.length === 0)
            throw new errors_1.ValidationError("No campaigns selected");
        campaign_access_service_1.campaignAccessService.assertCampaignIdsAccess(ctx, ids);
        let data;
        let summary;
        switch (input.action) {
            case "ENABLE_AI":
                data = { aiEnabled: true };
                summary = "AI agent enabled (bulk)";
                break;
            case "DISABLE_AI":
                data = { aiEnabled: false };
                summary = "AI agent disabled (bulk)";
                break;
            case "UPDATE_PROMPT":
                if (input.systemPrompt == null) {
                    throw new errors_1.ValidationError("systemPrompt is required for UPDATE_PROMPT");
                }
                data = { systemPrompt: input.systemPrompt };
                summary = "AI system prompt updated (bulk)";
                break;
            case "CHANGE_STATUS":
                if (!input.status) {
                    throw new errors_1.ValidationError("status is required for CHANGE_STATUS");
                }
                data = { status: input.status };
                summary = `Status changed to ${input.status} (bulk)`;
                break;
            case "ARCHIVE":
                data = { status: "ARCHIVED" };
                summary = "Campaign archived (bulk)";
                break;
            default:
                throw new errors_1.ValidationError("Unknown bulk action");
        }
        data.lastActivityAt = new Date();
        const updated = await this.repo.bulkUpdate(ctx.companyId, ids, data);
        await this.repo.createActivitiesForMany(ctx.companyId, ids, {
            type: "BULK_UPDATE",
            summary,
            actorId: ctx.userId,
        });
        return { updated };
    }
    async getContacts(ctx, campaignId, first, after) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_READ);
        campaign_access_service_1.campaignAccessService.assertCampaignAccess(ctx, campaignId);
        const limit = Math.min(Math.max(first ?? 25, 1), 100);
        const rows = await this.repo.findContacts(ctx.companyId, campaignId, limit, after);
        return rows.map((row) => ({
            id: row.id,
            phone: row.phone,
            field1: row.field1,
            field2: row.field2,
            field3: row.field3,
            createdAt: row.createdAt.toISOString(),
        }));
    }
    async getCallLogs(ctx, campaignId, first, after) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_READ);
        campaign_access_service_1.campaignAccessService.assertCampaignAccess(ctx, campaignId);
        const limit = Math.min(Math.max(first ?? 25, 1), 100);
        const rows = await this.repo.findCallLogs(ctx.companyId, campaignId, limit, after);
        return rows.map((row) => ({
            id: row.id,
            publicId: row.publicId ?? null,
            direction: row.direction,
            status: row.status,
            durationSeconds: row.durationSeconds,
            startedAt: row.startedAt.toISOString(),
            answeredAt: row.answeredAt?.toISOString() ?? null,
            endedAt: row.endedAt?.toISOString() ?? null,
            leadPhone: row.lead?.phone ?? row.phoneNumber?.number ?? null,
            phoneNumber: row.phoneNumber?.number ?? row.lead?.phone ?? null,
            leadName: [row.lead?.firstName, row.lead?.lastName].filter(Boolean).join(" ") ||
                null,
            providerStatus: row.providerStatus ?? null,
            disconnectReason: row.disconnectReason ?? null,
        }));
    }
    async getDocuments(ctx, campaignId) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_READ);
        campaign_access_service_1.campaignAccessService.assertCampaignAccess(ctx, campaignId);
        const rows = await this.repo.findDocuments(ctx.companyId, campaignId);
        return rows.map((row) => ({
            id: row.id,
            name: row.name,
            url: row.url,
            mimeType: row.mimeType,
            sizeBytes: row.sizeBytes,
            createdAt: row.createdAt.toISOString(),
        }));
    }
    async getAgents(ctx, campaignId) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_READ);
        campaign_access_service_1.campaignAccessService.assertCampaignAccess(ctx, campaignId);
        const rows = await this.repo.findAgents(ctx.companyId, campaignId);
        return rows.map((row) => mapAgent(row));
    }
    async getActivities(ctx, campaignId, limit) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_READ);
        campaign_access_service_1.campaignAccessService.assertCampaignAccess(ctx, campaignId);
        const take = Math.min(Math.max(limit ?? 50, 1), 200);
        const rows = await this.repo.findActivities(ctx.companyId, campaignId, take);
        return rows.map((row) => ({
            id: row.id,
            type: row.type,
            summary: row.summary,
            metadata: row.metadata,
            createdAt: row.createdAt.toISOString(),
        }));
    }
    async resendInvitation(ctx, campaignId) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_WRITE);
        const campaign = await this.repo.findById(ctx.companyId, campaignId);
        if (!campaign)
            throw new errors_1.NotFoundError("Campaign not found");
        const invitation = await prisma_1.default.campaignInvitation.findUnique({
            where: { campaignId },
        });
        if (!invitation)
            throw new errors_1.ValidationError("No invitation exists for this campaign.");
        const company = await prisma_1.default.company.findUnique({
            where: { id: ctx.companyId },
        });
        if (!company)
            throw new errors_1.NotFoundError("Company not found");
        const clerkOrganizationId = await organization_1.clerkOrgLib.getActiveClerkOrganizationId(company, {
            createdByClerkUserId: ctx.clerkUserId,
        });
        if (invitation.clerkInvitationId && clerkOrganizationId.startsWith("org_")) {
            await organization_1.clerkOrgLib.revokeClerkOrganizationInvitation({
                organizationId: clerkOrganizationId,
                invitationId: invitation.clerkInvitationId,
                requestingUserId: ctx.clerkUserId,
            });
        }
        const newToken = (0, crypto_1.randomUUID)();
        const clerkInvite = await organization_1.clerkOrgLib.sendClerkOrganizationInvitation({
            organizationId: clerkOrganizationId,
            email: invitation.email,
            role: "ADMIN",
            inviterUserId: ctx.clerkUserId,
            redirectUrl: (0, app_url_1.getCampaignInviteRedirectUrl)(newToken),
            metadata: {
                propnexRole: "ADMIN",
                campaignAccessType: "SELECTED",
                campaignIds: [campaignId],
                jobTitle: "Campaign Admin",
                inviteName: campaign.name,
            },
        });
        await prisma_1.default.campaignInvitation.update({
            where: { id: invitation.id },
            data: {
                token: newToken,
                sentAt: new Date(),
                expiresAt: clerkInvite.expiresAt,
                status: "PENDING",
                acceptedAt: null,
                clerkInvitationId: clerkInvite.invitationId,
                clerkOrganizationId,
            },
        });
        const reloaded = await this.repo.findById(ctx.companyId, campaignId);
        if (!reloaded)
            throw new errors_1.NotFoundError("Campaign not found");
        return mapBranch(reloaded, undefined, true);
    }
    async cancelInvitation(ctx, campaignId) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_WRITE);
        const invitation = await prisma_1.default.campaignInvitation.findUnique({
            where: { campaignId },
        });
        if (!invitation)
            throw new errors_1.ValidationError("No invitation exists for this campaign.");
        const company = await prisma_1.default.company.findUnique({
            where: { id: ctx.companyId },
        });
        if (!company)
            throw new errors_1.NotFoundError("Company not found");
        const clerkOrganizationId = await organization_1.clerkOrgLib.getActiveClerkOrganizationId(company, {
            createdByClerkUserId: ctx.clerkUserId,
        });
        if (invitation.clerkInvitationId && clerkOrganizationId.startsWith("org_")) {
            await organization_1.clerkOrgLib.revokeClerkOrganizationInvitation({
                organizationId: clerkOrganizationId,
                invitationId: invitation.clerkInvitationId,
                requestingUserId: ctx.clerkUserId,
            });
        }
        await prisma_1.default.campaignInvitation.update({
            where: { id: invitation.id },
            data: { status: "CANCELLED" },
        });
        const reloaded = await this.repo.findById(ctx.companyId, campaignId);
        if (!reloaded)
            throw new errors_1.NotFoundError("Campaign not found");
        return mapBranch(reloaded);
    }
    async generateNewInvitation(ctx, campaignId) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.CAMPAIGNS_WRITE);
        const campaign = await this.repo.findById(ctx.companyId, campaignId);
        if (!campaign)
            throw new errors_1.NotFoundError("Campaign not found");
        if (!campaign.email)
            throw new errors_1.ValidationError("Campaign has no email address configured.");
        const company = await prisma_1.default.company.findUnique({
            where: { id: ctx.companyId },
        });
        if (!company)
            throw new errors_1.NotFoundError("Company not found");
        const clerkOrganizationId = await organization_1.clerkOrgLib.getActiveClerkOrganizationId(company, {
            createdByClerkUserId: ctx.clerkUserId,
        });
        const oldInvitation = await prisma_1.default.campaignInvitation.findUnique({
            where: { campaignId },
        });
        if (oldInvitation?.clerkInvitationId && clerkOrganizationId.startsWith("org_")) {
            await organization_1.clerkOrgLib.revokeClerkOrganizationInvitation({
                organizationId: clerkOrganizationId,
                invitationId: oldInvitation.clerkInvitationId,
                requestingUserId: ctx.clerkUserId,
            });
        }
        const token = (0, crypto_1.randomUUID)();
        const clerkInvite = await organization_1.clerkOrgLib.sendClerkOrganizationInvitation({
            organizationId: clerkOrganizationId,
            email: campaign.email.trim().toLowerCase(),
            role: "ADMIN",
            inviterUserId: ctx.clerkUserId,
            redirectUrl: (0, app_url_1.getCampaignInviteRedirectUrl)(token),
            metadata: {
                propnexRole: "ADMIN",
                campaignAccessType: "SELECTED",
                campaignIds: [campaignId],
                jobTitle: "Campaign Admin",
                inviteName: campaign.name,
            },
        });
        const expiresAt = clerkInvite.expiresAt;
        await prisma_1.default.campaignInvitation.upsert({
            where: { campaignId },
            create: {
                companyId: ctx.companyId,
                campaignId,
                email: campaign.email.trim().toLowerCase(),
                token,
                status: "PENDING",
                expiresAt,
                clerkInvitationId: clerkInvite.invitationId,
                clerkOrganizationId,
            },
            update: {
                email: campaign.email.trim().toLowerCase(),
                token,
                status: "PENDING",
                expiresAt,
                sentAt: new Date(),
                acceptedAt: null,
                clerkInvitationId: clerkInvite.invitationId,
                clerkOrganizationId,
            },
        });
        const reloaded = await this.repo.findById(ctx.companyId, campaignId);
        if (!reloaded)
            throw new errors_1.NotFoundError("Campaign not found");
        return mapBranch(reloaded, undefined, true);
    }
}
exports.CampaignsService = CampaignsService;
exports.campaignsService = new CampaignsService();
//# sourceMappingURL=campaigns.service.js.map