"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var SubCompaniesController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.SubCompaniesController = void 0;
const common_1 = require("@nestjs/common");
const zod_1 = require("zod");
const http_1 = require("../../lib/api/http");
const prisma_1 = __importDefault(require("../../server/lib/prisma"));
const errors_1 = require("../../server/lib/errors");
const contract_id_1 = require("../../server/lib/contract-id");
const notification_service_1 = require("../../server/services/notification.service");
const createSubCompanySchema = zod_1.z.object({
    companyName: zod_1.z.string().min(1, "Company Name is required"),
    companyEmail: zod_1.z.string().optional().or(zod_1.z.literal("")),
    allocatedCredits: zod_1.z.number().min(0, "Allocated credits cannot be negative"),
});
let SubCompaniesController = SubCompaniesController_1 = class SubCompaniesController {
    logger = new common_1.Logger(SubCompaniesController_1.name);
    async getSubCompanies(req, res) {
        try {
            const authHeader = req.headers.authorization;
            if (!authHeader || !authHeader.startsWith("Bearer ")) {
                return res.status(401).json({ error: "Unauthorized" });
            }
            const token = authHeader.split(" ")[1];
            const payloadBase64 = token.split(".")[1];
            if (!payloadBase64)
                return res.status(401).json({ error: "Invalid token" });
            const payloadStr = Buffer.from(payloadBase64, "base64").toString("utf-8");
            const payload = JSON.parse(payloadStr);
            const email = payload.email || payload.sub;
            const dbUser = await prisma_1.default.user.findFirst({
                where: { email },
                include: { memberships: { where: { status: "ACTIVE" } } }
            });
            const parentCompanyId = dbUser?.memberships[0]?.companyId;
            if (!parentCompanyId)
                return res.status(403).json({ error: "Tenant not found" });
            const subCompanies = await prisma_1.default.company.findMany({
                where: { parentCompanyId },
                orderBy: { createdAt: "desc" },
                include: {
                    creditBalance: true,
                    phoneNumbers: true,
                    callLogs: {
                        where: { direction: "INBOUND" },
                    },
                    _count: {
                        select: { callLogs: true }
                    }
                }
            });
            const formatted = subCompanies.map((c) => {
                const allNumbers = (c.phoneNumbers || []).map((p) => p.number).filter(Boolean);
                return {
                    _id: c.id,
                    companyName: c.name,
                    companyEmail: "",
                    contactPhone: allNumbers[0] || "",
                    assignedNumbers: allNumbers,
                    status: c.status.toLowerCase(),
                    createdAt: c.createdAt.toISOString(),
                    creditsUsed: c.creditBalance?.creditsUsed || 0,
                    creditsRemaining: c.creditBalance?.creditsRemaining || 0,
                    inboundCalls: c.callLogs?.length || 0,
                    outboundCalls: (c._count?.callLogs || 0) - (c.callLogs?.length || 0)
                };
            });
            return res.json(formatted);
        }
        catch (err) {
            if ((0, errors_1.isAppError)(err)) {
                return (0, http_1.sendAppErrorResponse)(res, err);
            }
            this.logger.error(`GET /api/sub-companies failed: ${err}`);
            return res.status(500).json({ error: "Internal server error" });
        }
    }
    async createSubCompany(req, res) {
        try {
            const authHeader = req.headers.authorization;
            if (!authHeader || !authHeader.startsWith("Bearer ")) {
                return res.status(401).json({ error: "Unauthorized" });
            }
            const token = authHeader.split(" ")[1];
            const payloadBase64 = token.split(".")[1];
            if (!payloadBase64)
                return res.status(401).json({ error: "Invalid token" });
            const payloadStr = Buffer.from(payloadBase64, "base64").toString("utf-8");
            const payload = JSON.parse(payloadStr);
            const email = payload.email || payload.sub;
            const dbUser = await prisma_1.default.user.findFirst({
                where: { email },
                include: { memberships: { where: { status: "ACTIVE" } } }
            });
            const parentCompanyId = dbUser?.memberships[0]?.companyId;
            if (!parentCompanyId)
                return res.status(403).json({ error: "Tenant not found" });
            const body = createSubCompanySchema.parse(req.body);
            const contractId = (0, contract_id_1.generateContractId)();
            const result = await prisma_1.default.$transaction(async (tx) => {
                const parentCredit = await tx.creditBalance.findUnique({
                    where: { companyId: parentCompanyId }
                });
                if (!parentCredit) {
                    throw new Error("Parent company credit balance not found");
                }
                if (parentCredit.creditsRemaining < body.allocatedCredits) {
                    throw new Error("Insufficient credits in main company");
                }
                await tx.creditBalance.update({
                    where: { id: parentCredit.id },
                    data: {
                        creditsRemaining: { decrement: body.allocatedCredits }
                    }
                });
                const newCompany = await tx.company.create({
                    data: {
                        name: body.companyName,
                        slug: `sub-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
                        contractId,
                        cli: `SUB${Math.floor(Math.random() * 10000)}`,
                        companyCode: `CODE${Math.floor(Math.random() * 10000)}`,
                        tenantType: "CHILD",
                        parentCompanyId,
                        status: "PENDING",
                    },
                });
                await tx.creditBalance.create({
                    data: {
                        companyId: newCompany.id,
                        creditsRemaining: body.allocatedCredits,
                        creditsUsed: 0,
                    }
                });
                const parentCompany = await tx.company.findUnique({
                    where: { id: parentCompanyId },
                    select: { name: true }
                });
                return { newCompany, parentCompanyName: parentCompany?.name || "Main Company" };
            });
            notification_service_1.notificationService.sendSubCompanyCreatedEmail({
                companyName: result.newCompany.name,
                parentCompanyName: result.parentCompanyName,
                allocatedCredits: body.allocatedCredits,
                email: body.companyEmail || "",
            }).catch(console.error);
            return res.json({
                _id: result.newCompany.id,
                companyName: result.newCompany.name,
                companyEmail: body.companyEmail || "",
                status: result.newCompany.status.toLowerCase(),
                createdAt: result.newCompany.createdAt.toISOString(),
            });
        }
        catch (err) {
            if (err instanceof zod_1.z.ZodError) {
                return res.status(400).json({ error: err.issues[0]?.message ?? err.message });
            }
            if ((0, errors_1.isAppError)(err)) {
                return (0, http_1.sendAppErrorResponse)(res, err);
            }
            this.logger.error(`POST /api/sub-companies failed:`, err);
            return res.status(500).json({ error: err.message || "Internal server error" });
        }
    }
    async transferCredits(req, res) {
        try {
            const authHeader = req.headers.authorization;
            if (!authHeader || !authHeader.startsWith("Bearer ")) {
                return res.status(401).json({ error: "Unauthorized" });
            }
            const token = authHeader.split(" ")[1];
            const payloadBase64 = token.split(".")[1];
            if (!payloadBase64)
                return res.status(401).json({ error: "Invalid token" });
            const payloadStr = Buffer.from(payloadBase64, "base64").toString("utf-8");
            const payload = JSON.parse(payloadStr);
            const email = payload.email || payload.sub;
            const dbUser = await prisma_1.default.user.findFirst({
                where: { email },
                include: { memberships: { where: { status: "ACTIVE" } } }
            });
            const parentCompanyId = dbUser?.memberships[0]?.companyId;
            if (!parentCompanyId)
                return res.status(403).json({ error: "Tenant not found" });
            const childCompanyId = req.params.id;
            if (!childCompanyId)
                return res.status(400).json({ error: "Child company ID is required" });
            const childCompany = await prisma_1.default.company.findFirst({
                where: { id: childCompanyId, parentCompanyId }
            });
            if (!childCompany) {
                return res.status(404).json({ error: "Child company not found or does not belong to you" });
            }
            const bodySchema = zod_1.z.object({
                amount: zod_1.z.number().int().positive("Transfer amount must be positive"),
                action: zod_1.z.enum(["ADD", "REDUCE"]).default("ADD"),
            });
            const { amount, action } = bodySchema.parse(req.body);
            const result = await prisma_1.default.$transaction(async (tx) => {
                const parentCredit = await tx.creditBalance.findUnique({
                    where: { companyId: parentCompanyId }
                });
                const childCreditCheck = await tx.creditBalance.findUnique({
                    where: { companyId: childCompanyId }
                });
                if (action === "ADD") {
                    if (!parentCredit || parentCredit.creditsRemaining < amount) {
                        throw new Error("Insufficient credits in main company");
                    }
                    const updatedParent = await tx.creditBalance.update({
                        where: { id: parentCredit.id },
                        data: { creditsRemaining: { decrement: amount } }
                    });
                    const childCredit = await tx.creditBalance.upsert({
                        where: { companyId: childCompanyId },
                        create: {
                            companyId: childCompanyId,
                            creditsRemaining: amount,
                            creditsUsed: 0
                        },
                        update: {
                            creditsRemaining: { increment: amount }
                        }
                    });
                    if (parentCredit.creditsRemaining > 0 && updatedParent.creditsRemaining <= 0) {
                        process.nextTick(async () => {
                            try {
                                const fullCompany = await prisma_1.default.company.findUnique({
                                    where: { id: parentCompanyId },
                                    include: { members: { where: { role: "OWNER", status: "ACTIVE" }, include: { user: true } } },
                                });
                                const user = fullCompany?.members?.[0]?.user;
                                if (user && user.email) {
                                    await notification_service_1.notificationService.sendCreditZeroWarningEmail({
                                        email: user.email,
                                        name: user.firstName ? `${user.firstName} ${user.lastName}`.trim() : user.email.split("@")[0],
                                    });
                                }
                            }
                            catch (e) {
                                console.error("Failed to process parent zero warning:", e);
                            }
                        });
                    }
                    return childCredit;
                }
                else {
                    if (!childCreditCheck || childCreditCheck.creditsRemaining < amount) {
                        throw new Error("Insufficient credits in sub-company to withdraw");
                    }
                    const childCredit = await tx.creditBalance.update({
                        where: { companyId: childCompanyId },
                        data: { creditsRemaining: { decrement: amount } }
                    });
                    if (parentCredit) {
                        await tx.creditBalance.update({
                            where: { id: parentCredit.id },
                            data: { creditsRemaining: { increment: amount } }
                        });
                    }
                    if (childCreditCheck.creditsRemaining > 0 && childCredit.creditsRemaining <= 0) {
                        process.nextTick(async () => {
                            try {
                                const fullCompany = await prisma_1.default.company.findUnique({
                                    where: { id: childCompanyId },
                                    include: { members: { where: { role: "OWNER", status: "ACTIVE" }, include: { user: true } } },
                                });
                                const user = fullCompany?.members?.[0]?.user;
                                if (user && user.email) {
                                    await notification_service_1.notificationService.sendSubCompanyCreditZeroWarningEmail({
                                        email: user.email,
                                        companyName: fullCompany.name,
                                    });
                                }
                            }
                            catch (e) {
                                console.error("Failed to process child zero warning:", e);
                            }
                        });
                    }
                    return childCredit;
                }
            });
            return res.json({ success: true, newBalance: result.creditsRemaining });
        }
        catch (err) {
            if (err instanceof zod_1.z.ZodError) {
                return res.status(400).json({ error: err.issues[0]?.message ?? err.message });
            }
            this.logger.error(`POST /api/sub-companies/:id/transfer-credits failed:`, err);
            return res.status(500).json({ error: err.message || "Internal server error" });
        }
    }
};
exports.SubCompaniesController = SubCompaniesController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], SubCompaniesController.prototype, "getSubCompanies", null);
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], SubCompaniesController.prototype, "createSubCompany", null);
__decorate([
    (0, common_1.Post)(":id/transfer-credits"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], SubCompaniesController.prototype, "transferCredits", null);
exports.SubCompaniesController = SubCompaniesController = SubCompaniesController_1 = __decorate([
    (0, common_1.Controller)("api/sub-companies")
], SubCompaniesController);
//# sourceMappingURL=sub-company.controller.js.map