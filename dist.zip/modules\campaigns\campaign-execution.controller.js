"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CampaignExecutionController = void 0;
const common_1 = require("@nestjs/common");
const zod_1 = require("zod");
const http_1 = require("../../lib/api/http");
const tenant_context_1 = require("../../lib/api/tenant-context");
const permissions_1 = require("../../lib/permissions");
const errors_1 = require("../../server/lib/errors");
const campaign_execution_service_1 = require("../../server/campaign-execution/campaign-execution.service");
const scheduleSchema = zod_1.z.object({
    scheduledAt: zod_1.z.string().min(1),
});
const startSchema = zod_1.z.object({
    scheduledAt: zod_1.z.string().optional(),
});
const retryPolicySchema = zod_1.z.object({
    retryEnabled: zod_1.z.boolean().optional(),
    maxRetries: zod_1.z.number().int().min(0).optional(),
    retryDelaySeconds: zod_1.z.number().int().min(0).optional(),
    retryOnBusy: zod_1.z.boolean().optional(),
    retryOnNoAnswer: zod_1.z.boolean().optional(),
    retryOnFailed: zod_1.z.boolean().optional(),
    retryOnCancelled: zod_1.z.boolean().optional(),
    retryOnVoicemail: zod_1.z.boolean().optional(),
    retryOnMissed: zod_1.z.boolean().optional(),
});
let CampaignExecutionController = class CampaignExecutionController {
    async start(campaignId, req, res) {
        const result = await (0, tenant_context_1.requireTenantPermission)(req, permissions_1.PERMISSIONS.CAMPAIGNS_WRITE);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        try {
            const body = startSchema.parse(req.body ?? {});
            const response = await campaign_execution_service_1.campaignExecutionService.start(result.ctx, campaignId, body.scheduledAt);
            return res.json(response);
        }
        catch (err) {
            return this.handleError(res, err);
        }
    }
    async schedule(campaignId, req, res) {
        const result = await (0, tenant_context_1.requireTenantPermission)(req, permissions_1.PERMISSIONS.CAMPAIGNS_WRITE);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        try {
            const body = scheduleSchema.parse(req.body);
            const response = await campaign_execution_service_1.campaignExecutionService.schedule(result.ctx, campaignId, body.scheduledAt);
            return res.json(response);
        }
        catch (err) {
            return this.handleError(res, err);
        }
    }
    async pause(campaignId, req, res) {
        const result = await (0, tenant_context_1.requireTenantPermission)(req, permissions_1.PERMISSIONS.CAMPAIGNS_WRITE);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        try {
            const response = await campaign_execution_service_1.campaignExecutionService.pause(result.ctx, campaignId);
            return res.json(response);
        }
        catch (err) {
            return this.handleError(res, err);
        }
    }
    async resume(campaignId, req, res) {
        const result = await (0, tenant_context_1.requireTenantPermission)(req, permissions_1.PERMISSIONS.CAMPAIGNS_WRITE);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        try {
            const response = await campaign_execution_service_1.campaignExecutionService.resume(result.ctx, campaignId);
            return res.json(response);
        }
        catch (err) {
            return this.handleError(res, err);
        }
    }
    async retry(campaignId, req, res) {
        const result = await (0, tenant_context_1.requireTenantPermission)(req, permissions_1.PERMISSIONS.CAMPAIGNS_WRITE);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        try {
            const response = await campaign_execution_service_1.campaignExecutionService.retry(result.ctx, campaignId);
            return res.json(response);
        }
        catch (err) {
            return this.handleError(res, err);
        }
    }
    async reset(campaignId, req, res) {
        const result = await (0, tenant_context_1.requireTenantPermission)(req, permissions_1.PERMISSIONS.CAMPAIGNS_WRITE);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        try {
            const response = await campaign_execution_service_1.campaignExecutionService.reset(result.ctx, campaignId);
            return res.json(response);
        }
        catch (err) {
            return this.handleError(res, err);
        }
    }
    async cancel(campaignId, req, res) {
        const result = await (0, tenant_context_1.requireTenantPermission)(req, permissions_1.PERMISSIONS.CAMPAIGNS_WRITE);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        try {
            const response = await campaign_execution_service_1.campaignExecutionService.cancel(result.ctx, campaignId);
            return res.json(response);
        }
        catch (err) {
            return this.handleError(res, err);
        }
    }
    async status(campaignId, req, res) {
        const result = await (0, tenant_context_1.requireTenantPermission)(req, permissions_1.PERMISSIONS.CAMPAIGNS_READ);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        try {
            const response = await campaign_execution_service_1.campaignExecutionService.getStatus(result.ctx, campaignId);
            return res.json(response);
        }
        catch (err) {
            return this.handleError(res, err);
        }
    }
    async statistics(campaignId, req, res) {
        const result = await (0, tenant_context_1.requireTenantPermission)(req, permissions_1.PERMISSIONS.CAMPAIGNS_READ);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        try {
            const response = await campaign_execution_service_1.campaignExecutionService.getStatistics(result.ctx, campaignId);
            return res.json(response);
        }
        catch (err) {
            return this.handleError(res, err);
        }
    }
    async progress(campaignId, req, res) {
        const result = await (0, tenant_context_1.requireTenantPermission)(req, permissions_1.PERMISSIONS.CAMPAIGNS_READ);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        try {
            const response = await campaign_execution_service_1.campaignExecutionService.getProgress(result.ctx, campaignId);
            return res.json(response);
        }
        catch (err) {
            return this.handleError(res, err);
        }
    }
    async retryPolicy(campaignId, req, res) {
        const result = await (0, tenant_context_1.requireTenantPermission)(req, permissions_1.PERMISSIONS.CAMPAIGNS_READ);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        try {
            const response = await campaign_execution_service_1.campaignExecutionService.getRetryPolicy(result.ctx, campaignId);
            return res.json(response);
        }
        catch (err) {
            return this.handleError(res, err);
        }
    }
    async updateRetryPolicy(campaignId, req, res) {
        const result = await (0, tenant_context_1.requireTenantPermission)(req, permissions_1.PERMISSIONS.CAMPAIGNS_WRITE);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        try {
            const body = retryPolicySchema.parse(req.body ?? {});
            const response = await campaign_execution_service_1.campaignExecutionService.updateRetryPolicy(result.ctx, campaignId, body);
            return res.json(response);
        }
        catch (err) {
            return this.handleError(res, err);
        }
    }
    async retryHistory(campaignId, phoneNumber, req, res) {
        const result = await (0, tenant_context_1.requireTenantPermission)(req, permissions_1.PERMISSIONS.CAMPAIGNS_READ);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        try {
            const response = await campaign_execution_service_1.campaignExecutionService.getRetryHistory(result.ctx, campaignId, phoneNumber);
            return res.json(response);
        }
        catch (err) {
            return this.handleError(res, err);
        }
    }
    async pendingRetries(campaignId, req, res) {
        const result = await (0, tenant_context_1.requireTenantPermission)(req, permissions_1.PERMISSIONS.CAMPAIGNS_READ);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        try {
            const response = await campaign_execution_service_1.campaignExecutionService.getPendingRetries(result.ctx, campaignId);
            return res.json(response);
        }
        catch (err) {
            return this.handleError(res, err);
        }
    }
    async retryStatistics(campaignId, req, res) {
        const result = await (0, tenant_context_1.requireTenantPermission)(req, permissions_1.PERMISSIONS.CAMPAIGNS_READ);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        try {
            const response = await campaign_execution_service_1.campaignExecutionService.getRetryStatistics(result.ctx, campaignId);
            return res.json(response);
        }
        catch (err) {
            return this.handleError(res, err);
        }
    }
    async retrySummary(campaignId, req, res) {
        const result = await (0, tenant_context_1.requireTenantPermission)(req, permissions_1.PERMISSIONS.CAMPAIGNS_READ);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        try {
            const response = await campaign_execution_service_1.campaignExecutionService.getRetrySummary(result.ctx, campaignId);
            return res.json(response);
        }
        catch (err) {
            return this.handleError(res, err);
        }
    }
    handleError(res, err) {
        if (err instanceof zod_1.z.ZodError) {
            return res
                .status(400)
                .json({ error: err.issues[0]?.message ?? err.message });
        }
        if ((0, errors_1.isAppError)(err)) {
            return res.status(err.statusCode).json({ error: err.message });
        }
        return res.status(500).json({ error: "Internal server error" });
    }
};
exports.CampaignExecutionController = CampaignExecutionController;
__decorate([
    (0, common_1.Post)("start"),
    __param(0, (0, common_1.Param)("campaignId")),
    __param(1, (0, common_1.Req)()),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], CampaignExecutionController.prototype, "start", null);
__decorate([
    (0, common_1.Post)("schedule"),
    __param(0, (0, common_1.Param)("campaignId")),
    __param(1, (0, common_1.Req)()),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], CampaignExecutionController.prototype, "schedule", null);
__decorate([
    (0, common_1.Post)("pause"),
    __param(0, (0, common_1.Param)("campaignId")),
    __param(1, (0, common_1.Req)()),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], CampaignExecutionController.prototype, "pause", null);
__decorate([
    (0, common_1.Post)("resume"),
    __param(0, (0, common_1.Param)("campaignId")),
    __param(1, (0, common_1.Req)()),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], CampaignExecutionController.prototype, "resume", null);
__decorate([
    (0, common_1.Post)("retry"),
    __param(0, (0, common_1.Param)("campaignId")),
    __param(1, (0, common_1.Req)()),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], CampaignExecutionController.prototype, "retry", null);
__decorate([
    (0, common_1.Post)("reset"),
    __param(0, (0, common_1.Param)("campaignId")),
    __param(1, (0, common_1.Req)()),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], CampaignExecutionController.prototype, "reset", null);
__decorate([
    (0, common_1.Post)("cancel"),
    __param(0, (0, common_1.Param)("campaignId")),
    __param(1, (0, common_1.Req)()),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], CampaignExecutionController.prototype, "cancel", null);
__decorate([
    (0, common_1.Get)("status"),
    __param(0, (0, common_1.Param)("campaignId")),
    __param(1, (0, common_1.Req)()),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], CampaignExecutionController.prototype, "status", null);
__decorate([
    (0, common_1.Get)("statistics"),
    __param(0, (0, common_1.Param)("campaignId")),
    __param(1, (0, common_1.Req)()),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], CampaignExecutionController.prototype, "statistics", null);
__decorate([
    (0, common_1.Get)("progress"),
    __param(0, (0, common_1.Param)("campaignId")),
    __param(1, (0, common_1.Req)()),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], CampaignExecutionController.prototype, "progress", null);
__decorate([
    (0, common_1.Get)("retry-policy"),
    __param(0, (0, common_1.Param)("campaignId")),
    __param(1, (0, common_1.Req)()),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], CampaignExecutionController.prototype, "retryPolicy", null);
__decorate([
    (0, common_1.Put)("retry-policy"),
    __param(0, (0, common_1.Param)("campaignId")),
    __param(1, (0, common_1.Req)()),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], CampaignExecutionController.prototype, "updateRetryPolicy", null);
__decorate([
    (0, common_1.Get)("retry-history"),
    __param(0, (0, common_1.Param)("campaignId")),
    __param(1, (0, common_1.Query)("phoneNumber")),
    __param(2, (0, common_1.Req)()),
    __param(3, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object, Object]),
    __metadata("design:returntype", Promise)
], CampaignExecutionController.prototype, "retryHistory", null);
__decorate([
    (0, common_1.Get)("pending-retries"),
    __param(0, (0, common_1.Param)("campaignId")),
    __param(1, (0, common_1.Req)()),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], CampaignExecutionController.prototype, "pendingRetries", null);
__decorate([
    (0, common_1.Get)("retry-statistics"),
    __param(0, (0, common_1.Param)("campaignId")),
    __param(1, (0, common_1.Req)()),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], CampaignExecutionController.prototype, "retryStatistics", null);
__decorate([
    (0, common_1.Get)("retry-summary"),
    __param(0, (0, common_1.Param)("campaignId")),
    __param(1, (0, common_1.Req)()),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], CampaignExecutionController.prototype, "retrySummary", null);
exports.CampaignExecutionController = CampaignExecutionController = __decorate([
    (0, common_1.Controller)("api/campaigns/:campaignId/execution")
], CampaignExecutionController);
//# sourceMappingURL=campaign-execution.controller.js.map