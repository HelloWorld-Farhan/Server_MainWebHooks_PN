"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.schema = void 0;
const schema_1 = require("@graphql-tools/schema");
const debug_1 = require("./debug");
const database_url_1 = require("../lib/database-url");
const resolvers_1 = require("../resolvers");
const type_defs_generated_1 = require("./type-defs.generated");
function buildSchema() {
    (0, debug_1.gqlDebug)("schema:init:start", {
        typeDefCount: type_defs_generated_1.typeDefs.length,
        hasDatabaseUrl: Boolean((0, database_url_1.getDatabaseUrl)()),
        nodeEnv: process.env.NODE_ENV,
    });
    try {
        const built = (0, schema_1.makeExecutableSchema)({
            typeDefs: [...type_defs_generated_1.typeDefs],
            resolvers: resolvers_1.resolvers,
        });
        (0, debug_1.gqlDebug)("schema:init:done", { typeDefCount: type_defs_generated_1.typeDefs.length });
        return built;
    }
    catch (error) {
        (0, debug_1.gqlLogError)("schema:init:error", error, { typeDefCount: type_defs_generated_1.typeDefs.length });
        throw error;
    }
}
exports.schema = buildSchema();
//# sourceMappingURL=server.js.map