export declare const STANDARD_RATE_PER_MIN = 6;
export declare const VOLUME_RATE_PER_MIN = 5;
export declare const VOLUME_TIER_MIN_MINUTES = 30000;
export declare const VOLUME_TIER_MAX_MINUTES = 60000;
export type MinutePricingTier = {
    id: string;
    title: string;
    rangeLabel: string;
    ratePerMin: number | null;
    description: string;
    minMinutes: number;
    maxMinutes: number | null;
};
export declare const minutePricingTiers: MinutePricingTier[];
export declare const monthlyMinutePresets: {
    label: string;
    minutes: number;
}[];
export declare const pricingPlans: ({
    id: string;
    title: string;
    subtitle: string;
    description: string;
    features: string[];
    cta: string;
    ctaHref: string;
    variant: "outline";
    highlighted?: undefined;
} | {
    id: string;
    title: string;
    subtitle: string;
    description: null;
    features: string[];
    cta: string;
    ctaHref: string;
    variant: "default";
    highlighted: boolean;
})[];
export declare const pricingFaqs: {
    question: string;
    answer: string;
}[];
export declare function formatInr(amount: number): string;
export declare function formatRatePerMin(rate: number): string;
export type MinutePricingResult = {
    tier: MinutePricingTier;
    ratePerMin: number | null;
    isCustom: boolean;
    estimatedMonthlyCost: number | null;
};
export declare function getPricingForMonthlyMinutes(minutes: number): MinutePricingResult;
export declare function formatMinutes(minutes: number): string;
