import type { IntegrationId } from "../integrations/types";
export type AgentToolId = "faq" | "billing" | "google-calendar" | "google-sheets";
export type ToolStatus = "enabled" | "disabled";
export type ToolHealth = "healthy" | "degraded" | "down" | "unavailable";
export type ToolUsageMetrics = {
    totalExecutions: number;
    successRate: number;
    lastUsedAt: string | null;
    errorCount: number;
};
export type FaqToolConfig = {
    knowledgeSourceIds: string[];
    confidenceThreshold: number;
    fallbackResponse: string;
};
export type BillingToolPermissions = {
    creditAccess: boolean;
    planAccess: boolean;
    invoiceAccess: boolean;
};
export type BillingToolConfig = {
    permissions: BillingToolPermissions;
};
export type GoogleCalendarToolPermissions = {
    checkAvailability: boolean;
    createEvents: boolean;
    rescheduleEvents: boolean;
    cancelEvents: boolean;
};
export type GoogleCalendarToolConfig = {
    permissions: GoogleCalendarToolPermissions;
};
export type GoogleSheetsToolPermissions = {
    readRecords: boolean;
    createRecords: boolean;
    updateRecords: boolean;
    saveCallOutcomes: boolean;
    saveNotes: boolean;
    saveLeadScores: boolean;
};
export type GoogleSheetsToolConfig = {
    permissions: GoogleSheetsToolPermissions;
};
export type ToolConfig = FaqToolConfig | BillingToolConfig | GoogleCalendarToolConfig | GoogleSheetsToolConfig;
export type AgentToolAssignment = {
    toolId: AgentToolId;
    enabled: boolean;
    status: ToolStatus;
    health: ToolHealth;
    config: ToolConfig;
    usage: ToolUsageMetrics;
    blockedReason?: string;
};
export type AgentToolsState = {
    agentId: string;
    tools: AgentToolAssignment[];
};
export declare const DEFAULT_FAQ_CONFIG: FaqToolConfig;
export declare const DEFAULT_BILLING_CONFIG: BillingToolConfig;
export declare const DEFAULT_CALENDAR_TOOL_CONFIG: GoogleCalendarToolConfig;
export declare const DEFAULT_SHEETS_TOOL_CONFIG: GoogleSheetsToolConfig;
export type ToolDefinition = {
    id: AgentToolId;
    name: string;
    description: string;
    requiredIntegrationId?: IntegrationId;
};
