"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.redisConnection = void 0;
const ioredis_1 = __importDefault(require("ioredis"));
const redisUrl = process.env.UPSTASH_REDIS_URL || process.env.REDIS_URL || "redis://:Propnexai@123@200.234.34.240:6379";
exports.redisConnection = redisUrl
    ? new ioredis_1.default(redisUrl, {
        maxRetriesPerRequest: null,
    })
    : null;
if (!redisUrl) {
    console.warn("⚠️ REDIS_URL not found. BullMQ features (scheduled callbacks) will be disabled.");
}
//# sourceMappingURL=redis.client.js.map