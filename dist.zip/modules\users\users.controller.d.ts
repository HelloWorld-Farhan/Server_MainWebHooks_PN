import type { Request, Response } from "express";
export declare class UsersController {
    private readonly logger;
    signup(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    signin(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    getMe(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    getDashboardStats(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    getRecentActivity(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    getInboundCalls(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    requestTopup(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    getBillingHistory(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    getPendingTopup(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    remindAdmin(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
}
