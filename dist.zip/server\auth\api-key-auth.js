"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getApiKeyTokenFromRequest = getApiKeyTokenFromRequest;
exports.authenticateApiKey = authenticateApiKey;
exports.tryAuthenticateApiKeyFromRequest = tryAuthenticateApiKeyFromRequest;
const errors_1 = require("../lib/errors");
const api_key_crypto_1 = require("../lib/api-key-crypto");
const api_key_tenant_context_1 = require("../lib/api-key-tenant-context");
const prisma_1 = __importDefault(require("../lib/prisma"));
function logAuthFailure(reason, meta = {}) {
    console.warn("[api-key:auth:failed]", { reason, ...meta });
}
function getAuthorizationHeader(req, fetchRequest) {
    if (req) {
        const value = req.get("authorization");
        return value ?? null;
    }
    if (fetchRequest) {
        return fetchRequest.headers.get("authorization");
    }
    return null;
}
function getApiKeyTokenFromRequest(req, fetchRequest) {
    const header = getAuthorizationHeader(req, fetchRequest);
    const token = (0, api_key_crypto_1.extractBearerToken)(header);
    if (!token || !(0, api_key_crypto_1.looksLikeApiKey)(token))
        return null;
    return token;
}
async function authenticateApiKey(plaintext) {
    let parsed;
    try {
        parsed = (0, api_key_crypto_1.parseApiKey)(plaintext);
    }
    catch (error) {
        logAuthFailure("invalid_format");
        if (error instanceof errors_1.InvalidApiKeyFormatError)
            throw error;
        throw new errors_1.InvalidApiKeyFormatError();
    }
    const apiKey = await prisma_1.default.apiKey.findFirst({
        where: {
            keyId: parsed.keyId,
            deletedAt: null,
        },
        include: {
            campaignAccess: true,
        },
    });
    if (!apiKey) {
        logAuthFailure("not_found", { keyId: parsed.keyId });
        throw new errors_1.InvalidApiKeyError();
    }
    if (apiKey.environment !== parsed.environment) {
        logAuthFailure("environment_mismatch", { keyId: parsed.keyId });
        throw new errors_1.InvalidApiKeyError();
    }
    const primaryValid = (0, api_key_crypto_1.verifyApiKeySecret)(parsed.secret, apiKey.hashedSecret);
    const previousValid = Boolean(apiKey.previousHashedSecret) &&
        Boolean(apiKey.previousSecretExpiresAt) &&
        apiKey.previousSecretExpiresAt > new Date() &&
        (0, api_key_crypto_1.verifyApiKeySecret)(parsed.secret, apiKey.previousHashedSecret);
    if (!primaryValid && !previousValid) {
        logAuthFailure("secret_mismatch", { keyId: parsed.keyId, apiKeyId: apiKey.id });
        throw new errors_1.InvalidApiKeyError();
    }
    if (apiKey.status !== "ACTIVE") {
        logAuthFailure("disabled", { keyId: parsed.keyId, apiKeyId: apiKey.id });
        throw new errors_1.ApiKeyDisabledError();
    }
    if (apiKey.expiresAt && apiKey.expiresAt <= new Date()) {
        logAuthFailure("expired", { keyId: parsed.keyId, apiKeyId: apiKey.id });
        throw new errors_1.ApiKeyExpiredError();
    }
    void prisma_1.default.apiKey
        .update({
        where: { id: apiKey.id },
        data: { lastUsedAt: new Date() },
    })
        .catch((error) => {
        console.warn("[api-key:auth:lastUsedAt]", {
            apiKeyId: apiKey.id,
            error: error instanceof Error ? error.message : String(error),
        });
    });
    return (0, api_key_tenant_context_1.buildApiKeyTenantContext)(apiKey);
}
async function tryAuthenticateApiKeyFromRequest(req, fetchRequest) {
    const token = getApiKeyTokenFromRequest(req, fetchRequest);
    if (!token)
        return null;
    return authenticateApiKey(token);
}
//# sourceMappingURL=api-key-auth.js.map