"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.retrySchedulerService = exports.RetrySchedulerService = void 0;
const client_1 = require("@prisma/client");
const campaign_execution_repository_1 = require("../campaign-execution.repository");
const retry_logger_1 = require("../lib/retry-logger");
const mapper_1 = require("../../lib/public-id/mapper");
const prisma_1 = __importDefault(require("../../lib/prisma"));
const system_tenant_context_1 = require("../lib/system-tenant-context");
const retry_config_1 = require("./retry.config");
const contact_completion_service_1 = require("./contact-completion.service");
const retry_job_repository_1 = require("./retry-job.repository");
const retry_policy_service_1 = require("./retry-policy.service");
class RetrySchedulerService {
    async handleTerminalCall(input) {
        const { companyId, callLogId, campaignId, mappedStatus, correlationId } = input;
        const callLog = await prisma_1.default.callLog.findFirst({
            where: { id: callLogId, companyId },
            select: {
                retryNumber: true,
                phoneNumber: { select: { number: true } },
            },
        });
        if (!callLog) {
            return;
        }
        const phone = input.phone ?? callLog.phoneNumber?.number;
        if (!phone) {
            return;
        }
        const execution = await campaign_execution_repository_1.campaignExecutionRepository.findByCampaignId(companyId, campaignId);
        if (!execution || execution.status !== "RUNNING") {
            return;
        }
        const policy = retry_policy_service_1.retryPolicyService.extractPolicy(execution);
        const currentRetryCount = await retry_policy_service_1.retryPolicyService.countRetriesForContact(companyId, campaignId, phone);
        const ctx = await (0, system_tenant_context_1.createSystemTenantContext)(companyId);
        const campaignPublicId = await (0, mapper_1.toCampaignPublicId)(ctx, execution.campaign.resourceKey);
        if (!retry_policy_service_1.retryPolicyService.shouldRetry(policy, mappedStatus, currentRetryCount)) {
            await contact_completion_service_1.contactCompletionService.markContactCompleteIfDone(companyId, campaignId, phone);
            return;
        }
        if (execution.pendingRetries >= retry_config_1.retryConfig.maxPendingRetries) {
            (0, retry_logger_1.logRetryEvent)("retry:skipped", {
                campaignPublicId,
                phoneNumber: phone,
                retryNumber: currentRetryCount + 1,
                correlationId,
                skipReason: "max_pending_retries_cap",
                parentCallLogId: callLogId,
            });
            await contact_completion_service_1.contactCompletionService.markContactCompleteIfDone(companyId, campaignId, phone);
            return;
        }
        const scheduledAt = new Date(Date.now() + policy.retryDelaySeconds * 1000);
        try {
            await retry_job_repository_1.retryJobRepository.create({
                companyId,
                campaignId,
                parentCallLogId: callLogId,
                phoneNumber: phone,
                retryNumber: callLog.retryNumber + 1,
                retryReason: mappedStatus,
                correlationId: correlationId ?? execution.correlationId ?? undefined,
                scheduledAt,
            });
            await retry_job_repository_1.retryJobRepository.incrementExecutionCounters(companyId, campaignId, {
                pendingRetries: { increment: 1 },
                totalRetries: { increment: 1 },
            });
            (0, retry_logger_1.logRetryEvent)("retry:scheduled", {
                campaignPublicId,
                phoneNumber: phone,
                retryNumber: callLog.retryNumber + 1,
                correlationId,
                reason: mappedStatus,
                parentCallLogId: callLogId,
            });
        }
        catch (error) {
            if (error instanceof client_1.Prisma.PrismaClientKnownRequestError &&
                error.code === "P2002") {
                (0, retry_logger_1.logRetryEvent)("retry:skipped", {
                    campaignPublicId,
                    phoneNumber: phone,
                    retryNumber: callLog.retryNumber + 1,
                    correlationId,
                    skipReason: "duplicate_parent_call_log",
                    parentCallLogId: callLogId,
                });
                return;
            }
            throw error;
        }
    }
}
exports.RetrySchedulerService = RetrySchedulerService;
exports.retrySchedulerService = new RetrySchedulerService();
//# sourceMappingURL=retry-scheduler.service.js.map