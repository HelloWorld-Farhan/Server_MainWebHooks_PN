import type { PageCacheParams } from "../cache/keys";
export declare function parsePageCacheParams(searchParams: URLSearchParams): PageCacheParams;
