"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.emailService = exports.EmailService = void 0;
const nodemailer_1 = __importDefault(require("nodemailer"));
class EmailService {
    transporter = null;
    constructor() {
        const host = process.env.SMTP_HOST;
        const port = process.env.SMTP_PORT;
        const user = process.env.SMTP_USER;
        const pass = process.env.SMTP_PASS;
        if (host && port) {
            this.transporter = nodemailer_1.default.createTransport({
                host,
                port: parseInt(port, 10),
                auth: user && pass ? { user, pass } : undefined,
                secure: port === "465",
            });
        }
    }
    async sendEmail(options) {
        try {
            if (this.transporter) {
                await this.transporter.sendMail({
                    from: process.env.SMTP_FROM || '"PropNex AI" <noreply@propnex.ai>',
                    to: options.to,
                    subject: options.subject,
                    html: options.html,
                });
                return true;
            }
            else {
                console.log("=========================================");
                console.log(`[Email Service Mock] Sending email to: ${options.to}`);
                console.log(`Subject: ${options.subject}`);
                console.log(`Body:\n${options.html}`);
                console.log("=========================================");
                return true;
            }
        }
        catch (err) {
            console.error("[Email Service Error] Failed to send email:", err);
            return false;
        }
    }
}
exports.EmailService = EmailService;
exports.emailService = new EmailService();
//# sourceMappingURL=email.service.js.map