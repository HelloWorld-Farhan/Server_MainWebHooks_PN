"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createGraphQLContext = createGraphQLContext;
const clerk_1 = require("../../auth/clerk");
const request_context_1 = require("../../auth/request-context");
const api_key_auth_1 = require("../auth/api-key-auth");
const debug_1 = require("./debug");
const errors_1 = require("../lib/errors");
const tenant_context_builder_1 = require("../lib/tenant-context-builder");
const company_resolution_service_1 = require("../services/company-resolution.service");
async function createGraphQLContext(req, fetchRequest) {
    return (0, debug_1.gqlDebugTimed)("context:total", async () => {
        const expressRequest = req ?? (0, request_context_1.getCurrentRequest)();
        const apiKeyCtx = await (0, debug_1.gqlDebugTimed)("context:apiKeyAuth", async () => (0, api_key_auth_1.tryAuthenticateApiKeyFromRequest)(expressRequest, fetchRequest));
        if (apiKeyCtx) {
            (0, debug_1.gqlDebug)("context:done", {
                authType: "api_key",
                companyId: apiKeyCtx.companyId,
                apiKeyId: apiKeyCtx.apiKeyId,
            });
            return {
                isAuthenticated: true,
                ...apiKeyCtx,
            };
        }
        const authPath = expressRequest
            ? "express"
            : fetchRequest
                ? "fetch"
                : "none";
        const { userId, orgId } = await (0, debug_1.gqlDebugTimed)("context:auth", async () => {
            if (expressRequest) {
                return (0, clerk_1.getAuthFromRequest)(expressRequest);
            }
            if (fetchRequest) {
                return (0, clerk_1.getAuthFromFetchRequest)(fetchRequest);
            }
            return { userId: null, orgId: null };
        });
        (0, debug_1.gqlDebug)("context:auth", {
            authPath,
            hasUserId: Boolean(userId),
            hasOrgId: Boolean(orgId),
        });
        if (!userId) {
            (0, debug_1.gqlDebug)("context:auth:unauthorized", { reason: "no userId" });
            throw new errors_1.UnauthorizedError();
        }
        const resolutionCache = {};
        let tenant;
        try {
            tenant = await (0, debug_1.gqlDebugTimed)("context:resolveTenant", () => (0, company_resolution_service_1.resolveAuthenticatedTenant)(userId, orgId, { resolutionCache }));
        }
        catch (error) {
            (0, debug_1.gqlLogError)("context:resolveTenant:error", error, {
                clerkUserId: userId,
                orgId,
            });
            throw error;
        }
        (0, debug_1.gqlDebug)("context:resolveTenant", {
            orgId,
            companyFound: Boolean(tenant),
        });
        if (!tenant) {
            (0, debug_1.gqlDebug)("context:noCompany", { orgId, hasUserId: Boolean(userId) });
            throw new errors_1.ForbiddenError("Tenant not provisioned");
        }
        const tenantContext = await (0, debug_1.gqlDebugTimed)("context:buildTenant", () => (0, tenant_context_builder_1.buildTenantContext)(userId, tenant.company.id, tenant.membership));
        (0, debug_1.gqlDebug)("context:done", {
            authType: "user",
            companyId: tenant.company.id,
            userId: tenant.user.id,
            role: tenant.membership.role,
        });
        return {
            isAuthenticated: true,
            ...tenantContext,
        };
    });
}
//# sourceMappingURL=context.js.map