import type { Request, Response } from "express";
export declare class InternalController {
    sheetsSync(req: Request, body: {
        callId?: string;
    }, res: Response): Promise<Response<any, Record<string, any>>>;
}
