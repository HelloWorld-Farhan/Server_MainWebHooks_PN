"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getChannelQueuePollMs = exports.getChannelCooldownMs = exports.ChannelQueueWorker = exports.drainCompanyQueue = void 0;
const common_1 = require("@nestjs/common");
const redis_client_1 = require("../cache/redis.client");
const channel_keys_1 = require("./channel-keys");
Object.defineProperty(exports, "getChannelCooldownMs", { enumerable: true, get: function () { return channel_keys_1.getChannelCooldownMs; } });
Object.defineProperty(exports, "getChannelQueuePollMs", { enumerable: true, get: function () { return channel_keys_1.getChannelQueuePollMs; } });
const channel_queue_drain_1 = require("./channel-queue.drain");
const channel_queue_hooks_1 = require("./channel-queue.hooks");
const channel_service_1 = require("./channel.service");
const prisma_1 = __importDefault(require("../lib/prisma"));
const run_worker_task_1 = require("../lib/run-worker-task");
var channel_queue_drain_2 = require("./channel-queue.drain");
Object.defineProperty(exports, "drainCompanyQueue", { enumerable: true, get: function () { return channel_queue_drain_2.drainCompanyQueue; } });
let ChannelQueueWorker = class ChannelQueueWorker {
    interval = null;
    processing = false;
    onModuleInit() {
        if ((0, redis_client_1.isRedisDisabled)()) {
            (0, channel_queue_hooks_1.registerCompanyQueueWake)(async () => undefined);
            return;
        }
        (0, channel_queue_hooks_1.registerCompanyQueueWake)(channel_queue_drain_1.drainCompanyQueue);
        this.interval = setInterval(() => {
            (0, run_worker_task_1.runWorkerTask)("channel-queue", () => this.tick());
        }, (0, channel_keys_1.getChannelQueuePollMs)());
    }
    onModuleDestroy() {
        if (this.interval) {
            clearInterval(this.interval);
            this.interval = null;
        }
    }
    async tick() {
        if (this.processing) {
            return;
        }
        this.processing = true;
        try {
            const releases = await channel_service_1.channelService.drainExpiredCooldowns();
            const companies = new Set(releases.map((entry) => entry.companyId));
            for (const release of releases) {
                await channel_service_1.channelService.release(release.companyId);
                companies.add(release.companyId);
            }
            const companiesWithChannels = await prisma_1.default.company.findMany({
                where: {
                    setupConfig: {
                        is: {
                            totalChannels: { gt: 0 },
                        },
                    },
                },
                select: { id: true },
            });
            const pending = await channel_service_1.channelService.listCompaniesWithPendingWork(companiesWithChannels.map((company) => company.id));
            for (const companyId of pending) {
                companies.add(companyId);
            }
            for (const companyId of companies) {
                await this.processCompanyQueue(companyId);
            }
        }
        finally {
            this.processing = false;
        }
    }
    async processCompanyQueue(companyId) {
        await (0, channel_queue_drain_1.drainCompanyQueue)(companyId);
    }
};
exports.ChannelQueueWorker = ChannelQueueWorker;
exports.ChannelQueueWorker = ChannelQueueWorker = __decorate([
    (0, common_1.Injectable)()
], ChannelQueueWorker);
//# sourceMappingURL=channel-queue.worker.js.map