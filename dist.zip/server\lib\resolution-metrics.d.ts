type CounterKey = "clerk_api_requests" | "clerk_api_429" | "clerk_api_retries" | "redis_membership_hit" | "redis_membership_miss" | "redis_company_hit" | "redis_company_miss" | "cache_invalidations" | "circuit_breaker_opens";
export declare function incrementMetric(key: CounterKey, amount?: number): void;
export declare function recordReconciliationDuration(ms: number): void;
export declare function recordCompanyResolutionDuration(ms: number): void;
export declare function getResolutionMetricsSnapshot(): {
    reconciliation_duration_ms: number;
    company_resolution_duration_ms: number;
    clerk_api_requests: number;
    clerk_api_429: number;
    clerk_api_retries: number;
    redis_membership_hit: number;
    redis_membership_miss: number;
    redis_company_hit: number;
    redis_company_miss: number;
    cache_invalidations: number;
    circuit_breaker_opens: number;
};
export declare function logResolutionEvent(label: string, data?: Record<string, unknown>): void;
export {};
