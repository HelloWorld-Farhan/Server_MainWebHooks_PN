"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.publicIdResolver = exports.PublicIdResolverService = void 0;
const prisma_1 = __importDefault(require("../lib/prisma"));
const public_id_1 = require("../lib/public-id");
const types_1 = require("../lib/public-id/types");
const errors_1 = require("../lib/errors");
function normalizeEntityIdForLookup(entityId, resourceType) {
    if (resourceType === types_1.PublicResourceType.CALL_LOG) {
        return (0, public_id_1.normalizeCallLogEntityId)(entityId);
    }
    return entityId;
}
const LEGACY_RESOURCE_MODEL = {
    [types_1.PublicResourceType.AGENT]: {
        findByKey: (companyId, resourceKey) => prisma_1.default.aiAgent.findFirst({
            where: { companyId, resourceKey },
            select: { id: true },
        }),
        findKeyById: (companyId, id) => prisma_1.default.aiAgent.findFirst({
            where: { companyId, id },
            select: { resourceKey: true },
        }),
    },
    [types_1.PublicResourceType.CONTACT]: {
        findByKey: (companyId, resourceKey) => prisma_1.default.uploadedContact.findFirst({
            where: { companyId, resourceKey },
            select: { id: true },
        }),
        findKeyById: (companyId, id) => prisma_1.default.uploadedContact.findFirst({
            where: { companyId, id },
            select: { resourceKey: true },
        }),
    },
    [types_1.PublicResourceType.CAMPAIGN]: {
        findByKey: (companyId, resourceKey) => prisma_1.default.campaign.findFirst({
            where: { companyId, resourceKey },
            select: { id: true },
        }),
        findKeyById: (companyId, id) => prisma_1.default.campaign.findFirst({
            where: { companyId, id },
            select: { resourceKey: true },
        }),
    },
};
const CAMPAIGN_SCOPED_RESOURCE_MODEL = {
    [types_1.PublicResourceType.CALL_LOG]: {
        findByPublicId: (companyId, publicId) => prisma_1.default.callLog.findFirst({
            where: { companyId, publicId },
            select: { id: true },
        }),
        findByCampaignAndEntity: (companyId, campaignResourceKey, entityId) => prisma_1.default.callLog.findFirst({
            where: {
                companyId,
                callLogId: (0, public_id_1.normalizeCallLogEntityId)(entityId),
                campaign: { resourceKey: campaignResourceKey },
            },
            select: { id: true },
        }),
        findEntityById: (companyId, id) => prisma_1.default.callLog.findFirst({
            where: { companyId, id },
            select: {
                callLogId: true,
                publicId: true,
                campaignId: true,
                campaign: { select: { resourceKey: true } },
            },
        }).then((row) => row
            ? {
                entityId: row.callLogId,
                publicId: row.publicId,
                campaignId: row.campaignId,
                campaign: row.campaign,
            }
            : null),
    },
    [types_1.PublicResourceType.PHONE_NUMBER]: {
        findByPublicId: (companyId, publicId) => prisma_1.default.phoneNumber.findFirst({
            where: { companyId, publicId },
            select: { id: true },
        }),
        findByCampaignAndEntity: (companyId, campaignResourceKey, entityId) => prisma_1.default.phoneNumber.findFirst({
            where: {
                companyId,
                phoneNumberId: entityId,
                OR: [
                    {
                        campaign: { resourceKey: campaignResourceKey },
                    },
                    {
                        inboundAgent: {
                            campaign: { resourceKey: campaignResourceKey },
                        },
                    },
                    {
                        outboundAgent: {
                            campaign: { resourceKey: campaignResourceKey },
                        },
                    },
                ],
            },
            select: { id: true },
        }),
        findEntityById: (companyId, id) => prisma_1.default.phoneNumber
            .findFirst({
            where: { companyId, id },
            select: {
                phoneNumberId: true,
                publicId: true,
                campaignId: true,
                campaign: { select: { resourceKey: true } },
                inboundAgent: {
                    select: {
                        campaignId: true,
                        campaign: { select: { resourceKey: true } },
                    },
                },
                outboundAgent: {
                    select: {
                        campaignId: true,
                        campaign: { select: { resourceKey: true } },
                    },
                },
            },
        })
            .then((row) => {
            if (!row)
                return null;
            const campaign = row.campaign ??
                row.inboundAgent?.campaign ??
                row.outboundAgent?.campaign ??
                null;
            const campaignId = row.campaignId ??
                row.inboundAgent?.campaignId ??
                row.outboundAgent?.campaignId ??
                null;
            return {
                entityId: row.phoneNumberId,
                publicId: row.publicId,
                campaignId,
                campaign,
            };
        }),
    },
};
const companyIdentityCache = new Map();
class PublicIdResolverService {
    clearCompanyIdentityCache(companyId) {
        if (companyId) {
            companyIdentityCache.delete(companyId);
            return;
        }
        companyIdentityCache.clear();
    }
    async getCompanyPublicIdentity(companyId) {
        const cached = companyIdentityCache.get(companyId);
        if (cached) {
            return cached;
        }
        const company = await prisma_1.default.company.findUnique({
            where: { id: companyId },
            select: { cli: true, companyCode: true },
        });
        if (!company?.cli || !company.companyCode) {
            throw new errors_1.ValidationError("Company public identity is not configured");
        }
        const identity = {
            cli: company.cli,
            companyCode: company.companyCode,
        };
        companyIdentityCache.set(companyId, identity);
        return identity;
    }
    async getCampaignResourceKey(companyId, campaignInternalId) {
        const campaign = await prisma_1.default.campaign.findFirst({
            where: { companyId, id: campaignInternalId },
            select: { resourceKey: true },
        });
        if (!campaign?.resourceKey) {
            throw new errors_1.NotFoundError("Campaign not found");
        }
        return campaign.resourceKey;
    }
    toCampaignPublicId(identity, campaignResourceKey) {
        return (0, public_id_1.generateCampaignPublicId)({
            cli: identity.cli,
            campaignResourceKey,
        });
    }
    toLegacyPublicId(identity, resourceKey) {
        return (0, public_id_1.generateLegacyPublicId)({
            cli: identity.cli,
            companyCode: identity.companyCode,
            resourceKey,
        });
    }
    toPublicId(identity, campaignId, entityId) {
        return (0, public_id_1.generatePublicId)({
            cli: identity.cli,
            campaignId,
            entityId,
        });
    }
    async mapCampaignEntityToPublicId(companyId, campaignInternalId, entityId, identity) {
        if (!campaignInternalId) {
            throw new errors_1.ValidationError("Campaign is required for public ID");
        }
        const resolvedIdentity = identity ?? (await this.getCompanyPublicIdentity(companyId));
        const campaignResourceKey = await this.getCampaignResourceKey(companyId, campaignInternalId);
        return this.toPublicId(resolvedIdentity, campaignResourceKey, entityId);
    }
    async mapResourceKeyToLegacyPublicId(companyId, resourceKey, identity) {
        const resolvedIdentity = identity ?? (await this.getCompanyPublicIdentity(companyId));
        return this.toLegacyPublicId(resolvedIdentity, resourceKey);
    }
    async mapInternalIdToPublicId(companyId, internalId, resourceType, identity) {
        if (!internalId) {
            return null;
        }
        if (types_1.CAMPAIGN_SCOPED_RESOURCE_TYPES.has(resourceType)) {
            return this.mapInternalIdToCampaignScopedPublicId(companyId, internalId, undefined, resourceType, identity);
        }
        const row = await LEGACY_RESOURCE_MODEL[resourceType].findKeyById(companyId, internalId);
        if (!row?.resourceKey) {
            throw new errors_1.NotFoundError("Resource not found");
        }
        if (resourceType === types_1.PublicResourceType.CAMPAIGN) {
            const resolvedIdentity = identity ?? (await this.getCompanyPublicIdentity(companyId));
            return this.toCampaignPublicId(resolvedIdentity, row.resourceKey);
        }
        return this.mapResourceKeyToLegacyPublicId(companyId, row.resourceKey, identity);
    }
    async mapInternalIdToCampaignScopedPublicId(companyId, internalId, campaignInternalId, resourceType, identity) {
        if (!internalId) {
            return null;
        }
        const row = await CAMPAIGN_SCOPED_RESOURCE_MODEL[resourceType].findEntityById(companyId, internalId);
        if (!row?.entityId) {
            throw new errors_1.NotFoundError("Resource not found");
        }
        if (row.publicId) {
            return row.publicId;
        }
        const resolvedIdentity = identity ?? (await this.getCompanyPublicIdentity(companyId));
        if (campaignInternalId) {
            const campaignResourceKey = await this.getCampaignResourceKey(companyId, campaignInternalId);
            return this.toPublicId(resolvedIdentity, campaignResourceKey, row.entityId);
        }
        if (!row.campaignId || !row.campaign?.resourceKey) {
            throw new errors_1.ValidationError("Campaign context is required for campaign-scoped public ID");
        }
        return this.toPublicId(resolvedIdentity, row.campaign.resourceKey, row.entityId);
    }
    async mapInternalIdsToPublicIds(companyId, internalIds, resourceType, identity) {
        if (internalIds.length === 0) {
            return [];
        }
        const resolvedIdentity = identity ?? (await this.getCompanyPublicIdentity(companyId));
        const keys = await Promise.all(internalIds.map((id) => this.mapInternalIdToPublicId(companyId, id, resourceType, resolvedIdentity)));
        return keys.filter((id) => id !== null);
    }
    async resolveToInternalId(companyId, input, resourceType) {
        const trimmed = input.trim();
        if (!trimmed) {
            throw new errors_1.ValidationError("ID is required");
        }
        if (types_1.CAMPAIGN_SCOPED_RESOURCE_TYPES.has(resourceType)) {
            return this.resolveCampaignScopedToInternalId(companyId, trimmed, resourceType);
        }
        return this.resolveLegacyToInternalId(companyId, trimmed, resourceType);
    }
    async resolveCampaignScopedToInternalId(companyId, input, resourceType) {
        const model = CAMPAIGN_SCOPED_RESOURCE_MODEL[resourceType];
        if ((0, public_id_1.looksLikePublicId)(input)) {
            const campaignParsed = (0, public_id_1.parsePublicId)(input);
            if (campaignParsed) {
                if (!(0, public_id_1.resourceKeyMatchesType)(campaignParsed.entityId, resourceType)) {
                    throw new errors_1.ValidationError("Public ID does not match expected resource type");
                }
                const identity = await this.getCompanyPublicIdentity(companyId);
                if (campaignParsed.cli !== identity.cli) {
                    throw new errors_1.NotFoundError("Resource not found");
                }
                const byPublicId = await model.findByPublicId(companyId, input);
                if (byPublicId) {
                    return byPublicId.id;
                }
                const entityId = normalizeEntityIdForLookup(campaignParsed.entityId, resourceType);
                const row = await model.findByCampaignAndEntity(companyId, campaignParsed.campaignId, entityId);
                if (!row) {
                    throw new errors_1.NotFoundError("Resource not found");
                }
                return row.id;
            }
            const legacyParsed = (0, public_id_1.parseLegacyPublicId)(input);
            if (legacyParsed) {
                if (!(0, public_id_1.resourceKeyMatchesType)(legacyParsed.resourceKey, resourceType)) {
                    throw new errors_1.ValidationError("Public ID does not match expected resource type");
                }
                console.warn("[public-id:deprecated] Legacy company-scoped entity public ID format used; migrate to v1.<CLI>.<CP######>.<ENTITY>", { input, resourceType });
                const identity = await this.getCompanyPublicIdentity(companyId);
                if (legacyParsed.cli !== identity.cli ||
                    legacyParsed.companyCode !== identity.companyCode) {
                    throw new errors_1.NotFoundError("Resource not found");
                }
                const entityId = normalizeEntityIdForLookup(legacyParsed.resourceKey, resourceType);
                const row = await this.findLegacyCompanyScopedEntity(companyId, entityId, resourceType);
                if (!row) {
                    throw new errors_1.NotFoundError("Resource not found");
                }
                return row.id;
            }
        }
        if ((0, public_id_1.isLegacyObjectId)(input)) {
            const row = await model.findEntityById(companyId, input);
            if (!row) {
                throw new errors_1.NotFoundError("Resource not found");
            }
            return input;
        }
        throw new errors_1.ValidationError("Invalid public ID format");
    }
    async findLegacyCompanyScopedEntity(companyId, entityId, resourceType) {
        if (resourceType === types_1.PublicResourceType.CALL_LOG) {
            return prisma_1.default.callLog.findFirst({
                where: { companyId, callLogId: entityId },
                select: { id: true },
            });
        }
        return prisma_1.default.phoneNumber.findFirst({
            where: { companyId, phoneNumberId: entityId },
            select: { id: true },
        });
    }
    async resolveLegacyToInternalId(companyId, input, resourceType) {
        if ((0, public_id_1.looksLikePublicId)(input)) {
            if (resourceType === types_1.PublicResourceType.CAMPAIGN) {
                return this.resolveCampaignPublicIdToInternalId(companyId, input);
            }
            const parsed = (0, public_id_1.decodeLegacyPublicId)(input);
            if (!(0, public_id_1.resourceKeyMatchesType)(parsed.resourceKey, resourceType)) {
                throw new errors_1.ValidationError("Public ID does not match expected resource type");
            }
            const identity = await this.getCompanyPublicIdentity(companyId);
            if (parsed.cli !== identity.cli ||
                parsed.companyCode !== identity.companyCode) {
                throw new errors_1.NotFoundError("Resource not found");
            }
            const row = await LEGACY_RESOURCE_MODEL[resourceType].findByKey(companyId, parsed.resourceKey);
            if (!row) {
                throw new errors_1.NotFoundError("Resource not found");
            }
            return row.id;
        }
        if ((0, public_id_1.isLegacyObjectId)(input)) {
            const row = await LEGACY_RESOURCE_MODEL[resourceType].findKeyById(companyId, input);
            if (!row) {
                throw new errors_1.NotFoundError("Resource not found");
            }
            return input;
        }
        throw new errors_1.ValidationError("Invalid public ID format");
    }
    async resolveCampaignPublicIdToInternalId(companyId, input) {
        const campaignParsed = (0, public_id_1.parseCampaignPublicId)(input);
        if (campaignParsed) {
            const identity = await this.getCompanyPublicIdentity(companyId);
            if (campaignParsed.cli !== identity.cli) {
                throw new errors_1.NotFoundError("Resource not found");
            }
            const row = await LEGACY_RESOURCE_MODEL[types_1.PublicResourceType.CAMPAIGN].findByKey(companyId, campaignParsed.campaignResourceKey);
            if (!row) {
                throw new errors_1.NotFoundError("Resource not found");
            }
            return row.id;
        }
        const legacyParsed = (0, public_id_1.parseLegacyPublicId)(input);
        if (legacyParsed &&
            (0, public_id_1.resourceKeyMatchesType)(legacyParsed.resourceKey, types_1.PublicResourceType.CAMPAIGN)) {
            console.warn("[public-id:deprecated] Legacy campaign public ID format used; migrate to v1.<CLI>.<CP######>", { input });
            const identity = await this.getCompanyPublicIdentity(companyId);
            if (legacyParsed.cli !== identity.cli ||
                legacyParsed.companyCode !== identity.companyCode) {
                throw new errors_1.NotFoundError("Resource not found");
            }
            const row = await LEGACY_RESOURCE_MODEL[types_1.PublicResourceType.CAMPAIGN].findByKey(companyId, legacyParsed.resourceKey);
            if (!row) {
                throw new errors_1.NotFoundError("Resource not found");
            }
            return row.id;
        }
        throw new errors_1.ValidationError("Invalid public ID format");
    }
    tryParsePublicId(input) {
        return ((0, public_id_1.parsePublicId)(input) ??
            (0, public_id_1.parseCampaignPublicId)(input) ??
            (0, public_id_1.parseLegacyPublicId)(input));
    }
}
exports.PublicIdResolverService = PublicIdResolverService;
exports.publicIdResolver = new PublicIdResolverService();
//# sourceMappingURL=public-id-resolver.service.js.map