export declare const UPLOADED_CONTACTS_LIST_QUERY = "\n  query UploadedContactsList {\n    uploadedContacts {\n      list {\n        id\n        phone\n        field1\n        field2\n        field3\n        createdAt\n      }\n    }\n  }\n";
export declare const CREATE_UPLOADED_CONTACT_MUTATION = "\n  mutation CreateUploadedContact($phone: String!) {\n    uploadedContacts {\n      create(phone: $phone) {\n        id\n        phone\n        field1\n        field2\n        field3\n        createdAt\n      }\n    }\n  }\n";
export declare const IMPORT_UPLOADED_CONTACTS_MUTATION = "\n  mutation ImportUploadedContacts($contacts: [ImportedContactInput!]!) {\n    uploadedContacts {\n      importContacts(contacts: $contacts) {\n        created\n        updated\n        skipped\n        invalid\n        unmatchedCampaigns\n      }\n    }\n  }\n";
export declare const DELETE_UPLOADED_CONTACT_MUTATION = "\n  mutation DeleteUploadedContact($id: ID!) {\n    uploadedContacts {\n      delete(id: $id)\n    }\n  }\n";
export declare const BULK_DELETE_UPLOADED_CONTACTS_MUTATION = "\n  mutation BulkDeleteUploadedContacts($ids: [ID!]!) {\n    uploadedContacts {\n      bulkDelete(ids: $ids)\n    }\n  }\n";
export type UploadedContactResult = {
    id: string;
    phone: string;
    field1: string | null;
    field2: string | null;
    field3: string | null;
    createdAt: string;
};
export type ImportedContactInput = {
    phone: string;
    field1?: string | null;
    field2?: string | null;
    field3?: string | null;
    campaignNames?: string[];
    campaignIds?: string[];
};
export type UploadedContactsListResult = {
    uploadedContacts: {
        list: UploadedContactResult[];
    };
};
export type UploadedContactImportResult = {
    uploadedContacts: {
        importContacts: {
            created: number;
            updated: number;
            skipped: number;
            invalid: number;
            unmatchedCampaigns: string[];
        };
    };
};
