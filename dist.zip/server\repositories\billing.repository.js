"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnalyticsRepository = exports.BillingRepository = void 0;
const base_repository_1 = require("./base.repository");
const pagination_1 = require("../lib/pagination");
class BillingRepository extends base_repository_1.BaseRepository {
    getSubscription(companyId) {
        return this.prisma.billingSubscription.findUnique({
            where: { companyId },
        });
    }
    listInvoices(companyId, limit, after) {
        const cursor = after ? (0, pagination_1.decodeIdCursor)(after) : undefined;
        return this.prisma.billingInvoice.findMany({
            where: this.scope(companyId),
            orderBy: [{ issuedAt: "desc" }, { id: "desc" }],
            take: limit + 1,
            ...(cursor
                ? {
                    cursor: { id: cursor.id },
                    skip: 1,
                }
                : {}),
        });
    }
}
exports.BillingRepository = BillingRepository;
class AnalyticsRepository extends base_repository_1.BaseRepository {
    getLatestSnapshot(companyId, granularity) {
        return this.prisma.analyticsSnapshot.findFirst({
            where: {
                companyId,
                granularity,
                scope: "WORKSPACE",
                scopeId: "global",
            },
            orderBy: { periodStart: "desc" },
        });
    }
    async upsertDailySnapshot(companyId, periodStart, periodEnd, metricsDelta) {
        const existing = await this.prisma.analyticsSnapshot.findUnique({
            where: {
                companyId_granularity_periodStart_scope_scopeId: {
                    companyId,
                    granularity: "DAILY",
                    periodStart,
                    scope: "WORKSPACE",
                    scopeId: "global",
                },
            },
        });
        const currentMetrics = existing?.metrics ?? {};
        const mergedMetrics = { ...currentMetrics };
        for (const [key, value] of Object.entries(metricsDelta)) {
            mergedMetrics[key] = (mergedMetrics[key] ?? 0) + value;
        }
        return this.prisma.analyticsSnapshot.upsert({
            where: {
                companyId_granularity_periodStart_scope_scopeId: {
                    companyId,
                    granularity: "DAILY",
                    periodStart,
                    scope: "WORKSPACE",
                    scopeId: "global",
                },
            },
            create: {
                companyId,
                granularity: "DAILY",
                periodStart,
                periodEnd,
                scope: "WORKSPACE",
                scopeId: "global",
                metrics: mergedMetrics,
            },
            update: {
                metrics: mergedMetrics,
                periodEnd,
            },
        });
    }
}
exports.AnalyticsRepository = AnalyticsRepository;
//# sourceMappingURL=billing.repository.js.map