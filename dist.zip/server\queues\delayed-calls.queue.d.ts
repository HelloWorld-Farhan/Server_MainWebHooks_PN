import { Queue } from "bullmq";
import { CreateRetryOutboundCallInput, CreateOutboundCallInput } from "../services/outbound-calls.service";
import type { TenantContext } from "../types/context";
export declare const DELAYED_CALLS_QUEUE_NAME = "delayed-calls-queue";
export type DelayedCallJobData = {
    type: "RETRY" | "NEW";
    ctx: TenantContext;
    retryInput?: CreateRetryOutboundCallInput;
    newInput?: CreateOutboundCallInput;
    didNumber: string;
};
export declare const delayedCallsQueue: Queue<DelayedCallJobData, any, string, DelayedCallJobData, any, string, import("bullmq").RedisQueueBackend> | null;
export declare function scheduleDelayedCall(data: DelayedCallJobData, delayMs: number): Promise<void>;
