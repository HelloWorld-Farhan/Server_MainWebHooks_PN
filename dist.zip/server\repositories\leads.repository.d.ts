import type { LeadTemperature, Prisma } from "@prisma/client";
import { BaseRepository } from "./base.repository";
export type LeadFilter = {
    dormantOnly?: boolean;
    minDaysInactive?: number;
    temperature?: LeadTemperature;
};
export type LeadImportRow = {
    firstName?: string | null;
    lastName?: string | null;
    email?: string | null;
    phone: string;
    temperature: LeadTemperature;
};
export type LeadImportStats = {
    hot: number;
    warm: number;
    cold: number;
    total: number;
    invalid: number;
    created: number;
    updated: number;
};
export declare class LeadsRepository extends BaseRepository {
    findById(companyId: string, id: string): Prisma.Prisma__LeadClient<({
        stage: {
            name: string;
            id: string;
            slug: string;
            createdAt: Date;
            updatedAt: Date;
            companyId: string;
            order: number;
            color: string | null;
            isDefault: boolean;
            isClosed: boolean;
        };
        source: {
            name: string;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            companyId: string;
            type: import("@prisma/client").$Enums.LeadSourceType;
            isActive: boolean;
            externalId: string | null;
        } | null;
        assignedUser: {
            status: import("@prisma/client").$Enums.UserStatus;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            email: string;
            firstName: string | null;
            lastName: string | null;
            phone: string | null;
            clerkUserId: string;
            imageUrl: string | null;
            passwordHash: string | null;
            lastLoginAt: Date | null;
        } | null;
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        email: string | null;
        stageId: string;
        sourceId: string | null;
        assignedUserId: string | null;
        firstName: string | null;
        lastName: string | null;
        phone: string | null;
        companyName: string | null;
        temperature: import("@prisma/client").$Enums.LeadTemperature | null;
        score: number;
        customFields: Prisma.JsonValue;
        tags: string[];
        lastContactedAt: Date | null;
        nextFollowUpAt: Date | null;
        queueStatus: import("@prisma/client").$Enums.CallingQueueStatus;
        assignedAiAgentId: string | null;
        lockedAt: Date | null;
        channelId: string | null;
        campaignId: string | null;
    }) | null, null, import("@prisma/client/runtime/library").DefaultArgs, Prisma.PrismaClientOptions>;
    private buildWhere;
    findConnection(companyId: string, limit: number, after?: string, filter?: LeadFilter, scopeWhere?: Prisma.LeadWhereInput): Prisma.PrismaPromise<({
        stage: {
            name: string;
            id: string;
            slug: string;
            createdAt: Date;
            updatedAt: Date;
            companyId: string;
            order: number;
            color: string | null;
            isDefault: boolean;
            isClosed: boolean;
        };
        callLogs: ({
            aiAgent: {
                name: string;
                id: string;
            } | null;
        } & {
            status: import("@prisma/client").$Enums.CallStatus;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            companyId: string | null;
            assignedUserId: string | null;
            campaignId: string | null;
            phoneNumberId: string | null;
            publicId: string;
            provider: string | null;
            direction: import("@prisma/client").$Enums.CallDirection;
            callLogId: string;
            leadId: string | null;
            aiAgentId: string | null;
            outcome: import("@prisma/client").$Enums.CallOutcome | null;
            startedAt: Date;
            durationSeconds: number;
            recordingUrl: string | null;
            transcriptUrl: string | null;
            aiSummary: Prisma.JsonValue | null;
            sentiment: Prisma.JsonValue | null;
            engagement: Prisma.JsonValue | null;
            reactivationPlan: Prisma.JsonValue | null;
            cost: number | null;
            creditsUsed: number | null;
            providerStatus: string | null;
            providerCallId: string | null;
            correlationId: string | null;
            providerRequestedAt: Date | null;
            providerAcceptedAt: Date | null;
            providerCompletedAt: Date | null;
            answeredAt: Date | null;
            endedAt: Date | null;
            disconnectReason: string | null;
            providerRequest: Prisma.JsonValue | null;
            providerResponse: Prisma.JsonValue | null;
            providerWebhook: Prisma.JsonValue | null;
            providerMetadata: Prisma.JsonValue | null;
            retryNumber: number;
            parentCallLogId: string | null;
            isRetry: boolean;
            retryReason: import("@prisma/client").$Enums.CallStatus | null;
        })[];
        source: {
            name: string;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            companyId: string;
            type: import("@prisma/client").$Enums.LeadSourceType;
            isActive: boolean;
            externalId: string | null;
        } | null;
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        email: string | null;
        stageId: string;
        sourceId: string | null;
        assignedUserId: string | null;
        firstName: string | null;
        lastName: string | null;
        phone: string | null;
        companyName: string | null;
        temperature: import("@prisma/client").$Enums.LeadTemperature | null;
        score: number;
        customFields: Prisma.JsonValue;
        tags: string[];
        lastContactedAt: Date | null;
        nextFollowUpAt: Date | null;
        queueStatus: import("@prisma/client").$Enums.CallingQueueStatus;
        assignedAiAgentId: string | null;
        lockedAt: Date | null;
        channelId: string | null;
        campaignId: string | null;
    })[]>;
    countByTemperature(companyId: string, scopeWhere?: Prisma.LeadWhereInput): Prisma.GetLeadGroupByPayload<{
        by: "temperature"[];
        where: {
            companyId: string;
        } | {
            AND: (Prisma.LeadWhereInput | {
                companyId: string;
            })[];
        };
        _count: {
            id: true;
        };
    }>;
    create(companyId: string, data: Prisma.LeadCreateWithoutCompanyInput): Prisma.Prisma__LeadClient<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        email: string | null;
        stageId: string;
        sourceId: string | null;
        assignedUserId: string | null;
        firstName: string | null;
        lastName: string | null;
        phone: string | null;
        companyName: string | null;
        temperature: import("@prisma/client").$Enums.LeadTemperature | null;
        score: number;
        customFields: Prisma.JsonValue;
        tags: string[];
        lastContactedAt: Date | null;
        nextFollowUpAt: Date | null;
        queueStatus: import("@prisma/client").$Enums.CallingQueueStatus;
        assignedAiAgentId: string | null;
        lockedAt: Date | null;
        channelId: string | null;
        campaignId: string | null;
    }, never, import("@prisma/client/runtime/library").DefaultArgs, Prisma.PrismaClientOptions>;
    findByPhone(companyId: string, phone: string): Prisma.Prisma__LeadClient<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        email: string | null;
        stageId: string;
        sourceId: string | null;
        assignedUserId: string | null;
        firstName: string | null;
        lastName: string | null;
        phone: string | null;
        companyName: string | null;
        temperature: import("@prisma/client").$Enums.LeadTemperature | null;
        score: number;
        customFields: Prisma.JsonValue;
        tags: string[];
        lastContactedAt: Date | null;
        nextFollowUpAt: Date | null;
        queueStatus: import("@prisma/client").$Enums.CallingQueueStatus;
        assignedAiAgentId: string | null;
        lockedAt: Date | null;
        channelId: string | null;
        campaignId: string | null;
    } | null, null, import("@prisma/client/runtime/library").DefaultArgs, Prisma.PrismaClientOptions>;
    ensureImportDefaults(companyId: string): Promise<{
        stageId: string;
        sourceId: string;
    }>;
    importRows(companyId: string, rows: LeadImportRow[]): Promise<LeadImportStats>;
}
