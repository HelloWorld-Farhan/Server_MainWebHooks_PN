export declare class CampaignRunnerService {
    private readonly campaignsRepo;
    private readonly activeCampaignIds;
    getActiveCount(): number;
    resetActiveForTests(): void;
    processRunnableCampaigns(): Promise<number>;
    private processCampaign;
    private completeIfQueueDrained;
}
export declare const campaignRunnerService: CampaignRunnerService;
