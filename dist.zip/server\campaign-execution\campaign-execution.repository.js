"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.campaignExecutionRepository = exports.CampaignExecutionRepository = void 0;
const retry_config_1 = require("./retry/retry.config");
const prisma_write_retry_1 = require("../lib/prisma-write-retry");
const prisma_1 = __importDefault(require("../lib/prisma"));
const base_repository_1 = require("../repositories/base.repository");
class CampaignExecutionRepository extends base_repository_1.BaseRepository {
    findByCampaignId(companyId, campaignId) {
        return this.prisma.campaignExecution.findFirst({
            where: { companyId, campaignId },
            include: { campaign: { select: { resourceKey: true, name: true } } },
        });
    }
    findById(companyId, id) {
        return this.prisma.campaignExecution.findFirst({
            where: { id, companyId },
            include: { campaign: { select: { resourceKey: true, name: true } } },
        });
    }
    createDraft(companyId, campaignId, correlationId) {
        return this.prisma.campaignExecution.create({
            data: {
                companyId,
                campaignId,
                status: "DRAFT",
                correlationId,
                ...retry_config_1.DEFAULT_RETRY_POLICY,
            },
            include: { campaign: { select: { resourceKey: true, name: true } } },
        });
    }
    transitionStatus(companyId, campaignId, fromStatuses, data) {
        return (0, prisma_write_retry_1.withPrismaWriteRetry)(() => this.prisma.campaignExecution.updateMany({
            where: {
                companyId,
                campaignId,
                status: { in: fromStatuses },
            },
            data: data,
        }));
    }
    findDueScheduled(limit, now) {
        return this.prisma.campaignExecution.findMany({
            where: {
                status: "SCHEDULED",
                scheduledAt: { lte: now },
            },
            orderBy: [{ scheduledAt: "asc" }, { id: "asc" }],
            take: limit,
            include: { campaign: { select: { resourceKey: true } } },
        });
    }
    findRunningExecutions(limit) {
        return this.prisma.campaignExecution.findMany({
            where: { status: "RUNNING" },
            orderBy: [{ startedAt: "asc" }, { id: "asc" }],
            take: limit,
            include: { campaign: { select: { resourceKey: true } } },
        });
    }
    findStaleRunningLocks(now) {
        return this.prisma.campaignExecution.findMany({
            where: {
                status: "RUNNING",
                OR: [{ lockExpiresAt: null }, { lockExpiresAt: { lt: now } }],
            },
            include: { campaign: { select: { resourceKey: true } } },
        });
    }
    findActiveForProgress() {
        return this.prisma.campaignExecution.findMany({
            where: { status: { in: ["RUNNING", "PAUSED"] } },
            include: { campaign: { select: { resourceKey: true } } },
        });
    }
    updateLock(companyId, campaignId, workerId, lockExpiresAt) {
        return (0, prisma_write_retry_1.withPrismaWriteRetry)(() => this.prisma.campaignExecution.updateMany({
            where: { companyId, campaignId, status: "RUNNING" },
            data: { workerId, lockExpiresAt },
        }));
    }
    updateCursor(companyId, campaignId, lastProcessedContactId, processedCount) {
        return (0, prisma_write_retry_1.withPrismaWriteRetry)(() => this.prisma.campaignExecution.updateMany({
            where: { companyId, campaignId, status: "RUNNING" },
            data: { lastProcessedContactId, processedCount },
        }));
    }
    updateStatistics(companyId, campaignId, data) {
        return (0, prisma_write_retry_1.withPrismaWriteRetry)(() => this.prisma.campaignExecution.updateMany({
            where: { companyId, campaignId },
            data,
        }));
    }
    countRunning() {
        return this.prisma.campaignExecution.count({
            where: { status: "RUNNING" },
        });
    }
}
exports.CampaignExecutionRepository = CampaignExecutionRepository;
exports.campaignExecutionRepository = new CampaignExecutionRepository(prisma_1.default);
//# sourceMappingURL=campaign-execution.repository.js.map