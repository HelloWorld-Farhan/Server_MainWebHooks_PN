import type { Request } from "express";
export declare const clerkClient: import("@clerk/backend").ClerkClient;
export type ClerkAuthState = {
    userId: string | null;
    orgId: string | null;
    sessionId: string | null;
};
export declare function getAuthFromFetchRequest(request: globalThis.Request): Promise<ClerkAuthState>;
export declare function getAuthFromRequest(req: Request): Promise<ClerkAuthState>;
