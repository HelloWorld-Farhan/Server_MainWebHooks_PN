import type { TenantContext } from "../types/context";
export type CompanyBillingConfig = {
    pulseTimeSeconds: number;
    deltaSeconds: number;
    costPerCredit: number;
};
export type CallBillingResult = {
    credits: number;
    costInr: number;
};
export declare class BillingService {
    private readonly repo;
    private readonly quoteRepo;
    private readonly setupRepo;
    getSubscription(ctx: TenantContext): Promise<{
        id: string;
        planId: string;
        planName: string;
        status: import("@prisma/client").$Enums.BillingStatus;
        currentPeriodStart: string;
        currentPeriodEnd: string;
        cancelAtPeriodEnd: boolean;
        nextInvoiceAmount: number | null;
    } | null>;
    getInvoices(ctx: TenantContext, args: {
        first?: number;
        after?: string;
    }): Promise<import("../lib/pagination").Connection<{
        status: import("@prisma/client").$Enums.InvoiceStatus;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        externalId: string | null;
        description: string | null;
        subscriptionId: string;
        amountCents: number;
        currency: string;
        issuedAt: Date;
        dueAt: Date | null;
        paidAt: Date | null;
    }>>;
    getRates(ctx: TenantContext): Promise<{
        costPerChannel: number;
        costPerCredit: number;
        pulseTimeSeconds: number;
        setupOneTimeCost: number;
        currency: string;
        minChannelPurchase: number;
        virtualNumberCost: number;
        gstRate: number;
    }>;
    loadCompanyBillingConfig(companyId: string): Promise<CompanyBillingConfig>;
    calculateCallBilling(durationSeconds: number, config: CompanyBillingConfig): CallBillingResult;
    createQuote(ctx: TenantContext, input: {
        channelQty: number;
        virtualNumberQty: number;
        expectedMonthlyCalls: number;
    }): Promise<{
        id: string;
        status: string;
        channelQty: number;
        virtualNumberQty: number;
        expectedMonthlyCalls: number;
        pricing: {
            channelCost: number;
            virtualNumberCost: number;
            callCost: number;
            subtotal: number;
            gst: number;
            grandTotal: number;
            currency: string;
        };
        expiresAt: string | null;
        purchasedAt: string | null;
        invoiceId: string | null;
        createdAt: string;
        updatedAt: string;
    }>;
    listQuotes(ctx: TenantContext): Promise<{
        id: string;
        status: string;
        channelQty: number;
        virtualNumberQty: number;
        expectedMonthlyCalls: number;
        pricing: {
            channelCost: number;
            virtualNumberCost: number;
            callCost: number;
            subtotal: number;
            gst: number;
            grandTotal: number;
            currency: string;
        };
        expiresAt: string | null;
        purchasedAt: string | null;
        invoiceId: string | null;
        createdAt: string;
        updatedAt: string;
    }[]>;
    purchaseQuote(ctx: TenantContext, quoteId: string): Promise<{
        quote: {
            id: string;
            status: string;
            channelQty: number;
            virtualNumberQty: number;
            expectedMonthlyCalls: number;
            pricing: {
                channelCost: number;
                virtualNumberCost: number;
                callCost: number;
                subtotal: number;
                gst: number;
                grandTotal: number;
                currency: string;
            };
            expiresAt: string | null;
            purchasedAt: string | null;
            invoiceId: string | null;
            createdAt: string;
            updatedAt: string;
        };
        invoice: {
            id: string;
            amountCents: number;
            currency: string;
            status: import("@prisma/client").$Enums.InvoiceStatus;
            issuedAt: string;
        };
    }>;
}
export declare const billingService: BillingService;
