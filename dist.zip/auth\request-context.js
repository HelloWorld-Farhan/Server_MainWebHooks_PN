"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.requestStore = void 0;
exports.getCurrentRequest = getCurrentRequest;
exports.runWithRequest = runWithRequest;
const node_async_hooks_1 = require("node:async_hooks");
exports.requestStore = new node_async_hooks_1.AsyncLocalStorage();
function getCurrentRequest() {
    return exports.requestStore.getStore();
}
function runWithRequest(req, fn) {
    return exports.requestStore.run(req, fn);
}
//# sourceMappingURL=request-context.js.map