type LogPayload = Record<string, string | number | boolean | null | undefined>;
export declare function logCampaignExecutionEvent(event: string, payload: LogPayload): void;
export {};
