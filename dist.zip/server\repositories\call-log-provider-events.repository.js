"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CallLogProviderEventsRepository = void 0;
exports.createCallLogProviderEventsRepository = createCallLogProviderEventsRepository;
const client_1 = require("@prisma/client");
const base_repository_1 = require("./base.repository");
class CallLogProviderEventsRepository extends base_repository_1.BaseRepository {
    findExisting(callLogId, providerEventId) {
        return this.prisma.callLogProviderEvent.findFirst({
            where: { callLogId, providerEventId },
            select: { id: true },
        });
    }
    async tryInsert(data) {
        try {
            await this.prisma.callLogProviderEvent.create({
                data: {
                    callLogId: data.callLogId,
                    providerEventId: data.providerEventId,
                    correlationId: data.correlationId,
                },
            });
            return true;
        }
        catch (error) {
            if (error instanceof client_1.Prisma.PrismaClientKnownRequestError &&
                error.code === "P2002") {
                return false;
            }
            throw error;
        }
    }
}
exports.CallLogProviderEventsRepository = CallLogProviderEventsRepository;
function createCallLogProviderEventsRepository(prisma) {
    return new CallLogProviderEventsRepository(prisma);
}
//# sourceMappingURL=call-log-provider-events.repository.js.map