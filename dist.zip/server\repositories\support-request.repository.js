"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SupportRequestRepository = void 0;
class SupportRequestRepository {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    create(data) {
        return this.prisma.supportRequest.create({
            data: {
                name: data.name,
                email: data.email,
                reason: data.reason,
                planId: data.planId,
                planName: data.planName,
                message: data.message,
                userId: data.userId ?? null,
                companyId: data.companyId ?? null,
                clerkUserId: data.clerkUserId ?? null,
            },
        });
    }
    findById(id) {
        return this.prisma.supportRequest.findUnique({ where: { id } });
    }
}
exports.SupportRequestRepository = SupportRequestRepository;
//# sourceMappingURL=support-request.repository.js.map