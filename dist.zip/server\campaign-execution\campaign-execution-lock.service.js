"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.campaignExecutionLockService = exports.CampaignExecutionLockService = void 0;
const redis_client_1 = require("../cache/redis.client");
const campaign_execution_config_1 = require("./campaign-execution.config");
const LOCK_PREFIX = "campaign:runner-lock:";
class CampaignExecutionLockService {
    inMemory = new Map();
    getRedis() {
        return redis_client_1.redis?.status === "ready" ? redis_client_1.redis : null;
    }
    lockKey(campaignId) {
        return `${LOCK_PREFIX}${campaignId}`;
    }
    async acquire(campaignId, workerId) {
        const ttlMs = campaign_execution_config_1.campaignExecutionConfig.lockTtlMs;
        const client = this.getRedis();
        if (client) {
            const result = await client.set(this.lockKey(campaignId), workerId, "PX", ttlMs, "NX");
            return result === "OK";
        }
        const now = Date.now();
        const existing = this.inMemory.get(campaignId);
        if (existing && existing.expiresAt > now && existing.owner !== workerId) {
            return false;
        }
        this.inMemory.set(campaignId, {
            owner: workerId,
            expiresAt: now + ttlMs,
        });
        return true;
    }
    async renew(campaignId, workerId) {
        const ttlMs = campaign_execution_config_1.campaignExecutionConfig.lockTtlMs;
        const client = this.getRedis();
        if (client) {
            const key = this.lockKey(campaignId);
            const current = await client.get(key);
            if (current !== workerId) {
                return false;
            }
            await client.pexpire(key, ttlMs);
            return true;
        }
        const existing = this.inMemory.get(campaignId);
        if (!existing || existing.owner !== workerId) {
            return false;
        }
        existing.expiresAt = Date.now() + ttlMs;
        return true;
    }
    async release(campaignId, workerId) {
        const client = this.getRedis();
        if (client) {
            const key = this.lockKey(campaignId);
            const current = await client.get(key);
            if (current === workerId) {
                await client.del(key);
            }
            return;
        }
        const existing = this.inMemory.get(campaignId);
        if (existing?.owner === workerId) {
            this.inMemory.delete(campaignId);
        }
    }
    resetInMemoryForTests() {
        this.inMemory.clear();
    }
}
exports.CampaignExecutionLockService = CampaignExecutionLockService;
exports.campaignExecutionLockService = new CampaignExecutionLockService();
//# sourceMappingURL=campaign-execution-lock.service.js.map