import type { CallStatus } from "@prisma/client";
export type RequestDispatchInput = {
    companyId: string;
    callLogId: string;
    callLogPublicId: string;
    phone: string;
    campaignPublicId?: string;
};
export type RequestDispatchResult = {
    status: Extract<CallStatus, "QUEUED" | "QUEUED_AT_PROVIDER" | "FAILED">;
};
export type HandleProviderWebhookInput = {
    companyId: string;
    callLogId: string;
    currentStatus: CallStatus;
    providerStatus: string;
    durationSeconds?: number;
    answeredAt?: Date;
    endedAt?: Date;
    disconnectReason?: string;
    providerWebhook: import("@prisma/client").Prisma.InputJsonValue;
};
export declare class CallService {
    private readonly callLogsRepo;
    requestDispatch(input: RequestDispatchInput): Promise<RequestDispatchResult>;
    dispatchQueuedCall(callLogId: string): Promise<boolean>;
    handleProviderWebhook(input: HandleProviderWebhookInput): Promise<{
        applied: boolean;
        mappedStatus: CallStatus;
    }>;
    private queueCall;
    private dispatchDirect;
    private dispatchWithReservedChannel;
    markCancelled(companyId: string, callLogId: string): Promise<void>;
    retryQueuedCall(companyId: string, callLogId: string, retryCount: number): Promise<void>;
    private incrementRetryCount;
    private getAllocatedChannels;
    private ensureChannelState;
}
export declare const callService: CallService;
