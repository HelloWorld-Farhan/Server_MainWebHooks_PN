export declare class CampaignExecutionLockService {
    private readonly inMemory;
    private getRedis;
    private lockKey;
    acquire(campaignId: string, workerId: string): Promise<boolean>;
    renew(campaignId: string, workerId: string): Promise<boolean>;
    release(campaignId: string, workerId: string): Promise<void>;
    resetInMemoryForTests(): void;
}
export declare const campaignExecutionLockService: CampaignExecutionLockService;
