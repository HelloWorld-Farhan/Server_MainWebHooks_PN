"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BillingQuoteRepository = void 0;
const base_repository_1 = require("./base.repository");
class BillingQuoteRepository extends base_repository_1.BaseRepository {
    create(companyId, data) {
        return this.prisma.billingQuote.create({
            data: {
                companyId,
                ...data,
                currency: data.currency ?? "INR",
            },
        });
    }
    findMany(companyId) {
        return this.prisma.billingQuote.findMany({
            where: this.scope(companyId),
            orderBy: { createdAt: "desc" },
        });
    }
    findById(companyId, id) {
        return this.prisma.billingQuote.findFirst({
            where: { id, companyId },
        });
    }
    updateStatus(companyId, id, data) {
        return this.prisma.billingQuote.updateMany({
            where: { id, companyId },
            data,
        });
    }
}
exports.BillingQuoteRepository = BillingQuoteRepository;
//# sourceMappingURL=billing-quote.repository.js.map