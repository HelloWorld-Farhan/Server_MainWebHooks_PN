export declare function getOAuthClient(): import("googleapis-common").OAuth2Client;
