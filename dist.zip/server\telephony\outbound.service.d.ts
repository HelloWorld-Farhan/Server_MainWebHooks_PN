import type { CallStatus } from "@prisma/client";
import { ObdProviderClient } from "./provider-client";
export type ObdDispatchInput = {
    companyId: string;
    callLogId: string;
    callLogPublicId: string;
    phone: string;
    campaignPublicId?: string;
};
export type ObdDispatchResult = {
    status: Extract<CallStatus, "QUEUED_AT_PROVIDER" | "FAILED">;
    providerCallId: string | null;
    correlationId: string;
};
export declare class ObdOutboundService {
    private readonly providerClient;
    private readonly callLogsRepo;
    constructor(providerClient?: ObdProviderClient);
    dispatch(input: ObdDispatchInput): Promise<ObdDispatchResult>;
    private resolveDispatchConfig;
    private resolveContactFields;
}
export declare const obdOutboundService: ObdOutboundService;
