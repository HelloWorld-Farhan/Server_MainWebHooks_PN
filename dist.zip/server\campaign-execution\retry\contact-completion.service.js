"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.contactCompletionService = exports.ContactCompletionService = void 0;
const campaign_execution_repository_1 = require("../campaign-execution.repository");
const campaign_execution_service_1 = require("../campaign-execution.service");
const prisma_1 = __importDefault(require("../../lib/prisma"));
const call_status_lifecycle_1 = require("../../telephony/call-status-lifecycle");
const campaigns_repository_1 = require("../../repositories/campaigns.repository");
const retry_job_repository_1 = require("./retry-job.repository");
const retry_policy_service_1 = require("./retry-policy.service");
const SUCCESS_STATUSES = new Set([
    "ANSWERED",
    "COMPLETED",
]);
const NON_TERMINAL_STATUSES = [
    "PENDING",
    "QUEUED",
    "DISPATCHING",
    "QUEUED_AT_PROVIDER",
    "RINGING",
    "ANSWERED",
];
class ContactCompletionService {
    campaignsRepo = new campaigns_repository_1.CampaignsRepository(prisma_1.default);
    async isContactComplete(companyId, campaignId, phone, policy) {
        const execution = policy ??
            (await campaign_execution_repository_1.campaignExecutionRepository.findByCampaignId(companyId, campaignId));
        if (!execution) {
            return false;
        }
        const resolvedPolicy = retry_policy_service_1.retryPolicyService.extractPolicy(execution);
        const pendingRetries = await retry_job_repository_1.retryJobRepository.countPendingForPhone(companyId, campaignId, phone);
        if (pendingRetries > 0) {
            return false;
        }
        const inFlight = await prisma_1.default.callLog.count({
            where: {
                companyId,
                campaignId,
                phoneNumber: { number: phone },
                status: { in: NON_TERMINAL_STATUSES.filter((s) => s !== "ANSWERED") },
            },
        });
        if (inFlight > 0) {
            return false;
        }
        const latestCall = await prisma_1.default.callLog.findFirst({
            where: {
                companyId,
                campaignId,
                phoneNumber: { number: phone },
            },
            orderBy: [{ createdAt: "desc" }, { id: "desc" }],
            select: { status: true, isRetry: true },
        });
        if (!latestCall) {
            return false;
        }
        if (!(0, call_status_lifecycle_1.isTerminalCallStatus)(latestCall.status)) {
            return false;
        }
        if (SUCCESS_STATUSES.has(latestCall.status)) {
            return true;
        }
        if (!resolvedPolicy.retryEnabled) {
            return true;
        }
        const retryCount = await retry_policy_service_1.retryPolicyService.countRetriesForContact(companyId, campaignId, phone);
        if (retryCount >= resolvedPolicy.maxRetries) {
            return true;
        }
        return false;
    }
    async reconcileCompletedContactsCount(companyId, campaignId) {
        const execution = await campaign_execution_repository_1.campaignExecutionRepository.findByCampaignId(companyId, campaignId);
        if (!execution) {
            return 0;
        }
        const contacts = await this.campaignsRepo.findContactsForExecution(companyId, campaignId, execution.totalContacts || 100_000);
        let completed = 0;
        for (const contact of contacts) {
            if (await this.isContactComplete(companyId, campaignId, contact.phone)) {
                completed += 1;
            }
        }
        if (completed !== execution.completedContactsCount) {
            await campaign_execution_repository_1.campaignExecutionRepository.updateStatistics(companyId, campaignId, {
                completedContactsCount: completed,
            });
        }
        return completed;
    }
    async markContactCompleteIfDone(companyId, campaignId, phone) {
        await this.reconcileCompletedContactsCount(companyId, campaignId);
        await this.checkCampaignCompletion(companyId, campaignId);
    }
    async checkCampaignCompletion(companyId, campaignId) {
        const execution = await campaign_execution_repository_1.campaignExecutionRepository.findByCampaignId(companyId, campaignId);
        if (!execution || execution.status !== "RUNNING") {
            return false;
        }
        if (execution.processedCount < execution.totalContacts) {
            return false;
        }
        const pendingRetries = await retry_job_repository_1.retryJobRepository.countByStatus(companyId, campaignId, "PENDING");
        const processingRetries = await retry_job_repository_1.retryJobRepository.countByStatus(companyId, campaignId, "PROCESSING");
        if (pendingRetries > 0 || processingRetries > 0) {
            return false;
        }
        const inFlightCalls = await prisma_1.default.callLog.count({
            where: {
                companyId,
                campaignId,
                status: { in: NON_TERMINAL_STATUSES },
            },
        });
        if (inFlightCalls > 0) {
            return false;
        }
        const completedCount = await this.reconcileCompletedContactsCount(companyId, campaignId);
        if (completedCount < execution.totalContacts) {
            return false;
        }
        await campaign_execution_service_1.campaignExecutionService.markCompleted(companyId, campaignId);
        return true;
    }
}
exports.ContactCompletionService = ContactCompletionService;
exports.contactCompletionService = new ContactCompletionService();
//# sourceMappingURL=contact-completion.service.js.map