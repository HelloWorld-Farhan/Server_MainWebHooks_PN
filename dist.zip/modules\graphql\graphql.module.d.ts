export declare class GraphQLModule {
}
