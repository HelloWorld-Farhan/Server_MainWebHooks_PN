export type ChannelMetrics = {
    allocated: number;
    active: number;
    available: number;
    queueLength: number;
    cooldownCount: number;
};
export type CooldownRelease = {
    companyId: string;
    callLogId: string;
};
export declare class ChannelService {
    private readonly inMemory;
    private getRedis;
    private ensureInMemory;
    initializeCompany(companyId: string, allocated: number, active: number, queuedCallLogIds?: string[]): Promise<void>;
    tryReserve(companyId: string): Promise<boolean>;
    release(companyId: string): Promise<number>;
    enqueue(companyId: string, callLogId: string): Promise<number>;
    enqueueFront(companyId: string, callLogId: string): Promise<number>;
    dequeue(companyId: string): Promise<string | null>;
    startCooldown(companyId: string, callLogId: string, ms?: number): Promise<void>;
    drainExpiredCooldowns(): Promise<CooldownRelease[]>;
    acquireDispatchLock(callLogId: string): Promise<boolean>;
    releaseDispatchLock(callLogId: string): Promise<void>;
    getMetrics(companyId: string): Promise<ChannelMetrics>;
    listCompaniesWithPendingWork(companyIds: string[]): Promise<string[]>;
    resetInMemoryForTests(): void;
}
export declare const channelService: ChannelService;
