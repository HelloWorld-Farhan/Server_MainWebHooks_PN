export type ObdWebhookProcessResult = {
    received: true;
    duplicate?: boolean;
    callLogPublicId?: string;
    correlationId?: string;
};
export declare class ObdWebhookService {
    private readonly callLogsRepo;
    private readonly providerEventsRepo;
    assertAuthorized(apiKeyHeader: string | undefined): void;
    processWebhook(body: unknown): Promise<ObdWebhookProcessResult>;
}
export declare const obdWebhookService: ObdWebhookService;
