import { type RetryPolicyFields } from "./retry-policy.service";
export declare class ContactCompletionService {
    private readonly campaignsRepo;
    isContactComplete(companyId: string, campaignId: string, phone: string, policy?: RetryPolicyFields): Promise<boolean>;
    reconcileCompletedContactsCount(companyId: string, campaignId: string): Promise<number>;
    markContactCompleteIfDone(companyId: string, campaignId: string, phone: string): Promise<void>;
    checkCampaignCompletion(companyId: string, campaignId: string): Promise<boolean>;
}
export declare const contactCompletionService: ContactCompletionService;
