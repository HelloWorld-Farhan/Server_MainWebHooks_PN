import type { ApiKeyEnvironment } from "@prisma/client";
export type GeneratedApiKey = {
    plaintext: string;
    keyId: string;
    keyPrefix: string;
    hashedSecret: string;
    environment: ApiKeyEnvironment;
};
export type ParsedApiKey = {
    environment: ApiKeyEnvironment;
    keyId: string;
    secret: string;
};
export declare function hashApiKeySecret(secret: string): string;
export declare function verifyApiKeySecret(secret: string, hashedSecret: string): boolean;
export declare function generateApiKey(environment: ApiKeyEnvironment): GeneratedApiKey;
export declare function rotateApiKeySecret(environment: ApiKeyEnvironment, keyId: string): {
    plaintext: string;
    keyPrefix: string;
    hashedSecret: string;
};
export declare function maskApiKeyPrefix(keyPrefix: string): string;
export declare function looksLikeApiKey(token: string): boolean;
export declare function parseApiKey(plaintext: string): ParsedApiKey;
export declare function extractBearerToken(authorizationHeader: string | null | undefined): string | null;
export declare const API_KEY_ROTATION_GRACE_MS: number;
