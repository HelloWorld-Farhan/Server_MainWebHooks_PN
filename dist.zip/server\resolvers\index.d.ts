import type { TenantContext } from "../types/context";
declare function parseCallLogFilter(filter?: {
    direction?: string;
    status?: string;
    aiAgentId?: string;
    campaignId?: string;
    phoneNumberId?: string;
    assignedUserId?: string;
    dateFrom?: string;
    dateTo?: string;
    search?: string;
    callLogId?: string;
}): {
    direction: never;
    status: never;
    aiAgentId: string | undefined;
    campaignId: string | undefined;
    phoneNumberId: string | undefined;
    assignedUserId: string | undefined;
    dateFrom: Date | undefined;
    dateTo: Date | undefined;
    search: string | undefined;
    callLogId: string | undefined;
} | undefined;
declare function parsePhoneNumberFilter(filter?: {
    number?: string;
    numberContains?: string;
    labelContains?: string;
    search?: string;
    provider?: string;
    status?: string;
    inboundAgentId?: string;
    outboundAgentId?: string;
    hasInboundAgent?: boolean;
    hasOutboundAgent?: boolean;
    channelIndex?: number;
    hasChannelAssignment?: boolean;
    createdFrom?: string;
    createdTo?: string;
    lastActivityFrom?: string;
    lastActivityTo?: string;
    ids?: string[];
}): {
    number: string | undefined;
    numberContains: string | undefined;
    labelContains: string | undefined;
    search: string | undefined;
    provider: never;
    status: never;
    inboundAgentId: string | undefined;
    outboundAgentId: string | undefined;
    hasInboundAgent: boolean | undefined;
    hasOutboundAgent: boolean | undefined;
    channelIndex: number | undefined;
    hasChannelAssignment: boolean | undefined;
    createdFrom: Date | undefined;
    createdTo: Date | undefined;
    lastActivityFrom: Date | undefined;
    lastActivityTo: Date | undefined;
    ids: string[] | undefined;
} | undefined;
declare function parsePhoneNumberSort(sort?: {
    field?: string;
    direction?: string;
}): {
    field: "CREATED_AT" | "UPDATED_AT" | "LAST_ACTIVITY_AT" | "NUMBER" | "INBOUND_CALLS_COUNT" | "OUTBOUND_CALLS_COUNT";
    direction: "ASC" | "DESC";
} | undefined;
declare function parseLeadFilter(filter?: {
    dormantOnly?: boolean;
    minDaysInactive?: number;
    temperature?: string;
}): {
    dormantOnly: boolean | undefined;
    minDaysInactive: number | undefined;
    temperature: never;
} | undefined;
export declare const resolvers: {
    Query: {
        viewer: (_: unknown, __: unknown, ctx: TenantContext) => Promise<{
            id: string;
            membershipId: string;
            email: string;
            firstName: string | null;
            lastName: string | null;
            role: import("@prisma/client").$Enums.UserRole;
            permissions: string[];
            campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
            campaignIds: string[];
            company: {
                id: string;
                name: string;
                slug: string;
                contact: {
                    name: string;
                    email: string;
                    phone: string | null;
                    title: string | null;
                } | null;
            };
        }>;
        credits: () => {};
        billing: () => {};
        callLogs: () => {};
        analytics: () => {};
        agents: () => {};
        agentLibrary: () => {};
        phoneNumbers: () => {};
        uploadedContacts: () => {};
        leads: () => {};
        outboundCampaigns: () => {};
        notifications: () => {};
        integrations: () => {};
        scheduler: () => {};
        events: () => {};
        campaigns: () => {};
        employees: () => {};
        apiKeys: () => {};
    };
    Mutation: {
        credits: () => {};
        callLogs: () => {};
        agents: () => {};
        phoneNumbers: () => {};
        uploadedContacts: () => {};
        leads: () => {};
        outboundCampaigns: () => {};
        campaigns: () => {};
        employees: () => {};
        apiKeys: () => {};
    };
    CreditsQueries: {
        summary: (_: unknown, __: unknown, ctx: TenantContext) => Promise<{
            remaining: number;
            used: number;
            total: number;
            availablePercent: number;
            renewalAt: string | null;
            planId: string | null;
        }>;
        usageHistory: (_: unknown, args: {
            first?: number;
            after?: string;
        }, ctx: TenantContext) => Promise<import("../lib/pagination").Connection<{
            reason: import("@prisma/client").$Enums.CreditUsageReason;
            id: string;
            createdAt: Date;
            companyId: string;
            description: string | null;
            callLogId: string | null;
            metadata: import("@prisma/client/runtime/library").JsonValue;
            amount: number;
        }>>;
    };
    CreditsMutations: {
        adjustCredits: (_: unknown, args: {
            amount: number;
            description: string;
        }, ctx: TenantContext) => Promise<{
            reason: import("@prisma/client").$Enums.CreditUsageReason;
            id: string;
            createdAt: Date;
            companyId: string;
            description: string | null;
            callLogId: string | null;
            metadata: import("@prisma/client/runtime/library").JsonValue;
            amount: number;
        }>;
    };
    BillingQueries: {
        subscription: (_: unknown, __: unknown, ctx: TenantContext) => Promise<{
            id: string;
            planId: string;
            planName: string;
            status: import("@prisma/client").$Enums.BillingStatus;
            currentPeriodStart: string;
            currentPeriodEnd: string;
            cancelAtPeriodEnd: boolean;
            nextInvoiceAmount: number | null;
        } | null>;
        invoices: (_: unknown, args: {
            first?: number;
            after?: string;
        }, ctx: TenantContext) => Promise<import("../lib/pagination").Connection<{
            status: import("@prisma/client").$Enums.InvoiceStatus;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            companyId: string;
            externalId: string | null;
            description: string | null;
            subscriptionId: string;
            amountCents: number;
            currency: string;
            issuedAt: Date;
            dueAt: Date | null;
            paidAt: Date | null;
        }>>;
        rates: (_: unknown, __: unknown, ctx: TenantContext) => Promise<{
            costPerChannel: number;
            costPerCredit: number;
            pulseTimeSeconds: number;
            setupOneTimeCost: number;
            currency: string;
            minChannelPurchase: number;
            virtualNumberCost: number;
            gstRate: number;
        }>;
    };
    CallLogsQueries: {
        recent: (_: unknown, args: {
            limit?: number;
        }, ctx: TenantContext) => Promise<{
            startedAt: string;
            status: import("@prisma/client").$Enums.CallStatus;
            id: string;
            companyId: string | null;
            direction: import("@prisma/client").$Enums.CallDirection;
            leadId: string | null;
            aiAgentId: string | null;
            durationSeconds: number;
        }[]>;
        connection: (_: unknown, args: {
            first?: number;
            after?: string;
            filter?: Parameters<typeof parseCallLogFilter>[0];
        }, ctx: TenantContext) => Promise<{
            edges: {
                cursor: string;
                node: {
                    startedAt: string;
                    status: import("@prisma/client").$Enums.CallStatus;
                    id: string;
                    createdAt: Date;
                    updatedAt: Date;
                    companyId: string | null;
                    assignedUserId: string | null;
                    campaignId: string | null;
                    phoneNumberId: string | null;
                    publicId: string;
                    provider: string | null;
                    direction: import("@prisma/client").$Enums.CallDirection;
                    callLogId: string;
                    leadId: string | null;
                    aiAgentId: string | null;
                    outcome: import("@prisma/client").$Enums.CallOutcome | null;
                    durationSeconds: number;
                    recordingUrl: string | null;
                    transcriptUrl: string | null;
                    aiSummary: import("@prisma/client/runtime/library").JsonValue;
                    sentiment: import("@prisma/client/runtime/library").JsonValue;
                    cost: number | null;
                    creditsUsed: number | null;
                    providerStatus: string | null;
                    disconnectReason: string | null;
                };
            }[];
            pageInfo: import("../lib/pagination").PageInfo;
        }>;
        detail: (_: unknown, args: {
            id: string;
        }, ctx: TenantContext) => Promise<{
            startedAt: string;
            outcome: import("@prisma/client").$Enums.CallOutcome | null;
            aiSummary: import("@prisma/client/runtime/library").JsonValue;
            sentiment: import("@prisma/client/runtime/library").JsonValue;
            engagement: import("@prisma/client/runtime/library").JsonValue;
            reactivationPlan: import("@prisma/client/runtime/library").JsonValue;
            recordingUrl: string | null;
            cost: number | null;
            creditsUsed: number | null;
            provider: string | null;
            transcript: {
                id: string;
                createdAt: Date;
                updatedAt: Date;
                callLogId: string;
                segments: import("@prisma/client/runtime/library").JsonValue;
                fullText: string | null;
            } | null;
            internalNotes: {
                id: string;
                content: string;
                createdAt: string;
                updatedAt: string;
                author: {
                    id: string;
                    name: string;
                    email: string;
                };
            }[];
            phoneNumber: {
                id: string;
                number: string;
                label: string | null;
            } | null;
            lead: {
                id: string;
                createdAt: Date;
                updatedAt: Date;
                companyId: string;
                email: string | null;
                stageId: string;
                sourceId: string | null;
                assignedUserId: string | null;
                firstName: string | null;
                lastName: string | null;
                phone: string | null;
                companyName: string | null;
                temperature: import("@prisma/client").$Enums.LeadTemperature | null;
                score: number;
                customFields: import("@prisma/client/runtime/library").JsonValue;
                tags: string[];
                lastContactedAt: Date | null;
                nextFollowUpAt: Date | null;
                queueStatus: import("@prisma/client").$Enums.CallingQueueStatus;
                assignedAiAgentId: string | null;
                lockedAt: Date | null;
                channelId: string | null;
                campaignId: string | null;
            } | null;
            aiAgent: {
                status: import("@prisma/client").$Enums.AgentStatus;
                name: string;
                id: string;
                createdAt: Date;
                updatedAt: Date;
                companyId: string;
                type: import("@prisma/client").$Enums.AgentType;
                campaignId: string | null;
                resourceKey: string;
                libraryEntryId: string | null;
                description: string | null;
                category: string | null;
                environment: import("@prisma/client").$Enums.AgentEnvironment;
                enabled: boolean;
                languages: string[];
                firstMessage: string | null;
                systemPrompt: string | null;
                voiceConfig: import("@prisma/client/runtime/library").JsonValue;
                modelConfig: import("@prisma/client/runtime/library").JsonValue;
                transcriberConfig: import("@prisma/client/runtime/library").JsonValue;
                serverConfig: import("@prisma/client/runtime/library").JsonValue;
                structuredOutputs: import("@prisma/client/runtime/library").JsonValue;
                scorecards: import("@prisma/client/runtime/library").JsonValue;
                monitors: import("@prisma/client/runtime/library").JsonValue;
                demoAudioUrl: string | null;
            } | null;
            assignedUser: {
                status: import("@prisma/client").$Enums.UserStatus;
                id: string;
                createdAt: Date;
                updatedAt: Date;
                email: string;
                firstName: string | null;
                lastName: string | null;
                phone: string | null;
                clerkUserId: string;
                imageUrl: string | null;
                passwordHash: string | null;
                lastLoginAt: Date | null;
            } | null;
            status: import("@prisma/client").$Enums.CallStatus;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            companyId: string | null;
            assignedUserId: string | null;
            campaignId: string | null;
            phoneNumberId: string | null;
            publicId: string;
            direction: import("@prisma/client").$Enums.CallDirection;
            callLogId: string;
            leadId: string | null;
            aiAgentId: string | null;
            durationSeconds: number;
            transcriptUrl: string | null;
            providerStatus: string | null;
            providerCallId: string | null;
            correlationId: string | null;
            providerRequestedAt: Date | null;
            providerAcceptedAt: Date | null;
            providerCompletedAt: Date | null;
            answeredAt: Date | null;
            endedAt: Date | null;
            disconnectReason: string | null;
            providerRequest: import("@prisma/client/runtime/library").JsonValue | null;
            providerResponse: import("@prisma/client/runtime/library").JsonValue | null;
            providerWebhook: import("@prisma/client/runtime/library").JsonValue | null;
            providerMetadata: import("@prisma/client/runtime/library").JsonValue | null;
            retryNumber: number;
            parentCallLogId: string | null;
            isRetry: boolean;
            retryReason: import("@prisma/client").$Enums.CallStatus | null;
        }>;
    };
    CallLogsMutations: {
        recordCallCompleted: (_: unknown, args: {
            callLogId: string;
        }, ctx: TenantContext) => Promise<boolean>;
        updateOutcome: (_: unknown, args: {
            id: string;
            outcome: string;
            reactivationPlan?: Record<string, unknown> | null;
        }, ctx: TenantContext) => Promise<{
            startedAt: string;
            outcome: import("@prisma/client").$Enums.CallOutcome | null;
            aiSummary: import("@prisma/client/runtime/library").JsonValue;
            sentiment: import("@prisma/client/runtime/library").JsonValue;
            engagement: import("@prisma/client/runtime/library").JsonValue;
            reactivationPlan: import("@prisma/client/runtime/library").JsonValue;
            recordingUrl: string | null;
            cost: number | null;
            creditsUsed: number | null;
            provider: string | null;
            transcript: {
                id: string;
                createdAt: Date;
                updatedAt: Date;
                callLogId: string;
                segments: import("@prisma/client/runtime/library").JsonValue;
                fullText: string | null;
            } | null;
            internalNotes: {
                id: string;
                content: string;
                createdAt: string;
                updatedAt: string;
                author: {
                    id: string;
                    name: string;
                    email: string;
                };
            }[];
            phoneNumber: {
                id: string;
                number: string;
                label: string | null;
            } | null;
            lead: {
                id: string;
                createdAt: Date;
                updatedAt: Date;
                companyId: string;
                email: string | null;
                stageId: string;
                sourceId: string | null;
                assignedUserId: string | null;
                firstName: string | null;
                lastName: string | null;
                phone: string | null;
                companyName: string | null;
                temperature: import("@prisma/client").$Enums.LeadTemperature | null;
                score: number;
                customFields: import("@prisma/client/runtime/library").JsonValue;
                tags: string[];
                lastContactedAt: Date | null;
                nextFollowUpAt: Date | null;
                queueStatus: import("@prisma/client").$Enums.CallingQueueStatus;
                assignedAiAgentId: string | null;
                lockedAt: Date | null;
                channelId: string | null;
                campaignId: string | null;
            } | null;
            aiAgent: {
                status: import("@prisma/client").$Enums.AgentStatus;
                name: string;
                id: string;
                createdAt: Date;
                updatedAt: Date;
                companyId: string;
                type: import("@prisma/client").$Enums.AgentType;
                campaignId: string | null;
                resourceKey: string;
                libraryEntryId: string | null;
                description: string | null;
                category: string | null;
                environment: import("@prisma/client").$Enums.AgentEnvironment;
                enabled: boolean;
                languages: string[];
                firstMessage: string | null;
                systemPrompt: string | null;
                voiceConfig: import("@prisma/client/runtime/library").JsonValue;
                modelConfig: import("@prisma/client/runtime/library").JsonValue;
                transcriberConfig: import("@prisma/client/runtime/library").JsonValue;
                serverConfig: import("@prisma/client/runtime/library").JsonValue;
                structuredOutputs: import("@prisma/client/runtime/library").JsonValue;
                scorecards: import("@prisma/client/runtime/library").JsonValue;
                monitors: import("@prisma/client/runtime/library").JsonValue;
                demoAudioUrl: string | null;
            } | null;
            assignedUser: {
                status: import("@prisma/client").$Enums.UserStatus;
                id: string;
                createdAt: Date;
                updatedAt: Date;
                email: string;
                firstName: string | null;
                lastName: string | null;
                phone: string | null;
                clerkUserId: string;
                imageUrl: string | null;
                passwordHash: string | null;
                lastLoginAt: Date | null;
            } | null;
            status: import("@prisma/client").$Enums.CallStatus;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            companyId: string | null;
            assignedUserId: string | null;
            campaignId: string | null;
            phoneNumberId: string | null;
            publicId: string;
            direction: import("@prisma/client").$Enums.CallDirection;
            callLogId: string;
            leadId: string | null;
            aiAgentId: string | null;
            durationSeconds: number;
            transcriptUrl: string | null;
            providerStatus: string | null;
            providerCallId: string | null;
            correlationId: string | null;
            providerRequestedAt: Date | null;
            providerAcceptedAt: Date | null;
            providerCompletedAt: Date | null;
            answeredAt: Date | null;
            endedAt: Date | null;
            disconnectReason: string | null;
            providerRequest: import("@prisma/client/runtime/library").JsonValue | null;
            providerResponse: import("@prisma/client/runtime/library").JsonValue | null;
            providerWebhook: import("@prisma/client/runtime/library").JsonValue | null;
            providerMetadata: import("@prisma/client/runtime/library").JsonValue | null;
            retryNumber: number;
            parentCallLogId: string | null;
            isRetry: boolean;
            retryReason: import("@prisma/client").$Enums.CallStatus | null;
        }>;
        addInternalNote: (_: unknown, args: {
            callLogId: string;
            content: string;
        }, ctx: TenantContext) => Promise<{
            id: string;
            content: string;
            createdAt: string;
            updatedAt: string;
            author: {
                id: string;
                name: string;
                email: string;
            };
        }>;
        updateInternalNote: (_: unknown, args: {
            id: string;
            content: string;
        }, ctx: TenantContext) => Promise<{
            id: string;
            content: string;
            createdAt: string;
            updatedAt: string;
            author: {
                id: string;
                name: string;
                email: string;
            };
        }>;
        deleteInternalNote: (_: unknown, args: {
            id: string;
        }, ctx: TenantContext) => Promise<boolean>;
    };
    AnalyticsQueries: {
        summary: (_: unknown, args: {
            granularity?: "DAILY" | "WEEKLY" | "MONTHLY";
            dateFrom?: string;
            dateTo?: string;
        }, ctx: TenantContext) => Promise<{
            totalCalls: number;
            connectedCalls: number;
            conversionRate: number;
            generatedLeads: number;
            periodStart: string;
            periodEnd: string;
        }>;
        timeSeries: (_: unknown, args: {
            granularity?: "DAILY" | "WEEKLY" | "MONTHLY";
            dateFrom?: string;
            dateTo?: string;
        }, ctx: TenantContext) => Promise<{
            granularity: import("@prisma/client").$Enums.AnalyticsGranularity;
            periodStart: string;
            periodEnd: string;
            points: {
                periodStart: string;
                label: string;
                calls: number;
                connectedCalls: number;
                leads: number;
                conversions: number;
                conversionRate: number;
            }[];
        }>;
    };
    AgentsQueries: {
        statusSummary: (_: unknown, __: unknown, ctx: TenantContext) => Promise<{
            active: number;
            inactive: number;
            total: number;
        }>;
        list: (_: unknown, __: unknown, ctx: TenantContext) => Promise<{
            id: string;
            name: string;
            type: import("@prisma/client").$Enums.AgentType;
            category: string | null;
            status: import("@prisma/client").$Enums.AgentStatus;
            environment: import("@prisma/client").$Enums.AgentEnvironment;
            enabled: boolean;
            languages: string[];
            firstMessage: string | null;
            systemPrompt: string | null;
            voiceConfig: import("@prisma/client/runtime/library").JsonValue;
            modelConfig: import("@prisma/client/runtime/library").JsonValue;
            transcriberConfig: import("@prisma/client/runtime/library").JsonValue;
            serverConfig: import("@prisma/client/runtime/library").JsonValue;
            structuredOutputs: import("@prisma/client/runtime/library").JsonValue;
            scorecards: import("@prisma/client/runtime/library").JsonValue;
            monitors: import("@prisma/client/runtime/library").JsonValue;
            demoAudioUrl: string | null;
            campaignId: string | null;
            createdAt: string;
            updatedAt: string;
        }[]>;
        byId: (_: unknown, args: {
            id: string;
        }, ctx: TenantContext) => Promise<{
            id: string;
            name: string;
            type: import("@prisma/client").$Enums.AgentType;
            category: string | null;
            status: import("@prisma/client").$Enums.AgentStatus;
            environment: import("@prisma/client").$Enums.AgentEnvironment;
            enabled: boolean;
            languages: string[];
            firstMessage: string | null;
            systemPrompt: string | null;
            voiceConfig: import("@prisma/client/runtime/library").JsonValue;
            modelConfig: import("@prisma/client/runtime/library").JsonValue;
            transcriberConfig: import("@prisma/client/runtime/library").JsonValue;
            serverConfig: import("@prisma/client/runtime/library").JsonValue;
            structuredOutputs: import("@prisma/client/runtime/library").JsonValue;
            scorecards: import("@prisma/client/runtime/library").JsonValue;
            monitors: import("@prisma/client/runtime/library").JsonValue;
            demoAudioUrl: string | null;
            campaignId: string | null;
            createdAt: string;
            updatedAt: string;
        }>;
    };
    AgentsMutations: {
        create: (_: unknown, args: {
            input: Record<string, unknown>;
        }, ctx: TenantContext) => Promise<{
            id: string;
            name: string;
            type: import("@prisma/client").$Enums.AgentType;
            category: string | null;
            status: import("@prisma/client").$Enums.AgentStatus;
            environment: import("@prisma/client").$Enums.AgentEnvironment;
            enabled: boolean;
            languages: string[];
            firstMessage: string | null;
            systemPrompt: string | null;
            voiceConfig: import("@prisma/client/runtime/library").JsonValue;
            modelConfig: import("@prisma/client/runtime/library").JsonValue;
            transcriberConfig: import("@prisma/client/runtime/library").JsonValue;
            serverConfig: import("@prisma/client/runtime/library").JsonValue;
            structuredOutputs: import("@prisma/client/runtime/library").JsonValue;
            scorecards: import("@prisma/client/runtime/library").JsonValue;
            monitors: import("@prisma/client/runtime/library").JsonValue;
            demoAudioUrl: string | null;
            campaignId: string | null;
            createdAt: string;
            updatedAt: string;
        }>;
        update: (_: unknown, args: {
            id: string;
            input: Record<string, unknown>;
        }, ctx: TenantContext) => Promise<{
            id: string;
            name: string;
            type: import("@prisma/client").$Enums.AgentType;
            category: string | null;
            status: import("@prisma/client").$Enums.AgentStatus;
            environment: import("@prisma/client").$Enums.AgentEnvironment;
            enabled: boolean;
            languages: string[];
            firstMessage: string | null;
            systemPrompt: string | null;
            voiceConfig: import("@prisma/client/runtime/library").JsonValue;
            modelConfig: import("@prisma/client/runtime/library").JsonValue;
            transcriberConfig: import("@prisma/client/runtime/library").JsonValue;
            serverConfig: import("@prisma/client/runtime/library").JsonValue;
            structuredOutputs: import("@prisma/client/runtime/library").JsonValue;
            scorecards: import("@prisma/client/runtime/library").JsonValue;
            monitors: import("@prisma/client/runtime/library").JsonValue;
            demoAudioUrl: string | null;
            campaignId: string | null;
            createdAt: string;
            updatedAt: string;
        }>;
    };
    AgentLibraryQueries: {
        list: (_: unknown, __: unknown, ctx: TenantContext) => Promise<{
            id: string;
            slug: string;
            name: string;
            profile: string;
            category: string;
            useCases: string[];
            defaultType: import("@prisma/client").$Enums.AgentType;
            estimatedSetupMinutes: number;
            samplePrompt: string;
            defaultFirstMessage: string;
            defaultVariables: import("@prisma/client/runtime/library").JsonValue;
            compatibleVoices: import("@prisma/client/runtime/library").JsonValue;
            demoAudioUrl: string;
            avatarGradient: string | null;
            sortOrder: number;
        }[]>;
        bySlug: (_: unknown, args: {
            slug: string;
        }, ctx: TenantContext) => Promise<{
            id: string;
            slug: string;
            name: string;
            profile: string;
            category: string;
            useCases: string[];
            defaultType: import("@prisma/client").$Enums.AgentType;
            estimatedSetupMinutes: number;
            samplePrompt: string;
            defaultFirstMessage: string;
            defaultVariables: import("@prisma/client/runtime/library").JsonValue;
            compatibleVoices: import("@prisma/client/runtime/library").JsonValue;
            demoAudioUrl: string;
            avatarGradient: string | null;
            sortOrder: number;
        }>;
    };
    PhoneNumbersQueries: {
        list: (_: unknown, args: {
            filter?: Parameters<typeof parsePhoneNumberFilter>[0];
            sort?: Parameters<typeof parsePhoneNumberSort>[0];
        }, ctx: TenantContext) => Promise<{
            id: string;
            number: string;
            label: string | null;
            provider: import("@prisma/client").$Enums.TelephonyProvider;
            status: import("@prisma/client").$Enums.PhoneNumberStatus;
            inboundAgentId: string | null;
            outboundAgentId: string | null;
            inboundAgent: {
                id: string;
                name: string;
            } | null | undefined;
            outboundAgent: {
                id: string;
                name: string;
            } | null | undefined;
            inboundCallsCount: number;
            outboundCallsCount: number;
            lastActivityAt: string | null;
            createdAt: string;
            updatedAt: string;
        }[]>;
        connection: (_: unknown, args: {
            first?: number;
            after?: string;
            filter?: Parameters<typeof parsePhoneNumberFilter>[0];
            sort?: Parameters<typeof parsePhoneNumberSort>[0];
        }, ctx: TenantContext) => Promise<{
            edges: {
                node: {
                    id: string;
                    number: string;
                    label: string | null;
                    provider: import("@prisma/client").$Enums.TelephonyProvider;
                    status: import("@prisma/client").$Enums.PhoneNumberStatus;
                    inboundAgentId: string | null;
                    outboundAgentId: string | null;
                    inboundAgent: {
                        id: string;
                        name: string;
                    } | null | undefined;
                    outboundAgent: {
                        id: string;
                        name: string;
                    } | null | undefined;
                    inboundCallsCount: number;
                    outboundCallsCount: number;
                    lastActivityAt: string | null;
                    createdAt: string;
                    updatedAt: string;
                };
                cursor: string;
            }[];
            pageInfo: import("../lib/pagination").PageInfo;
            totalCount: number;
        }>;
        byId: (_: unknown, args: {
            id: string;
        }, ctx: TenantContext) => Promise<{
            id: string;
            number: string;
            label: string | null;
            provider: import("@prisma/client").$Enums.TelephonyProvider;
            status: import("@prisma/client").$Enums.PhoneNumberStatus;
            inboundAgentId: string | null;
            outboundAgentId: string | null;
            inboundAgent: {
                id: string;
                name: string;
            } | null | undefined;
            outboundAgent: {
                id: string;
                name: string;
            } | null | undefined;
            inboundCallsCount: number;
            outboundCallsCount: number;
            lastActivityAt: string | null;
            createdAt: string;
            updatedAt: string;
        }>;
    };
    PhoneNumbersMutations: {
        create: (_: unknown, args: {
            input: Record<string, unknown>;
        }, ctx: TenantContext) => Promise<{
            id: string;
            number: string;
            label: string | null;
            provider: import("@prisma/client").$Enums.TelephonyProvider;
            status: import("@prisma/client").$Enums.PhoneNumberStatus;
            inboundAgentId: string | null;
            outboundAgentId: string | null;
            inboundAgent: {
                id: string;
                name: string;
            } | null | undefined;
            outboundAgent: {
                id: string;
                name: string;
            } | null | undefined;
            inboundCallsCount: number;
            outboundCallsCount: number;
            lastActivityAt: string | null;
            createdAt: string;
            updatedAt: string;
        }>;
        update: (_: unknown, args: {
            id: string;
            input: Record<string, unknown>;
        }, ctx: TenantContext) => Promise<{
            id: string;
            number: string;
            label: string | null;
            provider: import("@prisma/client").$Enums.TelephonyProvider;
            status: import("@prisma/client").$Enums.PhoneNumberStatus;
            inboundAgentId: string | null;
            outboundAgentId: string | null;
            inboundAgent: {
                id: string;
                name: string;
            } | null | undefined;
            outboundAgent: {
                id: string;
                name: string;
            } | null | undefined;
            inboundCallsCount: number;
            outboundCallsCount: number;
            lastActivityAt: string | null;
            createdAt: string;
            updatedAt: string;
        }>;
    };
    UploadedContactsQueries: {
        list: (_: unknown, __: unknown, ctx: TenantContext) => Promise<{
            id: string;
            phone: string;
            field1: string | null;
            field2: string | null;
            field3: string | null;
            campaignIds: string[];
            createdAt: string;
        }[]>;
    };
    UploadedContactsMutations: {
        create: (_: unknown, args: {
            phone: string;
        }, ctx: TenantContext) => Promise<{
            id: string;
            phone: string;
            field1: string | null;
            field2: string | null;
            field3: string | null;
            campaignIds: string[];
            createdAt: string;
        }>;
        importContacts: (_: unknown, args: {
            contacts: Array<{
                phone: string;
                field1?: string | null;
                field2?: string | null;
                field3?: string | null;
                campaignNames?: string[];
                campaignIds?: string[];
            }>;
        }, ctx: TenantContext) => Promise<{
            created: number;
            updated: number;
            skipped: number;
            invalid: number;
            unmatchedCampaigns: string[];
        }>;
        delete: (_: unknown, args: {
            id: string;
        }, ctx: TenantContext) => Promise<boolean>;
        bulkDelete: (_: unknown, args: {
            ids: string[];
        }, ctx: TenantContext) => Promise<number>;
    };
    LeadsQueries: {
        connection: (_: unknown, args: {
            first?: number;
            after?: string;
            filter?: Parameters<typeof parseLeadFilter>[0];
        }, ctx: TenantContext) => Promise<{
            edges: {
                cursor: string;
                node: {
                    id: string;
                    firstName: string | null;
                    lastName: string | null;
                    email: string | null;
                    phone: string | null;
                    temperature: import("@prisma/client").$Enums.LeadTemperature | null;
                    score: number;
                    lastContactedAt: string | null;
                    createdAt: string;
                    sourceName: string | null;
                    stageName: string;
                };
            }[];
            pageInfo: import("../lib/pagination").PageInfo;
        }>;
        byId: (_: unknown, args: {
            id: string;
        }, ctx: TenantContext) => Promise<{
            id: string;
            firstName: string | null;
            lastName: string | null;
            email: string | null;
            phone: string | null;
            temperature: import("@prisma/client").$Enums.LeadTemperature | null;
            score: number;
            lastContactedAt: string | null;
            createdAt: string;
            sourceName: string | null;
            stageName: string;
        }>;
        temperatureBreakdown: (_: unknown, __: unknown, ctx: TenantContext) => Promise<{
            hot: number;
            warm: number;
            cold: number;
            total: number;
        }>;
    };
    LeadsMutations: {
        importRows: (_: unknown, args: {
            rows: {
                firstName?: string | null;
                lastName?: string | null;
                email?: string | null;
                phone: string;
                temperature: string;
            }[];
        }, ctx: TenantContext) => Promise<{
            invalid: number;
            hot: number;
            warm: number;
            cold: number;
            total: number;
            created: number;
            updated: number;
        }>;
    };
    OutboundCampaignsQueries: {
        list: (_: unknown, __: unknown, ctx: TenantContext) => Promise<{
            id: string;
            name: string;
            status: string;
            agentId: string | null;
            agentName: string;
            totalCalls: number;
            connectedCalls: number;
            conversionRate: number;
            generatedLeads: number;
            createdAt: string;
        }[]>;
    };
    OutboundCampaignsMutations: {
        create: (_: unknown, args: {
            input: {
                name: string;
                aiAgentId?: string | null;
            };
        }, ctx: TenantContext) => Promise<{
            id: string;
            name: string;
            status: string;
            agentId: string | null;
            agentName: string;
            totalCalls: number;
            connectedCalls: number;
            conversionRate: number;
            generatedLeads: number;
            createdAt: string;
        }>;
        launch: (_: unknown, args: {
            id: string;
        }, ctx: TenantContext) => Promise<{
            id: string;
            name: string;
            status: string;
            agentId: string | null;
            agentName: string;
            totalCalls: number;
            connectedCalls: number;
            conversionRate: number;
            generatedLeads: number;
            createdAt: string;
        }>;
        pause: (_: unknown, args: {
            id: string;
        }, ctx: TenantContext) => Promise<{
            id: string;
            name: string;
            status: string;
            agentId: string | null;
            agentName: string;
            totalCalls: number;
            connectedCalls: number;
            conversionRate: number;
            generatedLeads: number;
            createdAt: string;
        }>;
    };
    NotificationQueries: {
        list: (_: unknown, args: {
            first?: number;
            after?: string;
        }, ctx: TenantContext) => Promise<import("../lib/pagination").Connection<{
            userId: string;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            companyId: string;
            type: import("@prisma/client").$Enums.NotificationType;
            title: string;
            body: string;
            readAt: Date | null;
            data: import("@prisma/client/runtime/library").JsonValue;
        }>>;
    };
    IntegrationQueries: {
        list: (_: unknown, __: unknown, ctx: TenantContext) => Promise<{
            status: import("@prisma/client").$Enums.IntegrationStatus;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            companyId: string;
            type: import("@prisma/client").$Enums.IntegrationType;
            connectedAccount: string | null;
            config: import("@prisma/client/runtime/library").JsonValue;
            credentialsRef: string | null;
            lastSyncAt: Date | null;
            errorMessage: string | null;
        }[]>;
    };
    SchedulerQueries: {
        upcoming: (_: unknown, args: {
            limit?: number;
        }, ctx: TenantContext) => Promise<{
            status: import("@prisma/client").$Enums.SchedulerEventStatus;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            companyId: string;
            type: import("@prisma/client").$Enums.SchedulerEventType;
            assignedUserId: string | null;
            description: string | null;
            leadId: string | null;
            title: string;
            startAt: Date;
            endAt: Date | null;
            timezone: string;
            externalCalendarId: string | null;
            externalEventId: string | null;
            reminderAt: Date | null;
            metadata: import("@prisma/client/runtime/library").JsonValue;
        }[]>;
    };
    EventQueries: {
        recent: (_: unknown, args: {
            limit?: number;
        }, ctx: TenantContext) => Promise<{
            id: string;
            createdAt: Date;
            companyId: string;
            type: import("@prisma/client").$Enums.SystemEventType;
            title: string;
            entityType: string | null;
            entityId: string | null;
            actorId: string | null;
            payload: import("@prisma/client/runtime/library").JsonValue;
        }[]>;
    };
    CampaignsQueries: {
        connection: (_: unknown, args: {
            first?: number;
            after?: string;
            filter?: {
                search?: string;
                status?: string;
                aiEnabled?: boolean;
            };
        }, ctx: TenantContext) => Promise<{
            edges: {
                node: {
                    id: any;
                    name: any;
                    status: any;
                    direction: any;
                    address: any;
                    phone: any;
                    email: any;
                    notes: any;
                    customFields: any;
                    aiEnabled: any;
                    systemPrompt: any;
                    aiConfig: any;
                    contactsCount: number;
                    callLogsCount: number;
                    documentsCount: number;
                    agentsCount: number;
                    lastActivityAt: any;
                    createdAt: any;
                    updatedAt: any;
                    invitationEmailSent: boolean | null;
                    invitation: {
                        id: any;
                        email: any;
                        token: any;
                        status: any;
                        createdAt: any;
                        updatedAt: any;
                        sentAt: any;
                        acceptedAt: any;
                        expiresAt: any;
                    } | null;
                };
                cursor: string;
            }[];
            pageInfo: import("../lib/pagination").PageInfo;
            totalCount: number;
        }>;
        byId: (_: unknown, args: {
            id: string;
        }, ctx: TenantContext) => Promise<{
            id: any;
            name: any;
            status: any;
            direction: any;
            address: any;
            phone: any;
            email: any;
            notes: any;
            customFields: any;
            aiEnabled: any;
            systemPrompt: any;
            aiConfig: any;
            contactsCount: number;
            callLogsCount: number;
            documentsCount: number;
            agentsCount: number;
            lastActivityAt: any;
            createdAt: any;
            updatedAt: any;
            invitationEmailSent: boolean | null;
            invitation: {
                id: any;
                email: any;
                token: any;
                status: any;
                createdAt: any;
                updatedAt: any;
                sentAt: any;
                acceptedAt: any;
                expiresAt: any;
            } | null;
        }>;
        contacts: (_: unknown, args: {
            campaignId: string;
            first?: number;
            after?: string;
        }, ctx: TenantContext) => Promise<{
            id: string;
            phone: string;
            field1: string | null;
            field2: string | null;
            field3: string | null;
            createdAt: string;
        }[]>;
        callLogs: (_: unknown, args: {
            campaignId: string;
            first?: number;
            after?: string;
        }, ctx: TenantContext) => Promise<{
            id: string;
            publicId: string;
            direction: import("@prisma/client").$Enums.CallDirection;
            status: import("@prisma/client").$Enums.CallStatus;
            durationSeconds: number;
            startedAt: string;
            answeredAt: string | null;
            endedAt: string | null;
            leadPhone: string | null;
            phoneNumber: string | null;
            leadName: string | null;
            providerStatus: string | null;
            disconnectReason: string | null;
        }[]>;
        documents: (_: unknown, args: {
            campaignId: string;
        }, ctx: TenantContext) => Promise<{
            id: string;
            name: string;
            url: string;
            mimeType: string | null;
            sizeBytes: number | null;
            createdAt: string;
        }[]>;
        activities: (_: unknown, args: {
            campaignId: string;
            limit?: number;
        }, ctx: TenantContext) => Promise<{
            id: string;
            type: string;
            summary: string;
            metadata: import("@prisma/client/runtime/library").JsonValue;
            createdAt: string;
        }[]>;
        agents: (_: unknown, args: {
            campaignId: string;
        }, ctx: TenantContext) => Promise<{
            id: string;
            name: string;
            type: string;
            category: string | null;
            status: string;
            environment: string;
            enabled: boolean;
            languages: string[];
            firstMessage: string | null;
            systemPrompt: string | null;
            voiceConfig: unknown;
            modelConfig: unknown;
            transcriberConfig: unknown;
            serverConfig: unknown;
            structuredOutputs: unknown;
            scorecards: unknown;
            monitors: unknown;
            demoAudioUrl: string | null;
            campaignId: string | null;
            createdAt: string;
            updatedAt: string;
        }[]>;
    };
    CampaignsMutations: {
        create: (_: unknown, args: {
            input: Record<string, unknown>;
        }, ctx: TenantContext) => Promise<{
            id: any;
            name: any;
            status: any;
            direction: any;
            address: any;
            phone: any;
            email: any;
            notes: any;
            customFields: any;
            aiEnabled: any;
            systemPrompt: any;
            aiConfig: any;
            contactsCount: number;
            callLogsCount: number;
            documentsCount: number;
            agentsCount: number;
            lastActivityAt: any;
            createdAt: any;
            updatedAt: any;
            invitationEmailSent: boolean | null;
            invitation: {
                id: any;
                email: any;
                token: any;
                status: any;
                createdAt: any;
                updatedAt: any;
                sentAt: any;
                acceptedAt: any;
                expiresAt: any;
            } | null;
        }>;
        update: (_: unknown, args: {
            id: string;
            input: Record<string, unknown>;
        }, ctx: TenantContext) => Promise<{
            id: any;
            name: any;
            status: any;
            direction: any;
            address: any;
            phone: any;
            email: any;
            notes: any;
            customFields: any;
            aiEnabled: any;
            systemPrompt: any;
            aiConfig: any;
            contactsCount: number;
            callLogsCount: number;
            documentsCount: number;
            agentsCount: number;
            lastActivityAt: any;
            createdAt: any;
            updatedAt: any;
            invitationEmailSent: boolean | null;
            invitation: {
                id: any;
                email: any;
                token: any;
                status: any;
                createdAt: any;
                updatedAt: any;
                sentAt: any;
                acceptedAt: any;
                expiresAt: any;
            } | null;
        }>;
        updateAi: (_: unknown, args: {
            id: string;
            input: Record<string, unknown>;
        }, ctx: TenantContext) => Promise<{
            id: any;
            name: any;
            status: any;
            direction: any;
            address: any;
            phone: any;
            email: any;
            notes: any;
            customFields: any;
            aiEnabled: any;
            systemPrompt: any;
            aiConfig: any;
            contactsCount: number;
            callLogsCount: number;
            documentsCount: number;
            agentsCount: number;
            lastActivityAt: any;
            createdAt: any;
            updatedAt: any;
            invitationEmailSent: boolean | null;
            invitation: {
                id: any;
                email: any;
                token: any;
                status: any;
                createdAt: any;
                updatedAt: any;
                sentAt: any;
                acceptedAt: any;
                expiresAt: any;
            } | null;
        }>;
        bulkUpdate: (_: unknown, args: {
            input: Record<string, unknown>;
        }, ctx: TenantContext) => Promise<{
            updated: number;
        }>;
        bulkDelete: (_: unknown, args: {
            ids: string[];
        }, ctx: TenantContext) => Promise<{
            deleted: number;
        }>;
        archive: (_: unknown, args: {
            id: string;
        }, ctx: TenantContext) => Promise<{
            id: any;
            name: any;
            status: any;
            direction: any;
            address: any;
            phone: any;
            email: any;
            notes: any;
            customFields: any;
            aiEnabled: any;
            systemPrompt: any;
            aiConfig: any;
            contactsCount: number;
            callLogsCount: number;
            documentsCount: number;
            agentsCount: number;
            lastActivityAt: any;
            createdAt: any;
            updatedAt: any;
            invitationEmailSent: boolean | null;
            invitation: {
                id: any;
                email: any;
                token: any;
                status: any;
                createdAt: any;
                updatedAt: any;
                sentAt: any;
                acceptedAt: any;
                expiresAt: any;
            } | null;
        }>;
        delete: (_: unknown, args: {
            id: string;
        }, ctx: TenantContext) => Promise<boolean>;
        resendInvitation: (_: unknown, args: {
            campaignId: string;
        }, ctx: TenantContext) => Promise<{
            id: any;
            name: any;
            status: any;
            direction: any;
            address: any;
            phone: any;
            email: any;
            notes: any;
            customFields: any;
            aiEnabled: any;
            systemPrompt: any;
            aiConfig: any;
            contactsCount: number;
            callLogsCount: number;
            documentsCount: number;
            agentsCount: number;
            lastActivityAt: any;
            createdAt: any;
            updatedAt: any;
            invitationEmailSent: boolean | null;
            invitation: {
                id: any;
                email: any;
                token: any;
                status: any;
                createdAt: any;
                updatedAt: any;
                sentAt: any;
                acceptedAt: any;
                expiresAt: any;
            } | null;
        }>;
        cancelInvitation: (_: unknown, args: {
            campaignId: string;
        }, ctx: TenantContext) => Promise<{
            id: any;
            name: any;
            status: any;
            direction: any;
            address: any;
            phone: any;
            email: any;
            notes: any;
            customFields: any;
            aiEnabled: any;
            systemPrompt: any;
            aiConfig: any;
            contactsCount: number;
            callLogsCount: number;
            documentsCount: number;
            agentsCount: number;
            lastActivityAt: any;
            createdAt: any;
            updatedAt: any;
            invitationEmailSent: boolean | null;
            invitation: {
                id: any;
                email: any;
                token: any;
                status: any;
                createdAt: any;
                updatedAt: any;
                sentAt: any;
                acceptedAt: any;
                expiresAt: any;
            } | null;
        }>;
        generateNewInvitation: (_: unknown, args: {
            campaignId: string;
        }, ctx: TenantContext) => Promise<{
            id: any;
            name: any;
            status: any;
            direction: any;
            address: any;
            phone: any;
            email: any;
            notes: any;
            customFields: any;
            aiEnabled: any;
            systemPrompt: any;
            aiConfig: any;
            contactsCount: number;
            callLogsCount: number;
            documentsCount: number;
            agentsCount: number;
            lastActivityAt: any;
            createdAt: any;
            updatedAt: any;
            invitationEmailSent: boolean | null;
            invitation: {
                id: any;
                email: any;
                token: any;
                status: any;
                createdAt: any;
                updatedAt: any;
                sentAt: any;
                acceptedAt: any;
                expiresAt: any;
            } | null;
        }>;
    };
    EmployeesQueries: {
        connection: (_: unknown, args: {
            first?: number;
            after?: string;
            filter?: Record<string, unknown>;
        }, ctx: TenantContext) => Promise<{
            edges: {
                node: {
                    id: string;
                    userId: string;
                    name: string;
                    email: string;
                    phone: string | null;
                    imageUrl: string | null;
                    jobTitle: string | null;
                    role: import("@prisma/client").$Enums.UserRole;
                    customRole: {
                        id: string;
                        name: string;
                        slug: string;
                        permissions: string[];
                        isSystem: boolean;
                    } | null;
                    campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
                    assignedCampaigns: {
                        id: string;
                        name: string;
                        status: import("@prisma/client").$Enums.CampaignStatus;
                    }[];
                    status: import("@prisma/client").$Enums.MemberStatus;
                    invitationStatus: import("../services/employees.service").InvitationDisplayStatus;
                    lastActiveAt: string | null;
                    invitedAt: string | null;
                    joinedAt: string | null;
                    createdAt: string;
                    updatedAt: string;
                };
                cursor: string;
            }[];
            pageInfo: import("../lib/pagination").PageInfo;
            totalCount: number;
        }>;
        byId: (_: unknown, args: {
            id: string;
        }, ctx: TenantContext) => Promise<{
            id: string;
            userId: string;
            name: string;
            email: string;
            phone: string | null;
            imageUrl: string | null;
            jobTitle: string | null;
            role: import("@prisma/client").$Enums.UserRole;
            customRole: {
                id: string;
                name: string;
                slug: string;
                permissions: string[];
                isSystem: boolean;
            } | null;
            campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
            assignedCampaigns: {
                id: string;
                name: string;
                status: import("@prisma/client").$Enums.CampaignStatus;
            }[];
            status: import("@prisma/client").$Enums.MemberStatus;
            invitationStatus: import("../services/employees.service").InvitationDisplayStatus;
            lastActiveAt: string | null;
            invitedAt: string | null;
            joinedAt: string | null;
            createdAt: string;
            updatedAt: string;
        }>;
        permissionsForRole: (_: unknown, args: {
            role: TenantContext["role"];
        }, ctx: TenantContext) => import("../types/permissions").Permission[];
    };
    EmployeesMutations: {
        invite: (_: unknown, args: {
            input: Record<string, unknown>;
        }, ctx: TenantContext) => Promise<{
            id: string;
            userId: string;
            name: string;
            email: string;
            phone: string | null;
            imageUrl: string | null;
            jobTitle: string | null;
            role: import("@prisma/client").$Enums.UserRole;
            customRole: {
                id: string;
                name: string;
                slug: string;
                permissions: string[];
                isSystem: boolean;
            } | null;
            campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
            assignedCampaigns: {
                id: string;
                name: string;
                status: import("@prisma/client").$Enums.CampaignStatus;
            }[];
            status: import("@prisma/client").$Enums.MemberStatus;
            invitationStatus: import("../services/employees.service").InvitationDisplayStatus;
            lastActiveAt: string | null;
            invitedAt: string | null;
            joinedAt: string | null;
            createdAt: string;
            updatedAt: string;
        }>;
        update: (_: unknown, args: {
            id: string;
            input: Record<string, unknown>;
        }, ctx: TenantContext) => Promise<{
            id: string;
            userId: string;
            name: string;
            email: string;
            phone: string | null;
            imageUrl: string | null;
            jobTitle: string | null;
            role: import("@prisma/client").$Enums.UserRole;
            customRole: {
                id: string;
                name: string;
                slug: string;
                permissions: string[];
                isSystem: boolean;
            } | null;
            campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
            assignedCampaigns: {
                id: string;
                name: string;
                status: import("@prisma/client").$Enums.CampaignStatus;
            }[];
            status: import("@prisma/client").$Enums.MemberStatus;
            invitationStatus: import("../services/employees.service").InvitationDisplayStatus;
            lastActiveAt: string | null;
            invitedAt: string | null;
            joinedAt: string | null;
            createdAt: string;
            updatedAt: string;
        }>;
        deactivate: (_: unknown, args: {
            id: string;
        }, ctx: TenantContext) => Promise<{
            id: string;
            userId: string;
            name: string;
            email: string;
            phone: string | null;
            imageUrl: string | null;
            jobTitle: string | null;
            role: import("@prisma/client").$Enums.UserRole;
            customRole: {
                id: string;
                name: string;
                slug: string;
                permissions: string[];
                isSystem: boolean;
            } | null;
            campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
            assignedCampaigns: {
                id: string;
                name: string;
                status: import("@prisma/client").$Enums.CampaignStatus;
            }[];
            status: import("@prisma/client").$Enums.MemberStatus;
            invitationStatus: import("../services/employees.service").InvitationDisplayStatus;
            lastActiveAt: string | null;
            invitedAt: string | null;
            joinedAt: string | null;
            createdAt: string;
            updatedAt: string;
        }>;
        delete: (_: unknown, args: {
            id: string;
        }, ctx: TenantContext) => Promise<boolean>;
        resendInvite: (_: unknown, args: {
            id: string;
        }, ctx: TenantContext) => Promise<{
            id: string;
            userId: string;
            name: string;
            email: string;
            phone: string | null;
            imageUrl: string | null;
            jobTitle: string | null;
            role: import("@prisma/client").$Enums.UserRole;
            customRole: {
                id: string;
                name: string;
                slug: string;
                permissions: string[];
                isSystem: boolean;
            } | null;
            campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
            assignedCampaigns: {
                id: string;
                name: string;
                status: import("@prisma/client").$Enums.CampaignStatus;
            }[];
            status: import("@prisma/client").$Enums.MemberStatus;
            invitationStatus: import("../services/employees.service").InvitationDisplayStatus;
            lastActiveAt: string | null;
            invitedAt: string | null;
            joinedAt: string | null;
            createdAt: string;
            updatedAt: string;
        }>;
        cancelInvite: (_: unknown, args: {
            id: string;
        }, ctx: TenantContext) => Promise<boolean>;
    };
    UploadedContact: {
        campaigns: (parent: {
            campaignIds?: string[] | null;
        }, _: unknown, ctx: TenantContext) => Promise<any[]>;
    };
    Campaign: {
        execution: (parent: {
            id: string;
            companyId?: string;
        }, _: unknown, ctx: TenantContext) => Promise<{
            status: import("@prisma/client").$Enums.CampaignExecutionStatus;
            scheduledAt: string | null;
            totalContacts: number;
        } | null>;
    };
    CallLog: {
        lead: (parent: {
            leadId?: string | null;
        }, _: unknown, ctx: TenantContext) => Promise<{
            id: string;
            createdAt: Date;
            updatedAt: Date;
            companyId: string;
            email: string | null;
            stageId: string;
            sourceId: string | null;
            assignedUserId: string | null;
            firstName: string | null;
            lastName: string | null;
            phone: string | null;
            companyName: string | null;
            temperature: import("@prisma/client").$Enums.LeadTemperature | null;
            score: number;
            customFields: import("@prisma/client/runtime/library").JsonValue;
            tags: string[];
            lastContactedAt: Date | null;
            nextFollowUpAt: Date | null;
            queueStatus: import("@prisma/client").$Enums.CallingQueueStatus;
            assignedAiAgentId: string | null;
            lockedAt: Date | null;
            channelId: string | null;
            campaignId: string | null;
        } | null> | null;
        aiAgent: (parent: {
            aiAgentId?: string | null;
        }, _: unknown, ctx: TenantContext) => Promise<{
            status: import("@prisma/client").$Enums.AgentStatus;
            name: string;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            companyId: string;
            type: import("@prisma/client").$Enums.AgentType;
            campaignId: string | null;
            resourceKey: string;
            libraryEntryId: string | null;
            description: string | null;
            category: string | null;
            environment: import("@prisma/client").$Enums.AgentEnvironment;
            enabled: boolean;
            languages: string[];
            firstMessage: string | null;
            systemPrompt: string | null;
            voiceConfig: import("@prisma/client/runtime/library").JsonValue;
            modelConfig: import("@prisma/client/runtime/library").JsonValue;
            transcriberConfig: import("@prisma/client/runtime/library").JsonValue;
            serverConfig: import("@prisma/client/runtime/library").JsonValue;
            structuredOutputs: import("@prisma/client/runtime/library").JsonValue;
            scorecards: import("@prisma/client/runtime/library").JsonValue;
            monitors: import("@prisma/client/runtime/library").JsonValue;
            demoAudioUrl: string | null;
        } | null> | null;
        phoneNumber: (parent: {
            phoneNumberId?: string | null;
        }, _: unknown, ctx: TenantContext) => Promise<{
            number: string;
            id: string;
            label: string | null;
        } | null> | null;
        campaign: (parent: {
            campaignId?: string | null;
        }, _: unknown, ctx: TenantContext) => Promise<any>;
    };
    CreditUsage: {
        createdAt: (parent: {
            createdAt: Date | string;
        }) => string;
        reason: (parent: {
            reason: string;
        }) => string;
    };
    BillingInvoice: {
        issuedAt: (parent: {
            issuedAt: Date;
        }) => string;
        dueAt: (parent: {
            dueAt?: Date | null;
        }) => string | null;
        paidAt: (parent: {
            paidAt?: Date | null;
        }) => string | null;
    };
    Notification: {
        createdAt: (parent: {
            createdAt: Date;
        }) => string;
        readAt: (parent: {
            readAt?: Date | null;
        }) => string | null;
    };
    Integration: {
        lastSyncAt: (parent: {
            lastSyncAt?: Date | null;
        }) => string | null;
    };
    SchedulerEvent: {
        startAt: (parent: {
            startAt: Date;
        }) => string;
        endAt: (parent: {
            endAt?: Date | null;
        }) => string | null;
    };
    SystemEvent: {
        createdAt: (parent: {
            createdAt: Date;
        }) => string;
    };
    ApiKeysQueries: {
        connection: (_: unknown, args: {
            first?: number;
            after?: string;
            filter?: {
                search?: string;
                status?: string;
                environment?: string;
            };
        }, ctx: TenantContext) => Promise<{
            edges: {
                cursor: string;
                node: {
                    id: string;
                    name: string;
                    description: string | null;
                    keyId: string;
                    maskedSecret: string;
                    keyPrefix: string;
                    environment: import("@prisma/client").$Enums.ApiKeyEnvironment;
                    status: import("@prisma/client").$Enums.ApiKeyStatus;
                    scopes: string[];
                    campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
                    campaignIds: string[];
                    expiresAt: string | null;
                    lastUsedAt: string | null;
                    createdAt: string;
                    updatedAt: string;
                    createdBy: {
                        id: string;
                        email: string;
                        firstName: string | null;
                        lastName: string | null;
                    } | null;
                };
            }[];
            pageInfo: import("../lib/pagination").PageInfo;
            totalCount: number;
        }>;
        byId: (_: unknown, args: {
            id: string;
        }, ctx: TenantContext) => Promise<{
            id: string;
            name: string;
            description: string | null;
            keyId: string;
            maskedSecret: string;
            keyPrefix: string;
            environment: import("@prisma/client").$Enums.ApiKeyEnvironment;
            status: import("@prisma/client").$Enums.ApiKeyStatus;
            scopes: string[];
            campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
            campaignIds: string[];
            expiresAt: string | null;
            lastUsedAt: string | null;
            createdAt: string;
            updatedAt: string;
            createdBy: {
                id: string;
                email: string;
                firstName: string | null;
                lastName: string | null;
            } | null;
        } | null>;
        availableScopes: (_: unknown, __: unknown, ctx: TenantContext) => {
            scope: import("../types/permissions").Permission;
            label: string;
        }[];
        accessibleCampaigns: (_: unknown, __: unknown, ctx: TenantContext) => Promise<{
            id: string;
            name: string;
            status: import("@prisma/client").$Enums.CampaignStatus;
        }[]>;
    };
    ApiKeysMutations: {
        create: (_: unknown, args: {
            input: Record<string, unknown>;
        }, ctx: TenantContext) => Promise<{
            secret: string;
            id: string;
            name: string;
            description: string | null;
            keyId: string;
            maskedSecret: string;
            keyPrefix: string;
            environment: import("@prisma/client").$Enums.ApiKeyEnvironment;
            status: import("@prisma/client").$Enums.ApiKeyStatus;
            scopes: string[];
            campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
            campaignIds: string[];
            expiresAt: string | null;
            lastUsedAt: string | null;
            createdAt: string;
            updatedAt: string;
            createdBy: {
                id: string;
                email: string;
                firstName: string | null;
                lastName: string | null;
            } | null;
        }>;
        update: (_: unknown, args: {
            id: string;
            input: Record<string, unknown>;
        }, ctx: TenantContext) => Promise<{
            id: string;
            name: string;
            description: string | null;
            keyId: string;
            maskedSecret: string;
            keyPrefix: string;
            environment: import("@prisma/client").$Enums.ApiKeyEnvironment;
            status: import("@prisma/client").$Enums.ApiKeyStatus;
            scopes: string[];
            campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
            campaignIds: string[];
            expiresAt: string | null;
            lastUsedAt: string | null;
            createdAt: string;
            updatedAt: string;
            createdBy: {
                id: string;
                email: string;
                firstName: string | null;
                lastName: string | null;
            } | null;
        }>;
        enable: (_: unknown, args: {
            id: string;
        }, ctx: TenantContext) => Promise<{
            id: string;
            name: string;
            description: string | null;
            keyId: string;
            maskedSecret: string;
            keyPrefix: string;
            environment: import("@prisma/client").$Enums.ApiKeyEnvironment;
            status: import("@prisma/client").$Enums.ApiKeyStatus;
            scopes: string[];
            campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
            campaignIds: string[];
            expiresAt: string | null;
            lastUsedAt: string | null;
            createdAt: string;
            updatedAt: string;
            createdBy: {
                id: string;
                email: string;
                firstName: string | null;
                lastName: string | null;
            } | null;
        }>;
        disable: (_: unknown, args: {
            id: string;
        }, ctx: TenantContext) => Promise<{
            id: string;
            name: string;
            description: string | null;
            keyId: string;
            maskedSecret: string;
            keyPrefix: string;
            environment: import("@prisma/client").$Enums.ApiKeyEnvironment;
            status: import("@prisma/client").$Enums.ApiKeyStatus;
            scopes: string[];
            campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
            campaignIds: string[];
            expiresAt: string | null;
            lastUsedAt: string | null;
            createdAt: string;
            updatedAt: string;
            createdBy: {
                id: string;
                email: string;
                firstName: string | null;
                lastName: string | null;
            } | null;
        }>;
        delete: (_: unknown, args: {
            id: string;
        }, ctx: TenantContext) => Promise<{
            success: boolean;
            id: string;
        }>;
        regenerate: (_: unknown, args: {
            id: string;
        }, ctx: TenantContext) => Promise<{
            secret: string;
            id: string;
            name: string;
            description: string | null;
            keyId: string;
            maskedSecret: string;
            keyPrefix: string;
            environment: import("@prisma/client").$Enums.ApiKeyEnvironment;
            status: import("@prisma/client").$Enums.ApiKeyStatus;
            scopes: string[];
            campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
            campaignIds: string[];
            expiresAt: string | null;
            lastUsedAt: string | null;
            createdAt: string;
            updatedAt: string;
            createdBy: {
                id: string;
                email: string;
                firstName: string | null;
                lastName: string | null;
            } | null;
        }>;
        rotateSecret: (_: unknown, args: {
            id: string;
        }, ctx: TenantContext) => Promise<{
            secret: string;
            id: string;
            name: string;
            description: string | null;
            keyId: string;
            maskedSecret: string;
            keyPrefix: string;
            environment: import("@prisma/client").$Enums.ApiKeyEnvironment;
            status: import("@prisma/client").$Enums.ApiKeyStatus;
            scopes: string[];
            campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
            campaignIds: string[];
            expiresAt: string | null;
            lastUsedAt: string | null;
            createdAt: string;
            updatedAt: string;
            createdBy: {
                id: string;
                email: string;
                firstName: string | null;
                lastName: string | null;
            } | null;
        }>;
        updateScopes: (_: unknown, args: {
            id: string;
            scopes: string[];
        }, ctx: TenantContext) => Promise<{
            id: string;
            name: string;
            description: string | null;
            keyId: string;
            maskedSecret: string;
            keyPrefix: string;
            environment: import("@prisma/client").$Enums.ApiKeyEnvironment;
            status: import("@prisma/client").$Enums.ApiKeyStatus;
            scopes: string[];
            campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
            campaignIds: string[];
            expiresAt: string | null;
            lastUsedAt: string | null;
            createdAt: string;
            updatedAt: string;
            createdBy: {
                id: string;
                email: string;
                firstName: string | null;
                lastName: string | null;
            } | null;
        }>;
        updateCampaignAccess: (_: unknown, args: {
            id: string;
            input: {
                campaignAccessType: string;
                campaignIds?: string[];
            };
        }, ctx: TenantContext) => Promise<{
            id: string;
            name: string;
            description: string | null;
            keyId: string;
            maskedSecret: string;
            keyPrefix: string;
            environment: import("@prisma/client").$Enums.ApiKeyEnvironment;
            status: import("@prisma/client").$Enums.ApiKeyStatus;
            scopes: string[];
            campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
            campaignIds: string[];
            expiresAt: string | null;
            lastUsedAt: string | null;
            createdAt: string;
            updatedAt: string;
            createdBy: {
                id: string;
                email: string;
                firstName: string | null;
                lastName: string | null;
            } | null;
        }>;
        updateExpiration: (_: unknown, args: {
            id: string;
            expiresAt?: string | null;
        }, ctx: TenantContext) => Promise<{
            id: string;
            name: string;
            description: string | null;
            keyId: string;
            maskedSecret: string;
            keyPrefix: string;
            environment: import("@prisma/client").$Enums.ApiKeyEnvironment;
            status: import("@prisma/client").$Enums.ApiKeyStatus;
            scopes: string[];
            campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
            campaignIds: string[];
            expiresAt: string | null;
            lastUsedAt: string | null;
            createdAt: string;
            updatedAt: string;
            createdBy: {
                id: string;
                email: string;
                firstName: string | null;
                lastName: string | null;
            } | null;
        }>;
    };
};
export {};
