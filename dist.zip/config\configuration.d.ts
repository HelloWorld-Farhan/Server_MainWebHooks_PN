declare const _default: () => {
    port: number;
    databaseUrl: string;
    mainWebsiteUrl: string;
    mainServerUrl: string;
    agentServerApiKey: string | undefined;
    apiKeyPepper: string | undefined;
    clerkSecretKey: string | undefined;
    clerkWebhookSecret: string | undefined;
    clerkWebhooksEnabled: boolean;
};
export default _default;
