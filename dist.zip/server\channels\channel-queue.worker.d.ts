import { OnModuleDestroy, OnModuleInit } from "@nestjs/common";
import { getChannelCooldownMs, getChannelQueuePollMs } from "./channel-keys";
export { drainCompanyQueue } from "./channel-queue.drain";
export declare class ChannelQueueWorker implements OnModuleInit, OnModuleDestroy {
    private interval;
    private processing;
    onModuleInit(): void;
    onModuleDestroy(): void;
    tick(): Promise<void>;
    processCompanyQueue(companyId: string): Promise<void>;
}
export { getChannelCooldownMs, getChannelQueuePollMs };
