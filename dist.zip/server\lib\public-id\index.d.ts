import { formatResourceKey, inferResourceTypeFromKey, normalizeCallLogEntityId, resourceKeyMatchesType } from "./formatters";
import { decodeLegacyPublicId, generateLegacyPublicId, parseLegacyPublicId, validateLegacyPublicId } from "./legacy";
import { PUBLIC_ID_VERSION, CAMPAIGN_SCOPED_RESOURCE_TYPES, type CompanyPublicIdentity, type GenerateCampaignPublicIdInput, type GenerateLegacyPublicIdInput, type GeneratePublicIdInput, type ParsedCampaignPublicIdV1, type ParsedLegacyPublicIdV1, type ParsedPublicIdV1, type PublicIdVersion, PublicResourceType } from "./types";
export { PUBLIC_ID_VERSION, PublicResourceType, CAMPAIGN_SCOPED_RESOURCE_TYPES, type CompanyPublicIdentity, type GenerateCampaignPublicIdInput, type GenerateLegacyPublicIdInput, type GeneratePublicIdInput, type ParsedCampaignPublicIdV1, type ParsedLegacyPublicIdV1, type ParsedPublicIdV1, type PublicIdVersion, };
export { formatResourceKey, inferResourceTypeFromKey, normalizeCallLogEntityId, resourceKeyMatchesType, };
export { decodeLegacyPublicId, generateLegacyPublicId, parseLegacyPublicId, validateLegacyPublicId, };
export declare class UnsupportedPublicIdVersionError extends Error {
    constructor(version: string);
}
export declare function generateCampaignPublicId(input: GenerateCampaignPublicIdInput): string;
export declare function parseCampaignPublicId(input: string): ParsedCampaignPublicIdV1 | null;
export declare function validateCampaignPublicId(input: string): boolean;
export declare function decodeCampaignPublicId(input: string): ParsedCampaignPublicIdV1;
export declare function generatePublicId(input: GeneratePublicIdInput): string;
export declare function parsePublicId(input: string): ParsedPublicIdV1 | null;
export declare function getVersion(input: string): PublicIdVersion | null;
export declare function validatePublicId(input: string, expectedResourceType?: PublicResourceType): boolean;
export declare function decodePublicId(input: string): ParsedPublicIdV1;
export declare function isLegacyObjectId(input: string): boolean;
export declare function looksLikePublicId(input: string): boolean;
