"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseRepository = void 0;
class BaseRepository {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    scope(companyId) {
        return { companyId };
    }
}
exports.BaseRepository = BaseRepository;
//# sourceMappingURL=base.repository.js.map