import type { Company, CompanyMember, User } from "@prisma/client";
type MembershipWithRelations = CompanyMember & {
    user: User;
    customRole?: {
        permissions: string[];
    } | null;
    campaignAccess?: {
        campaignId: string;
    }[];
    company?: Company;
};
export type ResolvedTenant = {
    company: Company;
    user: User;
    membership: MembershipWithRelations;
};
export type ResolutionCache = {
    tenant?: ResolvedTenant | null;
};
export declare function resolveAuthenticatedTenant(clerkUserId: string, orgId?: string | null, options?: {
    resolutionCache?: ResolutionCache;
    forceReconcile?: boolean;
}): Promise<ResolvedTenant | null>;
export declare function resolveCompanyForAuthenticatedUser(clerkUserId: string, orgId?: string | null, options?: {
    resolutionCache?: ResolutionCache;
    forceReconcile?: boolean;
}): Promise<Company | null>;
export {};
