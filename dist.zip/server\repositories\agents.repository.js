"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentsRepository = void 0;
const types_1 = require("../lib/public-id/types");
const resource_key_1 = require("../lib/resource-key");
const base_repository_1 = require("./base.repository");
class AgentsRepository extends base_repository_1.BaseRepository {
    findStatusSummary(companyId) {
        return this.prisma.aiAgent.groupBy({
            by: ["status"],
            where: this.scope(companyId),
            _count: { id: true },
        });
    }
    findById(companyId, id) {
        return this.prisma.aiAgent.findFirst({
            where: { id, companyId },
        });
    }
    findMany(companyId) {
        return this.prisma.aiAgent.findMany({
            where: this.scope(companyId),
            orderBy: { createdAt: "desc" },
        });
    }
    findByIds(companyId, ids) {
        return this.prisma.aiAgent.findMany({
            where: { companyId, id: { in: ids } },
        });
    }
    findByCampaign(companyId, campaignId) {
        return this.prisma.aiAgent.findMany({
            where: { companyId, campaignId },
            orderBy: { createdAt: "desc" },
        });
    }
    countByCampaign(companyId, campaignId) {
        return this.prisma.aiAgent.count({ where: { companyId, campaignId } });
    }
    create(companyId, data) {
        return this.prisma.$transaction(async (tx) => {
            const resourceKey = data.resourceKey ??
                (await (0, resource_key_1.allocateResourceKey)(tx, companyId, types_1.PublicResourceType.AGENT));
            return tx.aiAgent.create({
                data: {
                    ...data,
                    resourceKey,
                    company: { connect: { id: companyId } },
                },
            });
        });
    }
    update(companyId, id, data) {
        return this.prisma.aiAgent.update({
            where: { id },
            data,
        });
    }
}
exports.AgentsRepository = AgentsRepository;
//# sourceMappingURL=agents.repository.js.map