import { z } from "zod";
import type { ProviderErrorDetails } from "./provider-error.dto";
export type ObdProviderOutboundSuccess = {
    ok: true;
    providerCallId: string | null;
    raw: unknown;
};
export type ObdProviderOutboundFailure = {
    ok: false;
    error: ProviderErrorDetails;
};
export type ObdProviderOutboundResult = ObdProviderOutboundSuccess | ObdProviderOutboundFailure;
export declare const obdProviderSuccessBodySchema: z.ZodObject<{
    request_id: z.ZodOptional<z.ZodString>;
    call_id: z.ZodOptional<z.ZodString>;
    id: z.ZodOptional<z.ZodString>;
    campaignid: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
    campaign_id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
    status: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
    value: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
    message: z.ZodOptional<z.ZodString>;
    error: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodBoolean]>>;
    success: z.ZodOptional<z.ZodBoolean>;
}, z.core.$loose>;
export declare function extractProviderCallId(body: unknown): string | null;
export declare function extractProviderErrorMessage(body: unknown): string | null;
