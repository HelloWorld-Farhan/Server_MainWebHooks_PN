export declare const AGENT_LIBRARY_LIST_QUERY = "\n  query AgentLibraryList {\n    agentLibrary {\n      list {\n        id\n        slug\n        name\n        profile\n        category\n        useCases\n        defaultType\n        estimatedSetupMinutes\n        samplePrompt\n        defaultFirstMessage\n        defaultVariables\n        compatibleVoices\n        demoAudioUrl\n        avatarGradient\n        sortOrder\n      }\n    }\n  }\n";
export declare const AGENT_LIBRARY_BY_SLUG_QUERY = "\n  query AgentLibraryBySlug($slug: String!) {\n    agentLibrary {\n      bySlug(slug: $slug) {\n        id\n        slug\n        name\n        profile\n        category\n        useCases\n        defaultType\n        estimatedSetupMinutes\n        samplePrompt\n        defaultFirstMessage\n        defaultVariables\n        compatibleVoices\n        demoAudioUrl\n        avatarGradient\n        sortOrder\n      }\n    }\n  }\n";
export type GraphQLAgentLibraryEntry = {
    id: string;
    slug: string;
    name: string;
    profile: string;
    category: string;
    useCases: string[];
    defaultType: string;
    estimatedSetupMinutes: number;
    samplePrompt: string;
    defaultFirstMessage: string;
    defaultVariables: {
        key: string;
        label: string;
        placeholder: string;
    }[];
    compatibleVoices: {
        id: string;
        name: string;
        provider: string;
    }[];
    demoAudioUrl: string;
    avatarGradient?: string | null;
    sortOrder: number;
};
export type AgentLibraryListResult = {
    agentLibrary: {
        list: GraphQLAgentLibraryEntry[];
    };
};
export type AgentLibraryBySlugResult = {
    agentLibrary: {
        bySlug: GraphQLAgentLibraryEntry | null;
    };
};
