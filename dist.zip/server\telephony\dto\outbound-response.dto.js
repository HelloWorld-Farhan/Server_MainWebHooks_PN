"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.obdProviderSuccessBodySchema = void 0;
exports.extractProviderCallId = extractProviderCallId;
exports.extractProviderErrorMessage = extractProviderErrorMessage;
const zod_1 = require("zod");
exports.obdProviderSuccessBodySchema = zod_1.z
    .object({
    request_id: zod_1.z.string().optional(),
    call_id: zod_1.z.string().optional(),
    id: zod_1.z.string().optional(),
    campaignid: zod_1.z.union([zod_1.z.string(), zod_1.z.number()]).optional(),
    campaign_id: zod_1.z.union([zod_1.z.string(), zod_1.z.number()]).optional(),
    status: zod_1.z.union([zod_1.z.string(), zod_1.z.number()]).optional(),
    value: zod_1.z.union([zod_1.z.string(), zod_1.z.number()]).optional(),
    message: zod_1.z.string().optional(),
    error: zod_1.z.union([zod_1.z.string(), zod_1.z.boolean()]).optional(),
    success: zod_1.z.boolean().optional(),
})
    .passthrough();
function stringifyProviderId(value) {
    if (value === undefined || value === null || value === "") {
        return null;
    }
    return String(value);
}
function extractProviderCallId(body) {
    const parsed = exports.obdProviderSuccessBodySchema.safeParse(body);
    if (!parsed.success) {
        return null;
    }
    return (stringifyProviderId(parsed.data.campaignid) ??
        stringifyProviderId(parsed.data.campaign_id) ??
        parsed.data.request_id ??
        parsed.data.call_id ??
        stringifyProviderId(parsed.data.id) ??
        null);
}
function normalizeProviderStatus(status) {
    if (typeof status === "string") {
        return status.trim().toLowerCase();
    }
    if (typeof status === "number") {
        return String(status);
    }
    return null;
}
function normalizeProviderValue(value) {
    if (typeof value === "string") {
        return value.trim().toLowerCase();
    }
    if (typeof value === "number") {
        return String(value);
    }
    return null;
}
function extractProviderErrorMessage(body) {
    const parsed = exports.obdProviderSuccessBodySchema.safeParse(body);
    if (!parsed.success) {
        return null;
    }
    if (parsed.data.success === false) {
        return parsed.data.message ?? "OBD provider rejected the request";
    }
    if (parsed.data.error === true) {
        return parsed.data.message ?? "OBD provider returned an error";
    }
    const status = normalizeProviderStatus(parsed.data.status);
    if (status === "error" || status === "failed" || status === "failure") {
        return parsed.data.message ?? `OBD provider status: ${status}`;
    }
    const value = normalizeProviderValue(parsed.data.value);
    if (value &&
        value !== "accepted" &&
        (value.includes("invalid") ||
            value.includes("error") ||
            value.includes("fail") ||
            value.includes("reject"))) {
        return parsed.data.message ?? `OBD provider value: ${value}`;
    }
    if (typeof parsed.data.message === "string") {
        const normalized = parsed.data.message.trim().toLowerCase();
        if (normalized.includes("invalid") ||
            normalized.includes("error") ||
            normalized.includes("fail")) {
            return parsed.data.message;
        }
    }
    return null;
}
//# sourceMappingURL=outbound-response.dto.js.map