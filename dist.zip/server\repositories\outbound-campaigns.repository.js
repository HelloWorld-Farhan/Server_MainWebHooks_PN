"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OutboundCampaignsRepository = void 0;
const base_repository_1 = require("./base.repository");
class OutboundCampaignsRepository extends base_repository_1.BaseRepository {
    findMany(companyId) {
        return this.prisma.outboundCampaign.findMany({
            where: this.scope(companyId),
            include: {
                aiAgent: { select: { id: true, name: true } },
            },
            orderBy: { createdAt: "desc" },
        });
    }
    findById(companyId, id) {
        return this.prisma.outboundCampaign.findFirst({
            where: { id, companyId },
            include: {
                aiAgent: { select: { id: true, name: true } },
            },
        });
    }
    create(companyId, data) {
        return this.prisma.outboundCampaign.create({
            data: {
                companyId,
                name: data.name,
                aiAgentId: data.aiAgentId ?? null,
                status: "DRAFT",
            },
            include: {
                aiAgent: { select: { id: true, name: true } },
            },
        });
    }
    updateStatus(companyId, id, status) {
        return this.prisma.outboundCampaign.updateMany({
            where: { id, companyId },
            data: { status },
        });
    }
}
exports.OutboundCampaignsRepository = OutboundCampaignsRepository;
//# sourceMappingURL=outbound-campaigns.repository.js.map