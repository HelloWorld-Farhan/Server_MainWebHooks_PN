import { BaseRepository } from "./base.repository";
export declare class CallInternalNoteRepository extends BaseRepository {
    listByCallLog(companyId: string, callLogId: string): import("@prisma/client").Prisma.PrismaPromise<({
        author: {
            id: string;
            email: string;
            firstName: string | null;
            lastName: string | null;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        callLogId: string;
        authorId: string;
        content: string;
    })[]>;
    create(companyId: string, callLogId: string, authorId: string, content: string): import("@prisma/client").Prisma.Prisma__CallInternalNoteClient<{
        author: {
            id: string;
            email: string;
            firstName: string | null;
            lastName: string | null;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        callLogId: string;
        authorId: string;
        content: string;
    }, never, import("@prisma/client/runtime/library").DefaultArgs, import("@prisma/client").Prisma.PrismaClientOptions>;
    update(companyId: string, id: string, content: string): import("@prisma/client").Prisma.PrismaPromise<import("@prisma/client").Prisma.BatchPayload>;
    delete(companyId: string, id: string): import("@prisma/client").Prisma.PrismaPromise<import("@prisma/client").Prisma.BatchPayload>;
}
