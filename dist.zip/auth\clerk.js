"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.clerkClient = void 0;
exports.getAuthFromFetchRequest = getAuthFromFetchRequest;
exports.getAuthFromRequest = getAuthFromRequest;
const backend_1 = require("@clerk/backend");
const clerk_config_1 = require("./clerk-config");
function getSecretKey() {
    const key = process.env.CLERK_SECRET_KEY;
    if (!key) {
        throw new Error("CLERK_SECRET_KEY is not configured");
    }
    return key;
}
function getPublishableKey() {
    const key = process.env.CLERK_PUBLISHABLE_KEY ??
        process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY;
    if (!key) {
        throw new Error("CLERK_PUBLISHABLE_KEY or NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY is not configured");
    }
    return key;
}
exports.clerkClient = (0, backend_1.createClerkClient)({
    secretKey: getSecretKey(),
    publishableKey: getPublishableKey(),
});
const clerkAuthorizedParties = (0, clerk_config_1.getClerkAuthorizedParties)();
function buildClerkRequestUrl(req) {
    const host = req.get("x-forwarded-host") ?? req.get("host") ?? "localhost";
    const proto = req.get("x-forwarded-proto") ?? req.protocol;
    return `${proto}://${host}${req.originalUrl}`;
}
function headerPresence(value) {
    return value ? "present" : "missing";
}
function logAuthRequestSnapshot(req) {
    console.log("[clerk:pre-auth]", {
        method: req.method,
        url: buildClerkRequestUrl(req),
        host: req.get("host"),
        origin: req.get("origin"),
        referer: req.get("referer"),
        cookie: headerPresence(req.get("cookie")),
        authorization: headerPresence(req.get("authorization")),
        x_forwarded_host: req.get("x-forwarded-host"),
        x_forwarded_proto: req.get("x-forwarded-proto"),
        x_forwarded_for: req.get("x-forwarded-for"),
        authorizedParties: clerkAuthorizedParties,
    });
}
function logFetchAuthRequestSnapshot(request) {
    console.log("[clerk:pre-auth]", {
        method: request.method,
        url: request.url,
        host: request.headers.get("host"),
        origin: request.headers.get("origin"),
        referer: request.headers.get("referer"),
        cookie: headerPresence(request.headers.get("cookie") ?? undefined),
        authorization: headerPresence(request.headers.get("authorization") ?? undefined),
        x_forwarded_host: request.headers.get("x-forwarded-host"),
        x_forwarded_proto: request.headers.get("x-forwarded-proto"),
        x_forwarded_for: request.headers.get("x-forwarded-for"),
        authorizedParties: clerkAuthorizedParties,
    });
}
function logAuthError(error) {
    const message = error instanceof Error ? error.message : String(error);
    const name = error instanceof Error ? error.name : "Error";
    console.error("[clerk:auth-error]", { name, message });
}
async function authenticateClerkRequest(request) {
    const secretKey = process.env.CLERK_SECRET_KEY;
    if (!secretKey) {
        return { userId: null, orgId: null, sessionId: null };
    }
    try {
        const result = await exports.clerkClient.authenticateRequest(request, {
            secretKey,
            publishableKey: getPublishableKey(),
            authorizedParties: clerkAuthorizedParties,
        });
        const auth = result.toAuth();
        console.log("[clerk:post-auth]", {
            status: result.status,
            isAuthenticated: result.isAuthenticated,
            userId: auth?.userId ?? null,
            sessionId: auth?.sessionId ?? null,
            orgId: auth?.orgId ?? null,
            actor: auth?.actor ?? null,
            reason: result.reason ?? undefined,
            message: result.message || undefined,
            tokenType: result.tokenType,
        });
        if (!auth) {
            return { userId: null, orgId: null, sessionId: null };
        }
        return {
            userId: auth.userId,
            orgId: auth.orgId ?? null,
            sessionId: auth.sessionId ?? null,
        };
    }
    catch (error) {
        logAuthError(error);
        return { userId: null, orgId: null, sessionId: null };
    }
}
async function getAuthFromFetchRequest(request) {
    logFetchAuthRequestSnapshot(request);
    return authenticateClerkRequest(request);
}
async function getAuthFromRequest(req) {
    logAuthRequestSnapshot(req);
    const request = new Request(buildClerkRequestUrl(req), {
        method: req.method,
        headers: req.headers,
    });
    return authenticateClerkRequest(request);
}
//# sourceMappingURL=clerk.js.map