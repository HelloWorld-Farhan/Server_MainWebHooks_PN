import { type ColumnMapping, type GoogleCalendarConfig, type GoogleSheetsConfig, type IntegrationId, type SheetRow, type SyncHistoryEntry, type WorkspaceIntegration } from "./types";
import type { AgentToolAssignment, AgentToolId } from "../tools/types";
import type { TenantContext } from "../../server/types/context";
export declare function listIntegrations(ctx: TenantContext): Promise<WorkspaceIntegration[]>;
export declare function getIntegrationById(ctx: TenantContext, id: IntegrationId): Promise<WorkspaceIntegration | null>;
export declare function connectIntegrationDb(ctx: TenantContext, id: IntegrationId, account?: string): Promise<WorkspaceIntegration | null>;
export declare function disconnectIntegrationDb(ctx: TenantContext, id: IntegrationId): Promise<WorkspaceIntegration | null>;
export declare function updateSheetsConfigDb(ctx: TenantContext, sheetsConfig: GoogleSheetsConfig): Promise<WorkspaceIntegration | null>;
export declare function updateCalendarConfigDb(ctx: TenantContext, calendarConfig: GoogleCalendarConfig): Promise<WorkspaceIntegration | null>;
export declare function getSpreadsheetsDb(ctx: TenantContext): Promise<{
    id: string;
    name: string;
    modifiedAt: string;
}[]>;
export declare function createSpreadsheetDb(ctx: TenantContext, name: string, columns?: ColumnMapping[]): Promise<import("../../lib/integrations/types").SpreadsheetOption>;
export declare function deleteSpreadsheetDb(ctx: TenantContext, spreadsheetId: string): Promise<WorkspaceIntegration | null>;
export declare function getWorksheetsDb(ctx: TenantContext, spreadsheetId: string): Promise<import("../../lib/integrations/types").WorksheetOption[]>;
export declare function getSyncHistoryDb(ctx: TenantContext): Promise<SyncHistoryEntry[]>;
export declare function triggerSheetsSyncDb(ctx: TenantContext): Promise<WorkspaceIntegration | null>;
export declare function completeSheetsSyncDb(ctx: TenantContext, message: string, rowsSynced: number, result?: "success" | "partial" | "error"): Promise<WorkspaceIntegration | null>;
export declare function getCalendarsDb(ctx: TenantContext): Promise<unknown[]>;
export declare function getCalendarConfigDb(ctx: TenantContext): Promise<GoogleCalendarConfig>;
export declare function getSheetRowsDb(ctx: TenantContext): Promise<SheetRow[]>;
export declare function syncSheetsDataDb(ctx: TenantContext): Promise<number>;
export type DialerSheetsSyncResult = {
    skipped: true;
    reason: string;
} | {
    success: true;
    spreadsheetId: string;
    rowsAppended: number;
};
export declare function syncDialerCallToSheetDb(ctx: TenantContext, callId: string): Promise<DialerSheetsSyncResult>;
export declare function readSheetRowDb(ctx: TenantContext, rowIndex: number): Promise<Record<string, string> | null>;
export declare function writeSheetRowDb(ctx: TenantContext, rowIndex: number, data: SheetRow): Promise<SheetRow>;
export declare function appendSheetRowDb(ctx: TenantContext, data: SheetRow): Promise<SheetRow>;
export declare function getCalendarEventsDb(ctx: TenantContext): Promise<{
    id: string;
    title: string;
    start: string;
    end: string;
    attendeeEmail?: string;
}[]>;
export declare function addCalendarEventDb(ctx: TenantContext, event: Omit<{
    id: string;
    title: string;
    start: string;
    end: string;
    attendeeEmail?: string;
}, "id">): Promise<{
    id: string;
    title: string;
    end: string;
    start: string;
    attendeeEmail?: string | undefined;
}>;
export declare function updateCalendarEventDb(ctx: TenantContext, eventId: string, update: Partial<{
    title: string;
    start: string;
    end: string;
    attendeeEmail?: string;
}>): Promise<{
    id: string;
    title: string;
    start: string;
    end: string;
    attendeeEmail?: string;
} | null>;
export declare function deleteCalendarEventDb(ctx: TenantContext, eventId: string): Promise<boolean>;
export declare function getAgentToolsDb(ctx: TenantContext, agentId: string): Promise<AgentToolAssignment[]>;
export declare function updateAgentToolDb(ctx: TenantContext, agentId: string, toolId: AgentToolId, patch: Partial<AgentToolAssignment>): Promise<{
    enabled: boolean;
    status: "enabled" | "disabled";
    config: AgentToolAssignment["config"];
    usage: AgentToolAssignment["usage"];
    health: import("../../lib/tools/types").ToolHealth;
    toolId: AgentToolId;
    blockedReason?: string;
}>;
