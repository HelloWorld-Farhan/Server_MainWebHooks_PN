import type { TenantContext } from "../../server/types/context";
export declare function createServiceTenantContext(companyId: string): TenantContext;
