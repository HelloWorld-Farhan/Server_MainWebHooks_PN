"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GraphQLController = void 0;
const common_1 = require("@nestjs/common");
const request_context_1 = require("../../auth/request-context");
const yoga_1 = require("../../server/graphql/yoga");
const API_GRAPHQL_PREFIX = "/api/graphql";
function normalizeGraphqlRequestPath(req) {
    if (!req.url.startsWith(API_GRAPHQL_PREFIX)) {
        return;
    }
    req.url = `/graphql${req.url.slice(API_GRAPHQL_PREFIX.length)}`;
}
let GraphQLController = class GraphQLController {
    async handleGraphQL(req, res) {
        return (0, request_context_1.runWithRequest)(req, async () => {
            normalizeGraphqlRequestPath(req);
            return (0, yoga_1.yoga)(req, res);
        });
    }
};
exports.GraphQLController = GraphQLController;
__decorate([
    (0, common_1.All)("graphql"),
    (0, common_1.All)("api/graphql"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], GraphQLController.prototype, "handleGraphQL", null);
exports.GraphQLController = GraphQLController = __decorate([
    (0, common_1.Controller)()
], GraphQLController);
//# sourceMappingURL=graphql.controller.js.map