"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IntegrationsController = void 0;
const common_1 = require("@nestjs/common");
const http_1 = require("../../lib/api/http");
const api_guard_1 = require("../../lib/integrations/api-guard");
const auth_status_1 = require("../../lib/integrations/google/auth-status");
const clerk_auth_1 = require("../../lib/integrations/google/clerk-auth");
const constants_1 = require("../../lib/integrations/google/constants");
const client_1 = require("../../lib/integrations/google/client");
const oauth_1 = require("../../lib/integrations/google/oauth");
const sheets_service_1 = require("../../lib/integrations/google/sheets-service");
const token_store_1 = require("../../lib/integrations/google/token-store");
const db_state_1 = require("../../lib/integrations/db-state");
const types_1 = require("../../lib/integrations/types");
const tenant_context_1 = require("../../lib/api/tenant-context");
function oauthRedirectResponse(ctx, integrationId, res) {
    const oauthUrl = (0, oauth_1.buildGoogleAuthUrl)(ctx.companyId, integrationId);
    return res.json({ oauthUrl, requiresOAuth: true });
}
let IntegrationsController = class IntegrationsController {
    async list(req, res) {
        const result = await (0, tenant_context_1.requireTenantContext)(req);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        const integrations = await (0, db_state_1.listIntegrations)(result.ctx);
        return res.json({ integrations });
    }
    async oauthStart(req, res) {
        const result = await (0, api_guard_1.requireIntegrationsRead)(req);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        const integrationId = req.query.integrationId;
        if (!integrationId || !(0, constants_1.isGoogleIntegration)(integrationId)) {
            return res.status(400).json({
                error: "integrationId must be google-sheets or google-calendar",
            });
        }
        try {
            const url = (0, oauth_1.buildGoogleAuthUrl)(result.ctx.companyId, integrationId);
            return res.redirect(url);
        }
        catch (e) {
            return res.status(500).json({
                error: e instanceof Error ? e.message : "Failed to start Google OAuth",
            });
        }
    }
    async oauthCallback(req, res) {
        const code = req.query.code;
        const state = req.query.state;
        const oauthError = req.query.error;
        const websiteUrl = process.env.MAIN_WEBSITE_URL ?? "http://200.234.34.240:3000";
        const settingsUrl = new URL("/settings", websiteUrl);
        settingsUrl.searchParams.set("tab", "integrations");
        if (oauthError) {
            settingsUrl.searchParams.set("oauth_error", oauthError);
            return res.redirect(settingsUrl.toString());
        }
        if (!code || !state) {
            settingsUrl.searchParams.set("oauth_error", "missing_code");
            return res.redirect(settingsUrl.toString());
        }
        try {
            const parsed = (0, oauth_1.parseGoogleOAuthState)(state);
            const ctx = await (0, tenant_context_1.resolveTenantContext)(req);
            if (!ctx || ctx.companyId !== parsed.companyId) {
                settingsUrl.searchParams.set("oauth_error", "unauthorized");
                return res.redirect(settingsUrl.toString());
            }
            const tokens = await (0, oauth_1.exchangeGoogleAuthCode)(code);
            await (0, token_store_1.saveGoogleTokens)(ctx, tokens);
            await (0, db_state_1.connectIntegrationDb)(ctx, parsed.integrationId, tokens.email ?? undefined);
            const otherId = parsed.integrationId === "google-sheets"
                ? "google-calendar"
                : "google-sheets";
            await (0, db_state_1.connectIntegrationDb)(ctx, otherId, tokens.email ?? undefined);
            settingsUrl.searchParams.set("oauth_success", parsed.integrationId);
            return res.redirect(settingsUrl.toString());
        }
        catch (e) {
            settingsUrl.searchParams.set("oauth_error", e instanceof Error ? e.message : "oauth_failed");
            return res.redirect(settingsUrl.toString());
        }
    }
    async googleConnect(req, res) {
        const result = await (0, api_guard_1.requireIntegrationsWrite)(req);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        const body = req.body;
        const integrationId = body.integrationId;
        if (!integrationId || !(0, constants_1.isGoogleIntegration)(integrationId)) {
            return res.status(400).json({
                error: "integrationId must be google-sheets or google-calendar",
            });
        }
        const clerkUserId = result.ctx.clerkUserId;
        if (clerkUserId) {
            const hasGoogle = await (0, clerk_auth_1.userHasGoogleAccount)(clerkUserId);
            const clerkToken = hasGoogle
                ? await (0, clerk_auth_1.getClerkGoogleAccessToken)(clerkUserId)
                : null;
            if (clerkToken && (0, clerk_auth_1.hasRequiredGoogleScopes)(clerkToken.scopes)) {
                const email = await (0, clerk_auth_1.getClerkGoogleEmail)(clerkUserId);
                await (0, auth_status_1.markGoogleIntegrationsConnected)(result.ctx, email, "clerk");
                const integration = await (0, db_state_1.getIntegrationById)(result.ctx, integrationId);
                if (!integration) {
                    return res.status(404).json({ error: "Integration not found" });
                }
                return res.json({ integration, authSource: "clerk" });
            }
        }
        try {
            return oauthRedirectResponse(result.ctx, integrationId, res);
        }
        catch (e) {
            return res.status(500).json({
                error: e instanceof Error
                    ? e.message
                    : "Google OAuth is not configured. Add GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET.",
            });
        }
    }
    async sheetsConfig(req, res) {
        const result = await (0, api_guard_1.requireIntegrationsWrite)(req);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        const body = req.body;
        const integration = await (0, db_state_1.updateSheetsConfigDb)(result.ctx, {
            spreadsheetId: body.spreadsheetId ?? null,
            spreadsheetName: body.spreadsheetName ?? null,
            worksheetId: body.worksheetId ?? null,
            worksheetName: body.worksheetName ?? null,
            columnMappings: body.columnMappings ?? [],
            autoSync: body.autoSync ?? false,
            lastSyncResult: body.lastSyncResult ?? null,
            lastSyncMessage: body.lastSyncMessage ?? null,
        });
        if (!integration) {
            return res.status(404).json({ error: "Integration not found" });
        }
        return res.json({ integration });
    }
    async listSpreadsheets(req, res) {
        const result = await (0, api_guard_1.requireIntegrationsRead)(req);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        try {
            const spreadsheets = await (0, db_state_1.getSpreadsheetsDb)(result.ctx);
            return res.json({ spreadsheets });
        }
        catch (e) {
            return res.status(500).json({
                error: e instanceof Error ? e.message : "Failed to list spreadsheets",
            });
        }
    }
    async createSpreadsheet(req, res) {
        const result = await (0, api_guard_1.requireIntegrationsWrite)(req);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        const body = req.body;
        const name = body.name?.trim() ||
            `PropNex Sheet ${new Date().toLocaleDateString()}`;
        try {
            const spreadsheet = await (0, db_state_1.createSpreadsheetDb)(result.ctx, name, body.columns ?? []);
            return res.json({ spreadsheet });
        }
        catch (e) {
            const status = e instanceof client_1.GoogleSheetsScopeError ? 400 : 500;
            return res.status(status).json({
                error: e instanceof Error ? e.message : "Failed to create spreadsheet",
            });
        }
    }
    async createSpreadsheetAlias(req, res) {
        return this.createSpreadsheet(req, res);
    }
    async deleteSpreadsheet(req, res) {
        const result = await (0, api_guard_1.requireIntegrationsWrite)(req);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        const spreadsheetId = req.query.spreadsheetId;
        if (!spreadsheetId) {
            return res.status(400).json({ error: "spreadsheetId required" });
        }
        try {
            const integration = await (0, db_state_1.deleteSpreadsheetDb)(result.ctx, spreadsheetId);
            const spreadsheets = await (0, db_state_1.getSpreadsheetsDb)(result.ctx);
            return res.json({ integration, spreadsheets });
        }
        catch (e) {
            return res.status(500).json({
                error: e instanceof Error ? e.message : "Failed to delete spreadsheet",
            });
        }
    }
    async worksheets(req, res) {
        const result = await (0, api_guard_1.requireIntegrationsRead)(req);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        const spreadsheetId = req.query.spreadsheetId;
        if (!spreadsheetId) {
            return res.status(400).json({ error: "spreadsheetId required" });
        }
        const worksheets = await (0, db_state_1.getWorksheetsDb)(result.ctx, spreadsheetId);
        return res.json({ worksheets });
    }
    async headers(req, res) {
        const result = await (0, api_guard_1.requireIntegrationsRead)(req);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        const spreadsheetId = req.query.spreadsheetId;
        const worksheetName = req.query.worksheetName ?? "Sheet1";
        if (!spreadsheetId) {
            return res.status(400).json({ error: "spreadsheetId required" });
        }
        try {
            const headers = await (0, sheets_service_1.getSheetHeaders)(result.ctx, spreadsheetId, worksheetName);
            return res.json({ headers });
        }
        catch (e) {
            return res.status(500).json({
                error: e instanceof Error ? e.message : "Failed to fetch headers",
            });
        }
    }
    async sheetsSync(req, res) {
        const result = await (0, api_guard_1.requireIntegrationsWrite)(req);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        try {
            await (0, db_state_1.triggerSheetsSyncDb)(result.ctx);
            const rowsSynced = await (0, db_state_1.syncSheetsDataDb)(result.ctx);
            const integration = await (0, db_state_1.completeSheetsSyncDb)(result.ctx, `Synced ${rowsSynced} row(s) successfully`, rowsSynced);
            return res.json({ integration });
        }
        catch (e) {
            const message = e instanceof Error ? e.message : "Sync failed";
            const integration = await (0, db_state_1.completeSheetsSyncDb)(result.ctx, message, 0, "error");
            return res.status(500).json({ error: message, integration });
        }
    }
    async syncHistory(req, res) {
        const result = await (0, api_guard_1.requireIntegrationsRead)(req);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        const history = await (0, db_state_1.getSyncHistoryDb)(result.ctx);
        return res.json({ history });
    }
    async calendarConfig(req, res) {
        const result = await (0, api_guard_1.requireIntegrationsWrite)(req);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        const body = req.body;
        const integration = await (0, db_state_1.updateCalendarConfigDb)(result.ctx, {
            calendarId: body.calendarId ?? null,
            calendarName: body.calendarName ?? null,
            timezone: body.timezone ?? "Asia/Kolkata",
            workingHours: body.workingHours ?? types_1.DEFAULT_WORKING_HOURS,
            meetingDurationMinutes: body.meetingDurationMinutes ?? 30,
            bufferMinutes: body.bufferMinutes ?? 15,
        });
        if (!integration) {
            return res.status(404).json({ error: "Integration not found" });
        }
        return res.json({ integration });
    }
    async calendars(req, res) {
        const result = await (0, api_guard_1.requireIntegrationsRead)(req);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        const calendars = await (0, db_state_1.getCalendarsDb)(result.ctx);
        return res.json({ calendars });
    }
    async getById(req, res, id) {
        const result = await (0, tenant_context_1.requireTenantContext)(req);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        const integration = await (0, db_state_1.getIntegrationById)(result.ctx, id);
        if (!integration) {
            return res.status(404).json({ error: "Integration not found" });
        }
        return res.json({ integration });
    }
    async connect(req, res, id) {
        const result = await (0, tenant_context_1.requireTenantContext)(req);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        if ((0, constants_1.isGoogleIntegration)(id)) {
            return res.status(400).json({
                error: "Use Google OAuth to connect this integration",
            });
        }
        const integration = await (0, db_state_1.connectIntegrationDb)(result.ctx, id);
        if (!integration) {
            return res.status(404).json({ error: "Integration not found" });
        }
        return res.json({ integration });
    }
    async disconnect(req, res, id) {
        const result = await (0, api_guard_1.requireIntegrationsWrite)(req);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        const integration = await (0, db_state_1.disconnectIntegrationDb)(result.ctx, id);
        if (!integration) {
            return res.status(404).json({ error: "Integration not found" });
        }
        return res.json({ integration });
    }
};
exports.IntegrationsController = IntegrationsController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], IntegrationsController.prototype, "list", null);
__decorate([
    (0, common_1.Get)("google/oauth/start"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], IntegrationsController.prototype, "oauthStart", null);
__decorate([
    (0, common_1.Get)("google/oauth/callback"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], IntegrationsController.prototype, "oauthCallback", null);
__decorate([
    (0, common_1.Post)("google/connect"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], IntegrationsController.prototype, "googleConnect", null);
__decorate([
    (0, common_1.Put)("google/sheets/config"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], IntegrationsController.prototype, "sheetsConfig", null);
__decorate([
    (0, common_1.Get)("google/sheets/spreadsheets"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], IntegrationsController.prototype, "listSpreadsheets", null);
__decorate([
    (0, common_1.Post)("google/sheets/spreadsheets"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], IntegrationsController.prototype, "createSpreadsheet", null);
__decorate([
    (0, common_1.Post)("google/sheets/spreadsheets/create"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], IntegrationsController.prototype, "createSpreadsheetAlias", null);
__decorate([
    (0, common_1.Delete)("google/sheets/spreadsheets"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], IntegrationsController.prototype, "deleteSpreadsheet", null);
__decorate([
    (0, common_1.Get)("google/sheets/worksheets"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], IntegrationsController.prototype, "worksheets", null);
__decorate([
    (0, common_1.Get)("google/sheets/headers"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], IntegrationsController.prototype, "headers", null);
__decorate([
    (0, common_1.Post)("google/sheets/sync"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], IntegrationsController.prototype, "sheetsSync", null);
__decorate([
    (0, common_1.Get)("google/sheets/sync-history"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], IntegrationsController.prototype, "syncHistory", null);
__decorate([
    (0, common_1.Put)("google/calendar/config"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], IntegrationsController.prototype, "calendarConfig", null);
__decorate([
    (0, common_1.Get)("google/calendar/calendars"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], IntegrationsController.prototype, "calendars", null);
__decorate([
    (0, common_1.Get)(":id"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __param(2, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, String]),
    __metadata("design:returntype", Promise)
], IntegrationsController.prototype, "getById", null);
__decorate([
    (0, common_1.Post)(":id/connect"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __param(2, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, String]),
    __metadata("design:returntype", Promise)
], IntegrationsController.prototype, "connect", null);
__decorate([
    (0, common_1.Post)(":id/disconnect"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __param(2, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, String]),
    __metadata("design:returntype", Promise)
], IntegrationsController.prototype, "disconnect", null);
exports.IntegrationsController = IntegrationsController = __decorate([
    (0, common_1.Controller)("api/integrations")
], IntegrationsController);
//# sourceMappingURL=integrations.controller.js.map