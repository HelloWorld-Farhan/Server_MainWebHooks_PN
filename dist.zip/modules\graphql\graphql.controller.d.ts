import type { Request, Response } from "express";
export declare class GraphQLController {
    handleGraphQL(req: Request, res: Response): Promise<void>;
}
