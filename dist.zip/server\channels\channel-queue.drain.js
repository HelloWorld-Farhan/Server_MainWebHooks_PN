"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.drainCompanyQueue = drainCompanyQueue;
const channel_service_1 = require("./channel.service");
const call_service_1 = require("../services/call.service");
async function drainCompanyQueue(companyId) {
    const metrics = await channel_service_1.channelService.getMetrics(companyId);
    if (metrics.allocated <= 0) {
        return;
    }
    while (true) {
        const reserved = await channel_service_1.channelService.tryReserve(companyId);
        if (!reserved) {
            break;
        }
        const callLogId = await channel_service_1.channelService.dequeue(companyId);
        if (!callLogId) {
            await channel_service_1.channelService.release(companyId);
            break;
        }
        const dispatched = await call_service_1.callService.dispatchQueuedCall(callLogId);
        if (!dispatched) {
            await channel_service_1.channelService.release(companyId);
            continue;
        }
    }
}
//# sourceMappingURL=channel-queue.drain.js.map