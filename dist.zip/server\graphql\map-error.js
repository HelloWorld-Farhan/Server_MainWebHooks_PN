"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toGraphQLError = toGraphQLError;
exports.maskGraphQLError = maskGraphQLError;
const client_1 = require("@prisma/client");
const graphql_1 = require("graphql");
const errors_1 = require("../lib/errors");
function unwrapError(error) {
    if (error instanceof graphql_1.GraphQLError && error.originalError) {
        return error.originalError;
    }
    if (error instanceof Error && "originalError" in error) {
        const nested = error.originalError;
        if (nested)
            return nested;
    }
    return error;
}
function isPrismaClientError(error) {
    return (error instanceof client_1.Prisma.PrismaClientKnownRequestError ||
        error instanceof client_1.Prisma.PrismaClientUnknownRequestError ||
        error instanceof client_1.Prisma.PrismaClientInitializationError ||
        error instanceof client_1.Prisma.PrismaClientRustPanicError);
}
function toAppGraphQLError(appError) {
    return new graphql_1.GraphQLError(appError.message, {
        extensions: {
            code: appError.code,
            http: {
                status: appError.statusCode,
                spec: true,
            },
        },
        originalError: appError,
    });
}
function toPrismaGraphQLError(error, isDev) {
    return new graphql_1.GraphQLError(isDev ? error.message : "Database temporarily unavailable", {
        extensions: {
            code: "SERVICE_UNAVAILABLE",
            http: {
                status: 503,
                spec: true,
            },
        },
        originalError: error,
    });
}
function toGraphQLError(error, isDev) {
    if (error instanceof graphql_1.GraphQLError) {
        const root = unwrapError(error);
        if ((0, errors_1.isAppError)(root)) {
            return toAppGraphQLError(root);
        }
        if (root instanceof Error && isPrismaClientError(root)) {
            return toPrismaGraphQLError(root, isDev);
        }
        return error;
    }
    const root = unwrapError(error);
    if ((0, errors_1.isAppError)(root)) {
        return toAppGraphQLError(root);
    }
    if (root instanceof Error && isPrismaClientError(root)) {
        return toPrismaGraphQLError(root, isDev);
    }
    if (error instanceof Error) {
        return new graphql_1.GraphQLError(isDev ? error.message : "Internal server error", {
            extensions: {
                code: "INTERNAL_SERVER_ERROR",
                unexpected: true,
                http: {
                    status: 500,
                },
            },
            originalError: error,
        });
    }
    return new graphql_1.GraphQLError("Internal server error", {
        extensions: {
            code: "INTERNAL_SERVER_ERROR",
            unexpected: true,
            http: {
                status: 500,
            },
        },
    });
}
function maskGraphQLError(error, message, isDev) {
    const root = unwrapError(error);
    if ((0, errors_1.isAppError)(error) || (0, errors_1.isAppError)(root)) {
        return toAppGraphQLError((0, errors_1.isAppError)(error) ? error : root);
    }
    if ((error instanceof Error && isPrismaClientError(error)) ||
        (root instanceof Error && isPrismaClientError(root))) {
        return toPrismaGraphQLError(root instanceof Error ? root : error, isDev);
    }
    if (error instanceof graphql_1.GraphQLError) {
        return error;
    }
    if (!isDev) {
        return new graphql_1.GraphQLError(message, {
            extensions: {
                code: "INTERNAL_SERVER_ERROR",
                unexpected: true,
                http: {
                    status: 500,
                },
            },
        });
    }
    return error instanceof Error ? error : new Error(String(error));
}
//# sourceMappingURL=map-error.js.map