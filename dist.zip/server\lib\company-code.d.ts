import type { PrismaClient } from "@prisma/client";
export declare function generateCompanyCode(): string;
export declare function normalizeCompanyCode(input: string): string | null;
export declare function generateUniqueCompanyCode(prisma: PrismaClient): Promise<string>;
