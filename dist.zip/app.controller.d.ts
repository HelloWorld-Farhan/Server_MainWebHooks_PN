export declare class AppController {
    getHealth(): {
        service: string;
        status: string;
        graphql: string;
        docs: string;
    };
    health(): {
        status: string;
    };
}
