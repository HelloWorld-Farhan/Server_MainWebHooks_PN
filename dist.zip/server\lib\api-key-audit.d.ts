import type { TenantContext } from "../types/context";
export type ApiKeyAuditAction = "CREATED" | "UPDATED" | "ENABLED" | "DISABLED" | "REGENERATED" | "ROTATED" | "DELETED" | "SCOPES_UPDATED" | "CAMPAIGN_ACCESS_UPDATED" | "EXPIRATION_UPDATED";
type AuditDeps = {
    create: (data: {
        companyId: string;
        userId: string | null;
        action: string;
        entityType: string;
        entityId: string;
        changes: Record<string, unknown>;
    }) => Promise<unknown>;
};
export declare function recordApiKeyAudit(deps: AuditDeps, ctx: TenantContext, apiKeyId: string, action: ApiKeyAuditAction, changes?: Record<string, unknown>): Promise<void>;
export {};
