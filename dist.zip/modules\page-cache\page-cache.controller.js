"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PageCacheController = void 0;
const common_1 = require("@nestjs/common");
const request_context_1 = require("../../auth/request-context");
const express_request_1 = require("../../lib/api/express-request");
const context_1 = require("../../server/graphql/context");
const errors_1 = require("../../server/lib/errors");
const keys_1 = require("../../server/cache/keys");
const page_cache_service_1 = require("../../server/cache/page-cache.service");
const parse_params_1 = require("../../server/page-cache/parse-params");
const registry_1 = require("../../server/page-cache/registry");
let PageCacheController = class PageCacheController {
    async getPageCache(req, res, pageKey) {
        if (!(0, registry_1.isValidPageCacheKey)(pageKey)) {
            return res.status(404).json({ error: "Unknown page key" });
        }
        return (0, request_context_1.runWithRequest)(req, async () => {
            try {
                const gqlContext = await (0, context_1.createGraphQLContext)(req);
                const loader = (0, registry_1.getPageLoader)(pageKey);
                if (!loader) {
                    return res.status(404).json({ error: "Page loader not found" });
                }
                const params = (0, parse_params_1.parsePageCacheParams)(new URL(`${req.protocol}://${req.get("host")}${req.originalUrl}`).searchParams);
                const cacheKey = keys_1.cacheKeys.page(gqlContext.companyId, pageKey, params);
                const result = await page_cache_service_1.pageCacheService.getPageData(cacheKey, () => loader((0, express_request_1.toFetchRequest)(req), params));
                return res.json(result);
            }
            catch (error) {
                if ((0, errors_1.isAppError)(error)) {
                    return res.status(error.statusCode).json({ error: error.message });
                }
                const message = error instanceof Error ? error.message : "Failed to load page cache";
                return res.status(500).json({ error: message });
            }
        });
    }
};
exports.PageCacheController = PageCacheController;
__decorate([
    (0, common_1.Get)(":pageKey"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __param(2, (0, common_1.Param)("pageKey")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, String]),
    __metadata("design:returntype", Promise)
], PageCacheController.prototype, "getPageCache", null);
exports.PageCacheController = PageCacheController = __decorate([
    (0, common_1.Controller)("api/page-cache")
], PageCacheController);
//# sourceMappingURL=page-cache.controller.js.map