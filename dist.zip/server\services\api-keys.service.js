"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.apiKeysService = exports.ApiKeysService = void 0;
const permissions_1 = require("../../lib/permissions");
const authorization_1 = require("../lib/authorization");
const api_key_audit_1 = require("../lib/api-key-audit");
const api_key_crypto_1 = require("../lib/api-key-crypto");
const errors_1 = require("../lib/errors");
const pagination_1 = require("../lib/pagination");
const prisma_1 = __importDefault(require("../lib/prisma"));
const api_keys_repository_1 = require("../repositories/api-keys.repository");
function toIso(value) {
    return value ? value.toISOString() : null;
}
function mapApiKey(row) {
    return {
        id: row.id,
        name: row.name,
        description: row.description,
        keyId: row.keyId,
        maskedSecret: (0, api_key_crypto_1.maskApiKeyPrefix)(row.keyPrefix),
        keyPrefix: row.keyPrefix,
        environment: row.environment,
        status: row.status,
        scopes: row.scopes,
        campaignAccessType: row.campaignAccessType,
        campaignIds: row.campaignAccess.map((b) => b.campaignId),
        expiresAt: toIso(row.expiresAt),
        lastUsedAt: toIso(row.lastUsedAt),
        createdAt: row.createdAt.toISOString(),
        updatedAt: row.updatedAt.toISOString(),
        createdBy: row.createdBy
            ? {
                id: row.createdBy.id,
                email: row.createdBy.email,
                firstName: row.createdBy.firstName,
                lastName: row.createdBy.lastName,
            }
            : null,
    };
}
function withSecret(row, secret) {
    return {
        ...mapApiKey(row),
        secret,
    };
}
class ApiKeysService {
    repo = new api_keys_repository_1.ApiKeysRepository(prisma_1.default);
    async audit(ctx, apiKeyId, action, changes = {}) {
        await (0, api_key_audit_1.recordApiKeyAudit)({ create: (data) => this.repo.createAuditLog(data) }, ctx, apiKeyId, action, changes);
    }
    validateScopes(scopes) {
        if (!scopes || scopes.length === 0) {
            throw new errors_1.ValidationError("At least one scope is required");
        }
        const unique = [...new Set(scopes)];
        for (const scope of unique) {
            if (!(0, permissions_1.isApiKeyScope)(scope)) {
                throw new errors_1.InvalidScopeError(scope);
            }
        }
        return unique;
    }
    async validateCampaigns(companyId, campaignAccessType, campaignIds) {
        if (campaignAccessType === "ALL") {
            return [];
        }
        const unique = [...new Set(campaignIds)];
        if (unique.length === 0) {
            throw new errors_1.ValidationError("At least one campaign is required when campaign access is SELECTED");
        }
        const found = await this.repo.findCampaignsByIds(companyId, unique);
        if (found.length !== unique.length) {
            throw new errors_1.InvalidCampaignError("One or more campaigns are invalid or do not belong to this company");
        }
        return unique;
    }
    enforcePrincipalSubset(ctx, scopes, campaignAccessType, campaignIds) {
        if (ctx.authType !== "api_key")
            return;
        (0, authorization_1.assertScopesAreSubset)(ctx.permissions, scopes);
        if (campaignAccessType === "ALL" && ctx.campaignAccess.type !== "ALL") {
            throw new errors_1.ValidationError("Cannot grant ALL campaign access beyond the current API key");
        }
        if (campaignAccessType === "SELECTED") {
            (0, authorization_1.assertCampaignsAreSubset)(ctx, campaignIds);
        }
    }
    async getConnection(ctx, args) {
        (0, authorization_1.requireScope)(ctx, permissions_1.PERMISSIONS.API_KEYS_READ);
        const limit = Math.min(Math.max(args.first ?? 20, 1), 100);
        const [rows, totalCount] = await Promise.all([
            this.repo.findConnection(ctx.companyId, limit, args.after ?? undefined, args.filter ?? undefined),
            this.repo.count(ctx.companyId, args.filter ?? undefined),
        ]);
        const connection = (0, pagination_1.buildConnection)(rows, limit, (item) => (0, pagination_1.encodeIdCursor)(item.id, item.createdAt));
        return {
            edges: connection.edges.map((edge) => ({
                cursor: edge.cursor,
                node: mapApiKey(edge.node),
            })),
            pageInfo: connection.pageInfo,
            totalCount,
        };
    }
    async getById(ctx, id) {
        (0, authorization_1.requireScope)(ctx, permissions_1.PERMISSIONS.API_KEYS_READ);
        const row = await this.repo.findById(ctx.companyId, id);
        if (!row)
            return null;
        return mapApiKey(row);
    }
    listAvailableScopes(ctx) {
        (0, authorization_1.requireScope)(ctx, permissions_1.PERMISSIONS.API_KEYS_READ);
        const labels = (0, permissions_1.getApiKeyScopeLabels)();
        return permissions_1.API_KEY_SCOPE_CATALOG.map((scope) => ({
            scope,
            label: labels[scope] ?? scope,
        }));
    }
    async listAccessibleCampaigns(ctx) {
        (0, authorization_1.requireScope)(ctx, permissions_1.PERMISSIONS.API_KEYS_READ);
        const campaignIds = ctx.campaignAccess.type === "ALL" ? null : ctx.campaignAccess.campaignIds;
        const rows = await this.repo.findAccessibleCampaigns(ctx.companyId, campaignIds);
        return rows.map((row) => ({
            id: row.id,
            name: row.name,
            status: row.status,
        }));
    }
    async create(ctx, input) {
        (0, authorization_1.requireScope)(ctx, permissions_1.PERMISSIONS.API_KEYS_WRITE);
        const name = input.name?.trim();
        if (!name)
            throw new errors_1.ValidationError("API key name is required");
        const existing = await this.repo.findByName(ctx.companyId, name);
        if (existing)
            throw new errors_1.DuplicateApiKeyNameError();
        const scopes = this.validateScopes(input.scopes);
        const campaignAccessType = input.campaignAccessType ?? "SELECTED";
        const campaignIds = await this.validateCampaigns(ctx.companyId, campaignAccessType, input.campaignIds ?? []);
        this.enforcePrincipalSubset(ctx, scopes, campaignAccessType, campaignIds);
        let expiresAt = null;
        if (input.expiresAt) {
            expiresAt = new Date(input.expiresAt);
            if (Number.isNaN(expiresAt.getTime())) {
                throw new errors_1.ValidationError("Invalid expiration date");
            }
            if (expiresAt <= new Date()) {
                throw new errors_1.ValidationError("Expiration must be in the future");
            }
        }
        const generated = (0, api_key_crypto_1.generateApiKey)(input.environment);
        const row = await this.repo.create({
            companyId: ctx.companyId,
            name,
            description: input.description?.trim() || null,
            keyId: generated.keyId,
            keyPrefix: generated.keyPrefix,
            hashedSecret: generated.hashedSecret,
            environment: generated.environment,
            scopes,
            campaignAccessType,
            campaignIds,
            expiresAt,
            createdById: ctx.userId,
        });
        await this.audit(ctx, row.id, "CREATED", {
            name,
            environment: row.environment,
            scopes,
            campaignAccessType,
            campaignIds,
        });
        return withSecret(row, generated.plaintext);
    }
    async update(ctx, id, input) {
        (0, authorization_1.requireScope)(ctx, permissions_1.PERMISSIONS.API_KEYS_WRITE);
        const existing = await this.repo.findById(ctx.companyId, id);
        if (!existing)
            throw new errors_1.ApiKeyNotFoundError();
        const data = {};
        if (input.name !== undefined) {
            const name = input.name.trim();
            if (!name)
                throw new errors_1.ValidationError("API key name is required");
            if (name !== existing.name) {
                const dup = await this.repo.findByName(ctx.companyId, name);
                if (dup)
                    throw new errors_1.DuplicateApiKeyNameError();
            }
            data.name = name;
        }
        if (input.description !== undefined) {
            data.description = input.description?.trim() || null;
        }
        const row = await this.repo.update(ctx.companyId, id, data);
        if (!row)
            throw new errors_1.ApiKeyNotFoundError();
        await this.audit(ctx, id, "UPDATED", data);
        return mapApiKey(row);
    }
    async enable(ctx, id) {
        (0, authorization_1.requireScope)(ctx, permissions_1.PERMISSIONS.API_KEYS_WRITE);
        const row = await this.repo.update(ctx.companyId, id, { status: "ACTIVE" });
        if (!row)
            throw new errors_1.ApiKeyNotFoundError();
        await this.audit(ctx, id, "ENABLED");
        return mapApiKey(row);
    }
    async disable(ctx, id) {
        (0, authorization_1.requireScope)(ctx, permissions_1.PERMISSIONS.API_KEYS_WRITE);
        const row = await this.repo.update(ctx.companyId, id, {
            status: "INACTIVE",
        });
        if (!row)
            throw new errors_1.ApiKeyNotFoundError();
        await this.audit(ctx, id, "DISABLED");
        return mapApiKey(row);
    }
    async delete(ctx, id) {
        (0, authorization_1.requireScope)(ctx, permissions_1.PERMISSIONS.API_KEYS_WRITE);
        const existing = await this.repo.findById(ctx.companyId, id);
        if (!existing)
            throw new errors_1.ApiKeyNotFoundError();
        await this.repo.softDelete(ctx.companyId, id);
        await this.audit(ctx, id, "DELETED", { name: existing.name });
        return { success: true, id };
    }
    async regenerate(ctx, id) {
        (0, authorization_1.requireScope)(ctx, permissions_1.PERMISSIONS.API_KEYS_WRITE);
        const existing = await this.repo.findById(ctx.companyId, id);
        if (!existing)
            throw new errors_1.ApiKeyNotFoundError();
        const generated = (0, api_key_crypto_1.generateApiKey)(existing.environment);
        const row = await this.repo.update(ctx.companyId, id, {
            keyId: generated.keyId,
            keyPrefix: generated.keyPrefix,
            hashedSecret: generated.hashedSecret,
            previousHashedSecret: null,
            previousSecretExpiresAt: null,
        });
        if (!row)
            throw new errors_1.ApiKeyNotFoundError();
        await this.audit(ctx, id, "REGENERATED");
        return withSecret(row, generated.plaintext);
    }
    async rotateSecret(ctx, id) {
        (0, authorization_1.requireScope)(ctx, permissions_1.PERMISSIONS.API_KEYS_WRITE);
        const existing = await this.repo.findById(ctx.companyId, id);
        if (!existing)
            throw new errors_1.ApiKeyNotFoundError();
        const rotated = (0, api_key_crypto_1.rotateApiKeySecret)(existing.environment, existing.keyId);
        const graceEnds = new Date(Date.now() + api_key_crypto_1.API_KEY_ROTATION_GRACE_MS);
        const row = await this.repo.update(ctx.companyId, id, {
            keyPrefix: rotated.keyPrefix,
            hashedSecret: rotated.hashedSecret,
            previousHashedSecret: existing.hashedSecret,
            previousSecretExpiresAt: graceEnds,
        });
        if (!row)
            throw new errors_1.ApiKeyNotFoundError();
        await this.audit(ctx, id, "ROTATED", {
            previousSecretExpiresAt: graceEnds.toISOString(),
        });
        return withSecret(row, rotated.plaintext);
    }
    async updateScopes(ctx, id, scopes) {
        (0, authorization_1.requireScope)(ctx, permissions_1.PERMISSIONS.API_KEYS_WRITE);
        const existing = await this.repo.findById(ctx.companyId, id);
        if (!existing)
            throw new errors_1.ApiKeyNotFoundError();
        const validated = this.validateScopes(scopes);
        this.enforcePrincipalSubset(ctx, validated, existing.campaignAccessType, existing.campaignAccess.map((b) => b.campaignId));
        const row = await this.repo.update(ctx.companyId, id, {
            scopes: validated,
        });
        if (!row)
            throw new errors_1.ApiKeyNotFoundError();
        await this.audit(ctx, id, "SCOPES_UPDATED", { scopes: validated });
        return mapApiKey(row);
    }
    async updateCampaignAccess(ctx, id, input) {
        (0, authorization_1.requireScope)(ctx, permissions_1.PERMISSIONS.API_KEYS_WRITE);
        const existing = await this.repo.findById(ctx.companyId, id);
        if (!existing)
            throw new errors_1.ApiKeyNotFoundError();
        const campaignIds = await this.validateCampaigns(ctx.companyId, input.campaignAccessType, input.campaignIds ?? []);
        this.enforcePrincipalSubset(ctx, existing.scopes, input.campaignAccessType, campaignIds);
        const row = await this.repo.replaceBranchAccess(ctx.companyId, id, input.campaignAccessType, campaignIds);
        if (!row)
            throw new errors_1.ApiKeyNotFoundError();
        await this.audit(ctx, id, "CAMPAIGN_ACCESS_UPDATED", {
            campaignAccessType: input.campaignAccessType,
            campaignIds,
        });
        return mapApiKey(row);
    }
    async updateExpiration(ctx, id, expiresAt) {
        (0, authorization_1.requireScope)(ctx, permissions_1.PERMISSIONS.API_KEYS_WRITE);
        const existing = await this.repo.findById(ctx.companyId, id);
        if (!existing)
            throw new errors_1.ApiKeyNotFoundError();
        let value = null;
        if (expiresAt) {
            value = new Date(expiresAt);
            if (Number.isNaN(value.getTime())) {
                throw new errors_1.ValidationError("Invalid expiration date");
            }
            if (value <= new Date()) {
                throw new errors_1.ValidationError("Expiration must be in the future");
            }
        }
        const row = await this.repo.update(ctx.companyId, id, {
            expiresAt: value,
        });
        if (!row)
            throw new errors_1.ApiKeyNotFoundError();
        await this.audit(ctx, id, "EXPIRATION_UPDATED", {
            expiresAt: toIso(value),
        });
        return mapApiKey(row);
    }
}
exports.ApiKeysService = ApiKeysService;
exports.apiKeysService = new ApiKeysService();
//# sourceMappingURL=api-keys.service.js.map