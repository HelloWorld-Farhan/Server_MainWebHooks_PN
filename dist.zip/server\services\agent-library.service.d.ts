import type { TenantContext } from "../types/context";
export declare class AgentLibraryService {
    list(ctx: TenantContext): Promise<{
        id: string;
        slug: string;
        name: string;
        profile: string;
        category: string;
        useCases: string[];
        defaultType: import("@prisma/client").$Enums.AgentType;
        estimatedSetupMinutes: number;
        samplePrompt: string;
        defaultFirstMessage: string;
        defaultVariables: import("@prisma/client/runtime/library").JsonValue;
        compatibleVoices: import("@prisma/client/runtime/library").JsonValue;
        demoAudioUrl: string;
        avatarGradient: string | null;
        sortOrder: number;
    }[]>;
    getBySlug(ctx: TenantContext, slug: string): Promise<{
        id: string;
        slug: string;
        name: string;
        profile: string;
        category: string;
        useCases: string[];
        defaultType: import("@prisma/client").$Enums.AgentType;
        estimatedSetupMinutes: number;
        samplePrompt: string;
        defaultFirstMessage: string;
        defaultVariables: import("@prisma/client/runtime/library").JsonValue;
        compatibleVoices: import("@prisma/client/runtime/library").JsonValue;
        demoAudioUrl: string;
        avatarGradient: string | null;
        sortOrder: number;
    }>;
}
export declare const agentLibraryService: AgentLibraryService;
