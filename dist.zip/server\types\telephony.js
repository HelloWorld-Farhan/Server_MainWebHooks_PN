"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_PROVIDER_CREDENTIALS = exports.DEFAULT_CHANNEL_SETTINGS = void 0;
exports.DEFAULT_CHANNEL_SETTINGS = {
    maxConcurrentCalls: 20,
    callQueueLimit: 50,
    overflowHandling: "queue",
};
exports.DEFAULT_PROVIDER_CREDENTIALS = {
    twilio: { accountSid: "", authToken: "", defaultPhoneNumber: "" },
    exotel: { apiKey: "", apiSecret: "", exophoneNumber: "" },
    propnex: { region: "us-east-1", environment: "production" },
};
//# sourceMappingURL=telephony.js.map