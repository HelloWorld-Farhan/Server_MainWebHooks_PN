import type { Response } from "express";
import type { ApiErrorBody } from "./tenant-context";
import type { AppError } from "../../server/lib/errors";
export declare function sendAppErrorResponse(res: Response, err: AppError): Response<any, Record<string, any>>;
export declare function isMissingApiRouteMessage(message: string | string[] | undefined): boolean;
export declare function sendTenantError(res: Response, error: ApiErrorBody): Response<any, Record<string, any>>;
export declare function handleTenantResult<T extends {
    error: ApiErrorBody | null;
}>(res: Response, result: T): result is T & {
    error: null;
};
