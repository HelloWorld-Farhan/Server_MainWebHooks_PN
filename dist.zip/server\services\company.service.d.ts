import type { TenantContext } from "../types/context";
export declare class CompanyService {
    private readonly repo;
    getContact(ctx: TenantContext): Promise<{
        name: string;
        email: string;
        phone: string | null;
        title: string | null;
    } | null>;
    upsertContact(ctx: TenantContext, data: {
        name: string;
        email: string;
        phone?: string;
        title?: string;
    }): Promise<{
        name: string;
        email: string;
        phone: string | null;
        title: string | null;
    }>;
}
export declare const companyService: CompanyService;
