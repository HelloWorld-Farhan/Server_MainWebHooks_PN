"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.channelService = exports.ChannelService = void 0;
const channel_keys_1 = require("./channel-keys");
const channel_metrics_1 = require("./channel-metrics");
const redis_client_1 = require("../cache/redis.client");
const RESERVE_SCRIPT = `
local allocated = tonumber(redis.call('HGET', KEYS[1], 'allocated') or '0')
local active = tonumber(redis.call('HGET', KEYS[1], 'active') or '0')
if active < allocated then
  redis.call('HINCRBY', KEYS[1], 'active', 1)
  return 1
end
return 0
`;
const RELEASE_SCRIPT = `
local active = tonumber(redis.call('HGET', KEYS[1], 'active') or '0')
if active > 0 then
  redis.call('HINCRBY', KEYS[1], 'active', -1)
end
return tonumber(redis.call('HGET', KEYS[1], 'active') or '0')
`;
const ENQUEUE_SCRIPT = `
if redis.call('SADD', KEYS[1], ARGV[1]) == 1 then
  redis.call('RPUSH', KEYS[2], ARGV[1])
  return redis.call('LLEN', KEYS[2])
end
return -1
`;
const ENQUEUE_FRONT_SCRIPT = `
if redis.call('SADD', KEYS[1], ARGV[1]) == 1 then
  redis.call('LPUSH', KEYS[2], ARGV[1])
  return redis.call('LLEN', KEYS[2])
end
return -1
`;
const DEQUEUE_SCRIPT = `
local callLogId = redis.call('LPOP', KEYS[1])
if callLogId then
  redis.call('SREM', KEYS[2], callLogId)
end
return callLogId
`;
const DRAIN_COOLDOWN_SCRIPT = `
local members = redis.call('ZRANGEBYSCORE', KEYS[1], 0, ARGV[1])
for i, member in ipairs(members) do
  redis.call('ZREM', KEYS[1], member)
end
return members
`;
class ChannelService {
    inMemory = new Map();
    getRedis() {
        return (0, redis_client_1.isRedisAvailable)() ? redis_client_1.redis : null;
    }
    ensureInMemory(companyId) {
        let state = this.inMemory.get(companyId);
        if (!state) {
            state = {
                allocated: 0,
                active: 0,
                queue: [],
                dedup: new Set(),
                cooldown: new Map(),
            };
            this.inMemory.set(companyId, state);
        }
        return state;
    }
    async initializeCompany(companyId, allocated, active, queuedCallLogIds = []) {
        const client = this.getRedis();
        if (client) {
            const pipeline = client.pipeline();
            pipeline.del(channel_keys_1.channelKeys.queue(companyId), channel_keys_1.channelKeys.queueDedup(companyId), channel_keys_1.channelKeys.cooldown(companyId));
            pipeline.hset(channel_keys_1.channelKeys.channels(companyId), {
                allocated: String(allocated),
                active: String(active),
            });
            for (const callLogId of queuedCallLogIds) {
                pipeline.sadd(channel_keys_1.channelKeys.queueDedup(companyId), callLogId);
                pipeline.rpush(channel_keys_1.channelKeys.queue(companyId), callLogId);
            }
            await pipeline.exec();
            return;
        }
        const state = this.ensureInMemory(companyId);
        state.allocated = allocated;
        state.active = active;
        state.queue = [...queuedCallLogIds];
        state.dedup = new Set(queuedCallLogIds);
        state.cooldown.clear();
    }
    async tryReserve(companyId) {
        const client = this.getRedis();
        if (client) {
            const result = await client.eval(RESERVE_SCRIPT, 1, channel_keys_1.channelKeys.channels(companyId));
            const reserved = Number(result) === 1;
            if (reserved) {
                (0, channel_metrics_1.incrementChannelMetric)("channels_reserved_total");
                const metrics = await this.getMetrics(companyId);
                (0, channel_metrics_1.logChannelEvent)("channels:reserved", {
                    companyId,
                    active: metrics.active,
                    allocated: metrics.allocated,
                });
            }
            return reserved;
        }
        const state = this.ensureInMemory(companyId);
        if (state.active < state.allocated) {
            state.active += 1;
            (0, channel_metrics_1.incrementChannelMetric)("channels_reserved_total");
            (0, channel_metrics_1.logChannelEvent)("channels:reserved", {
                companyId,
                active: state.active,
                allocated: state.allocated,
            });
            return true;
        }
        return false;
    }
    async release(companyId) {
        const client = this.getRedis();
        if (client) {
            const active = Number(await client.eval(RELEASE_SCRIPT, 1, channel_keys_1.channelKeys.channels(companyId)));
            (0, channel_metrics_1.incrementChannelMetric)("channels_released_total");
            (0, channel_metrics_1.logChannelEvent)("channels:released", { companyId, active });
            return active;
        }
        const state = this.ensureInMemory(companyId);
        if (state.active > 0) {
            state.active -= 1;
        }
        (0, channel_metrics_1.incrementChannelMetric)("channels_released_total");
        (0, channel_metrics_1.logChannelEvent)("channels:released", {
            companyId,
            active: state.active,
        });
        return state.active;
    }
    async enqueue(companyId, callLogId) {
        const client = this.getRedis();
        if (client) {
            const result = Number(await client.eval(ENQUEUE_SCRIPT, 2, channel_keys_1.channelKeys.queueDedup(companyId), channel_keys_1.channelKeys.queue(companyId), callLogId));
            if (result >= 0) {
                (0, channel_metrics_1.incrementChannelMetric)("calls_queued_total");
                (0, channel_metrics_1.logChannelEvent)("channels:queued", {
                    companyId,
                    callLogId,
                    queueLength: result,
                });
            }
            return result;
        }
        const state = this.ensureInMemory(companyId);
        if (state.dedup.has(callLogId)) {
            return -1;
        }
        state.dedup.add(callLogId);
        state.queue.push(callLogId);
        (0, channel_metrics_1.incrementChannelMetric)("calls_queued_total");
        (0, channel_metrics_1.logChannelEvent)("channels:queued", {
            companyId,
            callLogId,
            queueLength: state.queue.length,
        });
        return state.queue.length;
    }
    async enqueueFront(companyId, callLogId) {
        const client = this.getRedis();
        if (client) {
            const result = Number(await client.eval(ENQUEUE_FRONT_SCRIPT, 2, channel_keys_1.channelKeys.queueDedup(companyId), channel_keys_1.channelKeys.queue(companyId), callLogId));
            return result;
        }
        const state = this.ensureInMemory(companyId);
        if (state.dedup.has(callLogId)) {
            return -1;
        }
        state.dedup.add(callLogId);
        state.queue.unshift(callLogId);
        return state.queue.length;
    }
    async dequeue(companyId) {
        const client = this.getRedis();
        if (client) {
            const result = await client.eval(DEQUEUE_SCRIPT, 2, channel_keys_1.channelKeys.queue(companyId), channel_keys_1.channelKeys.queueDedup(companyId));
            return result ? String(result) : null;
        }
        const state = this.ensureInMemory(companyId);
        const callLogId = state.queue.shift() ?? null;
        if (callLogId) {
            state.dedup.delete(callLogId);
        }
        return callLogId;
    }
    async startCooldown(companyId, callLogId, ms = (0, channel_keys_1.getChannelCooldownMs)()) {
        const releaseAt = Date.now() + ms;
        const client = this.getRedis();
        if (client) {
            await client.zadd(channel_keys_1.channelKeys.cooldown(companyId), releaseAt, callLogId);
        }
        else {
            this.ensureInMemory(companyId).cooldown.set(callLogId, releaseAt);
        }
        (0, channel_metrics_1.logChannelEvent)("channels:cooldown:started", {
            companyId,
            callLogId,
            releaseAt,
        });
    }
    async drainExpiredCooldowns() {
        const now = Date.now();
        const releases = [];
        const client = this.getRedis();
        if (client) {
            const keys = await client.keys("company:*:cooldown");
            for (const key of keys) {
                const companyId = key.split(":")[1];
                if (!companyId) {
                    continue;
                }
                const members = (await client.eval(DRAIN_COOLDOWN_SCRIPT, 1, key, String(now)));
                for (const callLogId of members) {
                    releases.push({ companyId, callLogId });
                    (0, channel_metrics_1.logChannelEvent)("channels:cooldown:completed", {
                        companyId,
                        callLogId,
                    });
                }
            }
            return releases;
        }
        for (const [companyId, state] of this.inMemory.entries()) {
            for (const [callLogId, releaseAt] of state.cooldown.entries()) {
                if (releaseAt <= now) {
                    state.cooldown.delete(callLogId);
                    releases.push({ companyId, callLogId });
                    (0, channel_metrics_1.logChannelEvent)("channels:cooldown:completed", {
                        companyId,
                        callLogId,
                    });
                }
            }
        }
        return releases;
    }
    async acquireDispatchLock(callLogId) {
        const client = this.getRedis();
        if (client) {
            const result = await client.set(channel_keys_1.channelKeys.dispatchLock(callLogId), "1", "EX", channel_keys_1.DISPATCH_LOCK_TTL_SECONDS, "NX");
            return result === "OK";
        }
        const state = this.ensureInMemory("__locks__");
        if (state.dedup.has(callLogId)) {
            return false;
        }
        state.dedup.add(callLogId);
        return true;
    }
    async releaseDispatchLock(callLogId) {
        const client = this.getRedis();
        if (client) {
            await client.del(channel_keys_1.channelKeys.dispatchLock(callLogId));
            return;
        }
        this.ensureInMemory("__locks__").dedup.delete(callLogId);
    }
    async getMetrics(companyId) {
        const client = this.getRedis();
        if (client) {
            const pipeline = client.pipeline();
            pipeline.hgetall(channel_keys_1.channelKeys.channels(companyId));
            pipeline.llen(channel_keys_1.channelKeys.queue(companyId));
            pipeline.zcard(channel_keys_1.channelKeys.cooldown(companyId));
            const results = await pipeline.exec();
            const hash = (results?.[0]?.[1] ?? {});
            const allocated = Number(hash.allocated ?? 0);
            const active = Number(hash.active ?? 0);
            const queueLength = Number(results?.[1]?.[1] ?? 0);
            const cooldownCount = Number(results?.[2]?.[1] ?? 0);
            return {
                allocated,
                active,
                available: Math.max(allocated - active, 0),
                queueLength,
                cooldownCount,
            };
        }
        const state = this.ensureInMemory(companyId);
        return {
            allocated: state.allocated,
            active: state.active,
            available: Math.max(state.allocated - state.active, 0),
            queueLength: state.queue.length,
            cooldownCount: state.cooldown.size,
        };
    }
    async listCompaniesWithPendingWork(companyIds) {
        const pending = [];
        for (const companyId of companyIds) {
            const metrics = await this.getMetrics(companyId);
            if (metrics.allocated > 0 &&
                metrics.available > 0 &&
                metrics.queueLength > 0) {
                pending.push(companyId);
            }
        }
        return pending;
    }
    resetInMemoryForTests() {
        this.inMemory.clear();
    }
}
exports.ChannelService = ChannelService;
exports.channelService = new ChannelService();
//# sourceMappingURL=channel.service.js.map