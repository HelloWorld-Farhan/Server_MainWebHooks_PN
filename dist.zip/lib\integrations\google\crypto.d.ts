export declare function encryptJson(value: unknown): string;
export declare function decryptJson<T>(payload: string): T;
export declare function encryptOAuthState(value: unknown): string;
export declare function decryptOAuthState<T>(payload: string): T;
