"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChannelReconciliationService = exports.STALE_QUEUED_AT_PROVIDER_MS = exports.STALE_DISPATCHING_MS = void 0;
const common_1 = require("@nestjs/common");
const redis_client_1 = require("../cache/redis.client");
const channel_keys_1 = require("./channel-keys");
const channel_queue_hooks_1 = require("./channel-queue.hooks");
const channel_service_1 = require("./channel.service");
const channel_metrics_1 = require("./channel-metrics");
const retry_scheduler_service_1 = require("../campaign-execution/retry/retry-scheduler.service");
const debug_1 = require("../graphql/debug");
const prisma_1 = __importDefault(require("../lib/prisma"));
const run_worker_task_1 = require("../lib/run-worker-task");
const call_logs_repository_1 = require("../repositories/call-logs.repository");
const ACTIVE_CHANNEL_STATUSES = [
    "DISPATCHING",
    "QUEUED_AT_PROVIDER",
    "RINGING",
    "ANSWERED",
];
exports.STALE_DISPATCHING_MS = 2 * 60 * 1000;
exports.STALE_QUEUED_AT_PROVIDER_MS = 2 * 60 * 1000;
let ChannelReconciliationService = class ChannelReconciliationService {
    callLogsRepo = new call_logs_repository_1.CallLogsRepository(prisma_1.default);
    interval = null;
    processing = false;
    onModuleInit() {
        if ((0, redis_client_1.isRedisDisabled)()) {
            return;
        }
        this.interval = setInterval(() => {
            (0, run_worker_task_1.runWorkerTask)("channel-reconcile", () => this.reconcileAll());
        }, (0, channel_keys_1.getChannelReconcilePollMs)());
    }
    onModuleDestroy() {
        if (this.interval) {
            clearInterval(this.interval);
            this.interval = null;
        }
    }
    async reconcileAll() {
        if (this.processing) {
            return;
        }
        this.processing = true;
        try {
            await this.runReconcile();
        }
        finally {
            this.processing = false;
        }
    }
    async runReconcile() {
        const companies = await prisma_1.default.company.findMany({
            where: {
                setupConfig: {
                    is: {
                        totalChannels: { gt: 0 },
                    },
                },
            },
            select: {
                id: true,
                setupConfig: {
                    select: { totalChannels: true },
                },
            },
        });
        const now = Date.now();
        const staleDispatchingBefore = new Date(now - exports.STALE_DISPATCHING_MS);
        const staleQueuedAtProviderBefore = new Date(now - (0, channel_keys_1.getStaleQueuedAtProviderMs)());
        for (const company of companies) {
            const allocated = company.setupConfig?.totalChannels ?? 0;
            const staleDispatching = await this.callLogsRepo.failStaleDispatching(company.id, staleDispatchingBefore);
            const staleQueuedAtProvider = await this.callLogsRepo.failStaleQueuedAtProvider(company.id, staleQueuedAtProviderBefore);
            const orphanQueued = await this.callLogsRepo.failOrphanQueuedCalls(company.id);
            if (staleDispatching.count > 0 ||
                staleQueuedAtProvider.count > 0 ||
                orphanQueued.count > 0) {
                (0, channel_metrics_1.logChannelEvent)("channels:reconcile:stale-cleanup", {
                    companyId: company.id,
                    failedDispatching: staleDispatching.count,
                    failedQueuedAtProvider: staleQueuedAtProvider.count,
                    failedOrphanQueued: orphanQueued.count,
                });
            }
            for (const failed of [
                ...staleDispatching.failed,
                ...staleQueuedAtProvider.failed,
            ]) {
                if (!failed.campaignId) {
                    continue;
                }
                await retry_scheduler_service_1.retrySchedulerService.handleTerminalCall({
                    companyId: company.id,
                    callLogId: failed.id,
                    campaignId: failed.campaignId,
                    phone: failed.phoneNumber?.number,
                    mappedStatus: "FAILED",
                    correlationId: failed.correlationId ?? undefined,
                });
            }
            const active = await this.callLogsRepo.countByStatuses(company.id, ACTIVE_CHANNEL_STATUSES);
            const queued = await this.callLogsRepo.findQueuedCallLogIds(company.id);
            await channel_service_1.channelService.initializeCompany(company.id, allocated, active, queued);
            const metrics = await channel_service_1.channelService.getMetrics(company.id);
            if (metrics.available > 0 && metrics.queueLength > 0) {
                (0, channel_queue_hooks_1.wakeCompanyQueue)(company.id);
            }
            (0, debug_1.gqlDebug)("channels:reconcile:company", {
                companyId: company.id,
                allocated,
                active,
                queuedCount: queued.length,
            });
        }
        (0, channel_metrics_1.logChannelEvent)("channels:reconcile:complete", {
            companyCount: companies.length,
        });
    }
};
exports.ChannelReconciliationService = ChannelReconciliationService;
exports.ChannelReconciliationService = ChannelReconciliationService = __decorate([
    (0, common_1.Injectable)()
], ChannelReconciliationService);
//# sourceMappingURL=channel-reconciliation.service.js.map