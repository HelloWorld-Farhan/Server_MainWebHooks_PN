export declare function creditsForDuration(durationSec: number, pulseSec: number, deltaSec: number): number;
