import type { Request, Response } from "express";
export declare class AgentsController {
    listTools(req: Request, res: Response, agentId: string): Promise<Response<any, Record<string, any>> | undefined>;
    updateTool(req: Request, res: Response, agentId: string, toolId: string): Promise<Response<any, Record<string, any>> | undefined>;
    healthCheck(req: Request, res: Response, agentId: string, toolId: string): Promise<Response<any, Record<string, any>> | undefined>;
}
export declare class ContactPhonesController {
    parseUpload(req: Request, res: Response, file?: Express.Multer.File): Promise<Response<any, Record<string, any>> | undefined>;
}
export declare class ToolsController {
    billingLookup(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    faqSearch(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    googleSheetsExecute(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    googleCalendarEvents(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    googleCalendarAvailability(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
}
