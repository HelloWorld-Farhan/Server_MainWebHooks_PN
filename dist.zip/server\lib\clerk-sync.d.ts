export declare function companySlugFromName(name: string): string;
export declare function localClerkOrganizationId(clerkUserId: string): string;
export declare function mapClerkRoleToUserRole(role: string): "OWNER" | "ADMIN" | "MANAGER" | "AGENT" | "SALES" | "SUPPORT";
export declare function mapUserRoleToClerkRole(role: string): string;
export declare function mapUserRoleToClerkInviteRole(role: string): string;
