type CompanyOrgFields = {
    id: string;
    name: string;
    clerkOrganizationId: string | null;
    ownerUserId: string | null;
};
export type ClerkInviteMetadata = {
    propnexRole: string;
    campaignAccessType: string;
    campaignIds: string[];
    jobTitle: string | null;
    inviteName?: string;
};
export declare function getActiveClerkOrganizationId(company: CompanyOrgFields, options?: {
    createdByClerkUserId?: string;
}): Promise<string>;
export declare function mapClerkInviteError(error: unknown): string;
export declare function ensureClerkOrganizationMember(params: {
    organizationId: string;
    userId: string;
    propnexRole: string;
}): Promise<void>;
export declare function sendClerkOrganizationInvitation(params: {
    organizationId: string;
    email: string;
    role: string;
    metadata: ClerkInviteMetadata;
    inviterUserId?: string;
    expiresInDays?: number;
    redirectUrl?: string;
}): Promise<{
    invitationId: string;
    expiresAt: Date;
}>;
export declare function revokeClerkOrganizationInvitation(params: {
    organizationId: string;
    invitationId: string;
    requestingUserId?: string;
}): Promise<void>;
export declare function revokeAllClerkPendingInvitationsForEmail(params: {
    organizationId: string;
    email: string;
    requestingUserId?: string;
}): Promise<void>;
export declare function removeClerkOrganizationMember(params: {
    organizationId: string;
    email: string;
    clerkUserId?: string | null;
}): Promise<void>;
export declare function removeClerkOrganizationAccess(params: {
    organizationId: string;
    email: string;
    clerkUserId?: string | null;
    requestingUserId?: string;
}): Promise<void>;
export declare function findClerkPendingInvitationId(params: {
    organizationId: string;
    email: string;
}): Promise<string | null>;
export declare const clerkOrgLib: {
    getActiveClerkOrganizationId: typeof getActiveClerkOrganizationId;
    sendClerkOrganizationInvitation: typeof sendClerkOrganizationInvitation;
    revokeClerkOrganizationInvitation: typeof revokeClerkOrganizationInvitation;
    removeClerkOrganizationAccess: typeof removeClerkOrganizationAccess;
};
export {};
