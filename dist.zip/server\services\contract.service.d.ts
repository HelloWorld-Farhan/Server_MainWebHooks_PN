export declare class ContractService {
    getContractLinkStatus(clerkUserId: string): Promise<{
        linked: true;
        contractId: string;
        claimedAt: string | null;
        clerkOrganizationId: string | null;
    } | {
        linked: false;
        contractId?: undefined;
        claimedAt?: undefined;
        clerkOrganizationId?: undefined;
    }>;
    linkContractId(clerkUserId: string, rawContractId: string): Promise<{
        linked: true;
        contractId: string;
        claimedAt: string;
        clerkOrganizationId: string | null;
    }>;
}
export declare const contractService: ContractService;
