"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ROLE_LABELS = exports.isApiKeyScope = exports.getApiKeyScopeLabels = exports.getPermissionLabels = exports.hasAllPermissions = exports.hasAnyPermission = exports.hasPermission = exports.mergePermissions = exports.API_KEY_SCOPE_CATALOG = exports.PERMISSIONS = void 0;
exports.getPermissionsForRole = getPermissionsForRole;
var permissions_1 = require("../../lib/permissions");
Object.defineProperty(exports, "PERMISSIONS", { enumerable: true, get: function () { return permissions_1.PERMISSIONS; } });
Object.defineProperty(exports, "API_KEY_SCOPE_CATALOG", { enumerable: true, get: function () { return permissions_1.API_KEY_SCOPE_CATALOG; } });
Object.defineProperty(exports, "mergePermissions", { enumerable: true, get: function () { return permissions_1.mergePermissions; } });
Object.defineProperty(exports, "hasPermission", { enumerable: true, get: function () { return permissions_1.hasPermission; } });
Object.defineProperty(exports, "hasAnyPermission", { enumerable: true, get: function () { return permissions_1.hasAnyPermission; } });
Object.defineProperty(exports, "hasAllPermissions", { enumerable: true, get: function () { return permissions_1.hasAllPermissions; } });
Object.defineProperty(exports, "getPermissionLabels", { enumerable: true, get: function () { return permissions_1.getPermissionLabels; } });
Object.defineProperty(exports, "getApiKeyScopeLabels", { enumerable: true, get: function () { return permissions_1.getApiKeyScopeLabels; } });
Object.defineProperty(exports, "isApiKeyScope", { enumerable: true, get: function () { return permissions_1.isApiKeyScope; } });
Object.defineProperty(exports, "ROLE_LABELS", { enumerable: true, get: function () { return permissions_1.ROLE_LABELS; } });
const permissions_2 = require("../../lib/permissions");
const MANAGER_PERMISSIONS = [
    permissions_2.PERMISSIONS.BILLING_READ,
    permissions_2.PERMISSIONS.CREDITS_READ,
    permissions_2.PERMISSIONS.CALL_LOGS_READ,
    permissions_2.PERMISSIONS.CALL_LOGS_WRITE,
    permissions_2.PERMISSIONS.AGENTS_READ,
    permissions_2.PERMISSIONS.AGENTS_WRITE,
    permissions_2.PERMISSIONS.LEADS_READ,
    permissions_2.PERMISSIONS.LEADS_WRITE,
    permissions_2.PERMISSIONS.ANALYTICS_READ,
    permissions_2.PERMISSIONS.ANALYTICS_WRITE,
    permissions_2.PERMISSIONS.INTEGRATIONS_READ,
    permissions_2.PERMISSIONS.NOTIFICATIONS_READ,
    permissions_2.PERMISSIONS.EVENTS_READ,
    permissions_2.PERMISSIONS.SCHEDULER_READ,
    permissions_2.PERMISSIONS.SCHEDULER_WRITE,
    permissions_2.PERMISSIONS.CAMPAIGNS_READ,
    permissions_2.PERMISSIONS.CAMPAIGNS_WRITE,
    permissions_2.PERMISSIONS.DOCUMENTS_READ,
    permissions_2.PERMISSIONS.DOCUMENTS_WRITE,
    permissions_2.PERMISSIONS.EMPLOYEES_READ,
];
const ROLE_PERMISSIONS = {
    OWNER: Object.values(permissions_2.PERMISSIONS),
    ADMIN: Object.values(permissions_2.PERMISSIONS).filter((p) => p !== permissions_2.PERMISSIONS.SETTINGS_WRITE && p !== permissions_2.PERMISSIONS.CAMPAIGNS_BULK),
    MANAGER: MANAGER_PERMISSIONS,
    SALES: [
        permissions_2.PERMISSIONS.CALL_LOGS_READ,
        permissions_2.PERMISSIONS.CALL_LOGS_WRITE,
        permissions_2.PERMISSIONS.LEADS_READ,
        permissions_2.PERMISSIONS.LEADS_WRITE,
        permissions_2.PERMISSIONS.CAMPAIGNS_READ,
        permissions_2.PERMISSIONS.NOTIFICATIONS_READ,
        permissions_2.PERMISSIONS.EVENTS_READ,
    ],
    SUPPORT: [
        permissions_2.PERMISSIONS.CALL_LOGS_READ,
        permissions_2.PERMISSIONS.LEADS_READ,
        permissions_2.PERMISSIONS.CAMPAIGNS_READ,
        permissions_2.PERMISSIONS.NOTIFICATIONS_READ,
        permissions_2.PERMISSIONS.EVENTS_READ,
    ],
    AGENT: [
        permissions_2.PERMISSIONS.CREDITS_READ,
        permissions_2.PERMISSIONS.CALL_LOGS_READ,
        permissions_2.PERMISSIONS.AGENTS_READ,
        permissions_2.PERMISSIONS.LEADS_READ,
        permissions_2.PERMISSIONS.LEADS_WRITE,
        permissions_2.PERMISSIONS.NOTIFICATIONS_READ,
        permissions_2.PERMISSIONS.EVENTS_READ,
        permissions_2.PERMISSIONS.SCHEDULER_READ,
        permissions_2.PERMISSIONS.CAMPAIGNS_READ,
    ],
};
function getPermissionsForRole(role) {
    return ROLE_PERMISSIONS[role] ?? [];
}
//# sourceMappingURL=permissions.js.map