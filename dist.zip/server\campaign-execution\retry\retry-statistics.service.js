"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.retryStatisticsService = exports.RetryStatisticsService = void 0;
const campaign_execution_repository_1 = require("../campaign-execution.repository");
const prisma_1 = __importDefault(require("../../lib/prisma"));
const retry_job_repository_1 = require("./retry-job.repository");
const retry_policy_service_1 = require("./retry-policy.service");
const NO_ANSWER_STATUSES = ["NO_ANSWER", "MISSED", "VOICEMAIL"];
class RetryStatisticsService {
    async getPolicy(companyId, campaignId) {
        const execution = await campaign_execution_repository_1.campaignExecutionRepository.findByCampaignId(companyId, campaignId);
        if (!execution) {
            return null;
        }
        return retry_policy_service_1.retryPolicyService.extractPolicy(execution);
    }
    async getStatistics(companyId, campaignId) {
        const [initialCalls, retryCalls, grouped, pendingRetries] = await Promise.all([
            prisma_1.default.callLog.count({
                where: { companyId, campaignId, isRetry: false },
            }),
            prisma_1.default.callLog.count({
                where: { companyId, campaignId, isRetry: true },
            }),
            prisma_1.default.callLog.groupBy({
                by: ["status"],
                where: { companyId, campaignId },
                _count: { _all: true },
            }),
            retry_job_repository_1.retryJobRepository.countByStatus(companyId, campaignId, "PENDING"),
        ]);
        const totalCalls = initialCalls + retryCalls;
        let busy = 0;
        let noAnswer = 0;
        let failed = 0;
        let answered = 0;
        let completed = 0;
        for (const row of grouped) {
            const count = row._count._all;
            if (row.status === "BUSY") {
                busy += count;
            }
            else if (NO_ANSWER_STATUSES.includes(row.status)) {
                noAnswer += count;
            }
            else if (row.status === "FAILED" || row.status === "CANCELLED") {
                failed += count;
            }
            else if (row.status === "ANSWERED") {
                answered += count;
            }
            else if (row.status === "COMPLETED") {
                completed += count;
            }
        }
        const retrySuccessCount = await prisma_1.default.callLog.count({
            where: {
                companyId,
                campaignId,
                isRetry: true,
                status: { in: ["ANSWERED", "COMPLETED"] },
            },
        });
        const retrySuccessRate = retryCalls > 0 ? retrySuccessCount / retryCalls : 0;
        const contactsWithRetries = await prisma_1.default.callLog.groupBy({
            by: ["phoneNumberId"],
            where: { companyId, campaignId, isRetry: true, phoneNumberId: { not: null } },
            _count: { _all: true },
        });
        const averageRetryCount = contactsWithRetries.length > 0
            ? contactsWithRetries.reduce((sum, row) => sum + row._count._all, 0) /
                contactsWithRetries.length
            : 0;
        return {
            totalCalls,
            initialCalls,
            retryCalls,
            retrySuccessRate,
            averageRetryCount,
            busy,
            noAnswer,
            failed,
            answered,
            completed,
            pendingRetries,
        };
    }
    async getHistory(companyId, campaignId, phoneNumber) {
        const jobs = await retry_job_repository_1.retryJobRepository.findHistoryForCampaign(companyId, campaignId, phoneNumber);
        const entries = [];
        for (const job of jobs) {
            let callLogPublicId = null;
            let callStatus = "SCHEDULED";
            if (job.createdCallLogId) {
                const callLog = await prisma_1.default.callLog.findFirst({
                    where: { id: job.createdCallLogId, companyId },
                    select: { publicId: true, status: true },
                });
                callLogPublicId = callLog?.publicId ?? null;
                callStatus = callLog?.status ?? "UNKNOWN";
            }
            entries.push({
                retryNumber: job.retryNumber,
                createdAt: job.createdAt.toISOString(),
                reason: job.retryReason,
                callLogId: callLogPublicId,
                status: callStatus,
                jobStatus: job.status,
            });
        }
        return entries;
    }
    async getPendingRetries(companyId, campaignId) {
        const jobs = await retry_job_repository_1.retryJobRepository.findPendingForCampaign(companyId, campaignId);
        return jobs.map((job) => ({
            id: job.id,
            phoneNumber: job.phoneNumber,
            retryNumber: job.retryNumber,
            retryReason: job.retryReason,
            scheduledAt: job.scheduledAt.toISOString(),
            status: job.status,
            correlationId: job.correlationId,
        }));
    }
    async getSummary(companyId, campaignId) {
        const execution = await campaign_execution_repository_1.campaignExecutionRepository.findByCampaignId(companyId, campaignId);
        if (!execution) {
            return null;
        }
        const [statistics, pending] = await Promise.all([
            this.getStatistics(companyId, campaignId),
            this.getPendingRetries(companyId, campaignId),
        ]);
        return {
            policy: retry_policy_service_1.retryPolicyService.extractPolicy(execution),
            statistics,
            pendingRetries: pending.length,
            totalRetries: execution.totalRetries,
            completedRetries: execution.completedRetries,
            failedRetries: execution.failedRetries,
        };
    }
}
exports.RetryStatisticsService = RetryStatisticsService;
exports.retryStatisticsService = new RetryStatisticsService();
//# sourceMappingURL=retry-statistics.service.js.map