import type { Prisma, PrismaClient, SupportRequestReason } from "@prisma/client";
export type CreateSupportRequestInput = {
    name: string;
    email: string;
    reason: SupportRequestReason;
    planId: string | null;
    planName: string | null;
    message: string;
    userId?: string | null;
    companyId?: string | null;
    clerkUserId?: string | null;
};
export declare class SupportRequestRepository {
    private readonly prisma;
    constructor(prisma: PrismaClient);
    create(data: CreateSupportRequestInput): Prisma.Prisma__SupportRequestClient<{
        userId: string | null;
        status: import("@prisma/client").$Enums.SupportRequestStatus;
        reason: import("@prisma/client").$Enums.SupportRequestReason;
        message: string;
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string | null;
        email: string;
        planId: string | null;
        planName: string | null;
        clerkUserId: string | null;
    }, never, import("@prisma/client/runtime/library").DefaultArgs, Prisma.PrismaClientOptions>;
    findById(id: string): Prisma.Prisma__SupportRequestClient<{
        userId: string | null;
        status: import("@prisma/client").$Enums.SupportRequestStatus;
        reason: import("@prisma/client").$Enums.SupportRequestReason;
        message: string;
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string | null;
        email: string;
        planId: string | null;
        planName: string | null;
        clerkUserId: string | null;
    } | null, null, import("@prisma/client/runtime/library").DefaultArgs, Prisma.PrismaClientOptions>;
}
export type SupportRequestRecord = Prisma.SupportRequestGetPayload<{
    include: {
        company: {
            select: {
                name: true;
            };
        };
    };
}>;
