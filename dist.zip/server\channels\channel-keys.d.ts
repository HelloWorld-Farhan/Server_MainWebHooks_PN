export declare function getChannelCooldownMs(): number;
export declare function getChannelQueuePollMs(): number;
export declare function getChannelReconcilePollMs(): number;
export declare function getStaleQueuedAtProviderMs(): number;
export declare const CHANNEL_COOLDOWN_MS: number;
export declare const CHANNEL_QUEUE_POLL_MS: number;
export declare const DISPATCH_LOCK_TTL_SECONDS = 60;
export declare const channelKeys: {
    channels: (companyId: string) => string;
    queue: (companyId: string) => string;
    queueDedup: (companyId: string) => string;
    cooldown: (companyId: string) => string;
    dispatchLock: (callLogId: string) => string;
    companyPrefix: (companyId: string) => string;
};
