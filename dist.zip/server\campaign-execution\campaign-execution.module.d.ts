export declare class CampaignExecutionModule {
}
