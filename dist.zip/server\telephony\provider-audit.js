"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.appendProviderRequest = appendProviderRequest;
exports.appendProviderResponse = appendProviderResponse;
exports.appendProviderWebhook = appendProviderWebhook;
function toArray(value) {
    if (!value || !Array.isArray(value)) {
        return [];
    }
    return value;
}
function appendProviderRequest(existing, entry) {
    return [
        ...toArray(existing),
        entry,
    ];
}
function appendProviderResponse(existing, entry) {
    return [
        ...toArray(existing),
        entry,
    ];
}
function appendProviderWebhook(existing, entry) {
    return [
        ...toArray(existing),
        entry,
    ];
}
//# sourceMappingURL=provider-audit.js.map