"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ToolsController = exports.ContactPhonesController = exports.AgentsController = void 0;
const common_1 = require("@nestjs/common");
const billing_data_1 = require("../../lib/billing-data");
const api_guard_1 = require("../../lib/integrations/api-guard");
const db_state_1 = require("../../lib/integrations/db-state");
const platform_express_1 = require("@nestjs/platform-express");
const auth_1 = require("../../lib/api/auth");
const http_1 = require("../../lib/api/http");
const tenant_context_1 = require("../../lib/api/tenant-context");
const contact_phone_file_parser_1 = require("../../lib/contact-phone-file-parser");
const country_dial_codes_1 = require("../../lib/country-dial-codes");
const contact_phone_import_1 = require("../../lib/contact-phone-import");
const db_state_2 = require("../../lib/integrations/db-state");
const MAX_FILE_SIZE_BYTES = 50 * 1024 * 1024;
const SERVER_EXTENSION_SET = new Set(contact_phone_file_parser_1.SERVER_PARSE_EXTENSIONS);
let AgentsController = class AgentsController {
    async listTools(req, res, agentId) {
        const result = await (0, tenant_context_1.requireTenantContext)(req);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        const tools = await (0, db_state_2.getAgentToolsDb)(result.ctx, agentId);
        return res.json({ tools });
    }
    async updateTool(req, res, agentId, toolId) {
        const result = await (0, tenant_context_1.requireTenantContext)(req);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        const body = req.body;
        const tool = await (0, db_state_2.updateAgentToolDb)(result.ctx, agentId, toolId, body);
        return res.json({ tool });
    }
    async healthCheck(req, res, agentId, toolId) {
        const result = await (0, tenant_context_1.requireTenantContext)(req);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        await (0, auth_1.delay)(800);
        const tool = await (0, db_state_2.updateAgentToolDb)(result.ctx, agentId, toolId, {
            health: "healthy",
            usage: {
                totalExecutions: 1,
                successRate: 1,
                lastUsedAt: new Date().toISOString(),
                errorCount: 0,
            },
        });
        return res.json({ tool, testResult: "passed" });
    }
};
exports.AgentsController = AgentsController;
__decorate([
    (0, common_1.Get)(":agentId/tools"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __param(2, (0, common_1.Param)("agentId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, String]),
    __metadata("design:returntype", Promise)
], AgentsController.prototype, "listTools", null);
__decorate([
    (0, common_1.Put)(":agentId/tools/:toolId"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __param(2, (0, common_1.Param)("agentId")),
    __param(3, (0, common_1.Param)("toolId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, String, String]),
    __metadata("design:returntype", Promise)
], AgentsController.prototype, "updateTool", null);
__decorate([
    (0, common_1.Post)(":agentId/tools/:toolId"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __param(2, (0, common_1.Param)("agentId")),
    __param(3, (0, common_1.Param)("toolId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, String, String]),
    __metadata("design:returntype", Promise)
], AgentsController.prototype, "healthCheck", null);
exports.AgentsController = AgentsController = __decorate([
    (0, common_1.Controller)("api/agents")
], AgentsController);
let ContactPhonesController = class ContactPhonesController {
    async parseUpload(req, res, file) {
        const result = await (0, api_guard_1.requireAgentsWrite)(req);
        if (!(0, http_1.handleTenantResult)(res, result))
            return;
        if (!file) {
            return res.status(400).json({ error: "A file is required." });
        }
        const extension = (0, contact_phone_import_1.getContactPhoneUploadExtension)(file.originalname);
        if (!extension || !SERVER_EXTENSION_SET.has(extension)) {
            return res.status(400).json({
                error: "Unsupported file type. Upload Excel (.xlsx/.xls), PDF, or Word (.docx).",
            });
        }
        if (file.size > MAX_FILE_SIZE_BYTES) {
            return res.status(400).json({ error: "File exceeds the 50 MB limit." });
        }
        const defaultCountryRaw = req.body?.defaultCountry;
        const defaultCountry = typeof defaultCountryRaw === "string" && defaultCountryRaw.trim()
            ? defaultCountryRaw.trim()
            : country_dial_codes_1.DEFAULT_CONTACT_PHONE_COUNTRY;
        try {
            const parseResult = await (0, contact_phone_file_parser_1.parseContactPhoneUpload)(file.buffer, file.originalname, { defaultCountry });
            if (parseResult.contacts.length === 0) {
                return res.status(400).json({
                    error: parseResult.invalid > 0
                        ? "No valid phone numbers found. Use country (ISO code) and a 10-digit phone column, or a supported default country for unstructured files."
                        : "No phone numbers found in the uploaded file.",
                });
            }
            return res.json(parseResult);
        }
        catch (err) {
            const message = err instanceof Error ? err.message : "Unable to parse the uploaded file.";
            return res.status(400).json({ error: message });
        }
    }
};
exports.ContactPhonesController = ContactPhonesController;
__decorate([
    (0, common_1.Post)("parse-upload"),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)("file")),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __param(2, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, Object]),
    __metadata("design:returntype", Promise)
], ContactPhonesController.prototype, "parseUpload", null);
exports.ContactPhonesController = ContactPhonesController = __decorate([
    (0, common_1.Controller)("api/contact-phones")
], ContactPhonesController);
let ToolsController = class ToolsController {
    async billingLookup(req, res) {
        const authResult = await (0, auth_1.requireAuth)(req);
        if (authResult.error) {
            return res.status(authResult.error.status).json(authResult.error.body);
        }
        const body = req.body;
        const permissions = body.permissions ?? {
            creditAccess: true,
            planAccess: true,
            invoiceAccess: true,
        };
        const result = {};
        if (permissions.creditAccess) {
            result.credits = {
                remaining: billing_data_1.billingSummary.remainingCredits,
                total: billing_data_1.billingSummary.totalCredits,
                used: billing_data_1.billingSummary.usedCredits,
            };
        }
        if (permissions.planAccess) {
            result.plan = {
                name: billing_data_1.billingSummary.activePlan,
                resetDate: billing_data_1.billingSummary.resetDate,
            };
        }
        if (permissions.invoiceAccess) {
            result.invoice = {
                nextAmount: billing_data_1.billingSummary.nextInvoiceAmount,
                dueDate: billing_data_1.billingSummary.nextInvoiceDue,
                status: "paid",
            };
        }
        return res.json(result);
    }
    async faqSearch(req, res) {
        const authResult = await (0, auth_1.requireAuth)(req);
        if (authResult.error) {
            return res.status(authResult.error.status).json(authResult.error.body);
        }
        const FAQ_ANSWERS = {
            pricing: "PropNex AI offers flexible plans starting from pay-as-you-go credits. Enterprise plans include custom integrations and dedicated support.",
            company: "PropNex AI is a voice AI platform for real estate and sales teams, enabling automated phone conversations with AI agents.",
            product: "Our platform includes inbound/outbound AI agents, call analytics, lead qualification, and integrations with CRM and calendar tools.",
            default: "I found some relevant information in our knowledge base. Would you like me to elaborate on a specific topic?",
        };
        const body = req.body;
        const query = (body.query ?? "").toLowerCase();
        let answer = FAQ_ANSWERS.default;
        let confidence = 0.65;
        if (query.includes("price") || query.includes("cost") || query.includes("plan")) {
            answer = FAQ_ANSWERS.pricing;
            confidence = 0.92;
        }
        else if (query.includes("company") ||
            query.includes("about") ||
            query.includes("propnex")) {
            answer = FAQ_ANSWERS.company;
            confidence = 0.88;
        }
        else if (query.includes("product") || query.includes("feature")) {
            answer = FAQ_ANSWERS.product;
            confidence = 0.85;
        }
        return res.json({ answer, confidence, sources: ["Product FAQ"] });
    }
    async googleSheetsExecute(req, res) {
        const result = await (0, api_guard_1.requireAgentsWrite)(req);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        const body = req.body;
        try {
            if (body.action === "read") {
                if (body.rowIndex === undefined) {
                    return res.status(400).json({ error: "rowIndex required" });
                }
                const row = await (0, db_state_1.readSheetRowDb)(result.ctx, body.rowIndex);
                return res.json({ row });
            }
            if (body.action === "append" && body.data) {
                const row = await (0, db_state_1.appendSheetRowDb)(result.ctx, body.data);
                return res.json({ row });
            }
            if ((body.action === "write" || body.action === "update") &&
                body.data &&
                body.rowIndex !== undefined) {
                const row = await (0, db_state_1.writeSheetRowDb)(result.ctx, body.rowIndex, body.data);
                return res.json({ row });
            }
            return res.status(400).json({ error: "Invalid action" });
        }
        catch (e) {
            return res.status(500).json({
                error: e instanceof Error ? e.message : "Execute failed",
            });
        }
    }
    async googleCalendarEvents(req, res) {
        const result = await (0, api_guard_1.requireAgentsWrite)(req);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        const body = req.body;
        switch (body.action) {
            case "list":
                return res.json({ events: await (0, db_state_1.getCalendarEventsDb)(result.ctx) });
            case "create": {
                const event = await (0, db_state_1.addCalendarEventDb)(result.ctx, {
                    title: body.title ?? "Appointment",
                    start: body.start ?? new Date().toISOString(),
                    end: body.end ??
                        new Date(Date.now() + 30 * 60 * 1000).toISOString(),
                    attendeeEmail: body.attendeeEmail,
                });
                return res.json({ event });
            }
            case "reschedule": {
                if (!body.eventId) {
                    return res.status(400).json({ error: "eventId required" });
                }
                const event = await (0, db_state_1.updateCalendarEventDb)(result.ctx, body.eventId, {
                    start: body.start,
                    end: body.end,
                });
                if (!event) {
                    return res.status(404).json({ error: "Event not found" });
                }
                return res.json({ event });
            }
            case "cancel": {
                if (!body.eventId) {
                    return res.status(400).json({ error: "eventId required" });
                }
                const deleted = await (0, db_state_1.deleteCalendarEventDb)(result.ctx, body.eventId);
                if (!deleted) {
                    return res.status(404).json({ error: "Event not found" });
                }
                return res.json({ success: true });
            }
            default:
                return res.status(400).json({ error: "Invalid action" });
        }
    }
    async googleCalendarAvailability(req, res) {
        const result = await (0, api_guard_1.requireAgentsWrite)(req);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        const config = await (0, db_state_1.getCalendarConfigDb)(result.ctx);
        return res.json({
            available: true,
            timezone: config.timezone,
            workingHours: config.workingHours,
            meetingDurationMinutes: config.meetingDurationMinutes,
            bufferMinutes: config.bufferMinutes,
        });
    }
};
exports.ToolsController = ToolsController;
__decorate([
    (0, common_1.Post)("billing/lookup"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], ToolsController.prototype, "billingLookup", null);
__decorate([
    (0, common_1.Post)("faq/search"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], ToolsController.prototype, "faqSearch", null);
__decorate([
    (0, common_1.Post)("google-sheets/execute"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], ToolsController.prototype, "googleSheetsExecute", null);
__decorate([
    (0, common_1.Post)("google-calendar/events"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], ToolsController.prototype, "googleCalendarEvents", null);
__decorate([
    (0, common_1.Post)("google-calendar/availability"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], ToolsController.prototype, "googleCalendarAvailability", null);
exports.ToolsController = ToolsController = __decorate([
    (0, common_1.Controller)("api/tools")
], ToolsController);
//# sourceMappingURL=api.controllers.js.map