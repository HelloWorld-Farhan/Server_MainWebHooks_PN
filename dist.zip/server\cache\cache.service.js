"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cacheService = exports.CacheService = void 0;
const redis_client_1 = require("./redis.client");
const keys_1 = require("./keys");
const debug_1 = require("../graphql/debug");
const resolution_metrics_1 = require("../lib/resolution-metrics");
class CacheService {
    async get(key) {
        if (!redis_client_1.redis)
            return null;
        const client = redis_client_1.redis;
        try {
            const cached = await (0, debug_1.gqlDebugTimed)(`redis:get:${key}`, () => client.get(key));
            if (!cached)
                return null;
            return JSON.parse(cached);
        }
        catch {
            (0, debug_1.gqlDebug)("redis:get:error", { key });
            return null;
        }
    }
    async set(key, value, ttlSeconds) {
        if (!redis_client_1.redis)
            return;
        const client = redis_client_1.redis;
        try {
            await (0, debug_1.gqlDebugTimed)(`redis:set:${key}`, () => client.setex(key, ttlSeconds, JSON.stringify(value)));
        }
        catch {
            (0, debug_1.gqlDebug)("redis:set:error", { key });
        }
    }
    async del(...keys) {
        if (!redis_client_1.redis || keys.length === 0)
            return;
        try {
            await redis_client_1.redis.del(...keys);
        }
        catch {
        }
    }
    async getOrSet(key, ttlSeconds, factory) {
        const cached = await this.get(key);
        if (cached !== null) {
            return cached;
        }
        const value = await (0, debug_1.gqlDebugTimed)(`db:factory:${key}`, factory);
        await this.set(key, value, ttlSeconds);
        return value;
    }
    async getCachedPayload(key) {
        if (!redis_client_1.redis)
            return null;
        try {
            const cached = await redis_client_1.redis.get(key);
            if (!cached)
                return null;
            return JSON.parse(cached);
        }
        catch {
            (0, debug_1.gqlDebug)("redis:get-payload:error", { key });
            return null;
        }
    }
    async setCachedPayload(key, data, ttlSeconds) {
        const payload = { cachedAt: Date.now(), data };
        await this.set(key, payload, ttlSeconds);
    }
    async getWithStaleFallback(key) {
        const payload = await this.getCachedPayload(key);
        return payload?.data ?? null;
    }
    async getResolvedCompany(clerkUserId) {
        return this.get(keys_1.cacheKeys.resolvedCompany(clerkUserId));
    }
    async setResolvedCompany(clerkUserId, value, ttlSeconds) {
        await this.set(keys_1.cacheKeys.resolvedCompany(clerkUserId), { ...value, cachedAt: Date.now() }, ttlSeconds);
    }
    async invalidateClerkMembershipCaches(clerkUserId, orgId) {
        const keys = [keys_1.cacheKeys.clerkMemberships(clerkUserId), keys_1.cacheKeys.resolvedCompany(clerkUserId)];
        if (orgId) {
            keys.push(keys_1.cacheKeys.clerkOrgMemberships(orgId));
        }
        await this.del(...keys);
        (0, resolution_metrics_1.incrementMetric)("cache_invalidations");
        (0, debug_1.gqlDebug)("redis:invalidate-clerk-memberships", { clerkUserId, orgId });
    }
    async invalidateCompanyCredits(companyId) {
        await this.del(keys_1.cacheKeys.companyCredits(companyId));
    }
    async invalidateCompanyCallLogs(companyId) {
        await this.del(keys_1.cacheKeys.companyTopCallLogs(companyId));
    }
    async invalidateCompanyAnalytics(companyId) {
        if (!redis_client_1.redis)
            return;
        const prefix = keys_1.cacheKeys.companyAnalytics(companyId);
        try {
            let cursor = "0";
            do {
                const [nextCursor, keys] = await redis_client_1.redis.scan(cursor, "MATCH", `${prefix}*`, "COUNT", 100);
                cursor = nextCursor;
                if (keys.length > 0) {
                    await redis_client_1.redis.del(...keys);
                }
            } while (cursor !== "0");
        }
        catch {
            (0, debug_1.gqlDebug)("redis:invalidate-company-analytics:error", { prefix });
        }
    }
    async invalidateCompanyAgentStatus(companyId) {
        await this.del(keys_1.cacheKeys.companyAgentStatus(companyId));
    }
    async invalidateUserPermissions(userId) {
        await this.del(keys_1.cacheKeys.userPermissions(userId));
    }
    async invalidateCallRelated(companyId) {
        await this.del(keys_1.cacheKeys.companyTopCallLogs(companyId), keys_1.cacheKeys.companyAnalytics(companyId), keys_1.cacheKeys.companyCredits(companyId));
        await this.invalidatePagePrefix(companyId, "home");
        await this.invalidatePagePrefix(companyId, "call-logs");
        await this.invalidatePagePrefix(companyId, "call-detail");
        await this.invalidatePagePrefix(companyId, "phone-detail");
        await this.invalidatePagePrefix(companyId, "agent-detail");
        await this.invalidatePagePrefix(companyId, "lead-reactivation");
    }
    async invalidatePage(companyId, pageKey) {
        await this.del(keys_1.cacheKeys.page(companyId, pageKey));
    }
    async invalidatePagePrefix(companyId, pageKey) {
        if (!redis_client_1.redis)
            return;
        const prefix = keys_1.cacheKeys.pagePrefix(companyId, pageKey);
        try {
            let cursor = "0";
            do {
                const [nextCursor, keys] = await redis_client_1.redis.scan(cursor, "MATCH", `${prefix}*`, "COUNT", 100);
                cursor = nextCursor;
                if (keys.length > 0) {
                    await redis_client_1.redis.del(...keys);
                }
            } while (cursor !== "0");
        }
        catch {
            (0, debug_1.gqlDebug)("redis:invalidate-page-prefix:error", { prefix });
        }
    }
    async invalidateAgentPages(companyId) {
        await this.invalidateCompanyAgentStatus(companyId);
        await this.invalidatePage(companyId, "home");
        await this.invalidatePage(companyId, "agents");
        await this.invalidatePagePrefix(companyId, "agent-detail");
        await this.invalidatePage(companyId, "setup");
    }
    async invalidatePhoneNumberPages(companyId) {
        await this.invalidatePage(companyId, "setup");
        await this.invalidatePagePrefix(companyId, "phone-detail");
        await this.invalidatePagePrefix(companyId, "agent-detail");
    }
    async invalidateLeadPages(companyId) {
        await this.invalidatePage(companyId, "home");
        await this.invalidatePagePrefix(companyId, "lead-reactivation");
        await this.invalidatePagePrefix(companyId, "call-logs");
    }
    async invalidateUploadedContactPages(companyId) {
        await this.invalidatePagePrefix(companyId, "phone-contacts");
    }
    async invalidateBillingPages(companyId) {
        await this.invalidateCompanyCredits(companyId);
        await this.invalidatePagePrefix(companyId, "billing");
        await this.invalidatePage(companyId, "home");
    }
    async invalidateSettingsPages(companyId) {
        await this.invalidatePage(companyId, "settings");
        await this.invalidatePage(companyId, "setup");
    }
}
exports.CacheService = CacheService;
exports.cacheService = new CacheService();
//# sourceMappingURL=cache.service.js.map