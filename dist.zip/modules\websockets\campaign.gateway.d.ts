import { OnGatewayConnection, OnGatewayDisconnect } from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
export declare class CampaignGateway implements OnGatewayConnection, OnGatewayDisconnect {
    server: Server;
    private static instance;
    constructor();
    static getInstance(): CampaignGateway;
    handleConnection(client: Socket): void;
    handleDisconnect(client: Socket): void;
    broadcastCampaignUpdate(companyId: string, campaignState: any): void;
}
