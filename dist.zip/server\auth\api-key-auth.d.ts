import type { Request as ExpressRequest } from "express";
import type { TenantContext } from "../types/context";
export declare function getApiKeyTokenFromRequest(req?: ExpressRequest, fetchRequest?: Request): string | null;
export declare function authenticateApiKey(plaintext: string): Promise<TenantContext>;
export declare function tryAuthenticateApiKeyFromRequest(req?: ExpressRequest, fetchRequest?: Request): Promise<TenantContext | null>;
