"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pageCacheService = exports.PageCacheService = void 0;
const redis_client_1 = require("./redis.client");
const keys_1 = require("./keys");
const debug_1 = require("../graphql/debug");
class PageCacheService {
    async getPageData(cacheKey, loader, options) {
        const staleAfterMs = options?.staleAfterMs ?? keys_1.PAGE_CACHE_STALE_MS;
        const ttlSeconds = options?.ttlSeconds ?? keys_1.CACHE_TTL.PAGE_CACHE;
        if (redis_client_1.redis) {
            try {
                const cached = await (0, debug_1.gqlDebugTimed)(`redis:page:get:${cacheKey}`, () => redis_client_1.redis.get(cacheKey));
                if (cached) {
                    const payload = JSON.parse(cached);
                    const ageMs = Date.now() - payload.cachedAt;
                    if (ageMs < staleAfterMs) {
                        (0, debug_1.gqlDebug)("redis:page:hit", { cacheKey, ageMs });
                        return {
                            data: payload.data,
                            cachedAt: payload.cachedAt,
                            fromCache: true,
                        };
                    }
                    (0, debug_1.gqlDebug)("redis:page:stale", { cacheKey, ageMs });
                }
            }
            catch {
                (0, debug_1.gqlDebug)("redis:page:get:error", { cacheKey });
            }
        }
        const data = await (0, debug_1.gqlDebugTimed)(`page:loader:${cacheKey}`, loader);
        const cachedAt = Date.now();
        const payload = { cachedAt, data };
        if (redis_client_1.redis) {
            try {
                await (0, debug_1.gqlDebugTimed)(`redis:page:set:${cacheKey}`, () => redis_client_1.redis.setex(cacheKey, ttlSeconds, JSON.stringify(payload)));
            }
            catch {
                (0, debug_1.gqlDebug)("redis:page:set:error", { cacheKey });
            }
        }
        return { data, cachedAt, fromCache: false };
    }
    async invalidateKey(cacheKey) {
        if (!redis_client_1.redis)
            return;
        try {
            await redis_client_1.redis.del(cacheKey);
        }
        catch {
            (0, debug_1.gqlDebug)("redis:page:invalidate:error", { cacheKey });
        }
    }
    async invalidatePrefix(prefix) {
        if (!redis_client_1.redis)
            return;
        try {
            const pattern = `${prefix}*`;
            let cursor = "0";
            do {
                const [nextCursor, keys] = await redis_client_1.redis.scan(cursor, "MATCH", pattern, "COUNT", 100);
                cursor = nextCursor;
                if (keys.length > 0) {
                    await redis_client_1.redis.del(...keys);
                }
            } while (cursor !== "0");
        }
        catch {
            (0, debug_1.gqlDebug)("redis:page:invalidate-prefix:error", { prefix });
        }
    }
}
exports.PageCacheService = PageCacheService;
exports.pageCacheService = new PageCacheService();
//# sourceMappingURL=page-cache.service.js.map