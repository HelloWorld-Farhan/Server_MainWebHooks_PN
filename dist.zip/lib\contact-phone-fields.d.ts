export declare const CONTACT_PHONE_FIELD_LABELS: {
    readonly field1: "user_name";
    readonly field2: "Recording URL";
    readonly field3: "Transcripts";
};
export type ContactPhoneFieldKey = keyof typeof CONTACT_PHONE_FIELD_LABELS;
export declare function displayContactFieldValue(value: string | null | undefined): string;
