export declare const HOME_PAGE_QUERY = "\n  query HomePage($dateFrom: String, $dateTo: String) {\n    callLogs {\n      recent(limit: 10) {\n        id\n        startedAt\n        direction\n        status\n        durationSeconds\n        lead {\n          firstName\n          lastName\n        }\n      }\n    }\n    analytics {\n      summary(granularity: DAILY, dateFrom: $dateFrom, dateTo: $dateTo) {\n        totalCalls\n        connectedCalls\n        conversionRate\n      }\n    }\n    agents {\n      statusSummary {\n        active\n        inactive\n        total\n      }\n    }\n    leads {\n      temperatureBreakdown {\n        hot\n        warm\n        cold\n        total\n      }\n    }\n    scheduler {\n      upcoming(limit: 5) {\n        id\n        type\n        title\n        startAt\n        status\n      }\n    }\n    events {\n      recent(limit: 10) {\n        id\n        type\n        title\n        entityType\n        entityId\n        createdAt\n      }\n    }\n  }\n";
export type HomePageResult = {
    callLogs: {
        recent: {
            id: string;
            startedAt: string;
            direction: string;
            status: string;
            durationSeconds: number;
            lead: {
                firstName: string | null;
                lastName: string | null;
            } | null;
        }[];
    };
    analytics: {
        summary: {
            totalCalls: number;
            connectedCalls: number;
            conversionRate: number;
        };
    };
    agents: {
        statusSummary: {
            active: number;
            inactive: number;
            total: number;
        };
    };
    leads: {
        temperatureBreakdown: {
            hot: number;
            warm: number;
            cold: number;
            total: number;
        };
    };
    scheduler: {
        upcoming: {
            id: string;
            type: string;
            title: string;
            startAt: string;
            status: string;
        }[];
    };
    events: {
        recent: {
            id: string;
            type: string;
            title: string;
            entityType: string | null;
            entityId: string | null;
            createdAt: string;
        }[];
    };
};
export declare const CAMPAIGN_DASHBOARD_QUERY = "\n  query CampaignDashboard($campaignId: ID!, $dateFrom: String, $dateTo: String) {\n    campaigns {\n      byId(id: $campaignId) {\n        id\n        name\n        status\n        aiEnabled\n        lastActivityAt\n      }\n      callLogs(campaignId: $campaignId, first: 10) {\n        id\n        startedAt\n        direction\n        status\n        durationSeconds\n        leadPhone\n        leadName\n      }\n    }\n    analytics {\n      summary(granularity: DAILY, dateFrom: $dateFrom, dateTo: $dateTo) {\n        totalCalls\n        connectedCalls\n        conversionRate\n      }\n    }\n    leads {\n      temperatureBreakdown {\n        hot\n        warm\n        cold\n        total\n      }\n    }\n  }\n";
export type CampaignDashboardResult = {
    campaigns: {
        byId: {
            id: string;
            name: string;
            status: string;
            aiEnabled: boolean;
            lastActivityAt: string | null;
        } | null;
        callLogs: {
            id: string;
            startedAt: string;
            direction: string;
            status: string;
            durationSeconds: number;
            leadPhone: string | null;
            leadName: string | null;
        }[];
    };
    analytics: {
        summary: {
            totalCalls: number;
            connectedCalls: number;
            conversionRate: number;
        };
    };
    leads: {
        temperatureBreakdown: {
            hot: number;
            warm: number;
            cold: number;
            total: number;
        };
    };
};
