"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.yoga = void 0;
const graphql_yoga_1 = require("graphql-yoga");
const context_1 = require("./context");
const debug_1 = require("./debug");
const map_error_1 = require("./map-error");
const server_1 = require("./server");
const isDev = process.env.NODE_ENV !== "production";
function useGraphQLDebugPlugin() {
    return {
        onRequest({ request }) {
            (0, debug_1.gqlDebug)("request:start", {
                method: request.method,
                url: request.url,
            });
        },
        onParams({ params, }) {
            (0, debug_1.gqlDebug)("request:params", {
                operationName: params.operationName ?? null,
                queryPreview: params.query?.slice(0, 120) ?? null,
            });
        },
        onExecute() {
            (0, debug_1.gqlDebug)("execute:start");
        },
        onExecuteDone({ result, }) {
            const errors = result.errors;
            if (errors?.length) {
                (0, debug_1.gqlLogError)("execute:graphql-errors", errors[0], {
                    errorCount: errors.length,
                    messages: errors.map((e) => e.message),
                });
            }
            else {
                (0, debug_1.gqlDebug)("execute:done");
            }
        },
        onResponse({ response }) {
            (0, debug_1.gqlDebug)("request:end", { status: response.status });
        },
    };
}
exports.yoga = (0, graphql_yoga_1.createYoga)({
    schema: server_1.schema,
    graphqlEndpoint: "/graphql",
    landingPage: isDev,
    context: async ({ req, request }) => {
        (0, debug_1.gqlDebug)("context:create:start");
        try {
            const ctx = await (0, context_1.createGraphQLContext)(req, request);
            (0, debug_1.gqlDebug)("context:create:done", {
                companyId: ctx.companyId,
                userId: ctx.userId,
                role: ctx.role,
            });
            return ctx;
        }
        catch (error) {
            (0, debug_1.gqlLogError)("context:create:error", error);
            throw error;
        }
    },
    plugins: [useGraphQLDebugPlugin()],
    maskedErrors: {
        maskError(error, message, dev) {
            (0, debug_1.gqlLogError)("execute:masked-error", error, {
                maskedMessage: message,
                isDev: dev ?? false,
            });
            return (0, map_error_1.maskGraphQLError)(error, message, dev ?? false);
        },
    },
});
//# sourceMappingURL=yoga.js.map