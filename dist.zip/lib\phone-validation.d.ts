export declare function normalizeE164Phone(raw: string): string | null;
export declare function normalizeOutboundPhone(raw: string): string | null;
export declare function isValidE164Phone(value: string): boolean;
