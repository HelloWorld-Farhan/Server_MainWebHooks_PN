"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChannelsInternalController = void 0;
const common_1 = require("@nestjs/common");
const channel_service_1 = require("../../server/channels/channel.service");
const channel_metrics_1 = require("../../server/channels/channel-metrics");
const API_KEY_HEADER = "x-agent-server-key";
function validateInternalRequest(req) {
    const expectedKey = process.env.AGENT_SERVER_API_KEY;
    if (!expectedKey) {
        return {
            error: {
                status: 503,
                body: { error: "Internal API key is not configured" },
            },
        };
    }
    const providedKey = req.headers[API_KEY_HEADER];
    if (!providedKey || providedKey !== expectedKey) {
        return { error: { status: 401, body: { error: "Unauthorized" } } };
    }
    return {};
}
let ChannelsInternalController = class ChannelsInternalController {
    async metrics(req, res) {
        const auth = validateInternalRequest(req);
        if (auth.error) {
            return res.status(auth.error.status).json(auth.error.body);
        }
        return res.json((0, channel_metrics_1.getChannelMetricsSnapshot)());
    }
    async companyStatus(req, companyId, res) {
        const auth = validateInternalRequest(req);
        if (auth.error) {
            return res.status(auth.error.status).json(auth.error.body);
        }
        const trimmedCompanyId = companyId?.trim();
        if (!trimmedCompanyId) {
            return res.status(400).json({ error: "companyId is required" });
        }
        const status = await channel_service_1.channelService.getMetrics(trimmedCompanyId);
        return res.json(status);
    }
};
exports.ChannelsInternalController = ChannelsInternalController;
__decorate([
    (0, common_1.Get)("metrics"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], ChannelsInternalController.prototype, "metrics", null);
__decorate([
    (0, common_1.Get)(":companyId/status"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Param)("companyId")),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, Object]),
    __metadata("design:returntype", Promise)
], ChannelsInternalController.prototype, "companyStatus", null);
exports.ChannelsInternalController = ChannelsInternalController = __decorate([
    (0, common_1.Controller)("api/internal/channels")
], ChannelsInternalController);
//# sourceMappingURL=channels-internal.controller.js.map