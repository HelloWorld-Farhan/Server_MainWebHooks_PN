import { OnModuleInit } from "@nestjs/common";
import { ChannelReconciliationService } from "./channel-reconciliation.service";
export declare class ChannelsModule implements OnModuleInit {
    private readonly reconciliation;
    constructor(reconciliation: ChannelReconciliationService);
    onModuleInit(): Promise<void>;
}
