"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.outboundCampaignsService = exports.OutboundCampaignsService = void 0;
const prisma_1 = __importDefault(require("../lib/prisma"));
const outbound_campaigns_repository_1 = require("../repositories/outbound-campaigns.repository");
const permissions_1 = require("../types/permissions");
const tenant_service_1 = require("./tenant.service");
const errors_1 = require("../lib/errors");
function mapCampaign(row) {
    return {
        id: row.id,
        name: row.name,
        status: row.status,
        agentId: row.aiAgentId,
        agentName: row.aiAgent?.name ?? "Unassigned",
        totalCalls: row.totalCalls,
        connectedCalls: row.connectedCalls,
        conversionRate: row.conversionRate,
        generatedLeads: row.generatedLeads,
        createdAt: row.createdAt.toISOString(),
    };
}
class OutboundCampaignsService {
    repo = new outbound_campaigns_repository_1.OutboundCampaignsRepository(prisma_1.default);
    async list(ctx) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.ANALYTICS_READ);
        const rows = await this.repo.findMany(ctx.companyId);
        return rows.map(mapCampaign);
    }
    async create(ctx, input) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.AGENTS_WRITE);
        const name = input.name.trim();
        if (!name) {
            throw new errors_1.ValidationError("Campaign name is required.");
        }
        const row = await this.repo.create(ctx.companyId, {
            name,
            aiAgentId: input.aiAgentId ?? null,
        });
        return mapCampaign(row);
    }
    async launch(ctx, id) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.AGENTS_WRITE);
        const campaign = await this.repo.findById(ctx.companyId, id);
        if (!campaign) {
            throw new errors_1.NotFoundError("Campaign not found");
        }
        if (campaign.status === "ACTIVE") {
            return mapCampaign(campaign);
        }
        await this.repo.updateStatus(ctx.companyId, id, "ACTIVE");
        const updated = await this.repo.findById(ctx.companyId, id);
        return mapCampaign(updated);
    }
    async pause(ctx, id) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.AGENTS_WRITE);
        const campaign = await this.repo.findById(ctx.companyId, id);
        if (!campaign) {
            throw new errors_1.NotFoundError("Campaign not found");
        }
        await this.repo.updateStatus(ctx.companyId, id, "PAUSED");
        const updated = await this.repo.findById(ctx.companyId, id);
        return mapCampaign(updated);
    }
}
exports.OutboundCampaignsService = OutboundCampaignsService;
exports.outboundCampaignsService = new OutboundCampaignsService();
//# sourceMappingURL=outbound-campaigns.service.js.map