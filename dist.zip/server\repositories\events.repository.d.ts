import type { Prisma, SystemEventType } from "@prisma/client";
import { BaseRepository } from "./base.repository";
export declare class EventsRepository extends BaseRepository {
    listRecent(companyId: string, limit: number): Prisma.PrismaPromise<{
        id: string;
        createdAt: Date;
        companyId: string;
        type: import("@prisma/client").$Enums.SystemEventType;
        title: string;
        entityType: string | null;
        entityId: string | null;
        actorId: string | null;
        payload: Prisma.JsonValue;
    }[]>;
    create(companyId: string, data: {
        type: SystemEventType;
        actorId?: string;
        entityType?: string;
        entityId?: string;
        title: string;
        payload?: Prisma.InputJsonValue;
    }): Prisma.Prisma__SystemEventClient<{
        id: string;
        createdAt: Date;
        companyId: string;
        type: import("@prisma/client").$Enums.SystemEventType;
        title: string;
        entityType: string | null;
        entityId: string | null;
        actorId: string | null;
        payload: Prisma.JsonValue;
    }, never, import("@prisma/client/runtime/library").DefaultArgs, Prisma.PrismaClientOptions>;
}
