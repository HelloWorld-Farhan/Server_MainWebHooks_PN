import type { Request, Response } from "express";
export declare class CampaignExecutionController {
    start(campaignId: string, req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    schedule(campaignId: string, req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    pause(campaignId: string, req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    resume(campaignId: string, req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    retry(campaignId: string, req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    reset(campaignId: string, req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    cancel(campaignId: string, req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    status(campaignId: string, req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    statistics(campaignId: string, req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    progress(campaignId: string, req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    retryPolicy(campaignId: string, req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    updateRetryPolicy(campaignId: string, req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    retryHistory(campaignId: string, phoneNumber: string | undefined, req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    pendingRetries(campaignId: string, req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    retryStatistics(campaignId: string, req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    retrySummary(campaignId: string, req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    private handleError;
}
