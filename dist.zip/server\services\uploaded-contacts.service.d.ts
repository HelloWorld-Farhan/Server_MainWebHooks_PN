import { type UploadedContactCreateInput } from "../repositories/uploaded-contacts.repository";
import type { TenantContext } from "../types/context";
type ImportedContactRow = UploadedContactCreateInput & {
    campaignNames?: string[];
    campaignIds?: string[];
};
export declare class UploadedContactsService {
    private readonly repo;
    private readonly campaignsRepo;
    list(ctx: TenantContext): Promise<{
        id: string;
        phone: string;
        field1: string | null;
        field2: string | null;
        field3: string | null;
        campaignIds: string[];
        createdAt: string;
    }[]>;
    create(ctx: TenantContext, phone: string): Promise<{
        id: string;
        phone: string;
        field1: string | null;
        field2: string | null;
        field3: string | null;
        campaignIds: string[];
        createdAt: string;
    }>;
    importContacts(ctx: TenantContext, contacts: ImportedContactRow[]): Promise<{
        created: number;
        updated: number;
        skipped: number;
        invalid: number;
        unmatchedCampaigns: string[];
    }>;
    delete(ctx: TenantContext, id: string): Promise<boolean>;
    bulkDelete(ctx: TenantContext, ids: string[]): Promise<number>;
}
export declare const uploadedContactsService: UploadedContactsService;
export {};
