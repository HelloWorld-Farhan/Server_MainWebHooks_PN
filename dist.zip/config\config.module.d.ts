export declare class AppConfigModule {
}
