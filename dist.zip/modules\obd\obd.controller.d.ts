export declare class ObdController {
    getServiceNumbers(): {
        numbers: string[];
        defaultNumber: string | null;
    };
}
