export type ContactPhoneCountry = {
    code: string;
    label: string;
    dialCode: string;
};
export declare const CONTACT_PHONE_COUNTRIES: ContactPhoneCountry[];
export declare const DEFAULT_CONTACT_PHONE_COUNTRY = "IN";
export declare function resolveDialCode(iso2: string): string | null;
export declare function buildStoredContactPhone(iso2: string, localRaw: string): string | null;
export declare function splitStoredContactPhone(stored: string): {
    country: string;
    local: string;
} | null;
