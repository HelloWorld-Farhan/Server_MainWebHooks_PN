"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.phoneNumbersService = exports.PhoneNumbersService = void 0;
const errors_1 = require("../lib/errors");
const pagination_1 = require("../lib/pagination");
const cache_service_1 = require("../cache/cache.service");
const prisma_1 = __importDefault(require("../lib/prisma"));
const phone_numbers_repository_1 = require("../repositories/phone-numbers.repository");
const permissions_1 = require("../types/permissions");
const tenant_service_1 = require("./tenant.service");
function mapPhoneNumber(row) {
    return {
        id: row.id,
        number: row.number,
        label: row.label,
        provider: row.provider,
        status: row.status,
        inboundAgentId: row.inboundAgentId,
        outboundAgentId: row.outboundAgentId,
        inboundAgent: row.inboundAgent,
        outboundAgent: row.outboundAgent,
        inboundCallsCount: row.inboundCallsCount,
        outboundCallsCount: row.outboundCallsCount,
        lastActivityAt: row.lastActivityAt?.toISOString() ?? null,
        createdAt: row.createdAt.toISOString(),
        updatedAt: row.updatedAt.toISOString(),
    };
}
class PhoneNumbersService {
    repo = new phone_numbers_repository_1.PhoneNumbersRepository(prisma_1.default);
    async list(ctx, filter, sort) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.AGENTS_READ);
        const rows = await this.repo.findMany(ctx.companyId, filter, sort);
        return rows.map(mapPhoneNumber);
    }
    async getConnection(ctx, args) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.AGENTS_READ);
        const limit = Math.min(Math.max(args.first ?? 25, 1), 200);
        const [rows, totalCount] = await Promise.all([
            this.repo.findConnection(ctx.companyId, limit, args.after, args.filter, args.sort),
            this.repo.count(ctx.companyId, args.filter),
        ]);
        const connection = (0, pagination_1.buildConnection)(rows, limit, (row) => (0, pagination_1.encodeIdCursor)(row.id, row.createdAt));
        return {
            edges: connection.edges.map((edge) => ({
                node: mapPhoneNumber(edge.node),
                cursor: edge.cursor,
            })),
            pageInfo: connection.pageInfo,
            totalCount,
        };
    }
    async getById(ctx, id) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.AGENTS_READ);
        const row = await this.repo.findById(ctx.companyId, id);
        if (!row)
            throw new errors_1.NotFoundError("Phone number not found");
        return mapPhoneNumber(row);
    }
    async create(ctx, input) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.AGENTS_WRITE);
        const row = await this.repo.create(ctx.companyId, input);
        await cache_service_1.cacheService.invalidatePhoneNumberPages(ctx.companyId);
        return mapPhoneNumber(row);
    }
    async update(ctx, id, input) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.AGENTS_WRITE);
        const existing = await this.repo.findById(ctx.companyId, id);
        if (!existing)
            throw new errors_1.NotFoundError("Phone number not found");
        const row = await this.repo.update(ctx.companyId, id, {
            label: input.label,
            status: input.status,
            inboundAgent: input.inboundAgentId
                ? { connect: { id: input.inboundAgentId } }
                : input.inboundAgentId === null
                    ? { disconnect: true }
                    : undefined,
            outboundAgent: input.outboundAgentId
                ? { connect: { id: input.outboundAgentId } }
                : input.outboundAgentId === null
                    ? { disconnect: true }
                    : undefined,
        });
        await cache_service_1.cacheService.invalidatePhoneNumberPages(ctx.companyId);
        return mapPhoneNumber(row);
    }
}
exports.PhoneNumbersService = PhoneNumbersService;
exports.phoneNumbersService = new PhoneNumbersService();
//# sourceMappingURL=phone-numbers.service.js.map