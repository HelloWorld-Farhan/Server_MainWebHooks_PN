import { type ObdOutboundCallInput } from "./dto/outbound-request.dto";
import { type ObdProviderOutboundResult } from "./dto/outbound-response.dto";
import { type ObdConfig } from "./obd-config";
export type ObdProviderClientDeps = {
    fetchFn?: typeof fetch;
    config?: ObdConfig;
};
export declare class ObdProviderClient {
    private readonly fetchFn;
    private readonly configOverride?;
    constructor(deps?: ObdProviderClientDeps);
    sendOutboundCall(input: ObdOutboundCallInput, configOverride?: Partial<ObdConfig>): Promise<ObdProviderOutboundResult>;
    private executeRequest;
}
export declare const obdProviderClient: ObdProviderClient;
