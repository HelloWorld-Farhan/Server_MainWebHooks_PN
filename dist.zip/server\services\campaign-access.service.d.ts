import type { CampaignAccessType, Prisma } from "@prisma/client";
import type { CampaignAccessContext, TenantContext } from "../types/context";
export declare function buildCampaignAccessFromMember(data: {
    campaignAccessType: CampaignAccessType;
    campaignAccess?: {
        campaignId: string;
    }[];
    role: TenantContext["role"];
}): CampaignAccessContext;
export declare class CampaignAccessService {
    hasAllCampaignAccess(ctx: TenantContext): boolean;
    assertCampaignAccess(ctx: TenantContext, campaignId: string): void;
    assertCampaignIdsAccess(ctx: TenantContext, campaignIds: string[]): void;
    campaignIdScopeFilter(ctx: TenantContext): Prisma.CampaignWhereInput;
    campaignRelationFilter(ctx: TenantContext): Prisma.LeadWhereInput;
    callLogCampaignFilter(ctx: TenantContext): Prisma.CallLogWhereInput;
    employeeScopeFilter(ctx: TenantContext): Prisma.CompanyMemberWhereInput;
    assertEmployeeVisible(ctx: TenantContext, employee: {
        campaignAccessType: CampaignAccessType;
        campaignAccess?: {
            campaignId: string;
        }[];
    }): void;
    mergeEmployeeWhere(ctx: TenantContext, where: Prisma.CompanyMemberWhereInput): Prisma.CompanyMemberWhereInput;
    mergeLeadWhere(ctx: TenantContext, where: Prisma.LeadWhereInput): Prisma.LeadWhereInput;
    mergeCallLogWhere(ctx: TenantContext, where: Prisma.CallLogWhereInput): Prisma.CallLogWhereInput;
    mergeCampaignWhere(ctx: TenantContext, where: Prisma.CampaignWhereInput): Prisma.CampaignWhereInput;
    assertLeadCampaignAccess(ctx: TenantContext, campaignId: string | null | undefined): void;
    assertCallLogCampaignAccess(ctx: TenantContext, campaignId: string | null | undefined): void;
}
export declare const campaignAccessService: CampaignAccessService;
