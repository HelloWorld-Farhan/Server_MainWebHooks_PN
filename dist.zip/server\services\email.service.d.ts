export declare class EmailService {
    private transporter;
    constructor();
    sendEmail(options: {
        to: string;
        subject: string;
        html: string;
    }): Promise<boolean>;
}
export declare const emailService: EmailService;
