"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.integrationsManagementService = exports.IntegrationsManagementService = void 0;
const cache_service_1 = require("../cache/cache.service");
const errors_1 = require("../lib/errors");
const prisma_1 = __importDefault(require("../lib/prisma"));
const notifications_repository_1 = require("../repositories/notifications.repository");
const permissions_1 = require("../types/permissions");
const tenant_service_1 = require("./tenant.service");
const INTEGRATION_TYPE_MAP = {
    "google-sheets": "GOOGLE_SHEETS",
    "google-calendar": "GOOGLE_CALENDAR",
    hubspot: "HUBSPOT",
    salesforce: "SALESFORCE",
    email: "EMAIL",
    whatsapp: "WHATSAPP",
};
const INTEGRATION_ID_MAP = Object.fromEntries(Object.entries(INTEGRATION_TYPE_MAP).map(([k, v]) => [v, k]));
const TOOL_ID_TO_PRISMA = {
    faq: "FAQ",
    billing: "BILLING",
    "google-calendar": "GOOGLE_CALENDAR",
    "google-sheets": "GOOGLE_SHEETS",
};
const PRISMA_TO_TOOL_ID = {
    FAQ: "faq",
    BILLING: "billing",
    GOOGLE_CALENDAR: "google-calendar",
    GOOGLE_SHEETS: "google-sheets",
};
function mapIntegrationStatus(status) {
    switch (status) {
        case "CONNECTED":
            return "connected";
        case "SYNCING":
            return "syncing";
        case "ERROR":
            return "error";
        default:
            return "not_connected";
    }
}
function mapPrismaStatus(status) {
    switch (status) {
        case "connected":
            return "CONNECTED";
        case "syncing":
            return "SYNCING";
        case "error":
            return "ERROR";
        default:
            return "NOT_CONNECTED";
    }
}
class IntegrationsManagementService {
    repo = new notifications_repository_1.IntegrationsRepository(prisma_1.default);
    async list(ctx) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.INTEGRATIONS_READ);
        const rows = await this.repo.findAll(ctx.companyId);
        return rows.map((row) => ({
            id: INTEGRATION_ID_MAP[row.type] ?? row.type.toLowerCase(),
            type: row.type,
            status: mapIntegrationStatus(row.status),
            connectedAccount: row.connectedAccount,
            config: row.config,
            lastSyncAt: row.lastSyncAt?.toISOString() ?? null,
            errorMessage: row.errorMessage,
        }));
    }
    async getByType(ctx, integrationId) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.INTEGRATIONS_READ);
        const type = INTEGRATION_TYPE_MAP[integrationId];
        const row = await this.repo.findByType(ctx.companyId, type);
        if (!row)
            return null;
        return {
            id: integrationId,
            type: row.type,
            status: mapIntegrationStatus(row.status),
            connectedAccount: row.connectedAccount,
            config: row.config,
            lastSyncAt: row.lastSyncAt?.toISOString() ?? null,
            errorMessage: row.errorMessage,
        };
    }
    async connect(ctx, integrationId, account) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.INTEGRATIONS_WRITE);
        const type = INTEGRATION_TYPE_MAP[integrationId];
        const row = await prisma_1.default.integration.upsert({
            where: { companyId_type: { companyId: ctx.companyId, type } },
            create: {
                company: { connect: { id: ctx.companyId } },
                type,
                status: "CONNECTED",
                connectedAccount: account ?? null,
                lastSyncAt: new Date(),
            },
            update: {
                status: "CONNECTED",
                connectedAccount: account ?? undefined,
                lastSyncAt: new Date(),
                errorMessage: null,
            },
        });
        await cache_service_1.cacheService.invalidateSettingsPages(ctx.companyId);
        return {
            id: integrationId,
            status: mapIntegrationStatus(row.status),
            connectedAccount: row.connectedAccount,
            lastSyncAt: row.lastSyncAt?.toISOString() ?? null,
        };
    }
    async disconnect(ctx, integrationId) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.INTEGRATIONS_WRITE);
        const type = INTEGRATION_TYPE_MAP[integrationId];
        const row = await prisma_1.default.integration.upsert({
            where: { companyId_type: { companyId: ctx.companyId, type } },
            create: {
                company: { connect: { id: ctx.companyId } },
                type,
                status: "NOT_CONNECTED",
            },
            update: {
                status: "NOT_CONNECTED",
                connectedAccount: null,
                lastSyncAt: null,
                errorMessage: null,
                config: {},
            },
        });
        await cache_service_1.cacheService.invalidateSettingsPages(ctx.companyId);
        return {
            id: integrationId,
            status: mapIntegrationStatus(row.status),
        };
    }
    async updateConfig(ctx, integrationId, config) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.INTEGRATIONS_WRITE);
        const type = INTEGRATION_TYPE_MAP[integrationId];
        const row = await prisma_1.default.integration.upsert({
            where: { companyId_type: { companyId: ctx.companyId, type } },
            create: {
                company: { connect: { id: ctx.companyId } },
                type,
                config: config,
            },
            update: { config: config },
        });
        await cache_service_1.cacheService.invalidateSettingsPages(ctx.companyId);
        return row.config;
    }
    async getAgentTools(ctx, agentId) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.AGENTS_READ);
        const agent = await prisma_1.default.aiAgent.findFirst({
            where: { id: agentId, companyId: ctx.companyId },
        });
        if (!agent)
            throw new errors_1.NotFoundError("Agent not found");
        const assignments = await prisma_1.default.agentToolAssignment.findMany({
            where: { aiAgentId: agentId },
        });
        return assignments.map((row) => ({
            toolId: PRISMA_TO_TOOL_ID[row.toolId],
            enabled: row.enabled,
            config: row.config,
            usage: row.usage,
        }));
    }
    async updateAgentTool(ctx, agentId, toolId, data) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.AGENTS_WRITE);
        const agent = await prisma_1.default.aiAgent.findFirst({
            where: { id: agentId, companyId: ctx.companyId },
        });
        if (!agent)
            throw new errors_1.NotFoundError("Agent not found");
        const prismaToolId = TOOL_ID_TO_PRISMA[toolId];
        const row = await prisma_1.default.agentToolAssignment.upsert({
            where: {
                aiAgentId_toolId: { aiAgentId: agentId, toolId: prismaToolId },
            },
            create: {
                aiAgent: { connect: { id: agentId } },
                toolId: prismaToolId,
                enabled: data.enabled ?? false,
                config: (data.config ?? {}),
            },
            update: {
                enabled: data.enabled,
                config: data.config,
            },
        });
        await cache_service_1.cacheService.invalidateAgentPages(ctx.companyId);
        return {
            toolId: PRISMA_TO_TOOL_ID[row.toolId],
            enabled: row.enabled,
            config: row.config,
            usage: row.usage,
        };
    }
}
exports.IntegrationsManagementService = IntegrationsManagementService;
exports.integrationsManagementService = new IntegrationsManagementService();
//# sourceMappingURL=integrations-management.service.js.map