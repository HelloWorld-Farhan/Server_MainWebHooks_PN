export declare function isPrismaWriteConflict(error: unknown): boolean;
export declare function withPrismaWriteRetry<T>(fn: () => Promise<T>, options?: {
    maxAttempts?: number;
    baseDelayMs?: number;
}): Promise<T>;
