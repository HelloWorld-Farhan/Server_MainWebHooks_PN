"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.delayedCallsQueue = exports.DELAYED_CALLS_QUEUE_NAME = void 0;
exports.scheduleDelayedCall = scheduleDelayedCall;
const bullmq_1 = require("bullmq");
const redis_client_1 = require("./redis.client");
exports.DELAYED_CALLS_QUEUE_NAME = "delayed-calls-queue";
exports.delayedCallsQueue = redis_client_1.redisConnection
    ? new bullmq_1.Queue(exports.DELAYED_CALLS_QUEUE_NAME, {
        connection: redis_client_1.redisConnection,
        defaultJobOptions: {
            attempts: 3,
            backoff: { type: "exponential", delay: 5000 },
            removeOnComplete: true,
        },
    })
    : null;
async function scheduleDelayedCall(data, delayMs) {
    if (!exports.delayedCallsQueue) {
        console.warn("⚠️ Redis not configured. Cannot schedule delayed call.");
        return;
    }
    const uniqueId = Math.random().toString(36).substring(2, 9);
    const jobId = `call-${data.didNumber}-${Date.now()}-${uniqueId}`;
    await exports.delayedCallsQueue.add(jobId, data, {
        delay: Math.max(0, delayMs),
        jobId
    });
}
//# sourceMappingURL=delayed-calls.queue.js.map