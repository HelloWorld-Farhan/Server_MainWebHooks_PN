export declare const BILLING_PAGE_QUERY = "\n  query BillingPage($after: String) {\n    billing {\n      subscription {\n        planName\n        status\n        currentPeriodEnd\n        nextInvoiceAmount\n      }\n      rates {\n        costPerChannel\n        costPerCredit\n        pulseTimeSeconds\n        setupOneTimeCost\n        currency\n        minChannelPurchase\n        virtualNumberCost\n        gstRate\n      }\n      invoices(first: 20, after: $after) {\n        edges {\n          node {\n            id\n            issuedAt\n            amountCents\n            status\n            description\n            currency\n          }\n          cursor\n        }\n        pageInfo {\n          hasNextPage\n          endCursor\n        }\n      }\n    }\n    credits {\n      usageHistory(first: 20) {\n        edges {\n          node {\n            id\n            amount\n            reason\n            description\n            createdAt\n          }\n          cursor\n        }\n        pageInfo {\n          hasNextPage\n          endCursor\n        }\n      }\n    }\n  }\n";
export type BillingPageResult = {
    billing: {
        subscription: {
            planName: string;
            status: string;
            currentPeriodEnd: string;
            nextInvoiceAmount: number | null;
        } | null;
        invoices: {
            edges: {
                node: {
                    id: string;
                    issuedAt: string;
                    amountCents: number;
                    status: string;
                    description: string | null;
                    currency: string;
                };
                cursor: string;
            }[];
            pageInfo: {
                hasNextPage: boolean;
                endCursor: string | null;
            };
        };
    };
    credits: {
        usageHistory: {
            edges: {
                node: {
                    id: string;
                    amount: number;
                    reason: string;
                    description: string | null;
                    createdAt: string;
                };
                cursor: string;
            }[];
            pageInfo: {
                hasNextPage: boolean;
                endCursor: string | null;
            };
        };
    };
};
