export type ProviderErrorDetails = {
    message: string;
    httpStatus?: number;
    responseBody?: unknown;
    isNetworkError?: boolean;
    isTimeout?: boolean;
};
export declare function toProviderErrorJson(error: ProviderErrorDetails): Record<string, unknown>;
