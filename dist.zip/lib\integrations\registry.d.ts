import { type LucideIcon } from "lucide-react";
import type { IntegrationId } from "./types";
export type IntegrationDefinition = {
    id: IntegrationId;
    name: string;
    description: string;
    icon: LucideIcon;
    available: boolean;
    comingSoon?: boolean;
};
export declare const INTEGRATION_DEFINITIONS: IntegrationDefinition[];
export declare function getIntegrationDefinition(id: IntegrationId): IntegrationDefinition | undefined;
