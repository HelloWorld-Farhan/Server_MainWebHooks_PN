export type PageInfo = {
    hasNextPage: boolean;
    endCursor: string | null;
};
export type Connection<T> = {
    edges: {
        node: T;
        cursor: string;
    }[];
    pageInfo: PageInfo;
};
export declare function encodeCursor(startedAt: Date, id: string): string;
export declare function decodeCursor(cursor: string): {
    startedAt: Date;
    id: string;
};
export declare function encodeIdCursor(id: string, createdAt: Date): string;
export declare function decodeIdCursor(cursor: string): {
    createdAt: Date;
    id: string;
};
export declare function buildConnection<T extends {
    id: string;
}>(items: T[], limit: number, getCursor: (item: T) => string): Connection<T>;
