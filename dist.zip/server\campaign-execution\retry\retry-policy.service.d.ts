import type { CallStatus } from "@prisma/client";
export type RetryPolicyFields = {
    retryEnabled: boolean;
    maxRetries: number;
    retryDelaySeconds: number;
    retryOnBusy: boolean;
    retryOnNoAnswer: boolean;
    retryOnFailed: boolean;
    retryOnCancelled: boolean;
    retryOnVoicemail: boolean;
    retryOnMissed: boolean;
};
export declare class RetryPolicyService {
    isRetriableStatus(status: CallStatus): boolean;
    isStatusEnabledByPolicy(status: CallStatus, policy: RetryPolicyFields): boolean;
    shouldRetry(policy: RetryPolicyFields, status: CallStatus, currentRetryCount: number): boolean;
    countRetriesForContact(companyId: string, campaignId: string, phone: string): Promise<number>;
    extractPolicy(execution: RetryPolicyFields): RetryPolicyFields;
}
export declare const retryPolicyService: RetryPolicyService;
