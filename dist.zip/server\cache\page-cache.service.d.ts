export interface CachedPagePayload<T> {
    cachedAt: number;
    data: T;
}
export interface PageCacheResult<T> {
    data: T;
    cachedAt: number;
    fromCache: boolean;
}
export declare class PageCacheService {
    getPageData<T>(cacheKey: string, loader: () => Promise<T>, options?: {
        staleAfterMs?: number;
        ttlSeconds?: number;
    }): Promise<PageCacheResult<T>>;
    invalidateKey(cacheKey: string): Promise<void>;
    invalidatePrefix(prefix: string): Promise<void>;
}
export declare const pageCacheService: PageCacheService;
