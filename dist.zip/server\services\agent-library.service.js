"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.agentLibraryService = exports.AgentLibraryService = void 0;
const errors_1 = require("../lib/errors");
const agent_library_repository_1 = require("../repositories/agent-library.repository");
const permissions_1 = require("../types/permissions");
const tenant_service_1 = require("./tenant.service");
function mapEntry(entry) {
    return {
        id: entry.id,
        slug: entry.slug,
        name: entry.name,
        profile: entry.profile,
        category: entry.category,
        useCases: entry.useCases,
        defaultType: entry.defaultType,
        estimatedSetupMinutes: entry.estimatedSetupMinutes,
        samplePrompt: entry.samplePrompt,
        defaultFirstMessage: entry.defaultFirstMessage,
        defaultVariables: entry.defaultVariables,
        compatibleVoices: entry.compatibleVoices,
        demoAudioUrl: entry.demoAudioUrl,
        avatarGradient: entry.avatarGradient,
        sortOrder: entry.sortOrder,
    };
}
class AgentLibraryService {
    async list(ctx) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.AGENTS_READ);
        const entries = await agent_library_repository_1.agentLibraryRepository.findMany();
        return entries.map((entry) => mapEntry(entry));
    }
    async getBySlug(ctx, slug) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.AGENTS_READ);
        const entry = await agent_library_repository_1.agentLibraryRepository.findBySlug(slug);
        if (!entry || !entry.isPublished) {
            throw new errors_1.NotFoundError("Library agent not found");
        }
        return mapEntry(entry);
    }
}
exports.AgentLibraryService = AgentLibraryService;
exports.agentLibraryService = new AgentLibraryService();
//# sourceMappingURL=agent-library.service.js.map