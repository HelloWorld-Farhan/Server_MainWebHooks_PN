"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TelephonyController = void 0;
const common_1 = require("@nestjs/common");
const zod_1 = require("zod");
const http_1 = require("../../lib/api/http");
const tenant_context_1 = require("../../lib/api/tenant-context");
const permissions_1 = require("../../lib/permissions");
const errors_1 = require("../../server/lib/errors");
const telephony_service_1 = require("../../server/services/telephony.service");
const providerEnum = zod_1.z.enum(["twilio", "exotel", "propnex"]);
const providerConfigsSchema = zod_1.z.object({
    twilio: zod_1.z
        .object({
        accountSid: zod_1.z.string(),
        authToken: zod_1.z.string(),
        defaultPhoneNumber: zod_1.z.string(),
    })
        .optional(),
    exotel: zod_1.z
        .object({
        apiKey: zod_1.z.string(),
        apiSecret: zod_1.z.string(),
        exophoneNumber: zod_1.z.string(),
    })
        .optional(),
    propnex: zod_1.z
        .object({
        region: zod_1.z.string(),
        environment: zod_1.z.enum(["production", "sandbox"]),
    })
        .optional(),
});
const saveConfigSchema = zod_1.z.object({
    activeProvider: providerEnum,
    providerConfigs: providerConfigsSchema,
    channelSettings: zod_1.z
        .object({
        maxConcurrentCalls: zod_1.z.number().int().positive(),
        callQueueLimit: zod_1.z.number().int().nonnegative(),
        overflowHandling: zod_1.z.enum(["queue", "reject", "forward"]),
    })
        .optional(),
    totalChannels: zod_1.z.number().int().nonnegative().optional(),
    pulseTimeSeconds: zod_1.z.number().int().positive().optional(),
    deltaSeconds: zod_1.z.number().int().positive().optional(),
    channels: zod_1.z
        .array(zod_1.z.object({
        channelIndex: zod_1.z.number().int().nonnegative(),
        label: zod_1.z.string().optional(),
        phoneNumberId: zod_1.z.string().optional(),
    }))
        .optional(),
});
const testConnectionSchema = zod_1.z.object({
    provider: providerEnum,
    providerConfigs: providerConfigsSchema,
});
const testCallSchema = zod_1.z.object({
    phoneNumber: zod_1.z.string().min(1),
    provider: providerEnum.optional(),
});
let TelephonyController = class TelephonyController {
    async getConfig(req, res) {
        const result = await (0, tenant_context_1.requireTenantContext)(req);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        try {
            const config = await telephony_service_1.telephonyService.getConfig(result.ctx);
            return res.json({ config });
        }
        catch (err) {
            if ((0, errors_1.isAppError)(err)) {
                return res.status(err.statusCode).json({ error: err.message });
            }
            return res.status(500).json({ error: "Internal server error" });
        }
    }
    async saveConfig(req, res) {
        const result = await (0, tenant_context_1.requireTenantPermission)(req, permissions_1.PERMISSIONS.SETTINGS_WRITE);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        try {
            const body = saveConfigSchema.parse(req.body);
            const config = await telephony_service_1.telephonyService.saveConfig(result.ctx, {
                activeProvider: body.activeProvider,
                providerConfigs: {
                    twilio: body.providerConfigs.twilio ?? {
                        accountSid: "",
                        authToken: "",
                        defaultPhoneNumber: "",
                    },
                    exotel: body.providerConfigs.exotel ?? {
                        apiKey: "",
                        apiSecret: "",
                        exophoneNumber: "",
                    },
                    propnex: body.providerConfigs.propnex ?? {
                        region: "us-east-1",
                        environment: "production",
                    },
                },
                channelSettings: body.channelSettings,
                totalChannels: body.totalChannels,
                pulseTimeSeconds: body.pulseTimeSeconds,
                deltaSeconds: body.deltaSeconds,
                channels: body.channels,
            });
            return res.json({ config });
        }
        catch (err) {
            if (err instanceof zod_1.z.ZodError) {
                return res
                    .status(400)
                    .json({ error: err.issues[0]?.message ?? err.message });
            }
            if ((0, errors_1.isAppError)(err)) {
                return res.status(err.statusCode).json({ error: err.message });
            }
            return res.status(500).json({ error: "Internal server error" });
        }
    }
    async testConnection(req, res) {
        const result = await (0, tenant_context_1.requireTenantPermission)(req, permissions_1.PERMISSIONS.SETTINGS_WRITE);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        try {
            const body = testConnectionSchema.parse(req.body);
            const testResult = await telephony_service_1.telephonyService.testConnection(result.ctx, {
                provider: body.provider,
                providerConfigs: {
                    twilio: body.providerConfigs.twilio ?? {
                        accountSid: "",
                        authToken: "",
                        defaultPhoneNumber: "",
                    },
                    exotel: body.providerConfigs.exotel ?? {
                        apiKey: "",
                        apiSecret: "",
                        exophoneNumber: "",
                    },
                    propnex: body.providerConfigs.propnex ?? {
                        region: "us-east-1",
                        environment: "production",
                    },
                },
            });
            return res.json(testResult);
        }
        catch (err) {
            if (err instanceof zod_1.z.ZodError) {
                return res
                    .status(400)
                    .json({ error: err.issues[0]?.message ?? err.message });
            }
            if ((0, errors_1.isAppError)(err)) {
                return res.status(err.statusCode).json({ error: err.message });
            }
            return res.status(500).json({ error: "Internal server error" });
        }
    }
    async testCall(req, res) {
        const result = await (0, tenant_context_1.requireTenantPermission)(req, permissions_1.PERMISSIONS.SETTINGS_WRITE);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        try {
            const body = testCallSchema.parse(req.body);
            const testResult = await telephony_service_1.telephonyService.testCall(result.ctx, body);
            return res.json(testResult);
        }
        catch (err) {
            if (err instanceof zod_1.z.ZodError) {
                return res
                    .status(400)
                    .json({ error: err.issues[0]?.message ?? err.message });
            }
            if ((0, errors_1.isAppError)(err)) {
                return res.status(err.statusCode).json({ error: err.message });
            }
            return res.status(500).json({ error: "Internal server error" });
        }
    }
};
exports.TelephonyController = TelephonyController;
__decorate([
    (0, common_1.Get)("config"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TelephonyController.prototype, "getConfig", null);
__decorate([
    (0, common_1.Put)("config"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TelephonyController.prototype, "saveConfig", null);
__decorate([
    (0, common_1.Post)("test-connection"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TelephonyController.prototype, "testConnection", null);
__decorate([
    (0, common_1.Post)("test-call"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TelephonyController.prototype, "testCall", null);
exports.TelephonyController = TelephonyController = __decorate([
    (0, common_1.Controller)("api/telephony")
], TelephonyController);
//# sourceMappingURL=telephony.controller.js.map