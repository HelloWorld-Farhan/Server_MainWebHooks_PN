"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApiKeysRepository = void 0;
const base_repository_1 = require("./base.repository");
const pagination_1 = require("../lib/pagination");
const apiKeyInclude = {
    campaignAccess: true,
    createdBy: {
        select: {
            id: true,
            email: true,
            firstName: true,
            lastName: true,
        },
    },
};
class ApiKeysRepository extends base_repository_1.BaseRepository {
    notDeleted() {
        return { deletedAt: null };
    }
    buildWhere(companyId, filter) {
        const where = {
            ...this.scope(companyId),
            ...this.notDeleted(),
        };
        if (filter?.status)
            where.status = filter.status;
        if (filter?.environment)
            where.environment = filter.environment;
        const search = filter?.search?.trim();
        if (search) {
            where.OR = [
                { name: { contains: search, mode: "insensitive" } },
                { description: { contains: search, mode: "insensitive" } },
                { keyPrefix: { contains: search, mode: "insensitive" } },
            ];
        }
        return where;
    }
    findConnection(companyId, limit, after, filter) {
        const cursor = after ? (0, pagination_1.decodeIdCursor)(after) : undefined;
        return this.prisma.apiKey.findMany({
            where: this.buildWhere(companyId, filter),
            orderBy: [{ createdAt: "desc" }, { id: "desc" }],
            take: limit + 1,
            include: apiKeyInclude,
            ...(cursor
                ? {
                    cursor: { id: cursor.id },
                    skip: 1,
                }
                : {}),
        });
    }
    count(companyId, filter) {
        return this.prisma.apiKey.count({
            where: this.buildWhere(companyId, filter),
        });
    }
    findById(companyId, id) {
        return this.prisma.apiKey.findFirst({
            where: { id, companyId, ...this.notDeleted() },
            include: apiKeyInclude,
        });
    }
    findByName(companyId, name) {
        return this.prisma.apiKey.findFirst({
            where: { companyId, name, ...this.notDeleted() },
        });
    }
    findByKeyId(keyId) {
        return this.prisma.apiKey.findFirst({
            where: { keyId, ...this.notDeleted() },
            include: { campaignAccess: true },
        });
    }
    create(data) {
        return this.prisma.apiKey.create({
            data: {
                companyId: data.companyId,
                name: data.name,
                description: data.description ?? null,
                keyId: data.keyId,
                keyPrefix: data.keyPrefix,
                hashedSecret: data.hashedSecret,
                environment: data.environment,
                scopes: data.scopes,
                campaignAccessType: data.campaignAccessType,
                expiresAt: data.expiresAt ?? null,
                createdById: data.createdById,
                campaignAccess: data.campaignAccessType === "SELECTED" && data.campaignIds.length > 0
                    ? {
                        create: data.campaignIds.map((campaignId) => ({ campaignId })),
                    }
                    : undefined,
            },
            include: apiKeyInclude,
        });
    }
    async update(companyId, id, data) {
        const existing = await this.findById(companyId, id);
        if (!existing)
            return null;
        return this.prisma.apiKey.update({
            where: { id },
            data,
            include: apiKeyInclude,
        });
    }
    async replaceBranchAccess(companyId, apiKeyId, campaignAccessType, campaignIds) {
        const existing = await this.findById(companyId, apiKeyId);
        if (!existing)
            return null;
        await this.prisma.apiKeyCampaignAccess.deleteMany({ where: { apiKeyId } });
        if (campaignAccessType === "SELECTED" && campaignIds.length > 0) {
            await this.prisma.apiKeyCampaignAccess.createMany({
                data: campaignIds.map((campaignId) => ({ apiKeyId, campaignId })),
            });
        }
        return this.prisma.apiKey.update({
            where: { id: apiKeyId },
            data: { campaignAccessType },
            include: apiKeyInclude,
        });
    }
    softDelete(companyId, id) {
        return this.prisma.apiKey.updateMany({
            where: { id, companyId, deletedAt: null },
            data: { deletedAt: new Date(), status: "INACTIVE" },
        });
    }
    createAuditLog(data) {
        return this.prisma.auditLog.create({
            data: {
                companyId: data.companyId,
                userId: data.userId,
                action: data.action,
                entityType: data.entityType,
                entityId: data.entityId,
                changes: data.changes,
            },
        });
    }
    findCampaignsByIds(companyId, ids) {
        if (ids.length === 0)
            return Promise.resolve([]);
        return this.prisma.campaign.findMany({
            where: {
                companyId,
                id: { in: ids },
                status: { not: "ARCHIVED" },
            },
            select: { id: true, name: true, status: true },
        });
    }
    findAccessibleCampaigns(companyId, campaignIds) {
        return this.prisma.campaign.findMany({
            where: {
                companyId,
                status: { not: "ARCHIVED" },
                ...(campaignIds ? { id: { in: campaignIds } } : {}),
            },
            orderBy: { name: "asc" },
            select: { id: true, name: true, status: true },
        });
    }
}
exports.ApiKeysRepository = ApiKeysRepository;
//# sourceMappingURL=api-keys.repository.js.map