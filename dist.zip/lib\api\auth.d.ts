import type { Request } from "express";
export declare function requireAuth(req: Request): Promise<{
    error: {
        status: number;
        body: {
            error: string;
        };
    };
    userId: null;
} | {
    error: null;
    userId: string;
}>;
export declare function delay(ms: number): Promise<unknown>;
