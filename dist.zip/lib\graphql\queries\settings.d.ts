export declare const SETTINGS_PAGE_QUERY = "\n  query SettingsPage {\n    viewer {\n      id\n      email\n      firstName\n      lastName\n      role\n      company {\n        id\n        name\n        slug\n        contact {\n          name\n          email\n          phone\n          title\n        }\n      }\n    }\n    integrations {\n      list {\n        id\n        type\n        status\n        connectedAccount\n        lastSyncAt\n      }\n    }\n  }\n";
export type SettingsPageResult = {
    viewer: {
        id: string;
        email: string;
        firstName: string | null;
        lastName: string | null;
        role: string;
        company: {
            id: string;
            name: string;
            slug: string;
            contact: {
                name: string;
                email: string;
                phone: string | null;
                title: string | null;
            } | null;
        };
    };
    integrations: {
        list: {
            id: string;
            type: string;
            status: string;
            connectedAccount: string | null;
            lastSyncAt: string | null;
        }[];
    };
};
