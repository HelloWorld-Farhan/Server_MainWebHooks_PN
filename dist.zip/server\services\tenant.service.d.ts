import type { CallVolumeRange, PrimaryUseCase } from "@prisma/client";
import { TenantRepository } from "../repositories/tenant.repository";
import type { TenantContext } from "../types/context";
import { type Permission } from "../types/permissions";
export declare class TenantService {
    private readonly repo;
    resolveCompany(clerkOrgId: string | null | undefined): Promise<{
        status: import("@prisma/client").$Enums.CompanyStatus;
        name: string;
        id: string;
        clerkOrganizationId: string | null;
        contractId: string;
        claimedAt: Date | null;
        ownerUserId: string | null;
        slug: string;
        blockedUntil: Date | null;
        tenantType: import("@prisma/client").$Enums.TenantType;
        parentCompanyId: string | null;
        primaryUseCase: import("@prisma/client").$Enums.PrimaryUseCase | null;
        callVolume: import("@prisma/client").$Enums.CallVolumeRange | null;
        settings: import("@prisma/client/runtime/library").JsonValue;
        isDemo: boolean;
        cli: string;
        companyCode: string;
        createdAt: Date;
        updatedAt: Date;
    }>;
    resolveMembership(companyId: string, clerkUserId: string): Promise<{
        user: {
            status: import("@prisma/client").$Enums.UserStatus;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            email: string;
            firstName: string | null;
            lastName: string | null;
            phone: string | null;
            clerkUserId: string;
            imageUrl: string | null;
            passwordHash: string | null;
            lastLoginAt: Date | null;
        };
        membership: {
            company: {
                status: import("@prisma/client").$Enums.CompanyStatus;
                name: string;
                id: string;
                clerkOrganizationId: string | null;
                contractId: string;
                claimedAt: Date | null;
                ownerUserId: string | null;
                slug: string;
                blockedUntil: Date | null;
                tenantType: import("@prisma/client").$Enums.TenantType;
                parentCompanyId: string | null;
                primaryUseCase: import("@prisma/client").$Enums.PrimaryUseCase | null;
                callVolume: import("@prisma/client").$Enums.CallVolumeRange | null;
                settings: import("@prisma/client/runtime/library").JsonValue;
                isDemo: boolean;
                cli: string;
                companyCode: string;
                createdAt: Date;
                updatedAt: Date;
            };
            user: {
                status: import("@prisma/client").$Enums.UserStatus;
                id: string;
                createdAt: Date;
                updatedAt: Date;
                email: string;
                firstName: string | null;
                lastName: string | null;
                phone: string | null;
                clerkUserId: string;
                imageUrl: string | null;
                passwordHash: string | null;
                lastLoginAt: Date | null;
            };
            customRole: {
                name: string;
                id: string;
                slug: string;
                createdAt: Date;
                updatedAt: Date;
                companyId: string | null;
                permissions: string[];
                isSystem: boolean;
            } | null;
            campaignAccess: {
                id: string;
                createdAt: Date;
                campaignId: string;
                memberId: string;
            }[];
        } & {
            role: import("@prisma/client").$Enums.UserRole;
            userId: string;
            status: import("@prisma/client").$Enums.MemberStatus;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            companyId: string;
            roleId: string | null;
            jobTitle: string | null;
            campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
            invitedAt: Date | null;
            joinedAt: Date | null;
        };
    }>;
    resolveMembershipFromRecord(companyId: string, clerkUserId: string, membership: NonNullable<Awaited<ReturnType<TenantRepository["findMembership"]>>>): Promise<{
        user: {
            status: import("@prisma/client").$Enums.UserStatus;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            email: string;
            firstName: string | null;
            lastName: string | null;
            phone: string | null;
            clerkUserId: string;
            imageUrl: string | null;
            passwordHash: string | null;
            lastLoginAt: Date | null;
        };
        membership: {
            company: {
                status: import("@prisma/client").$Enums.CompanyStatus;
                name: string;
                id: string;
                clerkOrganizationId: string | null;
                contractId: string;
                claimedAt: Date | null;
                ownerUserId: string | null;
                slug: string;
                blockedUntil: Date | null;
                tenantType: import("@prisma/client").$Enums.TenantType;
                parentCompanyId: string | null;
                primaryUseCase: import("@prisma/client").$Enums.PrimaryUseCase | null;
                callVolume: import("@prisma/client").$Enums.CallVolumeRange | null;
                settings: import("@prisma/client/runtime/library").JsonValue;
                isDemo: boolean;
                cli: string;
                companyCode: string;
                createdAt: Date;
                updatedAt: Date;
            };
            user: {
                status: import("@prisma/client").$Enums.UserStatus;
                id: string;
                createdAt: Date;
                updatedAt: Date;
                email: string;
                firstName: string | null;
                lastName: string | null;
                phone: string | null;
                clerkUserId: string;
                imageUrl: string | null;
                passwordHash: string | null;
                lastLoginAt: Date | null;
            };
            customRole: {
                name: string;
                id: string;
                slug: string;
                createdAt: Date;
                updatedAt: Date;
                companyId: string | null;
                permissions: string[];
                isSystem: boolean;
            } | null;
            campaignAccess: {
                id: string;
                createdAt: Date;
                campaignId: string;
                memberId: string;
            }[];
        } & {
            role: import("@prisma/client").$Enums.UserRole;
            userId: string;
            status: import("@prisma/client").$Enums.MemberStatus;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            companyId: string;
            roleId: string | null;
            jobTitle: string | null;
            campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
            invitedAt: Date | null;
            joinedAt: Date | null;
        };
    }>;
    getPermissions(userId: string, role: TenantContext["role"], customPermissions?: string[]): Promise<string[]>;
    requirePermission(ctx: TenantContext, permission: Permission): void;
    syncUserFromClerk(data: {
        clerkUserId: string;
        email: string;
        firstName?: string | null;
        lastName?: string | null;
        imageUrl?: string | null;
        phone?: string | null;
    }): Promise<{
        status: import("@prisma/client").$Enums.UserStatus;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        email: string;
        firstName: string | null;
        lastName: string | null;
        phone: string | null;
        clerkUserId: string;
        imageUrl: string | null;
        passwordHash: string | null;
        lastLoginAt: Date | null;
    }>;
    ensureUserFromClerk(clerkUserId: string): Promise<{
        status: import("@prisma/client").$Enums.UserStatus;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        email: string;
        firstName: string | null;
        lastName: string | null;
        phone: string | null;
        clerkUserId: string;
        imageUrl: string | null;
        passwordHash: string | null;
        lastLoginAt: Date | null;
    } | null>;
    syncCompanyFromClerk(data: {
        clerkOrganizationId: string;
        name: string;
        slug: string;
        primaryUseCase?: PrimaryUseCase | null;
        callVolume?: CallVolumeRange | null;
    }): Promise<{
        status: import("@prisma/client").$Enums.CompanyStatus;
        name: string;
        id: string;
        clerkOrganizationId: string | null;
        contractId: string;
        claimedAt: Date | null;
        ownerUserId: string | null;
        slug: string;
        blockedUntil: Date | null;
        tenantType: import("@prisma/client").$Enums.TenantType;
        parentCompanyId: string | null;
        primaryUseCase: import("@prisma/client").$Enums.PrimaryUseCase | null;
        callVolume: import("@prisma/client").$Enums.CallVolumeRange | null;
        settings: import("@prisma/client/runtime/library").JsonValue;
        isDemo: boolean;
        cli: string;
        companyCode: string;
        createdAt: Date;
        updatedAt: Date;
    }>;
    syncMembership(data: {
        companyId: string;
        userId: string;
        role: TenantContext["role"];
    }): Promise<{
        role: import("@prisma/client").$Enums.UserRole;
        userId: string;
        status: import("@prisma/client").$Enums.MemberStatus;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        roleId: string | null;
        jobTitle: string | null;
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        invitedAt: Date | null;
        joinedAt: Date | null;
    }>;
    getViewer(ctx: TenantContext): Promise<{
        id: string;
        membershipId: string;
        email: string;
        firstName: string | null;
        lastName: string | null;
        role: import("@prisma/client").$Enums.UserRole;
        permissions: string[];
        campaignAccessType: import("@prisma/client").$Enums.CampaignAccessType;
        campaignIds: string[];
        company: {
            id: string;
            name: string;
            slug: string;
            contact: {
                name: string;
                email: string;
                phone: string | null;
                title: string | null;
            } | null;
        };
    }>;
}
export declare const tenantService: TenantService;
