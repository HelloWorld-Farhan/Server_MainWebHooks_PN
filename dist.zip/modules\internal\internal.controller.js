"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InternalController = void 0;
const common_1 = require("@nestjs/common");
const agent_server_auth_1 = require("../../lib/api/agent-server-auth");
const service_tenant_context_1 = require("../../lib/api/service-tenant-context");
const db_state_1 = require("../../lib/integrations/db-state");
let InternalController = class InternalController {
    async sheetsSync(req, body, res) {
        const { companyId, error } = (0, agent_server_auth_1.validateAgentServerRequest)(req);
        if (error) {
            return res.status(error.status).json(error.body);
        }
        const callId = body.callId?.trim();
        if (!callId) {
            return res.status(400).json({ error: "callId is required" });
        }
        try {
            const ctx = (0, service_tenant_context_1.createServiceTenantContext)(companyId);
            const result = await (0, db_state_1.syncDialerCallToSheetDb)(ctx, callId);
            return res.json(result);
        }
        catch (e) {
            return res.status(500).json({
                error: e instanceof Error ? e.message : "Sheets sync failed",
            });
        }
    }
};
exports.InternalController = InternalController;
__decorate([
    (0, common_1.Post)("sheets-sync"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, Object]),
    __metadata("design:returntype", Promise)
], InternalController.prototype, "sheetsSync", null);
exports.InternalController = InternalController = __decorate([
    (0, common_1.Controller)("api/internal/dialer")
], InternalController);
//# sourceMappingURL=internal.controller.js.map