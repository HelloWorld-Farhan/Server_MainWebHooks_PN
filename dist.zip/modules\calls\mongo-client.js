"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDb = getDb;
exports.getGridFS = getGridFS;
const mongodb_1 = require("mongodb");
let client = null;
async function getDb() {
    if (!client) {
        const uri = process.env.DATABASE_URL;
        if (!uri)
            throw new Error("DATABASE_URL is not set");
        client = new mongodb_1.MongoClient(uri);
        await client.connect();
    }
    return client.db();
}
async function getGridFS() {
    const db = await getDb();
    return new mongodb_1.GridFSBucket(db, { bucketName: "fs" });
}
//# sourceMappingURL=mongo-client.js.map