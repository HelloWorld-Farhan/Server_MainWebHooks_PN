"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cacheKeys = exports.CLERK_MEMBERSHIPS_STALE_MS = exports.PAGE_CACHE_STALE_MS = exports.CACHE_TTL = void 0;
const node_crypto_1 = require("node:crypto");
exports.CACHE_TTL = {
    CREDITS: 5 * 60,
    TOP_CALL_LOGS: 2 * 60,
    ANALYTICS: 5 * 60,
    PERMISSIONS: 30 * 60,
    AGENT_STATUS: 60,
    PAGE_CACHE: 30,
    CLERK_MEMBERSHIPS: 45,
    CLERK_ORG_MEMBERSHIPS: 45,
    RESOLVED_COMPANY: 30,
};
exports.PAGE_CACHE_STALE_MS = 10_000;
exports.CLERK_MEMBERSHIPS_STALE_MS = 35_000;
function hashValue(value) {
    return (0, node_crypto_1.createHash)("sha256")
        .update(JSON.stringify(value ?? {}))
        .digest("hex")
        .slice(0, 16);
}
exports.cacheKeys = {
    clerkMemberships: (clerkUserId) => `clerk:memberships:${clerkUserId}`,
    clerkOrgMemberships: (orgId) => `clerk:org-memberships:${orgId}`,
    resolvedCompany: (clerkUserId) => `company:${clerkUserId}`,
    companyCredits: (companyId) => `company:${companyId}:credits`,
    companyTopCallLogs: (companyId) => `company:${companyId}:top-call-logs`,
    companyAnalytics: (companyId) => `company:${companyId}:analytics`,
    userPermissions: (userId) => `user:${userId}:permissions`,
    companyAgentStatus: (companyId) => `company:${companyId}:agent-status`,
    page: (companyId, pageKey, params) => {
        const base = `page:${companyId}:${pageKey}`;
        switch (pageKey) {
            case "call-logs":
                return `${base}:${hashValue({ after: params?.after, filter: params?.filter })}`;
            case "call-detail":
            case "agent-detail":
                return `${base}:${params?.id ?? "missing"}`;
            case "agent-template":
                return `${base}:${params?.slug ?? "missing"}`;
            case "lead-reactivation":
                return `${base}:${hashValue(params?.filter)}`;
            case "phone-detail":
                return `${base}:${params?.id ?? "missing"}:${hashValue({ after: params?.after })}`;
            case "billing":
                return `${base}:${hashValue({ after: params?.after })}`;
            case "home":
                return `${base}:${hashValue(params?.filter)}`;
            default:
                return base;
        }
    },
    pagePrefix: (companyId, pageKey) => `page:${companyId}:${pageKey}`,
};
//# sourceMappingURL=keys.js.map