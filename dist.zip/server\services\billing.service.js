"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.billingService = exports.BillingService = void 0;
const pagination_1 = require("../lib/pagination");
const credits_util_1 = require("../lib/credits.util");
const prisma_1 = __importDefault(require("../lib/prisma"));
const billing_repository_1 = require("../repositories/billing.repository");
const billing_quote_repository_1 = require("../repositories/billing-quote.repository");
const setup_config_repository_1 = require("../repositories/setup-config.repository");
const permissions_1 = require("../types/permissions");
const tenant_service_1 = require("./tenant.service");
const errors_1 = require("../lib/errors");
const credits_service_1 = require("./credits.service");
const GST_RATE = 0.18;
const MIN_CHANNEL_QTY = 3;
const CHANNEL_COST = 650;
const VIRTUAL_NUMBER_COST = 370;
const DEFAULT_PULSE_SECONDS = 60;
const DEFAULT_DELTA_SECONDS = 2;
const DEFAULT_COST_PER_CREDIT = 0.31;
function getCallTierRate(monthlyCalls) {
    if (monthlyCalls >= 5001)
        return 3;
    if (monthlyCalls >= 1000)
        return 4;
    return 0;
}
function mapQuote(quote) {
    return {
        id: quote.id,
        status: quote.status,
        channelQty: quote.channelQty,
        virtualNumberQty: quote.virtualNumberQty,
        expectedMonthlyCalls: quote.expectedMonthlyCalls,
        pricing: {
            channelCost: quote.channelCost,
            virtualNumberCost: quote.virtualNumberCost,
            callCost: quote.callCost,
            subtotal: quote.subtotal,
            gst: quote.gst,
            grandTotal: quote.grandTotal,
            currency: quote.currency,
        },
        expiresAt: quote.expiresAt?.toISOString() ?? null,
        purchasedAt: quote.purchasedAt?.toISOString() ?? null,
        invoiceId: quote.invoiceId,
        createdAt: quote.createdAt.toISOString(),
        updatedAt: quote.updatedAt.toISOString(),
    };
}
class BillingService {
    repo = new billing_repository_1.BillingRepository(prisma_1.default);
    quoteRepo = new billing_quote_repository_1.BillingQuoteRepository(prisma_1.default);
    setupRepo = new setup_config_repository_1.SetupConfigRepository(prisma_1.default);
    async getSubscription(ctx) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.BILLING_READ);
        const subscription = await this.repo.getSubscription(ctx.companyId);
        if (!subscription)
            return null;
        return {
            id: subscription.id,
            planId: subscription.planId,
            planName: subscription.planName,
            status: subscription.status,
            currentPeriodStart: subscription.currentPeriodStart.toISOString(),
            currentPeriodEnd: subscription.currentPeriodEnd.toISOString(),
            cancelAtPeriodEnd: subscription.cancelAtPeriodEnd,
            nextInvoiceAmount: null,
        };
    }
    async getInvoices(ctx, args) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.BILLING_READ);
        const limit = Math.min(args.first ?? 20, 100);
        const items = await this.repo.listInvoices(ctx.companyId, limit, args.after);
        return (0, pagination_1.buildConnection)(items, limit, (item) => (0, pagination_1.encodeIdCursor)(item.id, item.issuedAt));
    }
    async getRates(ctx) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.BILLING_READ);
        const rates = await this.setupRepo.getBillingRates(ctx.companyId);
        return {
            costPerChannel: rates?.costPerChannel ?? CHANNEL_COST,
            costPerCredit: rates?.costPerCredit ?? DEFAULT_COST_PER_CREDIT,
            pulseTimeSeconds: rates?.pulseTimeSeconds ?? DEFAULT_PULSE_SECONDS,
            setupOneTimeCost: rates?.setupOneTimeCost ?? 0,
            currency: rates?.currency ?? "INR",
            minChannelPurchase: MIN_CHANNEL_QTY,
            virtualNumberCost: VIRTUAL_NUMBER_COST,
            gstRate: GST_RATE,
        };
    }
    async loadCompanyBillingConfig(companyId) {
        const [setupConfig, billingRates] = await Promise.all([
            this.setupRepo.getSetupConfig(companyId),
            this.setupRepo.getBillingRates(companyId),
        ]);
        return {
            pulseTimeSeconds: billingRates?.pulseTimeSeconds ??
                setupConfig?.pulseTimeSeconds ??
                DEFAULT_PULSE_SECONDS,
            deltaSeconds: setupConfig?.deltaSeconds ?? DEFAULT_DELTA_SECONDS,
            costPerCredit: billingRates?.costPerCredit ?? DEFAULT_COST_PER_CREDIT,
        };
    }
    calculateCallBilling(durationSeconds, config) {
        const credits = (0, credits_util_1.creditsForDuration)(durationSeconds, config.pulseTimeSeconds, config.deltaSeconds);
        const costInr = credits * config.costPerCredit;
        return { credits, costInr };
    }
    async createQuote(ctx, input) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.BILLING_WRITE);
        if (input.channelQty > 0 && input.channelQty < MIN_CHANNEL_QTY) {
            throw new errors_1.ValidationError(`Minimum channel purchase is ${MIN_CHANNEL_QTY}.`);
        }
        const rates = await this.getRates(ctx);
        const channelCost = input.channelQty * rates.costPerChannel;
        const virtualNumberCost = input.virtualNumberQty * VIRTUAL_NUMBER_COST;
        const callCost = input.expectedMonthlyCalls * getCallTierRate(input.expectedMonthlyCalls);
        const subtotal = channelCost + virtualNumberCost + callCost;
        const gst = Math.round(subtotal * GST_RATE * 100) / 100;
        const grandTotal = Math.round((subtotal + gst) * 100) / 100;
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + 30);
        const quote = await this.quoteRepo.create(ctx.companyId, {
            channelQty: input.channelQty,
            virtualNumberQty: input.virtualNumberQty,
            expectedMonthlyCalls: input.expectedMonthlyCalls,
            channelCost,
            virtualNumberCost,
            callCost,
            subtotal,
            gst,
            grandTotal,
            currency: rates.currency,
            expiresAt,
        });
        return mapQuote(quote);
    }
    async listQuotes(ctx) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.BILLING_READ);
        const quotes = await this.quoteRepo.findMany(ctx.companyId);
        return quotes.map(mapQuote);
    }
    async purchaseQuote(ctx, quoteId) {
        tenant_service_1.tenantService.requirePermission(ctx, permissions_1.PERMISSIONS.BILLING_WRITE);
        const quote = await this.quoteRepo.findById(ctx.companyId, quoteId);
        if (!quote) {
            throw new errors_1.NotFoundError("Quote not found");
        }
        if (quote.status === "PURCHASED") {
            throw new errors_1.ValidationError("Quote has already been purchased.");
        }
        if (quote.expiresAt && quote.expiresAt < new Date()) {
            await this.quoteRepo.updateStatus(ctx.companyId, quoteId, {
                status: "EXPIRED",
            });
            throw new errors_1.ValidationError("Quote has expired.");
        }
        const subscription = (await this.repo.getSubscription(ctx.companyId)) ??
            (await prisma_1.default.billingSubscription.create({
                data: {
                    companyId: ctx.companyId,
                    planId: "resource-purchase",
                    planName: "Resource Purchase",
                    status: "ACTIVE",
                    currentPeriodStart: new Date(),
                    currentPeriodEnd: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000),
                },
            }));
        const invoice = await prisma_1.default.billingInvoice.create({
            data: {
                companyId: ctx.companyId,
                subscriptionId: subscription.id,
                amountCents: Math.round(quote.grandTotal * 100),
                currency: quote.currency,
                status: "PAID",
                description: `Resource purchase quote ${quote.id}`,
                issuedAt: new Date(),
                paidAt: new Date(),
            },
        });
        if (quote.channelQty > 0) {
            const existing = await this.setupRepo.getSetupConfig(ctx.companyId);
            await this.setupRepo.upsertSetupConfig(ctx.companyId, {
                totalChannels: (existing?.totalChannels ?? 0) + quote.channelQty,
            });
        }
        const rates = await this.getRates(ctx);
        const creditsToAdd = Math.max(0, Math.round(quote.grandTotal / rates.costPerCredit));
        if (creditsToAdd > 0) {
            await credits_service_1.creditsService.adjustCredits(ctx, creditsToAdd, `Purchase from quote ${quote.id}`);
        }
        await this.quoteRepo.updateStatus(ctx.companyId, quoteId, {
            status: "PURCHASED",
            purchasedAt: new Date(),
            invoiceId: invoice.id,
        });
        const updated = await this.quoteRepo.findById(ctx.companyId, quoteId);
        return {
            quote: mapQuote(updated),
            invoice: {
                id: invoice.id,
                amountCents: invoice.amountCents,
                currency: invoice.currency,
                status: invoice.status,
                issuedAt: invoice.issuedAt.toISOString(),
            },
        };
    }
}
exports.BillingService = BillingService;
exports.billingService = new BillingService();
//# sourceMappingURL=billing.service.js.map