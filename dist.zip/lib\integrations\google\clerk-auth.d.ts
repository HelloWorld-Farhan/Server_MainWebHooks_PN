export type ClerkGoogleToken = {
    accessToken: string;
    scopes: string[];
    expiresAt: number | null;
};
export declare function getClerkGoogleAccessToken(clerkUserId: string): Promise<ClerkGoogleToken | null>;
export declare function hasRequiredGoogleScopes(scopes: string[]): boolean;
export declare function getClerkGoogleEmail(clerkUserId: string): Promise<string | null>;
export declare function userHasGoogleAccount(clerkUserId: string): Promise<boolean>;
