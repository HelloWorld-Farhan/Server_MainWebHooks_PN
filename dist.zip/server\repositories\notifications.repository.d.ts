import type { IntegrationType } from "@prisma/client";
import { BaseRepository } from "./base.repository";
export declare class NotificationsRepository extends BaseRepository {
    listForUser(companyId: string, userId: string, limit: number, after?: string): import("@prisma/client").Prisma.PrismaPromise<{
        userId: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        type: import("@prisma/client").$Enums.NotificationType;
        title: string;
        body: string;
        readAt: Date | null;
        data: import("@prisma/client/runtime/library").JsonValue;
    }[]>;
}
export declare class IntegrationsRepository extends BaseRepository {
    findAll(companyId: string): import("@prisma/client").Prisma.PrismaPromise<{
        status: import("@prisma/client").$Enums.IntegrationStatus;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        type: import("@prisma/client").$Enums.IntegrationType;
        connectedAccount: string | null;
        config: import("@prisma/client/runtime/library").JsonValue;
        credentialsRef: string | null;
        lastSyncAt: Date | null;
        errorMessage: string | null;
    }[]>;
    findByType(companyId: string, type: IntegrationType): import("@prisma/client").Prisma.Prisma__IntegrationClient<{
        status: import("@prisma/client").$Enums.IntegrationStatus;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        type: import("@prisma/client").$Enums.IntegrationType;
        connectedAccount: string | null;
        config: import("@prisma/client/runtime/library").JsonValue;
        credentialsRef: string | null;
        lastSyncAt: Date | null;
        errorMessage: string | null;
    } | null, null, import("@prisma/client/runtime/library").DefaultArgs, import("@prisma/client").Prisma.PrismaClientOptions>;
}
export declare class SchedulerRepository extends BaseRepository {
    listUpcoming(companyId: string, limit: number, leadBranchIds?: string[]): import("@prisma/client").Prisma.PrismaPromise<{
        status: import("@prisma/client").$Enums.SchedulerEventStatus;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        type: import("@prisma/client").$Enums.SchedulerEventType;
        assignedUserId: string | null;
        description: string | null;
        leadId: string | null;
        title: string;
        startAt: Date;
        endAt: Date | null;
        timezone: string;
        externalCalendarId: string | null;
        externalEventId: string | null;
        reminderAt: Date | null;
        metadata: import("@prisma/client/runtime/library").JsonValue;
    }[]>;
}
