export declare class AppError extends Error {
    readonly code: string;
    readonly statusCode: number;
    constructor(message: string, code: string, statusCode?: number);
}
export declare class UnauthorizedError extends AppError {
    constructor(message?: string);
}
export declare class ForbiddenError extends AppError {
    constructor(message?: string);
}
export declare class NotFoundError extends AppError {
    constructor(message?: string);
}
export declare class ContractNotFoundError extends AppError {
    constructor(message?: string);
}
export declare class ValidationError extends AppError {
    constructor(message?: string);
}
export declare class ConflictError extends AppError {
    constructor(message?: string);
}
export declare class InvalidApiKeyError extends AppError {
    constructor(message?: string);
}
export declare class InvalidApiKeyFormatError extends AppError {
    constructor(message?: string);
}
export declare class ApiKeyNotFoundError extends AppError {
    constructor(message?: string);
}
export declare class ApiKeyDisabledError extends AppError {
    constructor(message?: string);
}
export declare class ApiKeyExpiredError extends AppError {
    constructor(message?: string);
}
export declare class MissingScopeError extends AppError {
    constructor(scope: string);
}
export declare class MissingCampaignAccessError extends AppError {
    constructor(message?: string);
}
export declare class InvalidScopeError extends AppError {
    constructor(scope: string);
}
export declare class InvalidCampaignError extends AppError {
    constructor(message?: string);
}
export declare class DuplicateApiKeyNameError extends AppError {
    constructor(message?: string);
}
export declare function isAppError(error: unknown): error is AppError;
