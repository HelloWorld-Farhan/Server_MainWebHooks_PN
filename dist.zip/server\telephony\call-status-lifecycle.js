"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isTerminalCallStatus = isTerminalCallStatus;
exports.canTransitionCallStatus = canTransitionCallStatus;
exports.isProviderCompletedStatus = isProviderCompletedStatus;
const TERMINAL_STATUSES = new Set([
    "COMPLETED",
    "FAILED",
    "BUSY",
    "NO_ANSWER",
    "CANCELLED",
    "MISSED",
    "VOICEMAIL",
]);
const STATUS_RANK = {
    PENDING: 0,
    QUEUED: 1,
    DISPATCHING: 2,
    QUEUED_AT_PROVIDER: 3,
    RINGING: 4,
    ANSWERED: 5,
    COMPLETED: 100,
    FAILED: 100,
    BUSY: 100,
    NO_ANSWER: 100,
    CANCELLED: 100,
    MISSED: 100,
    VOICEMAIL: 100,
};
function isTerminalCallStatus(status) {
    return TERMINAL_STATUSES.has(status);
}
function canTransitionCallStatus(from, to) {
    if (from === to) {
        return true;
    }
    if (isTerminalCallStatus(from)) {
        return false;
    }
    return STATUS_RANK[to] >= STATUS_RANK[from];
}
function isProviderCompletedStatus(status) {
    return (status === "COMPLETED" ||
        status === "FAILED" ||
        status === "BUSY" ||
        status === "NO_ANSWER" ||
        status === "CANCELLED");
}
//# sourceMappingURL=call-status-lifecycle.js.map