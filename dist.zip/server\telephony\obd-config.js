"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_OBD_SERVICE_NUMBERS = void 0;
exports.getObdServiceNumbers = getObdServiceNumbers;
exports.getDefaultObdServiceNo = getDefaultObdServiceNo;
exports.getObdConfig = getObdConfig;
exports.assertObdDispatchConfig = assertObdDispatchConfig;
exports.resolveWebhookApiKey = resolveWebhookApiKey;
exports.DEFAULT_OBD_SERVICE_NUMBERS = [
    "7971502709",
    "7971501524",
    "7971502635",
];
function getObdServiceNumbers() {
    return [...exports.DEFAULT_OBD_SERVICE_NUMBERS];
}
function getDefaultObdServiceNo() {
    return getObdServiceNumbers()[0] ?? "";
}
function resolveDefaultServiceNo() {
    return getDefaultObdServiceNo();
}
function parsePositiveInt(value, fallback) {
    if (!value) {
        return fallback;
    }
    const parsed = Number.parseInt(value, 10);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}
function getObdConfig() {
    return {
        baseUrl: (process.env.OBD_BASE_URL ?? "").trim().replace(/\/$/, ""),
        apiKey: (process.env.OBD_API_KEY ?? "").trim(),
        webhookUrl: (process.env.OBD_WEBHOOK_URL ?? "").trim() || null,
        timeoutMs: parsePositiveInt(process.env.OBD_TIMEOUT_MS, 30_000),
        maxRetries: parsePositiveInt(process.env.OBD_MAX_RETRIES, 2),
        webhookSecret: (process.env.OBD_WEBHOOK_SECRET ?? "").trim() || null,
        serviceNo: resolveDefaultServiceNo(),
        voiceFile: (process.env.OBD_VOICE_FILE ?? "").trim(),
        ivrTemplateId: (process.env.OBD_IVR_TEMPLATE_ID ?? "179").trim(),
        retryAttempts: (process.env.OBD_RETRY_ATTEMPTS ?? "0").trim(),
        retryDuration: (process.env.OBD_RETRY_DURATION ?? "15").trim(),
        sourceType: (process.env.OBD_SOURCE_TYPE ?? "1").trim(),
        campaignType: (process.env.OBD_CAMPAIGN_TYPE ?? "4").trim(),
        fileType: (process.env.OBD_FILE_TYPE ?? "2").trim(),
        sendNow: (process.env.OBD_SEND_NOW ?? "1").trim(),
    };
}
function assertObdDispatchConfig(config) {
    if (!config.baseUrl) {
        throw new Error("OBD_BASE_URL is not configured");
    }
    if (!config.apiKey) {
        throw new Error("OBD_API_KEY is not configured");
    }
    if (!config.serviceNo) {
        throw new Error("No OBD service number is configured");
    }
}
function resolveWebhookApiKey(config) {
    return config.webhookSecret || null;
}
//# sourceMappingURL=obd-config.js.map