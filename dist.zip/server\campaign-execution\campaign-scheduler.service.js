"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.campaignSchedulerService = exports.CampaignSchedulerService = void 0;
const campaign_execution_config_1 = require("./campaign-execution.config");
const campaign_execution_repository_1 = require("./campaign-execution.repository");
const campaign_execution_service_1 = require("./campaign-execution.service");
const campaign_execution_logger_1 = require("./lib/campaign-execution-logger");
class CampaignSchedulerService {
    async recoverOnStartup() {
        const now = new Date();
        const stale = await campaign_execution_repository_1.campaignExecutionRepository.findStaleRunningLocks(now);
        for (const execution of stale) {
            (0, campaign_execution_logger_1.logCampaignExecutionEvent)("worker:restart", {
                campaignId: execution.campaignId,
                correlationId: execution.correlationId ?? undefined,
            });
        }
        await this.processDueScheduled();
    }
    async processDueScheduled() {
        const now = new Date();
        const runningCount = await campaign_execution_repository_1.campaignExecutionRepository.countRunning();
        const availableSlots = Math.max(0, campaign_execution_config_1.campaignExecutionConfig.maxConcurrentCampaigns - runningCount);
        if (availableSlots === 0) {
            return 0;
        }
        const due = await campaign_execution_repository_1.campaignExecutionRepository.findDueScheduled(availableSlots, now);
        let started = 0;
        for (const execution of due) {
            const promoted = await campaign_execution_service_1.campaignExecutionService.promoteScheduledToRunning(execution.id);
            if (promoted) {
                started += 1;
            }
        }
        return started;
    }
}
exports.CampaignSchedulerService = CampaignSchedulerService;
exports.campaignSchedulerService = new CampaignSchedulerService();
//# sourceMappingURL=campaign-scheduler.service.js.map