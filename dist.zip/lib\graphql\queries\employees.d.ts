export type UserRole = "OWNER" | "ADMIN" | "MANAGER" | "AGENT" | "SALES" | "SUPPORT";
export type MemberStatus = "ACTIVE" | "INVITED" | "DEACTIVATED" | "REMOVED";
export type CampaignAccessType = "ALL" | "SELECTED";
export type EmployeeCampaignNode = {
    id: string;
    name: string;
    status: string;
};
export type InvitationDisplayStatus = "PENDING" | "ACCEPTED" | "EXPIRED";
export type EmployeeNode = {
    id: string;
    userId: string;
    name: string;
    email: string;
    phone: string | null;
    imageUrl: string | null;
    jobTitle: string | null;
    role: UserRole;
    campaignAccessType: CampaignAccessType;
    assignedCampaigns: EmployeeCampaignNode[];
    status: MemberStatus;
    invitationStatus: InvitationDisplayStatus;
    lastActiveAt: string | null;
    invitedAt: string | null;
    joinedAt: string | null;
    createdAt: string;
    updatedAt: string;
};
export type EmployeesConnectionResult = {
    employees: {
        connection: {
            edges: {
                node: EmployeeNode;
                cursor: string;
            }[];
            pageInfo: {
                hasNextPage: boolean;
                endCursor: string | null;
            };
            totalCount: number;
        };
    };
};
export type EmployeeDetailResult = {
    employees: {
        byId: EmployeeNode | null;
        permissionsForRole: string[];
    };
};
export declare const EMPLOYEES_PAGE_QUERY = "\n  query EmployeesPage($first: Int, $after: String, $filter: EmployeeFilter) {\n    employees {\n      connection(first: $first, after: $after, filter: $filter) {\n        edges {\n          node {\n  id\n  userId\n  name\n  email\n  phone\n  imageUrl\n  jobTitle\n  role\n  campaignAccessType\n  assignedCampaigns {\n    id\n    name\n    status\n  }\n  status\n  invitationStatus\n  lastActiveAt\n  invitedAt\n  joinedAt\n  createdAt\n  updatedAt\n}\n          cursor\n        }\n        pageInfo {\n          hasNextPage\n          endCursor\n        }\n        totalCount\n      }\n    }\n  }\n";
export declare const EMPLOYEE_DETAIL_QUERY = "\n  query EmployeeDetail($id: ID!, $role: UserRole!) {\n    employees {\n      byId(id: $id) {\n  id\n  userId\n  name\n  email\n  phone\n  imageUrl\n  jobTitle\n  role\n  campaignAccessType\n  assignedCampaigns {\n    id\n    name\n    status\n  }\n  status\n  invitationStatus\n  lastActiveAt\n  invitedAt\n  joinedAt\n  createdAt\n  updatedAt\n}\n      permissionsForRole(role: $role)\n    }\n  }\n";
export declare const INVITE_EMPLOYEE_MUTATION = "\n  mutation InviteEmployee($input: InviteEmployeeInput!) {\n    employees {\n      invite(input: $input) {\n  id\n  userId\n  name\n  email\n  phone\n  imageUrl\n  jobTitle\n  role\n  campaignAccessType\n  assignedCampaigns {\n    id\n    name\n    status\n  }\n  status\n  invitationStatus\n  lastActiveAt\n  invitedAt\n  joinedAt\n  createdAt\n  updatedAt\n}\n    }\n  }\n";
export declare const UPDATE_EMPLOYEE_MUTATION = "\n  mutation UpdateEmployee($id: ID!, $input: UpdateEmployeeInput!) {\n    employees {\n      update(id: $id, input: $input) {\n  id\n  userId\n  name\n  email\n  phone\n  imageUrl\n  jobTitle\n  role\n  campaignAccessType\n  assignedCampaigns {\n    id\n    name\n    status\n  }\n  status\n  invitationStatus\n  lastActiveAt\n  invitedAt\n  joinedAt\n  createdAt\n  updatedAt\n}\n    }\n  }\n";
export declare const DEACTIVATE_EMPLOYEE_MUTATION = "\n  mutation DeactivateEmployee($id: ID!) {\n    employees {\n      deactivate(id: $id) {\n  id\n  userId\n  name\n  email\n  phone\n  imageUrl\n  jobTitle\n  role\n  campaignAccessType\n  assignedCampaigns {\n    id\n    name\n    status\n  }\n  status\n  invitationStatus\n  lastActiveAt\n  invitedAt\n  joinedAt\n  createdAt\n  updatedAt\n}\n    }\n  }\n";
export declare const DELETE_EMPLOYEE_MUTATION = "\n  mutation DeleteEmployee($id: ID!) {\n    employees {\n      delete(id: $id)\n    }\n  }\n";
export declare const RESEND_EMPLOYEE_INVITE_MUTATION = "\n  mutation ResendEmployeeInvite($id: ID!) {\n    employees {\n      resendInvite(id: $id) {\n  id\n  userId\n  name\n  email\n  phone\n  imageUrl\n  jobTitle\n  role\n  campaignAccessType\n  assignedCampaigns {\n    id\n    name\n    status\n  }\n  status\n  invitationStatus\n  lastActiveAt\n  invitedAt\n  joinedAt\n  createdAt\n  updatedAt\n}\n    }\n  }\n";
export declare const CANCEL_EMPLOYEE_INVITE_MUTATION = "\n  mutation CancelEmployeeInvite($id: ID!) {\n    employees {\n      cancelInvite(id: $id)\n    }\n  }\n";
