"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var CompanyController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContactRequestsController = exports.CompanyController = void 0;
const common_1 = require("@nestjs/common");
const zod_1 = require("zod");
const clerk_1 = require("../../auth/clerk");
const http_1 = require("../../lib/api/http");
const tenant_context_1 = require("../../lib/api/tenant-context");
const permissions_1 = require("../../lib/permissions");
const contact_request_handler_1 = require("../contact-requests/contact-request.handler");
const errors_1 = require("../../server/lib/errors");
const prisma_1 = __importDefault(require("../../server/lib/prisma"));
const tenant_repository_1 = require("../../server/repositories/tenant.repository");
const clerk_provision_service_1 = require("../../server/services/clerk-provision.service");
const company_service_1 = require("../../server/services/company.service");
const contract_service_1 = require("../../server/services/contract.service");
const tenantRepo = new tenant_repository_1.TenantRepository(prisma_1.default);
const contactSchema = zod_1.z.object({
    name: zod_1.z.string().min(1, "Name is required"),
    email: zod_1.z.string().email("Valid email is required"),
    phone: zod_1.z.string().optional(),
    title: zod_1.z.string().optional(),
});
const linkSchema = zod_1.z.object({
    contractId: zod_1.z.string().min(1, "Contract ID is required"),
});
let CompanyController = CompanyController_1 = class CompanyController {
    logger = new common_1.Logger(CompanyController_1.name);
    async getContact(req, res) {
        const result = await (0, tenant_context_1.requireTenantContext)(req);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        try {
            const contact = await company_service_1.companyService.getContact(result.ctx);
            return res.json({ contact });
        }
        catch (err) {
            if ((0, errors_1.isAppError)(err)) {
                return res.status(err.statusCode).json({ error: err.message });
            }
            return res.status(500).json({ error: "Internal server error" });
        }
    }
    async putContact(req, res) {
        const result = await (0, tenant_context_1.requireTenantPermission)(req, permissions_1.PERMISSIONS.SETTINGS_WRITE);
        if (!(0, http_1.handleTenantResult)(res, result) || !result.ctx)
            return;
        try {
            const body = contactSchema.parse(req.body);
            const contact = await company_service_1.companyService.upsertContact(result.ctx, {
                name: body.name.trim(),
                email: body.email.trim(),
                phone: body.phone?.trim() || undefined,
                title: body.title?.trim() || undefined,
            });
            return res.json({ contact });
        }
        catch (err) {
            if (err instanceof zod_1.z.ZodError) {
                return res
                    .status(400)
                    .json({ error: err.issues[0]?.message ?? err.message });
            }
            if ((0, errors_1.isAppError)(err)) {
                return res.status(err.statusCode).json({ error: err.message });
            }
            return res.status(500).json({ error: "Internal server error" });
        }
    }
    async getContract(req, res) {
        const { userId, orgId } = await (0, clerk_1.getAuthFromRequest)(req);
        if (!userId) {
            return res.status(401).json({ error: "Unauthorized" });
        }
        try {
            const dbUser = await tenantRepo.findUserByClerkId(userId);
            if (dbUser) {
                const invitedMembership = await prisma_1.default.companyMember.findFirst({
                    where: { userId: dbUser.id, status: "INVITED" },
                });
                const pendingCampaignInvite = await prisma_1.default.campaignInvitation.findFirst({
                    where: {
                        email: { equals: dbUser.email, mode: "insensitive" },
                        status: "PENDING",
                    },
                });
                if (invitedMembership || pendingCampaignInvite) {
                    await (0, clerk_provision_service_1.reconcileInviteMembershipOnLogin)(userId, orgId);
                }
            }
            const status = await contract_service_1.contractService.getContractLinkStatus(userId);
            return res.json(status);
        }
        catch (err) {
            if ((0, errors_1.isAppError)(err)) {
                return (0, http_1.sendAppErrorResponse)(res, err);
            }
            this.logger.error(`GET /api/company/contract failed: ${err instanceof Error ? err.stack ?? err.message : String(err)}`);
            return res.status(500).json({ error: "Internal server error" });
        }
    }
    async linkContract(req, res) {
        const { userId } = await (0, clerk_1.getAuthFromRequest)(req);
        if (!userId) {
            return res.status(401).json({ error: "Unauthorized" });
        }
        try {
            const body = linkSchema.parse(req.body);
            const result = await contract_service_1.contractService.linkContractId(userId, body.contractId);
            return res.json(result);
        }
        catch (err) {
            if (err instanceof zod_1.z.ZodError) {
                return res
                    .status(400)
                    .json({ error: err.issues[0]?.message ?? err.message });
            }
            if ((0, errors_1.isAppError)(err)) {
                return (0, http_1.sendAppErrorResponse)(res, err);
            }
            this.logger.error(`POST /api/company/contract/link failed: ${err instanceof Error ? err.stack ?? err.message : String(err)}`);
            return res.status(500).json({ error: "Internal server error" });
        }
    }
};
exports.CompanyController = CompanyController;
__decorate([
    (0, common_1.Get)("contact"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], CompanyController.prototype, "getContact", null);
__decorate([
    (0, common_1.Put)("contact"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], CompanyController.prototype, "putContact", null);
__decorate([
    (0, common_1.Get)("contract"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], CompanyController.prototype, "getContract", null);
__decorate([
    (0, common_1.Post)("contract/link"),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], CompanyController.prototype, "linkContract", null);
exports.CompanyController = CompanyController = CompanyController_1 = __decorate([
    (0, common_1.Controller)("api/company")
], CompanyController);
let ContactRequestsController = class ContactRequestsController {
    async submit(req, res) {
        const result = await (0, contact_request_handler_1.submitContactRequest)(req);
        if (!result.success) {
            return res.status(400).json({ error: result.error });
        }
        return res.json(result);
    }
};
exports.ContactRequestsController = ContactRequestsController;
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], ContactRequestsController.prototype, "submit", null);
exports.ContactRequestsController = ContactRequestsController = __decorate([
    (0, common_1.Controller)("api/contact-requests")
], ContactRequestsController);
//# sourceMappingURL=company.controller.js.map