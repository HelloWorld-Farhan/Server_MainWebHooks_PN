import type { Prisma } from "@prisma/client";
import type { TenantContext } from "../types/context";
import type { IntegrationId } from "../../lib/integrations/types";
import type { AgentToolId } from "../../lib/tools/types";
export declare class IntegrationsManagementService {
    private readonly repo;
    list(ctx: TenantContext): Promise<{
        id: string;
        type: import("@prisma/client").$Enums.IntegrationType;
        status: "error" | "connected" | "not_connected" | "syncing";
        connectedAccount: string | null;
        config: Prisma.JsonValue;
        lastSyncAt: string | null;
        errorMessage: string | null;
    }[]>;
    getByType(ctx: TenantContext, integrationId: IntegrationId): Promise<{
        id: IntegrationId;
        type: import("@prisma/client").$Enums.IntegrationType;
        status: "error" | "connected" | "not_connected" | "syncing";
        connectedAccount: string | null;
        config: Prisma.JsonValue;
        lastSyncAt: string | null;
        errorMessage: string | null;
    } | null>;
    connect(ctx: TenantContext, integrationId: IntegrationId, account?: string): Promise<{
        id: IntegrationId;
        status: "error" | "connected" | "not_connected" | "syncing";
        connectedAccount: string | null;
        lastSyncAt: string | null;
    }>;
    disconnect(ctx: TenantContext, integrationId: IntegrationId): Promise<{
        id: IntegrationId;
        status: "error" | "connected" | "not_connected" | "syncing";
    }>;
    updateConfig(ctx: TenantContext, integrationId: IntegrationId, config: Record<string, unknown>): Promise<Prisma.JsonValue>;
    getAgentTools(ctx: TenantContext, agentId: string): Promise<{
        toolId: AgentToolId;
        enabled: boolean;
        config: Prisma.JsonValue;
        usage: Prisma.JsonValue;
    }[]>;
    updateAgentTool(ctx: TenantContext, agentId: string, toolId: AgentToolId, data: {
        enabled?: boolean;
        config?: Record<string, unknown>;
    }): Promise<{
        toolId: AgentToolId;
        enabled: boolean;
        config: Prisma.JsonValue;
        usage: Prisma.JsonValue;
    }>;
}
export declare const integrationsManagementService: IntegrationsManagementService;
