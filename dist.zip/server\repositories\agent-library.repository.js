"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.agentLibraryRepository = exports.AgentLibraryRepository = void 0;
const prisma_1 = __importDefault(require("../lib/prisma"));
class AgentLibraryRepository {
    findMany() {
        return prisma_1.default.agentLibraryEntry.findMany({
            where: { isPublished: true },
            orderBy: { sortOrder: "asc" },
        });
    }
    findBySlug(slug) {
        return prisma_1.default.agentLibraryEntry.findUnique({
            where: { slug },
        });
    }
    upsertBySlug(data) {
        const { slug, ...rest } = data;
        return prisma_1.default.agentLibraryEntry.upsert({
            where: { slug },
            create: { slug, ...rest },
            update: rest,
        });
    }
}
exports.AgentLibraryRepository = AgentLibraryRepository;
exports.agentLibraryRepository = new AgentLibraryRepository();
//# sourceMappingURL=agent-library.repository.js.map