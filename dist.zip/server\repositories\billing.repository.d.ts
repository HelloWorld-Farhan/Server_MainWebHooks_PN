import type { AnalyticsGranularity } from "@prisma/client";
import { BaseRepository } from "./base.repository";
export declare class BillingRepository extends BaseRepository {
    getSubscription(companyId: string): import("@prisma/client").Prisma.Prisma__BillingSubscriptionClient<{
        status: import("@prisma/client").$Enums.BillingStatus;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        planId: string;
        planName: string;
        stripeCustomerId: string | null;
        stripeSubscriptionId: string | null;
        currentPeriodStart: Date;
        currentPeriodEnd: Date;
        cancelAtPeriodEnd: boolean;
    } | null, null, import("@prisma/client/runtime/library").DefaultArgs, import("@prisma/client").Prisma.PrismaClientOptions>;
    listInvoices(companyId: string, limit: number, after?: string): import("@prisma/client").Prisma.PrismaPromise<{
        status: import("@prisma/client").$Enums.InvoiceStatus;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        externalId: string | null;
        description: string | null;
        subscriptionId: string;
        amountCents: number;
        currency: string;
        issuedAt: Date;
        dueAt: Date | null;
        paidAt: Date | null;
    }[]>;
}
export declare class AnalyticsRepository extends BaseRepository {
    getLatestSnapshot(companyId: string, granularity: AnalyticsGranularity): import("@prisma/client").Prisma.Prisma__AnalyticsSnapshotClient<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        granularity: import("@prisma/client").$Enums.AnalyticsGranularity;
        periodStart: Date;
        periodEnd: Date;
        scope: import("@prisma/client").$Enums.AnalyticsScope;
        scopeId: string;
        metrics: import("@prisma/client/runtime/library").JsonValue;
        leadBreakdown: import("@prisma/client/runtime/library").JsonValue;
        agentPerformance: import("@prisma/client/runtime/library").JsonValue;
    } | null, null, import("@prisma/client/runtime/library").DefaultArgs, import("@prisma/client").Prisma.PrismaClientOptions>;
    upsertDailySnapshot(companyId: string, periodStart: Date, periodEnd: Date, metricsDelta: Record<string, number>): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        companyId: string;
        granularity: import("@prisma/client").$Enums.AnalyticsGranularity;
        periodStart: Date;
        periodEnd: Date;
        scope: import("@prisma/client").$Enums.AnalyticsScope;
        scopeId: string;
        metrics: import("@prisma/client/runtime/library").JsonValue;
        leadBreakdown: import("@prisma/client/runtime/library").JsonValue;
        agentPerformance: import("@prisma/client/runtime/library").JsonValue;
    }>;
}
