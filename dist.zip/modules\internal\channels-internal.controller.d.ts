import type { Request, Response } from "express";
export declare class ChannelsInternalController {
    metrics(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    companyStatus(req: Request, companyId: string, res: Response): Promise<Response<any, Record<string, any>>>;
}
