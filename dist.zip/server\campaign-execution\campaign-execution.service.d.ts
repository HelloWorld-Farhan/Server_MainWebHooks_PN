import type { CampaignExecutionProgress, CampaignExecutionStatistics, CampaignExecutionView, CampaignRetryPolicyInput, CampaignRetryPolicyView } from "./campaign-execution.types";
import { type CampaignRetryStatistics, type CampaignRetrySummary, type ContactRetryHistoryEntry } from "./retry/retry-statistics.service";
import type { TenantContext } from "../types/context";
export declare class CampaignExecutionService {
    private readonly campaignsRepo;
    private resolveCampaign;
    private getOrCreateExecution;
    private loadExecutionView;
    private writeActivity;
    getStatus(ctx: TenantContext, campaignPublicId: string): Promise<CampaignExecutionView>;
    getStatistics(ctx: TenantContext, campaignPublicId: string): Promise<CampaignExecutionStatistics>;
    getProgress(ctx: TenantContext, campaignPublicId: string): Promise<CampaignExecutionProgress>;
    schedule(ctx: TenantContext, campaignPublicId: string, scheduledAtInput: string): Promise<CampaignExecutionView>;
    start(ctx: TenantContext, campaignPublicId: string, scheduledAtInput?: string | null): Promise<CampaignExecutionView>;
    pause(ctx: TenantContext, campaignPublicId: string): Promise<CampaignExecutionView>;
    resume(ctx: TenantContext, campaignPublicId: string): Promise<CampaignExecutionView>;
    reset(ctx: TenantContext, campaignPublicId: string): Promise<CampaignExecutionView>;
    retry(ctx: TenantContext, campaignPublicId: string): Promise<CampaignExecutionView>;
    cancel(ctx: TenantContext, campaignPublicId: string): Promise<CampaignExecutionView>;
    promoteScheduledToRunning(executionId: string): Promise<boolean>;
    getRetryPolicy(ctx: TenantContext, campaignPublicId: string): Promise<CampaignRetryPolicyView>;
    updateRetryPolicy(ctx: TenantContext, campaignPublicId: string, input: CampaignRetryPolicyInput): Promise<CampaignRetryPolicyView>;
    getRetryHistory(ctx: TenantContext, campaignPublicId: string, phoneNumber?: string): Promise<ContactRetryHistoryEntry[]>;
    getPendingRetries(ctx: TenantContext, campaignPublicId: string): Promise<{
        id: string;
        phoneNumber: string;
        retryNumber: number;
        retryReason: import("@prisma/client").$Enums.CallStatus;
        scheduledAt: string;
        status: import("@prisma/client").$Enums.ContactRetryJobStatus;
        correlationId: string | null;
    }[]>;
    getRetryStatistics(ctx: TenantContext, campaignPublicId: string): Promise<CampaignRetryStatistics>;
    getRetrySummary(ctx: TenantContext, campaignPublicId: string): Promise<CampaignRetrySummary>;
    markCompleted(companyId: string, campaignId: string): Promise<void>;
    markFailed(companyId: string, campaignId: string, failureReason: string): Promise<void>;
    isRunning(companyId: string, campaignId: string): Promise<boolean>;
}
export declare const campaignExecutionService: CampaignExecutionService;
