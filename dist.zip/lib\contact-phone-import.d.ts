export type ParsedContactRecord = {
    phone: string;
    field1: string | null;
    field2: string | null;
    field3: string | null;
    campaignNames: string[];
};
export type ParsedPhoneImport = {
    contacts: ParsedContactRecord[];
    invalid: number;
};
export type ParsePhonesOptions = {
    defaultCountry?: string;
};
export declare const CONTACT_PHONE_UPLOAD_EXTENSIONS: readonly [".csv", ".xlsx", ".xls", ".pdf", ".docx"];
export declare function getContactPhoneUploadExtension(filename: string): string | null;
export declare function isSupportedContactPhoneUpload(filename: string): boolean;
export declare function parsePhonesFromStructuredRows(headers: string[], rows: string[][], options?: ParsePhonesOptions): ParsedPhoneImport;
export declare function parsePhonesFromCsv(text: string, options?: ParsePhonesOptions): ParsedPhoneImport;
export declare function parsePhonesFromUploadFile(file: File, options?: ParsePhonesOptions): Promise<ParsedPhoneImport>;
export declare const CONTACT_PHONES_SAMPLE_FILENAME = "propnex-phone-contacts-sample.csv";
export declare const CONTACT_PHONES_SAMPLE_CONTENT = "MSISDN,user_name,Recording URL,Transcripts\n9876543210,John Doe,https://example.com/recording/1,\"Hello, this is a sample transcript.\"\n9123456789,Jane Smith,https://example.com/recording/2,\"Another sample transcript.\"\n5551234567,Alex Rivera,,\n7911123456,Maria Chen,https://example.com/recording/3,\"London contact transcript.\"\n";
export declare function downloadContactPhonesSampleCsv(): void;
export declare function contactsToCsv(contacts: {
    phone: string;
}[]): string;
